import app from '../src/app.js';
import { connectDatabase } from '../src/config/database.js';
import User from '../src/models/User.js';
import Facility from '../src/models/Facility.js';
import Patient from '../src/models/Patient.js';
import SyncOperation from '../src/models/SyncOperation.js';
import bcrypt from 'bcryptjs';

/**
 * OFFLINE HEALTH - 20-Point Automated Backend & Synchronization Verification Suite
 */

async function runTests() {
  console.log('===============================================================');
  console.log('  RUNNING 20-POINT BACKEND ARCHITECTURE & SYNC TEST SUITE      ');
  console.log('===============================================================');

  await connectDatabase();

  let passedCount = 0;
  let failedCount = 0;

  function assert(testId, description, condition, details = '') {
    if (condition) {
      console.log(`[PASS] ${testId}: ${description} ${details ? '--> ' + details : ''}`);
      passedCount++;
    } else {
      console.error(`[FAIL] ${testId}: ${description} ${details ? '--> ' + details : ''}`);
      failedCount++;
    }
  }

  let server;
  await new Promise((resolve) => {
    server = app.listen(5099, '127.0.0.1', () => {
      console.log('Test HTTP server listening on http://127.0.0.1:5099');
      resolve();
    });
  });

  // Helper for real HTTP requests against test Express server
  async function request(method, path, body = null, headers = {}) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };
    if (body) {
      options.body = JSON.stringify(body);
    }
    const res = await fetch(`http://127.0.0.1:5099${path}`, options);
    let responseBody = null;
    const text = await res.text();
    try {
      responseBody = JSON.parse(text);
    } catch {
      responseBody = text;
    }
    return { status: res.status, body: responseBody };
  }

  // Clean up any stale records from previous test runs
  await Facility.deleteMany({ id: { $in: ['FAC-RAMPUR-PHC', 'FAC-OTHER-ZONE'] } }).catch(() => {});
  await User.deleteMany({ username: { $in: ['test_admin', 'sunita_asha_test', 'hacker'] } }).catch(() => {});
  await Patient.deleteMany({ id: { $in: ['pat-sync-test-01', 'pat-remote-zone'] } }).catch(() => {});
  await Patient.deleteMany({ patientId: { $in: ['PAT-RAM-9901', 'PAT-SYNC-001', 'PAT-OTHER-001'] } }).catch(() => {});
  await SyncOperation.deleteMany({ idempotencyKey: { $in: ['idemp-key-sync-001', 'idemp-key-conflict-001'] } }).catch(() => {});

  // Pre-seed test facilities and test admin user
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash('offline123', salt);

  await Facility.create({
    id: 'FAC-RAMPUR-PHC',
    facilityId: 'FAC-RAMPUR-PHC',
    name: 'Rampur Primary Health Centre',
    district: 'Mandya'
  });

  await Facility.create({
    id: 'FAC-OTHER-ZONE',
    facilityId: 'FAC-OTHER-ZONE',
    name: 'Remote Mountain Sub-Centre',
    district: 'Shimoga'
  });

  await User.create({
    id: 'test-admin-1',
    username: 'test_admin',
    passwordHash: hash,
    name: 'Dr. Rajesh Sharma',
    role: 'admin',
    facilityId: 'FAC-RAMPUR-PHC',
    status: 'active'
  });

  let adminToken = '';
  let ashaToken = '';
  let refreshToken = '';

  // TEST 1: Database Health Check
  const healthRes = await request('GET', '/api/health');
  assert('TEST-01', 'Database & API Health Endpoint', healthRes.status === 200 && healthRes.body.status === 'healthy', `Engine: ${healthRes.body.database?.engine}`);

  // TEST 2: Admin Login & JWT Issuance
  const loginRes = await request('POST', '/api/auth/login', { username: 'test_admin', password: 'offline123' });
  adminToken = loginRes.body.tokens?.accessToken;
  refreshToken = loginRes.body.tokens?.refreshToken;
  assert('TEST-02', 'User Login & JWT Token Generation', loginRes.status === 200 && Boolean(adminToken), `Token issued for user ${loginRes.body.user?.username}`);

  // TEST 3: Invalid Password Rejection
  const badLogin = await request('POST', '/api/auth/login', { username: 'test_admin', password: 'wrongpassword' });
  assert('TEST-03', 'Invalid Password Authentication Rejection', badLogin.status === 401 && badLogin.body.success === false, 'Correctly returned 401 Unauthorized');

  // TEST 4: Unauthorized Access Rejection (No Token)
  const noAuthRes = await request('GET', '/api/patients');
  assert('TEST-04', 'Missing JWT Token Protection', noAuthRes.status === 401 && noAuthRes.body.success === false, 'Blocked with 401');

  // TEST 5: User Registration by Admin
  const regWorkerRes = await request('POST', '/api/auth/register', {
    username: 'sunita_asha_test',
    password: 'password123',
    name: 'Sunita Devi (ASHA)',
    role: 'asha',
    facilityId: 'FAC-RAMPUR-PHC'
  }, { authorization: `Bearer ${adminToken}` });
  assert('TEST-05', 'Admin User Creation with bcrypt Hashing', regWorkerRes.status === 201 && regWorkerRes.body.user.role === 'asha', `Worker registered: ${regWorkerRes.body.user?.name}`);

  // Log in as ASHA worker
  const ashaLogin = await request('POST', '/api/auth/login', { username: 'sunita_asha_test', password: 'password123' });
  ashaToken = ashaLogin.body.tokens?.accessToken;

  // TEST 6: Role-Based Access Control (RBAC)
  const rbacViolation = await request('POST', '/api/auth/register', {
    username: 'hacker',
    password: '123',
    name: 'Fake User',
    role: 'admin'
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-06', 'RBAC Enforcement (ASHA prohibited from user admin)', rbacViolation.status === 403, 'Blocked with 403 Forbidden');

  // TEST 7: Refresh Token Rotation
  const refreshRes = await request('POST', '/api/auth/refresh-token', { refreshToken });
  assert('TEST-07', 'Secure Refresh Token Rotation', refreshRes.status === 200 && Boolean(refreshRes.body.accessToken), 'Rotated tokens successfully');

  // TEST 8: Patient Registration API
  const patientRes = await request('POST', '/api/patients', {
    patientId: 'PAT-RAM-9901',
    name: 'Kavita Gowda',
    age: 26,
    gender: 'female',
    villageHamlet: 'South Hamlet',
    bloodGroup: 'B+',
    riskLevel: 'high',
    category: 'maternal',
    isPregnant: true
  }, { authorization: `Bearer ${ashaToken}` });
  const createdPatient = patientRes.body.patient;
  assert('TEST-08', 'Patient Registration API (POST /api/patients)', patientRes.status === 201 && createdPatient.name === 'Kavita Gowda', `Assigned ID: ${createdPatient?.patientId}`);

  // TEST 9: Patient Listing & Query API
  const listPatientsRes = await request('GET', '/api/patients?riskLevel=high', null, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-09', 'Patient Listing & Triage Filter API', listPatientsRes.status === 200 && listPatientsRes.body.count > 0, `Returned ${listPatientsRes.body.count} high-risk patients`);

  // TEST 10: Patient Update API with Version Increment
  const updateRes = await request('PUT', `/api/patients/${createdPatient.id}`, { age: 27 }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-10', 'Patient Update API & Versioning', updateRes.status === 200 && updateRes.body.patient.version === 2, `Version incremented to v${updateRes.body.patient?.version}`);

  // TEST 11: Health Assessment API with Warning Signs
  const assessmentRes = await request('POST', '/api/assessments', {
    patientId: createdPatient.id,
    systolicBp: 160,
    diastolicBp: 100,
    pulse: 88,
    spo2: 95,
    warningSigns: ['Severe Gestational Hypertension']
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-11', 'Health Assessment Creation (POST /api/assessments)', assessmentRes.status === 201 && assessmentRes.body.assessment.systolicBp === 160, 'Logged assessment with vital warning signs');

  // TEST 12: Maternal Healthcare Record API
  const maternalRes = await request('POST', '/api/maternal', {
    patientId: createdPatient.id,
    lmp: '2026-04-10',
    edd: '2027-01-17',
    trimester: 3,
    highRiskFactors: ['Pregnancy Induced Hypertension']
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-12', 'Maternal Healthcare Record API', maternalRes.status === 201 && maternalRes.body.maternalRecord.trimester === 3, 'Created maternal ANC record');

  // TEST 13: Child Healthcare Record API
  const childRes = await request('POST', '/api/children', {
    patientId: 'pat-child-01',
    motherId: createdPatient.id,
    birthWeight: 2.8,
    deliveryType: 'Institutional'
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-13', 'Child Healthcare Record API', childRes.status === 201 && childRes.body.childRecord.birthWeight === 2.8, 'Created child wellness record');

  // TEST 14: Emergency Referral API
  const referralRes = await request('POST', '/api/referrals', {
    patientId: createdPatient.id,
    urgency: 'emergency',
    referralFacility: 'Mandya District Hospital',
    reason: 'BP 160/100 mmHg with severe headache'
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-14', 'Emergency Referral Creation API', referralRes.status === 201 && referralRes.body.referral.urgency === 'emergency', 'Dispatched clinical referral');

  // TEST 15: Follow-Up Scheduling API
  const followUpRes = await request('POST', '/api/follow-ups', {
    patientId: createdPatient.id,
    scheduledDate: '2026-11-28',
    visitType: 'PNC Day 3 Newborn Check',
    priority: 'urgent'
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-15', 'Follow-up Scheduling API', followUpRes.status === 201 && followUpRes.body.followUp.priority === 'urgent', 'Scheduled field visit');

  // TEST 16: Two-Way Synchronization Push API (Batch Sync)
  const syncPushRes = await request('POST', '/api/sync/push', {
    operations: [
      {
        entity: 'patients',
        entityId: 'pat-sync-test-01',
        operation: 'CREATE',
        payload: {
          patientId: 'PAT-SYNC-001',
          name: 'Meena Bai',
          age: 32,
          gender: 'female',
          villageHamlet: 'Rampur Hamlet 2',
          facilityId: 'FAC-RAMPUR-PHC',
          version: 1
        },
        idempotencyKey: 'idemp-key-sync-001',
        deviceId: 'DEV-ASHA-TABLET-01',
        version: 1
      }
    ]
  }, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-16', 'Batch Synchronization Push (POST /api/sync/push)', syncPushRes.status === 200 && syncPushRes.body.summary.appliedCount === 1, 'Applied batch operation into server database');

  // TEST 17: Idempotency & Duplicate Operation Prevention
  const dupSyncRes = await request('POST', '/api/sync/push', {
    operations: [
      {
        entity: 'patients',
        entityId: 'pat-sync-test-01',
        operation: 'CREATE',
        payload: {
          patientId: 'PAT-SYNC-001',
          name: 'Meena Bai',
          age: 32,
          gender: 'female',
          villageHamlet: 'Rampur Hamlet 2'
        },
        idempotencyKey: 'idemp-key-sync-001' // Exact same idempotency key
      }
    ]
  }, { authorization: `Bearer ${ashaToken}` });
  const isDuplicateHandled = dupSyncRes.body.applied[0]?.status === 'already_processed';
  assert('TEST-17', 'Idempotency Protection (Zero duplicate database writes)', dupSyncRes.status === 200 && isDuplicateHandled, 'Identified existing idempotency key and returned already_processed');

  // TEST 18: Version Conflict Detection (Zero Silent Overwrites)
  // Server patient is at version 2. Client submits update with stale version 1.
  const conflictSyncRes = await request('POST', '/api/sync/push', {
    operations: [
      {
        entity: 'patients',
        entityId: createdPatient.id,
        operation: 'UPDATE',
        payload: { name: 'Kavita Stale Edit', age: 20 },
        version: 1, // Stale version
        idempotencyKey: 'idemp-key-conflict-001'
      }
    ]
  }, { authorization: `Bearer ${ashaToken}` });
  const hasConflict = conflictSyncRes.body.summary.conflictCount === 1 && conflictSyncRes.body.conflicts.length > 0;
  assert('TEST-18', 'Version Conflict Detection Engine', hasConflict, `Stale version rejected without overwriting: ${conflictSyncRes.body.conflicts[0]?.message}`);

  // TEST 19: Incremental Cursor-Based Synchronization Pull API
  const syncPullRes = await request('GET', '/api/sync/pull?cursor=2026-01-01T00:00:00Z', null, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-19', 'Incremental Synchronization Pull (GET /api/sync/pull)', syncPullRes.status === 200 && syncPullRes.body.count > 0, `Returned ${syncPullRes.body.count} updated records with new cursor`);

  // TEST 20: Facility-Level Data Isolation
  // Create patient in FAC-OTHER-ZONE
  const otherPatient = await Patient.create({
    id: 'pat-remote-zone',
    patientId: 'PAT-OTHER-001',
    name: 'Remote Resident',
    age: 50,
    gender: 'male',
    villageHamlet: 'Mountain Sector',
    facilityId: 'FAC-OTHER-ZONE',
    isDeleted: false
  });

  const foreignAccessRes = await request('GET', `/api/patients/${otherPatient.id}`, null, { authorization: `Bearer ${ashaToken}` });
  assert('TEST-20', 'Facility-Level Clinical Data Isolation', foreignAccessRes.status === 403, 'Correctly denied access with 403: Patient belongs to another facility');

  // TEST 21: AI Document Analysis Endpoint (Auth + Clinical Analysis)
  const docUnauthRes = await request('POST', '/api/documents/analyze', { text: 'Hb: 6.5 g/dL' });
  const docAuthRes = await request('POST', '/api/documents/analyze', {
    text: 'Hb: 6.5 g/dL, BP: 155/98 mmHg',
    documentType: 'lab_report',
    language: 'en',
    findings: [
      { key: 'hemoglobin', label: 'Hemoglobin (Hb)', value: '6.5', unit: 'g/dL', status: 'critical', note: 'Severe Anemia' }
    ]
  }, { authorization: `Bearer ${ashaToken}` });
  assert(
    'TEST-21',
    'AI Document Analysis API (POST /api/documents/analyze)',
    docUnauthRes.status === 401 && docAuthRes.status === 200 && docAuthRes.body.success === true && Boolean(docAuthRes.body.analysis?.summary),
    `Returned summary via ${docAuthRes.body.analysis?.provider}`
  );

  // TEST 22: Hybrid Chatbot Endpoint (Auth + Validation + Safe Response)
  const chatUnauthRes = await request('POST', '/api/assistant/chat', { message: 'What are pregnancy danger signs?' });
  const chatAuthRes = await request('POST', '/api/assistant/chat', {
    message: 'What are pregnancy danger signs?',
    language: 'en'
  }, { authorization: `Bearer ${ashaToken}` });
  assert(
    'TEST-22',
    'AI Chatbot Endpoint (POST /api/assistant/chat)',
    chatUnauthRes.status === 401 && chatAuthRes.status === 200 && chatAuthRes.body.success === true && typeof chatAuthRes.body.reply === 'string',
    'Chatbot endpoint authenticated and returned valid schema'
  );

  if (server) server.close();

  console.log('===============================================================');
  console.log(`  BACKEND TEST SUMMARY: ${passedCount} PASSED, ${failedCount} FAILED    `);
  console.log('===============================================================');

  if (failedCount > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests().catch(err => {
  console.error('[FATAL TEST SUITE ERROR]', err);
  process.exit(1);
});
