import Patient from '../models/Patient.js';
import AuditLog from '../models/AuditLog.js';

export const PatientController = {
  async createPatient(req, res) {
    try {
      const data = req.body;
      if (!data.name || data.age === undefined || !data.villageHamlet) {
        return res.status(400).json({ success: false, error: 'Name, age, and villageHamlet are required' });
      }

      // Facility Isolation: assign user's facility if not admin
      const facilityId = (req.user.role === 'admin' && data.facilityId) ? data.facilityId : req.user.facilityId;

      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const patientId = data.patientId || `PAT-RAM-${randomSuffix}`;
      const id = data.id || `pat-${Date.now()}`;

      const newPatient = await Patient.create({
        ...data,
        id,
        patientId,
        facilityId,
        version: 1,
        isDeleted: false,
        createdBy: req.user.name,
        updatedBy: req.user.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      await AuditLog.create({
        entity: 'patients',
        entityId: newPatient.id,
        action: 'PATIENT_CREATED',
        performedBy: req.user.name,
        role: req.user.role,
        facilityId,
        details: `Registered patient ${newPatient.name} (${newPatient.patientId}) at facility ${facilityId}`
      });

      res.status(201).json({ success: true, patient: newPatient });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getPatients(req, res) {
    try {
      const { search, villageHamlet, riskLevel, category, limit = 50, page = 1 } = req.query;

      // Facility level data isolation
      const filter = { isDeleted: false };
      if (req.user.role !== 'admin') {
        filter.facilityId = req.user.facilityId;
      } else if (req.query.facilityId) {
        filter.facilityId = req.query.facilityId;
      }

      if (villageHamlet && villageHamlet !== 'all') filter.villageHamlet = villageHamlet;
      if (riskLevel && riskLevel !== 'all') filter.riskLevel = riskLevel;
      if (category && category !== 'all') filter.category = category;

      let list = await Patient.find(filter);

      // Search filtering
      if (search) {
        const q = search.toLowerCase();
        list = list.filter(p =>
          (p.name && p.name.toLowerCase().includes(q)) ||
          (p.patientId && p.patientId.toLowerCase().includes(q)) ||
          (p.contactNumber && p.contactNumber.includes(q)) ||
          (p.abhaId && p.abhaId.toLowerCase().includes(q))
        );
      }

      // Sort by recent
      list.sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt));

      res.json({
        success: true,
        count: list.length,
        patients: list.slice((page - 1) * limit, page * limit)
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getPatientById(req, res) {
    try {
      const { id } = req.params;
      let patient = await Patient.findById(id);
      if (!patient) {
        patient = await Patient.findOne({ patientId: id });
      }

      if (!patient) {
        return res.status(404).json({ success: false, error: 'Patient not found' });
      }

      // Check facility isolation
      if (req.user.role !== 'admin' && patient.facilityId !== req.user.facilityId) {
        return res.status(403).json({ success: false, error: 'Access denied: Patient belongs to another facility' });
      }

      res.json({ success: true, patient });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async updatePatient(req, res) {
    try {
      const { id } = req.params;
      const patient = await Patient.findById(id);
      if (!patient) {
        return res.status(404).json({ success: false, error: 'Patient not found' });
      }

      if (req.user.role !== 'admin' && patient.facilityId !== req.user.facilityId) {
        return res.status(403).json({ success: false, error: 'Access denied: Patient belongs to another facility' });
      }

      const newVersion = (patient.version || 1) + 1;
      const updated = await Patient.findOneAndUpdate(
        { id },
        {
          ...req.body,
          version: newVersion,
          updatedBy: req.user.name,
          updatedAt: new Date().toISOString()
        }
      );

      await AuditLog.create({
        entity: 'patients',
        entityId: id,
        action: 'PATIENT_UPDATED',
        performedBy: req.user.name,
        role: req.user.role,
        facilityId: patient.facilityId,
        details: `Updated details for ${patient.name} (${patient.patientId}). Version: ${newVersion}`
      });

      res.json({ success: true, patient: updated });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async deletePatient(req, res) {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      const patient = await Patient.findById(id);
      if (!patient) {
        return res.status(404).json({ success: false, error: 'Patient not found' });
      }

      if (req.user.role !== 'admin' && patient.facilityId !== req.user.facilityId) {
        return res.status(403).json({ success: false, error: 'Access denied' });
      }

      await Patient.updateOne(
        { id },
        {
          isDeleted: true,
          deletionReason: reason || 'Administrative soft delete',
          updatedBy: req.user.name,
          updatedAt: new Date().toISOString()
        }
      );

      await AuditLog.create({
        entity: 'patients',
        entityId: id,
        action: 'PATIENT_SOFT_DELETED',
        performedBy: req.user.name,
        role: req.user.role,
        facilityId: patient.facilityId,
        details: `Soft deleted patient ${patient.name}. Reason: ${reason || 'N/A'}`
      });

      res.json({ success: true, message: 'Patient record soft deleted and tombstone logged' });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};
