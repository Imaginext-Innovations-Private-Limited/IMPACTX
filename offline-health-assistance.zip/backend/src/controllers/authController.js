import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ENV } from '../config/environment.js';
import User from '../models/User.js';
import AuditLog from '../models/AuditLog.js';

function generateTokens(user) {
  const payload = {
    id: user.id,
    username: user.username,
    role: user.role,
    facilityId: user.facilityId
  };

  const accessToken = jwt.sign(payload, ENV.JWT_ACCESS_SECRET, {
    expiresIn: ENV.JWT_ACCESS_EXPIRY
  });

  const refreshToken = jwt.sign({ id: user.id }, ENV.JWT_REFRESH_SECRET, {
    expiresIn: ENV.JWT_REFRESH_EXPIRY
  });

  return { accessToken, refreshToken };
}

export const AuthController = {
  async login(req, res) {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Username and password required' });
      }

      const user = await User.findOne({ username });
      if (!user) {
        return res.status(401).json({ success: false, error: 'Invalid username or password' });
      }

      if (user.status !== 'active') {
        return res.status(403).json({ success: false, error: 'Account has been suspended' });
      }

      const isMatch = await bcrypt.compare(password, user.passwordHash);
      if (!isMatch) {
        return res.status(401).json({ success: false, error: 'Invalid username or password' });
      }

      const { accessToken, refreshToken } = generateTokens(user);

      // Save refresh token for rotation
      const tokens = user.refreshTokens || [];
      tokens.push(refreshToken);
      await User.updateOne({ id: user.id }, { refreshTokens: tokens.slice(-5) }); // Keep last 5

      // Audit login
      await AuditLog.create({
        entity: 'auth',
        entityId: user.id,
        action: 'USER_LOGIN',
        performedBy: user.username,
        role: user.role,
        facilityId: user.facilityId,
        details: `Successful login from IP: ${req.ip}`
      });

      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          role: user.role,
          facilityId: user.facilityId,
          village: user.village,
          district: user.district
        },
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: ENV.JWT_ACCESS_EXPIRY
        }
      });
    } catch (err) {
      console.error('[Auth Error]', err);
      res.status(500).json({ success: false, error: 'Authentication failed' });
    }
  },

  async refreshToken(req, res) {
    try {
      const { refreshToken } = req.body;
      if (!refreshToken) {
        return res.status(400).json({ success: false, error: 'Refresh token required' });
      }

      let decoded;
      try {
        decoded = jwt.verify(refreshToken, ENV.JWT_REFRESH_SECRET);
      } catch (err) {
        return res.status(401).json({ success: false, error: 'Invalid or expired refresh token' });
      }

      const user = await User.findById(decoded.id);
      if (!user || !user.refreshTokens?.includes(refreshToken)) {
        // Token reuse or revocation detected
        return res.status(401).json({ success: false, error: 'Refresh token revoked' });
      }

      // Rotate token: Remove old refresh token and issue new pair
      const remainingTokens = user.refreshTokens.filter(t => t !== refreshToken);
      const newTokens = generateTokens(user);
      remainingTokens.push(newTokens.refreshToken);

      await User.updateOne({ id: user.id }, { refreshTokens: remainingTokens });

      res.json({
        success: true,
        accessToken: newTokens.accessToken,
        refreshToken: newTokens.refreshToken
      });
    } catch (err) {
      res.status(500).json({ success: false, error: 'Token refresh error' });
    }
  },

  async logout(req, res) {
    try {
      const { refreshToken } = req.body;
      if (req.user && refreshToken) {
        const user = await User.findById(req.user.id);
        if (user) {
          const remaining = (user.refreshTokens || []).filter(t => t !== refreshToken);
          await User.updateOne({ id: user.id }, { refreshTokens: remaining });
        }
      }
      res.json({ success: true, message: 'Logged out successfully' });
    } catch (err) {
      res.status(500).json({ success: false, error: 'Logout error' });
    }
  },

  async registerUser(req, res) {
    try {
      const { username, password, name, role, facilityId, village, district } = req.body;
      if (!username || !password || !name || !role) {
        return res.status(400).json({ success: false, error: 'All fields required' });
      }

      const existing = await User.findOne({ username });
      if (existing) {
        return res.status(409).json({ success: false, error: 'Username already registered' });
      }

      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);

      const id = `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const newUser = await User.create({
        id,
        username,
        passwordHash,
        name,
        role,
        facilityId: facilityId || req.user?.facilityId || 'FAC-RAMPUR-PHC',
        village: village || 'Rampur Village',
        district: district || 'Mandya District',
        status: 'active'
      });

      await AuditLog.create({
        entity: 'users',
        entityId: id,
        action: 'USER_REGISTERED',
        performedBy: req.user?.username || 'admin',
        role: req.user?.role || 'admin',
        facilityId: newUser.facilityId,
        details: `Created new ${role} user: ${name} (${username})`
      });

      res.status(201).json({
        success: true,
        user: {
          id: newUser.id,
          username: newUser.username,
          name: newUser.name,
          role: newUser.role,
          facilityId: newUser.facilityId
        }
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getProfile(req, res) {
    res.json({ success: true, user: req.user });
  }
};
