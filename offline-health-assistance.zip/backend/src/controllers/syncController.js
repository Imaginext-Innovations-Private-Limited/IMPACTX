import { Models } from '../models/schemas.js';
import SyncOperation from '../models/SyncOperation.js';
import AuditLog from '../models/AuditLog.js';

export const SyncController = {
  /**
   * PUSH: Process batch of pending offline operations from community health worker device
   * - Enforces idempotency keys
   * - Detects version conflicts
   * - Persists approved changes to MongoDB
   * - Returns per-operation acknowledgements and conflict reports
   */
  async push(req, res) {
    try {
      const { operations } = req.body;
      if (!Array.isArray(operations)) {
        return res.status(400).json({ success: false, error: 'Expected operations array' });
      }

      const applied = [];
      const conflicts = [];
      const errors = [];
      const facilityId = req.user.facilityId;

      for (const op of operations) {
        const { entity, entityId, operation, payload, idempotencyKey, deviceId, version } = op;

        if (!entity || !entityId || !operation) {
          errors.push({ entityId, error: 'Malformed operation payload' });
          continue;
        }

        // 1. Idempotency Check: Prevent duplicate operations on network retry
        if (idempotencyKey) {
          const existingOp = await SyncOperation.findOne({ idempotencyKey });
          if (existingOp) {
            applied.push({
              entityId,
              operation,
              idempotencyKey,
              status: 'already_processed',
              message: 'Idempotent request: operation already applied previously.'
            });
            continue;
          }
        }

        const Model = Models[capitalize(entity)] || Models[entity];
        if (!Model) {
          errors.push({ entityId, error: `Unknown entity: ${entity}` });
          continue;
        }

        // 2. Conflict Detection for Updates
        if (operation === 'UPDATE') {
          const currentServerRecord = await Model.findById(entityId);
          if (currentServerRecord) {
            const serverVersion = currentServerRecord.version || 1;
            const submittedVersion = version || payload?.version || 1;

            if (serverVersion > submittedVersion) {
              // Version collision detected: server has newer data
              const diffs = [];
              const keys = new Set([...Object.keys(currentServerRecord), ...Object.keys(payload || {})]);
              keys.forEach(k => {
                if (['syncStatus', 'updatedAt', 'version', 'deviceId'].includes(k)) return;
                if (JSON.stringify(currentServerRecord[k]) !== JSON.stringify(payload[k])) {
                  diffs.push({ field: k, server: currentServerRecord[k], client: payload[k] });
                }
              });

              await SyncOperation.create({
                id: `sync-conf-${Date.now()}`,
                operationId: op.id || `${Date.now()}`,
                entity,
                entityId,
                operation,
                payload,
                deviceId,
                facilityId,
                version: submittedVersion,
                status: 'conflict',
                idempotencyKey: idempotencyKey || `key-${Date.now()}-${entityId}`,
                error: `Version mismatch: Server v${serverVersion} > Submitted v${submittedVersion}`
              });

              conflicts.push({
                entity,
                entityId,
                serverVersion,
                submittedVersion,
                serverRecord: currentServerRecord,
                clientRecord: payload,
                diffs,
                message: 'Stale update rejected: conflict requires clinical reconciliation.'
              });
              continue;
            }
          }
        }

        // 3. Apply Operation
        try {
          const timestamp = new Date().toISOString();
          let resultRecord;

          if (operation === 'CREATE') {
            const createData = {
              ...payload,
              id: entityId,
              facilityId: payload.facilityId || facilityId,
              deviceId: deviceId || 'OFFLINE-CLIENT',
              createdAt: payload.createdAt || timestamp,
              updatedAt: timestamp
            };
            if (entity.toLowerCase().includes('patient') && !createData.patientId) {
              createData.patientId = payload.patientId || `PAT-${entityId.toUpperCase().slice(-6)}`;
            }
            resultRecord = await Model.findOneAndUpdate(
              { id: entityId },
              { $set: createData },
              { upsert: true, new: true, setDefaultsOnInsert: true }
            );
          } else if (operation === 'UPDATE') {
            resultRecord = await Model.findOneAndUpdate(
              { id: entityId },
              {
                $set: {
                  ...payload,
                  updatedAt: timestamp
                }
              },
              { upsert: true, new: true }
            );
          } else if (operation === 'DELETE') {
            resultRecord = await Model.findOneAndUpdate(
              { id: entityId },
              {
                isDeleted: true,
                deletionReason: payload?.reason || 'Synchronized tombstone deletion',
                updatedAt: timestamp
              }
            );
          }

          // Record successful sync operation
          const recordedOp = await SyncOperation.create({
            id: `sync-op-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            operationId: op.id || `${Date.now()}`,
            entity,
            entityId,
            operation,
            payload,
            deviceId,
            facilityId,
            version: payload?.version || 1,
            status: 'applied',
            idempotencyKey: idempotencyKey || `key-${Date.now()}-${entityId}`,
            appliedAt: timestamp
          });

          applied.push({
            entity,
            entityId,
            operation,
            version: payload?.version || 1,
            status: 'applied',
            appliedAt: timestamp
          });
        } catch (opErr) {
          console.error(`[Sync] Operation error for ${entityId}:`, opErr);
          errors.push({ entityId, error: opErr.message });
        }
      }

      // Record Audit Log for sync batch
      await AuditLog.create({
        entity: 'sync',
        entityId: `batch-${Date.now()}`,
        action: 'BATCH_PUSH_SYNC',
        performedBy: req.user.name,
        role: req.user.role,
        facilityId,
        details: `Processed ${operations.length} operations. Applied: ${applied.length}, Conflicts: ${conflicts.length}, Errors: ${errors.length}`
      });

      res.json({
        success: true,
        summary: {
          totalReceived: operations.length,
          appliedCount: applied.length,
          conflictCount: conflicts.length,
          errorCount: errors.length
        },
        applied,
        conflicts,
        errors
      });
    } catch (err) {
      console.error('[Sync Push Error]', err);
      res.status(500).json({ success: false, error: err.message });
    }
  },

  /**
   * PULL: Incremental cursor-based synchronization from MongoDB
   * Returns all changes newer than the client cursor for the authorized facility
   */
  async pull(req, res) {
    try {
      const cursor = req.query.cursor || new Date(0).toISOString();
      const facilityId = (req.user.role === 'admin' && req.query.facilityId) ? req.query.facilityId : req.user.facilityId;

      const filter = {
        updatedAt: { $gt: cursor }
      };

      if (req.user.role !== 'admin') {
        filter.facilityId = facilityId;
      }

      const [patients, assessments, maternal, child, referrals, followUps, documentAnalyses] = await Promise.all([
        Models.Patient.find(filter),
        Models.HealthAssessment.find(filter),
        Models.MaternalRecord.find(filter),
        Models.ChildRecord.find(filter),
        Models.Referral.find(filter),
        Models.FollowUp.find(filter),
        Models.DocumentAnalysis.find(filter)
      ]);

      const changes = [
        ...patients.map(p => ({ entity: 'patients', data: p })),
        ...assessments.map(a => ({ entity: 'healthAssessments', data: a })),
        ...maternal.map(m => ({ entity: 'maternalRecords', data: m })),
        ...child.map(c => ({ entity: 'childRecords', data: c })),
        ...referrals.map(r => ({ entity: 'referrals', data: r })),
        ...followUps.map(f => ({ entity: 'followUps', data: f })),
        ...documentAnalyses.map(d => ({ entity: 'documentAnalyses', data: d }))
      ];

      res.json({
        success: true,
        cursor: new Date().toISOString(),
        count: changes.length,
        changes
      });
    } catch (err) {
      console.error('[Sync Pull Error]', err);
      res.status(500).json({ success: false, error: err.message });
    }
  }
};

function capitalize(s) {
  if (!s) return '';
  // Convert plural/camel to PascalCase (patients -> Patient, healthAssessments -> HealthAssessment)
  const map = {
    patients: 'Patient',
    healthAssessments: 'HealthAssessment',
    maternalRecords: 'MaternalRecord',
    antenatalVisits: 'AntenatalVisit',
    childRecords: 'ChildRecord',
    growthRecords: 'GrowthRecord',
    immunizations: 'Immunization',
    chronicConditions: 'ChronicCondition',
    referrals: 'Referral',
    followUps: 'FollowUp',
    knowledgeArticles: 'KnowledgeArticle',
    documentAnalyses: 'DocumentAnalysis'
  };
  return map[s] || (s.charAt(0).toUpperCase() + s.slice(1).replace(/s$/, ''));
}
