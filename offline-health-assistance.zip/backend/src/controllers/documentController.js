import DocumentAnalysis from '../models/DocumentAnalysis.js';

const LANGUAGE_LABELS = {
  en: 'English',
  hi: 'Hindi',
  kn: 'Kannada',
};

const FALLBACK_TEMPLATES = {
  en: {
    critical: (count) =>
      `Detected ${count} clinical finding(s) with CRITICAL flags. Arrange urgent PHC/CHC Medical Officer review immediately.`,
    warning: (count) =>
      `Detected ${count} clinical finding(s) with borderline/abnormal values. Schedule follow-up monitoring.`,
    normal: (count) =>
      count > 0
        ? `Analyzed ${count} clinical metric(s); all detected values appear within acceptable ranges.`
        : 'Document reviewed. No automated numeric thresholds triggered; verify handwritten entries manually.',
  },
  hi: {
    critical: (count) =>
      `दस्तावेज़ में ${count} चिकित्सीय मान मिले हैं जिनमें गंभीर (CRITICAL) संकेत हैं। कृपया तुरंत PHC/CHC डॉक्टर से जांच कराएं।`,
    warning: (count) =>
      `दस्तावेज़ में ${count} चिकित्सीय मान मिले हैं जिनमें असामान्य या सीमावर्ती परिणाम हैं। नियमित फॉलो-अप सुनिश्चित करें।`,
    normal: (count) =>
      count > 0
        ? `${count} चिकित्सीय मान सामान्य सीमा में प्रतीत होते हैं। नियमित देखभाल जारी रखें।`
        : 'दस्तावेज़ की समीक्षा की गई। कृपया हस्तलिखित विवरण की जांच डॉक्टर या ANM से कराएं।',
  },
  kn: {
    critical: (count) =>
      `ದಾಖಲೆಯಲ್ಲಿ ${count} ವೈದ್ಯಕೀಯ ಅಂಶಗಳು ಪತ್ತೆಯಾಗಿದ್ದು ತುರ್ತು (CRITICAL) ಎಚ್ಚರಿಕೆ ಇದೆ. ತಕ್ಷಣ PHC/CHC ವೈದ್ಯಾಧಿಕಾರಿಗಳ ಬಳಿ ಕಳುಹಿಸಿ.`,
    warning: (count) =>
      `ದಾಖಲೆಯಲ್ಲಿ ${count} ವೈದ್ಯಕೀಯ ಅಂಶಗಳು ಸಾಮಾನ್ಯಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿವೆ. ನಿಯಮಿತ ಫಾಲೋ-ಅಪ್ ಪರಿಶೀಲನೆ ನಡೆಸಿ.`,
    normal: (count) =>
      count > 0
        ? `${count} ವೈದ್ಯಕೀಯ ಅಂಶಗಳು ಸಾಮಾನ್ಯ ಮಟ್ಟದಲ್ಲಿವೆ. ನಿಯಮಿತ ಆರೈಕೆ ಮುಂದುವರಿಸಿ.`
        : 'ದಾಖಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ. ಕೈಬರಹದ ವಿವರಗಳನ್ನು ದಯವಿಟ್ಟು ವೈದ್ಯಾಧಿಕಾರಿಗಳಿಂದ ದೃಢೀಕರಿಸಿ.',
  },
};

export const DocumentController = {
  async analyze(req, res) {
    try {
      const { text, documentType = 'lab_report', language = 'en', findings = [] } = req.body;
      if (!text || typeof text !== 'string' || !text.trim()) {
        return res.status(400).json({ success: false, error: 'Document text is required' });
      }

      const langCode = LANGUAGE_LABELS[language] ? language : 'en';
      const targetLanguage = LANGUAGE_LABELS[langCode];
      const apiKey = process.env.GEMINI_API_KEY;

      if (apiKey) {
        try {
          const prompt = `You are a clinical decision-support assistant for an ASHA/ANM community health worker in rural India.
Analyze this ${documentType} text and reply in ${targetLanguage} as strict JSON with keys:
"summary" (2-3 clear sentences) and "actionItems" (array of 2-4 concise, practical next steps).
Do not invent numbers that do not appear in the text.

TEXT:
${text.slice(0, 6000)}`;

          const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: { responseMimeType: 'application/json' },
              }),
            }
          );

          if (response.ok) {
            const payload = await response.json();
            const rawJson = payload?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
            const parsed = JSON.parse(rawJson);

            return res.json({
              success: true,
              analysis: {
                summary: parsed.summary || 'Cloud AI analysis completed.',
                actionItems: Array.isArray(parsed.actionItems) ? parsed.actionItems : [],
                provider: 'gemini-cloud-ai',
              },
            });
          }
        } catch (aiErr) {
          console.warn('[DocumentController] Gemini API fallback triggered:', aiErr.message);
        }
      }

      const safeFindings = Array.isArray(findings) ? findings : [];
      const hasCritical = safeFindings.some((f) => f.status === 'critical');
      const hasWarning = safeFindings.some((f) => f.status === 'warning');
      const tier = hasCritical ? 'critical' : hasWarning ? 'warning' : 'normal';
      const templates = FALLBACK_TEMPLATES[langCode] || FALLBACK_TEMPLATES.en;

      const actionItems = safeFindings
        .filter((f) => f.status !== 'normal')
        .map((f) => `${f.label} (${f.value} ${f.unit || ''}): ${f.note}`.trim());

      if (actionItems.length === 0) {
        actionItems.push('Verify OCR-extracted figures against the original paper report.');
        if (hasCritical) actionItems.push('Refer immediately to PHC/CHC Medical Officer.');
      }

      return res.json({
        success: true,
        analysis: {
          summary: templates[tier](safeFindings.length),
          actionItems,
          provider: 'cloud-clinical-rules',
        },
      });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  },

  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `doc-${Date.now()}`;
      const record = await DocumentAnalysis.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        analyzedBy: data.analyzedBy || req.user.name,
        version: 1,
        createdAt: data.createdAt || new Date().toISOString(),
      });
      return res.status(201).json({ success: true, documentAnalysis: record });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  },

  async getAll(req, res) {
    try {
      const filter = req.user.role === 'admin' ? {} : { facilityId: req.user.facilityId };
      if (req.query.patientId) filter.patientId = req.query.patientId;
      const list = await DocumentAnalysis.find({ ...filter, isDeleted: { $ne: true } });
      return res.json({ success: true, documentAnalyses: list });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  },
};
