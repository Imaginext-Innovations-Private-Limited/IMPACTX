const LANG_NAMES = { en: 'English', hi: 'Hindi', kn: 'Kannada' };

export const AssistantController = {
  async chat(req, res) {
    try {
      const { message, language = 'en', history = [] } = req.body;
      if (!message || typeof message !== 'string' || !message.trim()) {
        return res.status(400).json({ success: false, error: 'Message is required' });
      }

      const targetLang = LANG_NAMES[language] || 'English';
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.json({
          success: true,
          reply: '',
          emergency: false,
          sources: [],
        });
      }

      const conversationContext = (Array.isArray(history) ? history : [])
        .slice(-6)
        .map((m) => `${m.role === 'user' ? 'Worker' : 'Assistant'}: ${m.text}`)
        .join('\n');

      const prompt = `You are a clinical decision-support chatbot for ASHA/ANM rural health workers in India.
Reply concisely in ${targetLang} following NHM/WHO primary care protocols.
Never invent diagnoses; flag red-flag emergencies (call 108 / refer to PHC).
Return strict JSON: {"reply": string, "emergency": boolean}.

Recent chat:
${conversationContext}

Worker question: ${message.slice(0, 1500)}`;

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: 'application/json' },
          }),
        }
      );

      if (!response.ok) {
        return res.json({ success: true, reply: '', emergency: false, sources: [] });
      }

      const data = await response.json();
      const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      const parsed = JSON.parse(raw);

      return res.json({
        success: true,
        reply: parsed.reply || '',
        emergency: Boolean(parsed.emergency),
        sources: ['NHM / WHO Clinical AI Assistant'],
      });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  },
};
