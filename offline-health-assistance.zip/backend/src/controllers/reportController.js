import Patient from '../models/Patient.js';
import User from '../models/User.js';
import MaternalRecord from '../models/MaternalRecord.js';
import ChildRecord from '../models/ChildRecord.js';
import Referral from '../models/Referral.js';
import HealthAssessment from '../models/HealthAssessment.js';
import SyncOperation from '../models/SyncOperation.js';

export const ReportController = {
  async getDashboardMetrics(req, res) {
    try {
      const facilityFilter = req.user.role === 'admin' ? {} : { facilityId: req.user.facilityId };

      const [totalPatients, totalWorkers, totalMaternal, totalChild, totalReferrals, recentSyncOps] = await Promise.all([
        Patient.countDocuments({ ...facilityFilter, isDeleted: false }),
        User.countDocuments(facilityFilter),
        MaternalRecord.countDocuments({ ...facilityFilter, status: 'active' }),
        ChildRecord.countDocuments(facilityFilter),
        Referral.countDocuments({ ...facilityFilter, status: 'referred' }),
        SyncOperation.find({})
      ]);

      const allPatients = await Patient.find({ ...facilityFilter, isDeleted: false });
      const highRiskCount = allPatients.filter(p => p.riskLevel === 'high').length;

      res.json({
        success: true,
        metrics: {
          totalPatients,
          totalWorkers,
          totalMaternal,
          totalChild,
          totalReferrals,
          highRiskCount,
          syncOperationsCount: recentSyncOps.length,
          lastSyncAt: recentSyncOps[recentSyncOps.length - 1]?.appliedAt || null
        }
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};
