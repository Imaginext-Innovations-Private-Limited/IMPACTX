import HealthAssessment from '../models/HealthAssessment.js';
import MaternalRecord from '../models/MaternalRecord.js';
import AntenatalVisit from '../models/AntenatalVisit.js';
import ChildRecord from '../models/ChildRecord.js';
import GrowthRecord from '../models/GrowthRecord.js';
import Immunization from '../models/Immunization.js';
import ChronicCondition from '../models/ChronicCondition.js';
import Referral from '../models/Referral.js';
import FollowUp from '../models/FollowUp.js';
import AuditLog from '../models/AuditLog.js';

// ================= ASSESSMENTS ================= //
export const AssessmentController = {
  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `ha-${Date.now()}`;
      const record = await HealthAssessment.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        assessedBy: req.user.name,
        version: 1,
        createdAt: new Date().toISOString()
      });

      res.status(201).json({ success: true, assessment: record });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getByPatient(req, res) {
    try {
      const { patientId } = req.query;
      const list = await HealthAssessment.find(patientId ? { patientId } : {});
      res.json({ success: true, assessments: list });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};

// ================= MATERNAL ================= //
export const MaternalController = {
  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `mat-${Date.now()}`;
      const record = await MaternalRecord.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        version: 1,
        createdAt: new Date().toISOString()
      });
      res.status(201).json({ success: true, maternalRecord: record });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getAll(req, res) {
    try {
      const list = await MaternalRecord.find({});
      res.json({ success: true, maternalRecords: list });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};

// ================= CHILD ================= //
export const ChildController = {
  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `ch-${Date.now()}`;
      const record = await ChildRecord.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        version: 1,
        createdAt: new Date().toISOString()
      });
      res.status(201).json({ success: true, childRecord: record });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getAll(req, res) {
    try {
      const list = await ChildRecord.find({});
      res.json({ success: true, childRecords: list });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};

// ================= REFERRALS ================= //
export const ReferralController = {
  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `ref-${Date.now()}`;
      const record = await Referral.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        referredBy: req.user.name,
        status: 'referred',
        version: 1,
        createdAt: new Date().toISOString()
      });
      res.status(201).json({ success: true, referral: record });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async update(req, res) {
    try {
      const { id } = req.params;
      const updated = await Referral.findOneAndUpdate({ id }, { ...req.body, updatedAt: new Date().toISOString() });
      res.json({ success: true, referral: updated });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getAll(req, res) {
    try {
      const list = await Referral.find({});
      res.json({ success: true, referrals: list });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};

// ================= FOLLOW-UPS ================= //
export const FollowUpController = {
  async create(req, res) {
    try {
      const data = req.body;
      const id = data.id || `fu-${Date.now()}`;
      const record = await FollowUp.create({
        ...data,
        id,
        facilityId: req.user.facilityId,
        isCompleted: false,
        version: 1,
        createdAt: new Date().toISOString()
      });
      res.status(201).json({ success: true, followUp: record });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  async getAll(req, res) {
    try {
      const list = await FollowUp.find({});
      res.json({ success: true, followUps: list });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};
