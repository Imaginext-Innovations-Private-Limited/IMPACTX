import app from './app.js';
import { ENV } from './config/environment.js';
import { connectDatabase } from './config/database.js';
import bcrypt from 'bcryptjs';
import User from './models/User.js';
import Facility from './models/Facility.js';

async function seedInitialAccounts() {
  try {
    // 1. Seed Facilities
    const existingFacility = await Facility.findById('FAC-RAMPUR-PHC');
    if (!existingFacility) {
      await Facility.create({
        id: 'FAC-RAMPUR-PHC',
        facilityId: 'FAC-RAMPUR-PHC',
        name: 'Rampur Primary Health Centre',
        type: 'PHC',
        district: 'Mandya District',
        state: 'Karnataka',
        activeWorkers: ['usr-asha-1', 'usr-doc-1']
      });
      console.log('[Seed] Created default healthcare facility: Rampur PHC');
    }

    // 2. Seed Users: Admin, Doctor, ASHA Worker with bcrypt password hashing
    const salt = await bcrypt.genSalt(10);
    const defaultPasswordHash = await bcrypt.hash('offline123', salt);

    const defaultUsers = [
      {
        id: 'usr-admin-1',
        username: 'admin',
        passwordHash: defaultPasswordHash,
        name: 'Dr. Rajesh Sharma',
        role: 'admin',
        facilityId: 'FAC-RAMPUR-PHC',
        village: 'District Health Directorate',
        district: 'Mandya District',
        status: 'active'
      },
      {
        id: 'usr-doc-1',
        username: 'doctor',
        passwordHash: defaultPasswordHash,
        name: 'Dr. Priya Rao',
        role: 'doctor',
        facilityId: 'FAC-RAMPUR-PHC',
        village: 'Rampur Village',
        district: 'Mandya District',
        status: 'active'
      },
      {
        id: 'usr-asha-1',
        username: 'asha_sunita',
        passwordHash: defaultPasswordHash,
        name: 'Sunita Devi',
        role: 'asha',
        facilityId: 'FAC-RAMPUR-PHC',
        village: 'Rampur Sub-Centre',
        district: 'Mandya District',
        status: 'active'
      }
    ];

    for (const u of defaultUsers) {
      const exists = await User.findOne({ username: u.username });
      if (!exists) {
        await User.create(u);
        console.log(`[Seed] Initialized authorized user: ${u.name} (${u.role})`);
      }
    }
  } catch (err) {
    console.warn('[Seed] Warning during initial account seeding:', err.message);
  }
}

async function startServer() {
  await connectDatabase();
  await seedInitialAccounts();

  const server = app.listen(ENV.PORT, '0.0.0.0', () => {
    console.log(`====================================================`);
    console.log(` OFFLINE HEALTH - Central Cloud Express API Server `);
    console.log(` Live on: http://localhost:${ENV.PORT}`);
    console.log(` Environment: ${ENV.NODE_ENV}`);
    console.log(` Health Endpoint: http://localhost:${ENV.PORT}/api/health`);
    console.log(`====================================================`);
  });

  return server;
}

startServer().catch(err => {
  console.error('[Fatal Server Startup Error]', err);
  process.exit(1);
});
