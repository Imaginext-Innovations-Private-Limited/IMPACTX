import { Router } from 'express';
import { PatientController } from '../controllers/patientController.js';
import { authenticate } from '../middleware/authenticate.js';
import { authorize } from '../middleware/authorize.js';

const router = Router();

router.use(authenticate);

router.post('/', authorize(['admin', 'asha', 'doctor']), PatientController.createPatient);
router.get('/', authorize(['admin', 'asha', 'doctor']), PatientController.getPatients);
router.get('/:id', authorize(['admin', 'asha', 'doctor']), PatientController.getPatientById);
router.put('/:id', authorize(['admin', 'asha', 'doctor']), PatientController.updatePatient);
router.delete('/:id', authorize(['admin']), PatientController.deletePatient);

export default router;
