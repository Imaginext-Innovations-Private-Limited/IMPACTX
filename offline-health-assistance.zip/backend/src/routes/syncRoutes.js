import { Router } from 'express';
import { SyncController } from '../controllers/syncController.js';
import { authenticate } from '../middleware/authenticate.js';

const router = Router();

router.use(authenticate);

router.post('/push', SyncController.push);
router.get('/pull', SyncController.pull);

export default router;
