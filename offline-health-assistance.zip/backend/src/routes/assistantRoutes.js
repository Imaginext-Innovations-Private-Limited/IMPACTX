import { Router } from 'express';
import { AssistantController } from '../controllers/assistantController.js';
import { authenticate } from '../middleware/authenticate.js';
import { authorize } from '../middleware/authorize.js';

const router = Router();
router.use(authenticate);

router.post('/chat', authorize(['admin', 'asha', 'doctor']), AssistantController.chat);

export default router;
