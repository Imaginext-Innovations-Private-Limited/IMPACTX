import { Router } from 'express';
import {
  AssessmentController,
  MaternalController,
  ChildController,
  ReferralController,
  FollowUpController
} from '../controllers/clinicalControllers.js';
import { authenticate } from '../middleware/authenticate.js';
import { authorize } from '../middleware/authorize.js';

const router = Router();
router.use(authenticate);

// Assessments
router.post('/assessments', authorize(['admin', 'asha', 'doctor']), AssessmentController.create);
router.get('/assessments', authorize(['admin', 'asha', 'doctor']), AssessmentController.getByPatient);

// Maternal
router.post('/maternal', authorize(['admin', 'asha', 'doctor']), MaternalController.create);
router.get('/maternal', authorize(['admin', 'asha', 'doctor']), MaternalController.getAll);

// Child
router.post('/children', authorize(['admin', 'asha', 'doctor']), ChildController.create);
router.get('/children', authorize(['admin', 'asha', 'doctor']), ChildController.getAll);

// Referrals
router.post('/referrals', authorize(['admin', 'asha', 'doctor']), ReferralController.create);
router.get('/referrals', authorize(['admin', 'asha', 'doctor']), ReferralController.getAll);
router.put('/referrals/:id', authorize(['admin', 'doctor']), ReferralController.update);

// Follow-ups
router.post('/follow-ups', authorize(['admin', 'asha', 'doctor']), FollowUpController.create);
router.get('/follow-ups', authorize(['admin', 'asha', 'doctor']), FollowUpController.getAll);

export default router;
