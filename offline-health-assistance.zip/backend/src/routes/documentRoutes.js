import { Router } from 'express';
import { DocumentController } from '../controllers/documentController.js';
import { authenticate } from '../middleware/authenticate.js';
import { authorize } from '../middleware/authorize.js';

const router = Router();
router.use(authenticate);

router.post('/analyze', authorize(['admin', 'asha', 'doctor']), DocumentController.analyze);
router.post('/', authorize(['admin', 'asha', 'doctor']), DocumentController.create);
router.get('/', authorize(['admin', 'asha', 'doctor']), DocumentController.getAll);

export default router;
