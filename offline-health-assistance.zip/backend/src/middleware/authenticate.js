import jwt from 'jsonwebtoken';
import { ENV } from '../config/environment.js';
import User from '../models/User.js';

export async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, error: 'Authentication token required' });
    }

    const token = authHeader.split(' ')[1];
    let decoded;
    try {
      decoded = jwt.verify(token, ENV.JWT_ACCESS_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ success: false, error: 'Token expired', code: 'TOKEN_EXPIRED' });
      }
      return res.status(401).json({ success: false, error: 'Invalid authentication token' });
    }

    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, error: 'User account not found' });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ success: false, error: 'Account has been suspended or revoked' });
    }

    req.user = {
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
      facilityId: user.facilityId,
      village: user.village,
      district: user.district
    };

    next();
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Authentication processing error' });
  }
}
