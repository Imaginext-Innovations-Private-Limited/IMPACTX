export function authorize(allowedRoles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, error: 'Unauthenticated' });
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: `Access forbidden: requires one of [${allowedRoles.join(', ')}] role`
      });
    }

    next();
  };
}

export function authorizeFacility(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ success: false, error: 'Unauthenticated' });
  }

  // Admins have district-wide cross-facility access
  if (req.user.role === 'admin') {
    return next();
  }

  // Check if requested facility matches user's assigned facility
  const targetFacilityId = req.params.facilityId || req.query.facilityId || req.body.facilityId;
  if (targetFacilityId && targetFacilityId !== req.user.facilityId) {
    return res.status(403).json({
      success: false,
      error: 'Facility isolation violation: Access denied to other facility records.'
    });
  }

  next();
}
