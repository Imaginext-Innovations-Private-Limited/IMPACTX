import mongoose from 'mongoose';
import { memoryStore, getDatabaseStatus } from '../config/database.js';

/**
 * Mongoose Schema Definitions for All 16 Centralized Collections
 */

// 1. Facility Schema
export const FacilitySchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  facilityId: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true },
  type: { type: String, enum: ['SubCentre', 'PHC', 'CHC', 'DistrictHospital'], default: 'PHC' },
  district: { type: String, required: true },
  state: { type: String, default: 'Karnataka' },
  activeWorkers: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// 2. User Schema
export const UserSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  username: { type: String, required: true, unique: true, index: true },
  passwordHash: { type: String, required: true },
  name: { type: String, required: true },
  role: { type: String, enum: ['admin', 'asha', 'doctor'], default: 'asha' },
  facilityId: { type: String, required: true, index: true },
  village: { type: String, default: 'Rampur Village' },
  district: { type: String, default: 'Mandya District' },
  status: { type: String, enum: ['active', 'suspended', 'revoked'], default: 'active' },
  refreshTokens: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// 3. Patient Schema
export const PatientSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true, index: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['female', 'male', 'other'], required: true },
  dateOfBirth: String,
  contactNumber: String,
  emergencyContact: String,
  abhaId: { type: String, index: true },
  aadhaarLast4: String,
  villageHamlet: { type: String, required: true, index: true },
  wardNumber: String,
  houseNumber: String,
  bloodGroup: String,
  riskLevel: { type: String, enum: ['normal', 'moderate', 'high'], default: 'normal', index: true },
  category: { type: String, enum: ['general', 'maternal', 'child', 'chronic'], default: 'general', index: true },
  isPregnant: { type: Boolean, default: false },
  chronicConditions: [String],
  allergies: String,
  consentGiven: { type: Boolean, default: true },
  facilityId: { type: String, required: true, index: true },
  version: { type: Number, default: 1, index: true },
  isDeleted: { type: Boolean, default: false, index: true },
  deletionReason: String,
  deviceId: String,
  createdBy: String,
  updatedBy: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now, index: true }
});

// 4. Health Assessment Schema
export const HealthAssessmentSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  assessmentType: { type: String, default: 'General' },
  assessmentDate: String,
  assessmentTime: String,
  systolicBp: Number,
  diastolicBp: Number,
  repeatBp: { type: Array, default: [] },
  pulse: Number,
  spo2: Number,
  bloodGlucose: Number,
  glucoseContext: String,
  temperature: Number,
  respiratoryRate: Number,
  height: Number,
  weight: Number,
  bmi: Number,
  bmiInterpretation: String,
  muacCm: Number,
  vitalSigns: { type: mongoose.Schema.Types.Mixed, default: {} },
  screeningResponses: { type: mongoose.Schema.Types.Mixed, default: {} },
  calculatedIndicators: { type: mongoose.Schema.Types.Mixed, default: {} },
  warningSigns: [String],
  warningIndicators: [String],
  observations: String,
  notes: String,
  status: { type: String, default: 'completed' }, // completed, partial, requires_follow_up, referred
  riskLevel: { type: String, default: 'normal' },
  referralId: String,
  followUpId: String,
  facilityId: { type: String, index: true },
  assessedBy: String,
  healthcareWorkerId: String,
  location: String,
  auditHistory: { type: Array, default: [] },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

// 5. Maternal Record Schema
export const MaternalRecordSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  lmp: String,
  edd: String,
  trimester: Number,
  gravidity: Number,
  parity: Number,
  highRiskFactors: [String],
  status: { type: String, enum: ['active', 'delivered', 'referred', 'closed'], default: 'active' },
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now }
});

// 6. Antenatal Visit Schema
export const AntenatalVisitSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  maternalRecordId: { type: String, index: true },
  visitNumber: Number,
  systolicBp: Number,
  diastolicBp: Number,
  weightKg: Number,
  fundalHeightCm: Number,
  fetalHeartRate: Number,
  urineProtein: String,
  hemoglobin: Number,
  warningSigns: { type: mongoose.Schema.Types.Mixed, default: [] },
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

// 7. Child Record Schema
export const ChildRecordSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  motherId: String,
  birthWeight: Number,
  gestationalAge: Number,
  deliveryType: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

// 8. Growth Record Schema
export const GrowthRecordSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  childId: { type: String, required: true, index: true },
  patientId: { type: String, required: true, index: true },
  ageMonths: Number,
  weightKg: Number,
  heightCm: Number,
  muacCm: Number,
  nutritionGrade: String,
  measuredBy: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

// 9. Immunization Schema
export const ImmunizationSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  childId: { type: String, required: true, index: true },
  patientId: { type: String, required: true, index: true },
  vaccineName: { type: String, required: true },
  doseNumber: Number,
  dueDate: String,
  givenDate: String,
  status: { type: String, enum: ['scheduled', 'administered', 'overdue', 'missed'], default: 'scheduled' },
  administeredBy: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now }
}, { strict: false });

// 10. Chronic Condition Schema
export const ChronicConditionSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  conditionName: { type: String, required: true },
  severity: String,
  diagnosedDate: String,
  lastChecked: String,
  medicationAdherence: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true }
}, { strict: false });

// 11. Referral Schema
export const ReferralSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  urgency: { type: String, default: 'urgent', index: true },
  status: { type: String, default: 'referred', index: true },
  referralFacility: { type: String, default: 'Community Health Centre' },
  reason: { type: String, default: 'Clinical Referral' },
  referredBy: String,
  doctorFeedback: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now }
}, { strict: false });

// 12. Follow-Up Schema
export const FollowUpSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  scheduledDate: { type: String, required: true, index: true },
  visitType: String,
  priority: { type: String, default: 'routine' },
  isCompleted: { type: Boolean, default: false, index: true },
  notes: String,
  completedDate: String,
  facilityId: { type: String, index: true },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now }
}, { strict: false });

// 13. Knowledge Article Schema
export const KnowledgeArticleSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  category: { type: String, required: true, index: true },
  title: { type: String, required: true },
  language: { type: String, default: 'en', index: true },
  summary: String,
  content: { type: String, required: true },
  authority: String,
  version: String,
  reviewDate: String,
  approvalStatus: { type: String, enum: ['approved', 'draft', 'archived'], default: 'approved' },
  lastUpdated: String
});

// 14. Sync Operation Schema
export const SyncOperationSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  operationId: { type: String, required: true, index: true },
  entity: { type: String, required: true, index: true },
  entityId: { type: String, required: true, index: true },
  operation: { type: String, enum: ['CREATE', 'UPDATE', 'DELETE'], required: true },
  payload: mongoose.Schema.Types.Mixed,
  deviceId: { type: String, index: true },
  facilityId: { type: String, index: true },
  version: Number,
  status: { type: String, enum: ['applied', 'rejected', 'conflict'], default: 'applied' },
  idempotencyKey: { type: String, required: true, unique: true, index: true },
  appliedAt: { type: Date, default: Date.now },
  error: String
});

// 15. Audit Log Schema
export const AuditLogSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  entity: { type: String, required: true, index: true },
  entityId: { type: String, required: true, index: true },
  action: { type: String, required: true, index: true },
  performedBy: String,
  role: String,
  facilityId: String,
  timestamp: { type: Date, default: Date.now, index: true },
  details: String
});

// 16. AI Document Analysis Schema
export const DocumentAnalysisSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, index: true },
  patientName: String,
  documentType: { type: String, default: 'lab_report', index: true },
  fileName: String,
  rawText: String,
  findings: [mongoose.Schema.Types.Mixed],
  medications: [String],
  riskLevel: { type: String, enum: ['normal', 'warning', 'critical'], default: 'normal', index: true },
  summary: String,
  recommendations: [String],
  analyzedMode: String,
  language: { type: String, default: 'en' },
  analyzedBy: String,
  facilityId: { type: String, index: true },
  isDeleted: { type: Boolean, default: false },
  version: { type: Number, default: 1 },
  deviceId: String,
  createdAt: { type: String },
  updatedAt: { type: String }
});

/**
 * Universal Model Wrapper Factory:
 * Delivers identical Mongoose document interface whether backed by Mongoose or embedded store.
 */
function createModelWrapper(name, schema, storeKey) {
  let MongooseModel;
  try {
    MongooseModel = mongoose.model(name, schema);
  } catch {
    MongooseModel = mongoose.models[name];
  }

  return {
    async find(filter = {}) {
      const status = getDatabaseStatus();
      if (!status.isInMemoryFallback && mongoose.connection.readyState === 1) {
        return await MongooseModel.find(filter).lean();
      }

      // In-Memory filtering
      const store = memoryStore[storeKey];
      let results = Array.from(store.values());

      for (const [key, value] of Object.entries(filter)) {
        if (value && typeof value === 'object') {
          if (value.$ne !== undefined) results = results.filter(d => d[key] !== value.$ne);
          if (value.$gt !== undefined) results = results.filter(d => new Date(d[key]) > new Date(value.$gt));
          if (value.$in !== undefined) results = results.filter(d => value.$in.includes(d[key]));
        } else {
          results = results.filter(d => d[key] === value);
        }
      }
      return results;
    },

    async findById(id) {
      return this.findOne({ id });
    },

    async findOne(filter = {}) {
      const list = await this.find(filter);
      return list[0] || null;
    },

    async create(doc) {
      const status = getDatabaseStatus();
      const enriched = {
        ...doc,
        id: doc.id || doc._id || `${storeKey}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        createdAt: doc.createdAt || new Date().toISOString(),
        updatedAt: doc.updatedAt || new Date().toISOString()
      };

      if (!status.isInMemoryFallback && mongoose.connection.readyState === 1) {
        return await MongooseModel.create(enriched);
      }

      memoryStore[storeKey].set(enriched.id, enriched);
      return enriched;
    },

    async updateOne(filter, update) {
      const doc = await this.findOne(filter);
      if (!doc) return { modifiedCount: 0 };

      const setUpdates = update.$set || update;
      const updated = {
        ...doc,
        ...setUpdates,
        updatedAt: new Date().toISOString()
      };

      const status = getDatabaseStatus();
      if (!status.isInMemoryFallback && mongoose.connection.readyState === 1) {
        return await MongooseModel.updateOne(filter, update);
      }

      memoryStore[storeKey].set(updated.id, updated);
      return { modifiedCount: 1, doc: updated };
    },

    async findOneAndUpdate(filter, update, options = {}) {
      await this.updateOne(filter, update);
      return this.findOne(filter);
    },

    async deleteOne(filter) {
      const doc = await this.findOne(filter);
      if (!doc) return { deletedCount: 0 };

      const status = getDatabaseStatus();
      if (!status.isInMemoryFallback && mongoose.connection.readyState === 1) {
        return await MongooseModel.deleteOne(filter);
      }

      memoryStore[storeKey].delete(doc.id);
      return { deletedCount: 1 };
    },

    async deleteMany(filter = {}) {
      const status = getDatabaseStatus();
      if (!status.isInMemoryFallback && mongoose.connection.readyState === 1) {
        return await MongooseModel.deleteMany(filter);
      }

      const docs = await this.find(filter);
      let count = 0;
      for (const d of docs) {
        memoryStore[storeKey].delete(d.id);
        count++;
      }
      return { deletedCount: count };
    },

    async countDocuments(filter = {}) {
      const docs = await this.find(filter);
      return docs.length;
    }
  };
}

export const Models = {
  Facility: createModelWrapper('Facility', FacilitySchema, 'facilities'),
  User: createModelWrapper('User', UserSchema, 'users'),
  Patient: createModelWrapper('Patient', PatientSchema, 'patients'),
  HealthAssessment: createModelWrapper('HealthAssessment', HealthAssessmentSchema, 'healthAssessments'),
  MaternalRecord: createModelWrapper('MaternalRecord', MaternalRecordSchema, 'maternalRecords'),
  AntenatalVisit: createModelWrapper('AntenatalVisit', AntenatalVisitSchema, 'antenatalVisits'),
  ChildRecord: createModelWrapper('ChildRecord', ChildRecordSchema, 'childRecords'),
  GrowthRecord: createModelWrapper('GrowthRecord', GrowthRecordSchema, 'growthRecords'),
  Immunization: createModelWrapper('Immunization', ImmunizationSchema, 'immunizations'),
  ChronicCondition: createModelWrapper('ChronicCondition', ChronicConditionSchema, 'chronicConditions'),
  Referral: createModelWrapper('Referral', ReferralSchema, 'referrals'),
  FollowUp: createModelWrapper('FollowUp', FollowUpSchema, 'followUps'),
  KnowledgeArticle: createModelWrapper('KnowledgeArticle', KnowledgeArticleSchema, 'knowledgeArticles'),
  DocumentAnalysis: createModelWrapper('DocumentAnalysis', DocumentAnalysisSchema, 'documentAnalyses'),
  SyncOperation: createModelWrapper('SyncOperation', SyncOperationSchema, 'syncOperations'),
  AuditLog: createModelWrapper('AuditLog', AuditLogSchema, 'auditLogs')
};
