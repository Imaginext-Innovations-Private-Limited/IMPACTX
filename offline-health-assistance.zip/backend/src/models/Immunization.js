import { Models } from './schemas.js';
export default Models.Immunization;
