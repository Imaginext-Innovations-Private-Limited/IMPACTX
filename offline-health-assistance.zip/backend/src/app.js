import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { ENV } from './config/environment.js';
import { apiRateLimiter } from './middleware/rateLimiter.js';
import { errorHandler } from './middleware/errorHandler.js';
import { getDatabaseStatus } from './config/database.js';

import authRoutes from './routes/authRoutes.js';
import patientRoutes from './routes/patientRoutes.js';
import clinicalRoutes from './routes/clinicalRoutes.js';
import syncRoutes from './routes/syncRoutes.js';
import reportRoutes from './routes/reportRoutes.js';
import documentRoutes from './routes/documentRoutes.js';
import assistantRoutes from './routes/assistantRoutes.js';

const app = express();

// Security Middlewares
app.use(helmet());
app.use(cors({
  origin: [ENV.FRONTEND_URL, 'http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Apply rate limiting to all /api routes
app.use('/api', apiRateLimiter);

// System Health & Connectivity Check Endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'Offline Health Central Cloud API',
    version: '1.0.0',
    database: getDatabaseStatus()
  });
});

// Route Mounts
app.use('/api/auth', authRoutes);
app.use('/api/patients', patientRoutes);
app.use('/api', clinicalRoutes);
app.use('/api/sync', syncRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/assistant', assistantRoutes);

// 404 Handler
app.use('*', (req, res) => {
  res.status(404).json({ success: false, error: `Route not found: ${req.method} ${req.originalUrl}` });
});

// Central Error Handler
app.use(errorHandler);

export default app;
