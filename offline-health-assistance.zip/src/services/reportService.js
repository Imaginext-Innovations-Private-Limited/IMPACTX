import { db } from '../db/db';

export const ReportService = {
  /**
   * Aggregate maternal health indicators
   */
  async getMaternalIndicators() {
    const [maternalRecords, ancVisits, patients] = await Promise.all([
      db.maternalRecords.toArray(),
      db.antenatalVisits.toArray(),
      db.patients.toArray()
    ]);

    const totalPregnancies = maternalRecords.length;
    const activePregnancies = maternalRecords.filter(m => m.status === 'active').length;
    const hrpCount = maternalRecords.filter(m => m.isHighRisk).length;
    const trimester1Count = maternalRecords.filter(m => m.trimester === 1).length;
    const deliveredCount = maternalRecords.filter(m => m.status === 'delivered').length;
    const institutionalDeliveries = maternalRecords.filter(m => m.deliveryType === 'institutional').length;

    const earlyRegistrationRate = totalPregnancies > 0 
      ? Math.round((trimester1Count / totalPregnancies) * 100) 
      : 0;

    return {
      totalPregnancies,
      activePregnancies,
      hrpCount,
      trimester1Count,
      earlyRegistrationRate,
      totalAncVisits: ancVisits.length,
      deliveredCount,
      institutionalDeliveries,
      institutionalDeliveryRate: deliveredCount > 0 
        ? Math.round((institutionalDeliveries / deliveredCount) * 100) 
        : 100
    };
  },

  /**
   * Aggregate child health & immunization indicators
   */
  async getChildIndicators() {
    const [children, immunizations, growthRecords] = await Promise.all([
      db.childRecords.toArray(),
      db.immunizations.toArray(),
      db.growthRecords.toArray()
    ]);

    const totalChildren = children.length;
    const lowBirthWeightCount = children.filter(c => parseFloat(c.birthWeight) < 2.5).length;
    
    // Fully immunized check: child has BCG, OPV-3, Pentavalent-3, MR-1
    const givenImmunizations = immunizations.filter(i => i.status === 'administered');
    const childVaccineMap = {};
    givenImmunizations.forEach(i => {
      const cid = i.childId || i.patientId;
      if (!childVaccineMap[cid]) childVaccineMap[cid] = new Set();
      childVaccineMap[cid].add(i.vaccineName);
    });

    let fullyImmunizedCount = 0;
    children.forEach(c => {
      const vaxSet = childVaccineMap[c.id] || childVaccineMap[c.patientId] || new Set();
      if (vaxSet.has('BCG') && (vaxSet.has('Pentavalent-1') || vaxSet.has('Pentavalent-3'))) {
        fullyImmunizedCount++;
      }
    });

    // Malnutrition from latest growth records
    const samCount = growthRecords.filter(g => parseFloat(g.muacCm) < 11.5).length;
    const mamCount = growthRecords.filter(g => {
      const muac = parseFloat(g.muacCm);
      return muac >= 11.5 && muac < 12.5;
    }).length;

    const fullCoverageRate = totalChildren > 0 
      ? Math.round((fullyImmunizedCount / totalChildren) * 100) 
      : 0;

    return {
      totalChildren,
      lowBirthWeightCount,
      lowBirthWeightRate: totalChildren > 0 ? Math.round((lowBirthWeightCount / totalChildren) * 100) : 0,
      fullyImmunizedCount,
      fullCoverageRate,
      samCount,
      mamCount,
      totalGrowthScreenings: growthRecords.length
    };
  },

  /**
   * Aggregate NCD screening and control indicators
   */
  async getNcdIndicators() {
    const [conditions, assessments] = await Promise.all([
      db.chronicConditions.toArray(),
      db.healthAssessments.toArray()
    ]);

    const htnCases = conditions.filter(c => c.conditionName?.includes('Hypertension')).length;
    const diabetesCases = conditions.filter(c => c.conditionName?.includes('Diabetes')).length;

    const vitalsWithBp = assessments.filter(a => a.systolicBp && a.diastolicBp);
    const controlledBp = vitalsWithBp.filter(a => a.systolicBp < 140 && a.diastolicBp < 90).length;

    const vitalsWithRbs = assessments.filter(a => a.bloodGlucose);
    const controlledRbs = vitalsWithRbs.filter(a => a.bloodGlucose < 140).length;

    const bpControlRate = vitalsWithBp.length > 0 ? Math.round((controlledBp / vitalsWithBp.length) * 100) : 0;
    const rbsControlRate = vitalsWithRbs.length > 0 ? Math.round((controlledRbs / vitalsWithRbs.length) * 100) : 0;

    return {
      totalNcdConditions: conditions.length,
      htnCases,
      diabetesCases,
      totalVitalsScreened: assessments.length,
      controlledBp,
      bpControlRate,
      controlledRbs,
      rbsControlRate
    };
  },

  /**
   * Aggregate referral audit metrics
   */
  async getReferralAuditIndicators() {
    const referrals = await db.referrals.toArray();
    const total = referrals.length;
    const emergencyCount = referrals.filter(r => r.urgency === 'emergency').length;
    const ambulanceCount = referrals.filter(r => r.ambulanceDispatched === true).length;
    const reviewedCount = referrals.filter(r => Boolean(r.doctorFeedback) || r.status === 'accepted' || r.status === 'completed').length;
    const completedCount = referrals.filter(r => r.status === 'completed').length;

    const reviewRate = total > 0 ? Math.round((reviewedCount / total) * 100) : 0;
    const completionRate = total > 0 ? Math.round((completedCount / total) * 100) : 0;

    return {
      totalReferrals: total,
      emergencyCount,
      ambulanceCount,
      reviewedCount,
      reviewRate,
      completedCount,
      completionRate
    };
  },

  /**
   * Village Health and Nutrition Day (VHND) Summary
   */
  async getVhndMonthlySummary() {
    const [patients, maternal, children, referrals] = await Promise.all([
      db.patients.toArray(),
      db.maternalRecords.toArray(),
      db.childRecords.toArray(),
      db.referrals.toArray()
    ]);

    const villageMap = {};

    patients.forEach(p => {
      const v = p.villageHamlet || 'Rampur Central';
      if (!villageMap[v]) {
        villageMap[v] = {
          villageName: v,
          totalPopulation: 0,
          registeredMothers: 0,
          registeredChildren: 0,
          highRiskCases: 0,
          referralsEscalated: 0
        };
      }
      villageMap[v].totalPopulation++;
      if (p.riskLevel === 'high') {
        villageMap[v].highRiskCases++;
      }
    });

    maternal.forEach(m => {
      const pat = patients.find(p => p.id === m.patientId || p.patientId === m.patientId);
      const v = pat?.villageHamlet || 'Rampur Central';
      if (villageMap[v]) villageMap[v].registeredMothers++;
    });

    children.forEach(c => {
      const pat = patients.find(p => p.id === c.patientId || p.patientId === c.patientId);
      const v = pat?.villageHamlet || 'Rampur Central';
      if (villageMap[v]) villageMap[v].registeredChildren++;
    });

    referrals.forEach(r => {
      const pat = patients.find(p => p.id === r.patientId || p.patientId === r.patientId);
      const v = pat?.villageHamlet || 'Rampur Central';
      if (villageMap[v]) villageMap[v].referralsEscalated++;
    });

    return Object.values(villageMap);
  },

  /**
   * Convert array of data rows to CSV string and initiate browser download
   */
  exportToCsv(filename, headers, rows) {
    if (!rows || !rows.length) {
      alert('No data rows available to export.');
      return;
    }

    const headerLine = headers.map(h => `"${h.label.replace(/"/g, '""')}"`).join(',');
    const dataLines = rows.map(row => {
      return headers.map(h => {
        let val = row[h.key];
        if (val === null || val === undefined) val = '';
        return `"${String(val).replace(/"/g, '""')}"`;
      }).join(',');
    });

    const csvContent = [headerLine, ...dataLines].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
};
