import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';
import { ClinicalCalculators } from '../utils/clinicalCalculators';

const deviceId = getOrCreateDeviceId();

export const ChildService = {
  /**
   * 1. Live Child Healthcare Statistics
   */
  async getDashboardStats() {
    try {
      const allPatients = await db.patients.filter(p => !p.isDeleted && (p.category === 'child' || (p.age !== undefined && p.age <= 5))).toArray();
      const allGrowth = await db.growthRecords.toArray();
      const allImmunizations = await db.immunizations.toArray();

      let total = allPatients.length;
      let normalGrowth = 0;
      let mamCount = 0;
      let samCount = 0;
      let overdueVaccines = 0;
      let upToDateCount = 0;

      // Group growth by patientId
      const latestGrowthByPatient = new Map();
      allGrowth.forEach(g => {
        const existing = latestGrowthByPatient.get(g.patientId);
        if (!existing || new Date(g.createdAt || 0) > new Date(existing.createdAt || 0)) {
          latestGrowthByPatient.set(g.patientId, g);
        }
      });

      // Group immunizations by patientId
      const immunizationsByPatient = new Map();
      allImmunizations.forEach(imm => {
        const list = immunizationsByPatient.get(imm.patientId) || [];
        list.push(imm);
        immunizationsByPatient.set(imm.patientId, list);
      });

      allPatients.forEach(p => {
        const growth = latestGrowthByPatient.get(p.id) || latestGrowthByPatient.get(p.patientId);
        if (growth) {
          const grade = (growth.nutritionGrade || '').toLowerCase();
          if (grade.includes('sam') || (growth.muacCm > 0 && growth.muacCm < 11.5)) {
            samCount++;
          } else if (grade.includes('mam') || (growth.muacCm >= 11.5 && growth.muacCm < 12.5)) {
            mamCount++;
          } else {
            normalGrowth++;
          }
        } else {
          normalGrowth++;
        }

        const vaxList = immunizationsByPatient.get(p.id) || immunizationsByPatient.get(p.patientId) || [];
        const uip = ClinicalCalculators.getUipImmunizationSchedule(p.dateOfBirth, vaxList);
        const hasOverdue = uip.some(v => v.status === 'overdue');
        if (hasOverdue) {
          overdueVaccines++;
        } else {
          upToDateCount++;
        }
      });

      return {
        total,
        normalGrowth,
        mamCount,
        samCount,
        overdueVaccines,
        upToDateCount
      };
    } catch (err) {
      console.error('[ChildService] Failed to compute stats:', err);
      return { total: 0, normalGrowth: 0, mamCount: 0, samCount: 0, overdueVaccines: 0, upToDateCount: 0 };
    }
  },

  /**
   * 2. Query Child Cohort with Filters
   */
  async getChildRecords({ query = '', nutritionFilter = 'all', immunizationFilter = 'all', village = 'all' } = {}) {
    try {
      const allPatients = await db.patients.filter(p => !p.isDeleted && (p.category === 'child' || (p.age !== undefined && p.age <= 5))).toArray();
      const allChildRecords = await db.childRecords.toArray();
      const allGrowth = await db.growthRecords.toArray();
      const allImmunizations = await db.immunizations.toArray();

      const birthMap = new Map();
      allChildRecords.forEach(c => {
        if (c.patientId) birthMap.set(c.patientId, c);
        if (c.id) birthMap.set(c.id, c);
      });

      const growthByPatient = new Map();
      allGrowth.forEach(g => {
        const list = growthByPatient.get(g.patientId) || [];
        list.push(g);
        growthByPatient.set(g.patientId, list);
      });

      const vaxByPatient = new Map();
      allImmunizations.forEach(i => {
        const list = vaxByPatient.get(i.patientId) || [];
        list.push(i);
        vaxByPatient.set(i.patientId, list);
      });

      let enriched = allPatients.map(patient => {
        const birth = birthMap.get(patient.id) || birthMap.get(patient.patientId) || null;
        const growths = growthByPatient.get(patient.id) || growthByPatient.get(patient.patientId) || [];
        growths.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        const latestGrowth = growths[0] || null;

        const vaxList = vaxByPatient.get(patient.id) || vaxByPatient.get(patient.patientId) || [];
        const uipSchedule = ClinicalCalculators.getUipImmunizationSchedule(patient.dateOfBirth, vaxList);

        const administeredCount = uipSchedule.filter(v => v.status === 'administered').length;
        const overdueCount = uipSchedule.filter(v => v.status === 'overdue').length;

        // Malnutrition Classification
        let nutritionGrade = 'Normal Growth';
        let nutritionBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
        let isSam = false;
        let isMam = false;

        if (latestGrowth) {
          const muac = parseFloat(latestGrowth.muacCm);
          if (muac > 0 && muac < 11.5) {
            nutritionGrade = 'SAM (Severe Acute Malnutrition)';
            nutritionBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-black';
            isSam = true;
          } else if (muac >= 11.5 && muac < 12.5) {
            nutritionGrade = 'MAM (Moderate Acute Malnutrition)';
            nutritionBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
            isMam = true;
          } else if (latestGrowth.nutritionGrade?.includes('SAM')) {
            nutritionGrade = 'SAM (Severe Acute Malnutrition)';
            nutritionBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-black';
            isSam = true;
          }
        }

        return {
          ...patient,
          patient,
          birth,
          latestGrowth,
          growthCount: growths.length,
          growths,
          uipSchedule,
          vaxList,
          administeredCount,
          overdueCount,
          nutritionGrade,
          nutritionBadge,
          isSam,
          isMam
        };
      });

      // Search Query
      if (query.trim()) {
        const q = query.toLowerCase().trim();
        enriched = enriched.filter(c =>
          c.name?.toLowerCase().includes(q) ||
          c.patientId?.toLowerCase().includes(q) ||
          c.contactNumber?.includes(q) ||
          c.villageHamlet?.toLowerCase().includes(q)
        );
      }

      // Nutrition Filter
      if (nutritionFilter === 'sam') {
        enriched = enriched.filter(c => c.isSam);
      } else if (nutritionFilter === 'mam') {
        enriched = enriched.filter(c => c.isMam);
      } else if (nutritionFilter === 'normal') {
        enriched = enriched.filter(c => !c.isSam && !c.isMam);
      }

      // Immunization Filter
      if (immunizationFilter === 'overdue') {
        enriched = enriched.filter(c => c.overdueCount > 0);
      } else if (immunizationFilter === 'uptodate') {
        enriched = enriched.filter(c => c.overdueCount === 0);
      }

      // Village Filter
      if (village !== 'all') {
        enriched = enriched.filter(c => c.villageHamlet === village);
      }

      enriched.sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));

      return enriched;
    } catch (err) {
      console.error('[ChildService] Failed to get child records:', err);
      return [];
    }
  },

  /**
   * 3. Get Full Child Profile by ID
   */
  async getChildById(id) {
    try {
      let patient = await db.patients.get(id);
      if (!patient) {
        patient = await db.patients.where('patientId').equals(id).first() || null;
      }
      if (!patient) return null;

      const birth = await db.childRecords.where('patientId').equals(patient.id).first() ||
                    await db.childRecords.where('patientId').equals(patient.patientId).first() || null;

      let growths = await db.growthRecords.where('patientId').equals(patient.id).toArray();
      if (growths.length === 0) {
        growths = await db.growthRecords.where('patientId').equals(patient.patientId).toArray();
      }
      growths.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));

      let immunizations = await db.immunizations.where('patientId').equals(patient.id).toArray();
      if (immunizations.length === 0) {
        immunizations = await db.immunizations.where('patientId').equals(patient.patientId).toArray();
      }

      const referrals = await db.referrals.where('patientId').equals(patient.id).toArray();
      const followUps = await db.followUps.where('patientId').equals(patient.id).toArray();

      const uipSchedule = ClinicalCalculators.getUipImmunizationSchedule(patient.dateOfBirth, immunizations);

      let mother = null;
      if (birth?.motherId) {
        mother = await db.patients.get(birth.motherId) ||
                 await db.patients.where('patientId').equals(birth.motherId).first() || null;
      }

      return {
        patient,
        birth,
        mother,
        growths,
        immunizations,
        referrals,
        followUps,
        uipSchedule
      };
    } catch (err) {
      console.error('[ChildService] Failed to get child by id:', err);
      return null;
    }
  },

  /**
   * 4. Register a Child (Under-5 Registration)
   */
  async registerChild(data, user) {
    const timestamp = new Date().toISOString();
    const id = `pat-${Date.now()}`;
    const patientId = data.patientId || `PAT-CH-${Date.now().toString().slice(-4)}`;

    const birthWeight = parseFloat(data.birthWeight) || 2.8;
    const isLbw = birthWeight < 2.5;

    const patient = {
      id,
      patientId,
      name: data.name,
      gender: data.gender || 'male',
      age: parseInt(data.age, 10) || 0,
      dateOfBirth: data.dateOfBirth,
      contactNumber: data.contactNumber || '',
      emergencyContact: data.emergencyContact || (data.motherName ? `Mother: ${data.motherName}` : ''),
      villageHamlet: data.villageHamlet,
      wardNumber: data.wardNumber || 'Ward 1',
      houseNumber: data.houseNumber || '',
      bloodGroup: data.bloodGroup || '',
      riskLevel: isLbw ? 'high' : 'normal',
      category: 'child',
      isPregnant: false,
      chronicConditions: isLbw ? ['Low Birth Weight (LBW)'] : [],
      allergies: data.allergies || 'None',
      consentGiven: true,
      syncStatus: 'pending',
      version: 1,
      isDeleted: false,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.patients.add(patient);

    // Create birth record
    const chRecordId = `ch-${Date.now()}`;
    const birthRecord = {
      id: chRecordId,
      patientId: id,
      motherId: data.motherId || '',
      birthWeight,
      gestationalAge: parseInt(data.gestationalAge, 10) || 38,
      deliveryType: data.deliveryType || 'Institutional (PHC)',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };
    await db.childRecords.add(birthRecord);

    // Initial UIP Birth Doses (BCG, OPV-0, Hepatitis B-0)
    const birthVax = [
      { name: 'BCG', key: 'BCG', dose: 1 },
      { name: 'OPV-0', key: 'OPV-0', dose: 0 },
      { name: 'Hepatitis B (Birth Dose)', key: 'HepB-0', dose: 0 }
    ];

    for (const v of birthVax) {
      const immId = `imm-${Date.now()}-${v.key}`;
      const isGiven = (data.vaccinesGivenAtBirth || []).includes(v.key) || (data.vaccinesGivenAtBirth || []).includes(v.name);
      await db.immunizations.add({
        id: immId,
        childId: chRecordId,
        patientId: id,
        vaccineName: v.name,
        vaccineKey: v.key,
        doseNumber: v.dose,
        dueDate: data.dateOfBirth,
        givenDate: isGiven ? data.dateOfBirth : null,
        status: isGiven ? 'administered' : 'scheduled',
        administeredBy: isGiven ? (user?.name || 'PHC Staff Nurse') : null,
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });
    }

    // Schedule 6-Week Immunization Follow-up
    const dobDate = new Date(data.dateOfBirth);
    const sixWeeksDue = new Date(dobDate.getTime() + (42 * 24 * 60 * 60 * 1000)).toISOString().slice(0, 10);
    const fuId = `fu-${Date.now()}-vax6w`;
    await db.followUps.add({
      id: fuId,
      patientId: id,
      scheduledDate: sixWeeksDue,
      visitType: '6-Week Universal Immunization (Pentavalent-1 + Rota-1 + OPV-1)',
      priority: 'routine',
      isCompleted: false,
      notes: `Bring child to Anganwadi/Sub-Centre for 6-week immunization session.`,
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    });

    // Queue sync
    await db.syncQueue.add({
      entity: 'patients',
      entityId: id,
      operation: 'CREATE',
      payload: patient,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit Log
    await db.auditLogs.add({
      entity: 'childRecords',
      entityId: chRecordId,
      action: 'CHILD_REGISTERED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Registered infant ${patient.name} (${patientId}). Birth weight: ${birthWeight} kg`
    });

    return { patient, birthRecord };
  },

  /**
   * 5. Record Child Growth & Malnutrition Screening (MUAC)
   */
  async recordGrowthMeasurement(data, user) {
    const timestamp = new Date().toISOString();
    const id = `gr-${Date.now()}`;

    const child = await db.patients.get(data.patientId);
    if (!child) throw new Error('Child patient record not found');

    const ageMonths = parseInt(data.ageMonths, 10) || (child.age * 12) || 0;
    const growthEval = ClinicalCalculators.classifyPediatricGrowth(
      ageMonths,
      child.gender,
      data.weightKg,
      data.heightCm,
      data.muacCm
    );

    const record = {
      id,
      childId: data.childId || data.patientId,
      patientId: data.patientId,
      ageMonths,
      weightKg: parseFloat(data.weightKg) || 0,
      heightCm: parseFloat(data.heightCm) || 0,
      muacCm: parseFloat(data.muacCm) || 0,
      nutritionGrade: growthEval.overallGrade,
      warningSigns: growthEval.alerts,
      measuredBy: user?.name || 'ASHA Worker',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.growthRecords.add(record);

    // Update child risk level if SAM or MAM
    if (growthEval.isEmergency || growthEval.overallGrade.includes('SAM')) {
      await db.patients.update(data.patientId, {
        riskLevel: 'high',
        chronicConditions: Array.from(new Set([...(child.chronicConditions || []), 'Severe Acute Malnutrition (SAM)'])),
        updatedAt: timestamp
      });

      // Auto-create Emergency NRC Referral
      const refId = `ref-${Date.now()}`;
      await db.referrals.add({
        id: refId,
        patientId: data.patientId,
        urgency: 'emergency',
        status: 'referred',
        referralFacility: 'Nutrition Rehabilitation Centre (NRC) / Taluka Hospital',
        reason: `Pediatric Emergency: Severe Acute Malnutrition (SAM). MUAC ${data.muacCm} cm, Weight ${data.weightKg} kg at ${ageMonths} months`,
        referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'ASHA Worker',
        doctorFeedback: '',
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });

      await db.syncQueue.add({
        entity: 'referrals',
        entityId: refId,
        operation: 'CREATE',
        payload: { id: refId, patientId: data.patientId, urgency: 'emergency' },
        status: 'pending',
        retryCount: 0,
        createdAt: timestamp
      });
    } else if (growthEval.isMalnourished) {
      await db.patients.update(data.patientId, {
        riskLevel: 'moderate',
        chronicConditions: Array.from(new Set([...(child.chronicConditions || []), 'Moderate Acute Malnutrition (MAM)'])),
        updatedAt: timestamp
      });
    }

    // Queue sync
    await db.syncQueue.add({
      entity: 'growthRecords',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'growthRecords',
      entityId: id,
      action: 'PEDIATRIC_GROWTH_RECORDED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Growth evaluated for ${data.patientId}: Wt ${data.weightKg} kg, MUAC ${data.muacCm} cm. Grade: ${growthEval.overallGrade}`
    });

    return { record, growthEval };
  },

  /**
   * 6. Administer / Update Universal Immunization
   */
  async recordImmunization(data, user) {
    const timestamp = new Date().toISOString();
    const id = data.id || `imm-${Date.now()}-${data.vaccineKey || 'vax'}`;

    const record = {
      id,
      childId: data.childId || data.patientId,
      patientId: data.patientId,
      vaccineName: data.vaccineName,
      vaccineKey: data.vaccineKey || '',
      doseNumber: parseInt(data.doseNumber, 10) || 1,
      dueDate: data.dueDate,
      givenDate: data.givenDate || timestamp.slice(0, 10),
      status: 'administered',
      batchNumber: data.batchNumber || '',
      administeredBy: user?.name || 'ANM Healthcare Staff',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.immunizations.put(record);

    await db.syncQueue.add({
      entity: 'immunizations',
      entityId: id,
      operation: 'UPDATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'immunizations',
      entityId: id,
      action: 'VACCINE_ADMINISTERED',
      performedBy: user?.name || 'Local Staff',
      role: user?.role || 'anm',
      timestamp,
      details: `Administered ${data.vaccineName} to ${data.patientId} on ${record.givenDate}`
    });

    return record;
  },

  /**
   * 7. 1-Click Referral Dispatch from Child View
   */
  async createReferralFromChild(child, reason, facility, urgency = 'urgent', user) {
    const timestamp = new Date().toISOString();
    const id = `ref-${Date.now()}`;

    const record = {
      id,
      patientId: child.id || child.patientId,
      urgency,
      status: 'referred',
      referralFacility: facility || 'Taluka Hospital (Pediatrics) / NRC',
      reason: reason || 'Pediatric clinical evaluation required',
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Community Worker',
      doctorFeedback: '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.referrals.add(record);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  },

  /**
   * 8. 1-Click Follow-Up Scheduler for Child
   */
  async scheduleFollowUpFromChild(child, visitType, scheduledDate, notes, priority = 'routine', user) {
    const timestamp = new Date().toISOString();
    const id = `fu-${Date.now()}`;

    const record = {
      id,
      patientId: child.id || child.patientId,
      scheduledDate: scheduledDate || timestamp.slice(0, 10),
      visitType: visitType || 'Child Growth & Immunization Follow-up',
      priority,
      isCompleted: false,
      notes: notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.followUps.add(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  }
};
