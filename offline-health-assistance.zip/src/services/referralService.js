import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';

const deviceId = getOrCreateDeviceId();

export const ReferralService = {
  /**
   * Get referral metrics for dashboard cards
   */
  async getDashboardStats() {
    const all = await db.referrals.toArray();
    
    return {
      total: all.length,
      emergency: all.filter(r => r.urgency === 'emergency').length,
      urgent: all.filter(r => r.urgency === 'urgent').length,
      routine: all.filter(r => r.urgency === 'routine').length,
      pendingDoctorReview: all.filter(r => r.status === 'pending_doctor_review' || r.status === 'referred').length,
      acceptedAdmitted: all.filter(r => r.status === 'accepted').length,
      completed: all.filter(r => r.status === 'completed').length,
      ambulanceDispatched: all.filter(r => r.ambulanceDispatched === true).length
    };
  },

  /**
   * Get referrals list with joined patient data and filters
   */
  async getReferrals({ query = '', urgencyFilter = 'all', statusFilter = 'all', facilityFilter = 'all', villageFilter = 'all' } = {}) {
    const [referrals, patients] = await Promise.all([
      db.referrals.toArray(),
      db.patients.toArray()
    ]);

    // Build patient map supporting both internal id and formatted patientId
    const patientMap = {};
    patients.forEach(p => {
      if (p.id) patientMap[p.id] = p;
      if (p.patientId) patientMap[p.patientId] = p;
    });

    // Join referrals with patient demographics
    let combined = referrals.map(ref => {
      const pat = patientMap[ref.patientId] || {};
      return {
        ...ref,
        patientName: pat.name || 'Unknown Patient',
        patientAge: pat.age,
        patientGender: pat.gender,
        patientVillage: pat.villageHamlet || 'Unknown Village',
        patientContact: pat.contactNumber,
        patientAbha: pat.abhaId,
        patientRiskLevel: pat.riskLevel || 'normal'
      };
    });

    // Sort newest first
    combined.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

    // Apply filters
    if (query.trim()) {
      const q = query.toLowerCase().trim();
      combined = combined.filter(r =>
        (r.patientName && r.patientName.toLowerCase().includes(q)) ||
        (r.patientId && r.patientId.toLowerCase().includes(q)) ||
        (r.id && r.id.toLowerCase().includes(q)) ||
        (r.reason && r.reason.toLowerCase().includes(q)) ||
        (r.referralFacility && r.referralFacility.toLowerCase().includes(q))
      );
    }

    if (urgencyFilter !== 'all') {
      combined = combined.filter(r => r.urgency === urgencyFilter);
    }

    if (statusFilter !== 'all') {
      combined = combined.filter(r => r.status === statusFilter);
    }

    if (facilityFilter !== 'all') {
      combined = combined.filter(r => r.referralFacility && r.referralFacility.includes(facilityFilter));
    }

    if (villageFilter !== 'all') {
      combined = combined.filter(r => r.patientVillage === villageFilter);
    }

    return combined;
  },

  /**
   * Get detailed referral dossier by ID
   */
  async getReferralById(id) {
    const ref = await db.referrals.get(id);
    if (!ref) return null;

    const patient = await db.patients.where('id').equals(ref.patientId).first() ||
                    await db.patients.where('patientId').equals(ref.patientId).first();

    return {
      ...ref,
      patient
    };
  },

  /**
   * Create an emergency or urgent clinical referral
   */
  async createReferral(data, user) {
    const timestamp = new Date().toISOString();
    const id = `ref-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      urgency: data.urgency || 'urgent', // emergency, urgent, routine
      status: data.status || 'referred', // referred, pending_doctor_review, accepted, completed, cancelled
      referralFacility: data.referralFacility,
      facilityType: data.facilityType || 'Community Health Centre',
      reason: data.reason,
      provisionalDiagnosis: data.provisionalDiagnosis || '',
      transportation: data.transportation || '108 Ambulance',
      ambulanceDispatched: data.ambulanceDispatched || (data.transportation === '108 Ambulance'),
      ambulanceDetails: data.ambulanceDetails || '',
      accompaniedByAsha: data.accompaniedByAsha ?? true,
      ashaWorkerName: user?.name || data.ashaWorkerName || 'Community Health Worker',
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Community Health Worker',
      vitalsAtReferral: {
        systolicBp: data.systolicBp ? parseInt(data.systolicBp, 10) : null,
        diastolicBp: data.diastolicBp ? parseInt(data.diastolicBp, 10) : null,
        pulse: data.pulse ? parseInt(data.pulse, 10) : null,
        spo2: data.spo2 ? parseInt(data.spo2, 10) : null,
        bloodGlucose: data.bloodGlucose ? parseInt(data.bloodGlucose, 10) : null,
        temperature: data.temperature ? parseFloat(data.temperature) : null
      },
      doctorFeedback: data.doctorFeedback || '',
      actionPlan: data.actionPlan || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.referrals.add(record);

    // Queue for cloud synchronization
    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log entry
    await db.auditLogs.add({
      entity: 'referrals',
      entityId: id,
      action: 'CLINICAL_REFERRAL_CREATED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Referral created for ${data.patientId} to ${data.referralFacility} (${data.urgency.toUpperCase()}). Ambulance: ${record.ambulanceDispatched ? 'YES' : 'NO'}`
    });

    // Auto-create a follow-up reminder if emergency/urgent
    if (data.autoScheduleFollowUp !== false) {
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + (data.urgency === 'emergency' ? 2 : 4));
      
      const fuId = `fu-${Date.now()}`;
      const followUpRecord = {
        id: fuId,
        patientId: data.patientId,
        scheduledDate: followUpDate.toISOString().slice(0, 10),
        visitType: 'Post-Referral Hospital Outcome Check',
        priority: data.urgency === 'emergency' ? 'urgent' : 'high',
        isCompleted: false,
        notes: `Check hospital discharge status, medication adherence, and clinical recovery following referral to ${data.referralFacility}.`,
        referralId: id,
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      };

      await db.followUps.add(followUpRecord);
      await db.syncQueue.add({
        entity: 'followUps',
        entityId: fuId,
        operation: 'CREATE',
        payload: followUpRecord,
        status: 'pending',
        retryCount: 0,
        createdAt: timestamp
      });
    }

    return record;
  },

  /**
   * Update doctor clinical review and triage feedback
   */
  async updateDoctorFeedback(id, feedbackData, user) {
    const timestamp = new Date().toISOString();
    const existing = await db.referrals.get(id);
    if (!existing) throw new Error(`Referral with ID ${id} not found.`);

    const updated = {
      ...existing,
      doctorFeedback: feedbackData.doctorFeedback || existing.doctorFeedback,
      doctorName: feedbackData.doctorName || existing.doctorName || 'Attending Medical Officer',
      hospitalName: feedbackData.hospitalName || existing.referralFacility,
      triageDecision: feedbackData.triageDecision || existing.triageDecision || 'Admitted for Inpatient Care',
      treatmentPrescribed: feedbackData.treatmentPrescribed || existing.treatmentPrescribed || '',
      status: feedbackData.status || (feedbackData.triageDecision === 'Outpatient Treated & Discharged' ? 'completed' : 'accepted'),
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.referrals.put(updated);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'referrals',
      entityId: id,
      action: 'DOCTOR_FEEDBACK_RECORDED',
      performedBy: user?.name || feedbackData.doctorName || 'Medical Officer',
      role: 'doctor',
      timestamp,
      details: `Doctor review recorded for referral ${id}: ${updated.status}. Decision: ${updated.triageDecision}`
    });

    return updated;
  },

  /**
   * Update referral lifecycle status
   */
  async updateReferralStatus(id, newStatus, user) {
    const timestamp = new Date().toISOString();
    const existing = await db.referrals.get(id);
    if (!existing) throw new Error(`Referral with ID ${id} not found.`);

    const updated = {
      ...existing,
      status: newStatus,
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.referrals.put(updated);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return updated;
  },

  /**
   * Quick dispatch 108 Emergency Ambulance for a referral
   */
  async dispatch108Ambulance(id, ambulanceInfo, user) {
    const timestamp = new Date().toISOString();
    const existing = await db.referrals.get(id);
    if (!existing) throw new Error(`Referral with ID ${id} not found.`);

    const updated = {
      ...existing,
      ambulanceDispatched: true,
      ambulanceDetails: ambulanceInfo || '108 Ambulance Unit Dispatched from Taluka Base',
      urgency: 'emergency',
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.referrals.put(updated);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'referrals',
      entityId: id,
      action: 'AMBULANCE_DISPATCH_RECORDED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `108 Ambulance dispatched for referral ${id}`
    });

    return updated;
  }
};
