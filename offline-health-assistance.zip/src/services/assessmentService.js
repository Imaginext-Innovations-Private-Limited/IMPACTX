import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';
import { ClinicalCalculators } from '../utils/clinicalCalculators';

const deviceId = getOrCreateDeviceId();

export const AssessmentService = {
  /**
   * Compute real-time dashboard statistics from IndexedDB
   */
  async getDashboardStats() {
    const allAssessments = await db.healthAssessments.toArray();
    const allPatients = await db.patients.filter(p => !p.isDeleted).toArray();
    const allReferrals = await db.referrals.toArray();
    const allFollowUps = await db.followUps.toArray();

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const thisMonthStr = now.toISOString().slice(0, 7);

    let todayCount = 0;
    let thisMonthCount = 0;
    let withWarningsCount = 0;
    let requiringFollowUpCount = 0;
    let completedCount = 0;
    let partialCount = 0;

    const highPriorityAlerts = [];

    // Map patient names for quick access
    const patientMap = new Map();
    allPatients.forEach(p => patientMap.set(p.id, p));

    allAssessments.forEach(item => {
      const itemDate = (item.assessmentDate || item.createdAt || '').slice(0, 10);
      const itemMonth = (item.assessmentDate || item.createdAt || '').slice(0, 7);

      if (itemDate === todayStr) todayCount++;
      if (itemMonth === thisMonthStr) thisMonthCount++;

      const isPartial = item.status === 'partial' || (!item.systolicBp && !item.bloodGlucose && !item.weight);
      if (isPartial) partialCount++;
      else completedCount++;

      const hasWarning = (item.warningSigns && item.warningSigns.length > 0) ||
                         (item.warningIndicators && item.warningIndicators.length > 0) ||
                         item.riskLevel === 'urgent_emergency' ||
                         item.riskLevel === 'warning_detected';

      if (hasWarning) {
        withWarningsCount++;
        const p = patientMap.get(item.patientId);
        highPriorityAlerts.push({
          id: item.id,
          patientId: item.patientId,
          patientName: p ? p.name : 'Patient ' + item.patientId,
          village: p ? p.villageHamlet : 'Hamlet',
          warnings: item.warningSigns || item.warningIndicators || ['Clinical alert'],
          date: item.assessmentDate || item.createdAt,
          isEmergency: item.riskLevel === 'urgent_emergency'
        });
      }

      if (item.requiresFollowUp || item.status === 'requires_follow_up' || hasWarning) {
        requiringFollowUpCount++;
      }
    });

    const pendingReferrals = allReferrals.filter(r => r.status === 'referred' || r.status === 'pending').length;

    // Sort high priority alerts: emergencies first, then recent
    highPriorityAlerts.sort((a, b) => {
      if (a.isEmergency && !b.isEmergency) return -1;
      if (!a.isEmergency && b.isEmergency) return 1;
      return new Date(b.date) - new Date(a.date);
    });

    return {
      total: allAssessments.length,
      today: todayCount,
      thisMonth: thisMonthCount,
      withWarnings: withWarningsCount,
      requiringFollowUp: requiringFollowUpCount,
      pendingReferrals,
      completed: completedCount,
      partial: partialCount,
      highPriorityAlerts: highPriorityAlerts.slice(0, 6)
    };
  },

  /**
   * Retrieve filtered assessments joined with patient details
   */
  async getAssessments(filters = {}) {
    let items = await db.healthAssessments.toArray();
    items.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    const allPatients = await db.patients.toArray();
    const patientMap = new Map();
    allPatients.forEach(p => patientMap.set(p.id, p));

    // Enrich with patient metadata
    items = items.map(item => {
      const patient = patientMap.get(item.patientId);
      return {
        ...item,
        patientName: patient ? patient.name : 'Unknown Patient',
        patientAge: patient ? patient.age : 'N/A',
        patientGender: patient ? patient.gender : 'N/A',
        patientVillage: patient ? patient.villageHamlet : 'N/A',
        patientRisk: patient ? patient.riskLevel : 'normal',
        patientCategory: patient ? patient.category : 'general',
        isPregnant: patient ? patient.isPregnant : false
      };
    });

    // Filter by Search Query
    if (filters.search && filters.search.trim()) {
      const q = filters.search.toLowerCase().trim();
      items = items.filter(i =>
        (i.patientName && i.patientName.toLowerCase().includes(q)) ||
        (i.patientId && i.patientId.toLowerCase().includes(q)) ||
        (i.id && i.id.toLowerCase().includes(q)) ||
        (i.patientVillage && i.patientVillage.toLowerCase().includes(q))
      );
    }

    // Filter by Category
    if (filters.category && filters.category !== 'all') {
      items = items.filter(i => (i.assessmentType || '').toLowerCase() === filters.category.toLowerCase());
    }

    // Filter by Risk Tier
    if (filters.riskLevel && filters.riskLevel !== 'all') {
      items = items.filter(i => (i.riskLevel || 'normal').toLowerCase() === filters.riskLevel.toLowerCase());
    }

    // Filter by Date
    if (filters.date) {
      items = items.filter(i => (i.assessmentDate || i.createdAt || '').startsWith(filters.date));
    }

    return items;
  },

  /**
   * Get complete assessment by ID
   */
  async getAssessmentById(id) {
    const item = await db.healthAssessments.get(id);
    if (!item) return null;

    const patient = await db.patients.get(item.patientId);
    let referral = null;
    let followUp = null;

    if (item.referralId) {
      referral = await db.referrals.get(item.referralId);
    }
    if (item.followUpId) {
      followUp = await db.followUps.get(item.followUpId);
    }

    return {
      ...item,
      patient,
      referral,
      followUp
    };
  },

  /**
   * Get patient assessment history with longitudinal trends
   */
  async getPatientHistory(patientId) {
    const records = await db.healthAssessments
      .where('patientId')
      .equals(patientId)
      .toArray();
    records.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));

    // Build trend datasets
    const bpTrends = [];
    const glucoseTrends = [];
    const bmiTrends = [];

    records.forEach(r => {
      const dateLabel = (r.assessmentDate || r.createdAt || '').slice(0, 10);
      if (r.systolicBp && r.diastolicBp) {
        bpTrends.push({
          date: dateLabel,
          systolic: r.systolicBp,
          diastolic: r.diastolicBp
        });
      }
      if (r.bloodGlucose) {
        glucoseTrends.push({
          date: dateLabel,
          glucose: r.bloodGlucose,
          context: r.glucoseContext || 'random'
        });
      }
      if (r.bmi || r.weight) {
        bmiTrends.push({
          date: dateLabel,
          bmi: r.bmi,
          weight: r.weight
        });
      }
    });

    return {
      records: [...records].reverse(),
      bpTrends,
      glucoseTrends,
      bmiTrends
    };
  },

  /**
   * Create a new health assessment with full validation, calculation, and sync queueing
   */
  async createAssessment(data, user) {
    const timestamp = new Date().toISOString();
    const id = `ha-${Date.now()}`;
    const patient = await db.patients.get(data.patientId);

    if (!patient) {
      throw new Error(`Patient with ID "${data.patientId}" was not found in local database.`);
    }

    // 1. Automatic calculations & decision support
    const patientContext = {
      age: patient.age,
      gender: patient.gender,
      isPregnant: patient.isPregnant || data.isPregnant
    };

    const bmiCalc = ClinicalCalculators.calculateBmi(data.height, data.weight, patientContext);
    const evalResult = ClinicalCalculators.evaluateAssessment(data, patientContext);

    // Calculate IDRS if diabetes screening section completed
    let idrsResult = null;
    if (data.screeningResponses?.diabetes) {
      idrsResult = ClinicalCalculators.calculateIdrs(data.screeningResponses.diabetes, patient);
    }

    const calculatedIndicators = {
      bmi: bmiCalc.bmi,
      bmiCategory: bmiCalc.category,
      bmiInterpretation: bmiCalc.interpretation,
      bmiFormula: bmiCalc.formula,
      idrsScore: idrsResult ? idrsResult.score : null,
      idrsTier: idrsResult ? idrsResult.riskTier : null
    };

    const isPartial = !data.systolicBp && !data.bloodGlucose && !data.weight && !data.height;

    const record = {
      id,
      patientId: data.patientId,
      assessmentType: data.assessmentType || 'General Health Screening',
      assessmentDate: data.assessmentDate || timestamp.slice(0, 10),
      assessmentTime: data.assessmentTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      healthcareWorkerId: user?.id || 'worker-local',
      assessedBy: user?.name || 'Community Health Worker',
      facilityId: user?.facilityId || 'FAC-RAMPUR-PHC',
      location: data.location || patient.villageHamlet || 'Community Field Visit',

      // Vital Signs
      systolicBp: parseInt(data.systolicBp, 10) || null,
      diastolicBp: parseInt(data.diastolicBp, 10) || null,
      repeatBp: data.repeatBp || [],
      pulse: parseInt(data.pulse, 10) || null,
      temperature: parseFloat(data.temperature) || null,
      respiratoryRate: parseInt(data.respiratoryRate, 10) || null,
      spo2: parseInt(data.spo2, 10) || null,
      height: parseFloat(data.height) || null,
      weight: parseFloat(data.weight) || null,
      bmi: bmiCalc.bmi,
      bmiInterpretation: bmiCalc.interpretation,
      bloodGlucose: parseFloat(data.bloodGlucose) || null,
      glucoseContext: data.glucoseContext || 'random',
      muacCm: parseFloat(data.muacCm) || null,

      // Rich clinical responses
      vitalSigns: {
        bpPosition: data.bpPosition || 'Sitting',
        bpArm: data.bpArm || 'Right Arm',
        glucoseMethod: data.glucoseMethod || 'Capillary Strip'
      },
      screeningResponses: data.screeningResponses || {},
      calculatedIndicators,
      warningSigns: evalResult.warnings,
      warningIndicators: evalResult.warnings,
      observations: data.observations || '',
      notes: data.notes || '',

      // Status & Triage
      status: isPartial ? 'partial' : evalResult.isEmergency ? 'urgent_emergency' : evalResult.requiresFollowUp ? 'requires_follow_up' : 'completed',
      riskLevel: evalResult.riskTier,
      classification: evalResult.classification,
      requiresFollowUp: evalResult.requiresFollowUp,
      isEmergency: evalResult.isEmergency,

      referralId: data.referralId || null,
      followUpId: data.followUpId || null,

      auditHistory: [
        {
          action: 'CREATED',
          performedBy: user?.name || 'Local Worker',
          role: user?.role || 'worker',
          timestamp,
          reason: 'Initial community assessment recorded.'
        }
      ],

      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    // 2. Save Assessment in Dexie
    await db.healthAssessments.add(record);

    // 3. Update Patient record triage if high-risk alert
    if (evalResult.isEmergency || evalResult.warnings.length > 0) {
      await db.patients.update(patient.id, {
        riskLevel: evalResult.isEmergency ? 'high' : 'moderate',
        updatedAt: timestamp
      });
    }

    // 4. Connect Maternal ANC Visit if patient is pregnant
    if (patient.isPregnant && (data.assessmentType === 'Maternal Healthcare' || data.isAncVisit)) {
      await db.antenatalVisits.add({
        id: `anc-${Date.now()}`,
        patientId: patient.id,
        maternalRecordId: '',
        visitNumber: data.ancVisitNumber || 1,
        systolicBp: record.systolicBp,
        diastolicBp: record.diastolicBp,
        weightKg: record.weight,
        fundalHeightCm: data.fundalHeightCm || null,
        fetalHeartRate: data.fetalHeartRate || null,
        urineProtein: data.urineProtein || 'Nil',
        dangerSigns: evalResult.warnings,
        assessedBy: user?.name || 'Local ANM',
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });
    }

    // 5. Connect Child Growth Record if patient is child
    if (patient.age < 5 && data.height && data.weight) {
      await db.growthRecords.add({
        id: `gr-${Date.now()}`,
        childId: patient.id,
        patientId: patient.id,
        ageMonths: Math.round(patient.age * 12),
        weightKg: record.weight,
        heightCm: record.height,
        muacCm: record.muacCm,
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });
    }

    // 6. Push to Sync Queue
    await db.syncQueue.add({
      entity: 'healthAssessments',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // 7. Audit Log
    await db.auditLogs.add({
      entity: 'healthAssessments',
      entityId: id,
      action: 'HEALTH_ASSESSMENT_RECORDED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Assessment ${id} recorded for ${patient.name} (${patient.id}). Classification: ${evalResult.classification}`
    });

    return record;
  },

  /**
   * Edit assessment with immutable audit trail
   */
  async updateAssessment(id, updates, auditReason = 'Correction of vital parameters', user) {
    const existing = await db.healthAssessments.get(id);
    if (!existing) {
      throw new Error(`Assessment with ID "${id}" does not exist.`);
    }

    const timestamp = new Date().toISOString();
    const patient = await db.patients.get(existing.patientId);

    const mergedData = { ...existing, ...updates };
    const patientContext = {
      age: patient ? patient.age : 30,
      gender: patient ? patient.gender : 'female',
      isPregnant: patient ? patient.isPregnant : false
    };

    const bmiCalc = ClinicalCalculators.calculateBmi(mergedData.height, mergedData.weight, patientContext);
    const evalResult = ClinicalCalculators.evaluateAssessment(mergedData, patientContext);

    const updatedRecord = {
      ...existing,
      ...updates,
      bmi: bmiCalc.bmi,
      bmiInterpretation: bmiCalc.interpretation,
      warningSigns: evalResult.warnings,
      warningIndicators: evalResult.warnings,
      status: evalResult.isEmergency ? 'urgent_emergency' : evalResult.requiresFollowUp ? 'requires_follow_up' : 'completed',
      riskLevel: evalResult.riskTier,
      classification: evalResult.classification,
      version: (existing.version || 1) + 1,
      updatedAt: timestamp,
      syncStatus: 'pending',
      auditHistory: [
        ...(existing.auditHistory || []),
        {
          action: 'UPDATED',
          performedBy: user?.name || 'Local User',
          role: user?.role || 'worker',
          timestamp,
          reason: auditReason,
          changes: updates
        }
      ]
    };

    await db.healthAssessments.put(updatedRecord);

    await db.syncQueue.add({
      entity: 'healthAssessments',
      entityId: id,
      operation: 'UPDATE',
      payload: updatedRecord,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'healthAssessments',
      entityId: id,
      action: 'HEALTH_ASSESSMENT_UPDATED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Assessment ${id} updated: ${auditReason}`
    });

    return updatedRecord;
  },

  /**
   * 1-Click Referral Integration from Assessment
   */
  async createReferralFromAssessment(assessmentId, referralData, user) {
    const assessment = await db.healthAssessments.get(assessmentId);
    if (!assessment) throw new Error('Assessment not found');

    const timestamp = new Date().toISOString();
    const referralId = `ref-${Date.now()}`;

    const referralRecord = {
      id: referralId,
      patientId: assessment.patientId,
      assessmentId,
      urgency: referralData.urgency || (assessment.isEmergency ? 'emergency' : 'urgent'),
      referralFacility: referralData.referralFacility || 'Rampur Primary Health Centre',
      reason: referralData.reason || assessment.warningSigns?.join(', ') || 'Clinical screening indicator detected',
      clinicalSummary: `Vitals: BP ${assessment.systolicBp || 'NR'}/${assessment.diastolicBp || 'NR'} mmHg, Pulse ${assessment.pulse || 'NR'}, SpO2 ${assessment.spo2 || 'NR'}%, RBS ${assessment.bloodGlucose || 'NR'} mg/dL. Warning flags: ${assessment.warningSigns?.join('; ') || 'None'}. Notes: ${assessment.observations || assessment.notes || 'None'}`,
      status: 'referred',
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Community Health Worker',
      doctorFeedback: '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.referrals.add(referralRecord);

    // Link referral ID to assessment
    await db.healthAssessments.update(assessmentId, {
      referralId,
      status: 'referred',
      updatedAt: timestamp
    });

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: referralId,
      operation: 'CREATE',
      payload: referralRecord,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'referrals',
      entityId: referralId,
      action: 'EMERGENCY_REFERRAL_DISPATCHED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Referral ${referralId} created from assessment ${assessmentId} to ${referralRecord.referralFacility}`
    });

    return referralRecord;
  },

  /**
   * 1-Click Follow-up Scheduling from Assessment
   */
  async scheduleFollowUpFromAssessment(assessmentId, followUpData, user) {
    const assessment = await db.healthAssessments.get(assessmentId);
    if (!assessment) throw new Error('Assessment not found');

    const timestamp = new Date().toISOString();
    const followUpId = `fu-${Date.now()}`;

    const followUpRecord = {
      id: followUpId,
      patientId: assessment.patientId,
      assessmentId,
      scheduledDate: followUpData.scheduledDate,
      visitType: followUpData.visitType || 'Repeat Vital Signs & Symptom Review',
      priority: followUpData.priority || (assessment.warningSigns?.length > 0 ? 'urgent' : 'routine'),
      isCompleted: false,
      notes: followUpData.notes || `Follow-up on ${assessment.warningSigns?.join(', ') || 'assessment'}`,
      scheduledBy: user?.name || 'Local Health Worker',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.followUps.add(followUpRecord);

    // Link follow-up ID to assessment
    await db.healthAssessments.update(assessmentId, {
      followUpId,
      requiresFollowUp: true,
      updatedAt: timestamp
    });

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: followUpId,
      operation: 'CREATE',
      payload: followUpRecord,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'followUps',
      entityId: followUpId,
      action: 'FOLLOW_UP_SCHEDULED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Follow-up ${followUpId} scheduled for patient ${assessment.patientId} on ${followUpData.scheduledDate}`
    });

    return followUpRecord;
  }
};
