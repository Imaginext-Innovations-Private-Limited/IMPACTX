import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';
import { ClinicalCalculators } from '../utils/clinicalCalculators';

const deviceId = getOrCreateDeviceId();

export const MaternalService = {
  /**
   * 1. Live Database Statistics Aggregation
   */
  async getDashboardStats() {
    try {
      const records = await db.maternalRecords.toArray();
      const allPatients = await db.patients.filter(p => !p.isDeleted).toArray();
      const patientMap = new Map();
      allPatients.forEach(p => {
        if (p.id) patientMap.set(p.id, p);
        if (p.patientId) patientMap.set(p.patientId, p);
      });

      let total = records.length;
      let active = 0;
      let trimester1 = 0;
      let trimester2 = 0;
      let trimester3 = 0;
      let highRisk = 0;
      let delivered = 0;

      const now = new Date();

      records.forEach(r => {
        if (r.status === 'delivered') {
          delivered++;
        } else {
          active++;
          const ga = ClinicalCalculators.calculateGestationalAge(r.lmp, now);
          if (ga.trimester === 1) trimester1++;
          else if (ga.trimester === 2) trimester2++;
          else if (ga.trimester === 3) trimester3++;

          const patient = patientMap.get(r.patientId) || {};
          const hrp = ClinicalCalculators.evaluateHighRiskPregnancy(
            { ...r, age: patient.age },
            r.latestVitals || {}
          );
          if (hrp.isHighRisk || (r.highRiskFactors && r.highRiskFactors.length > 0)) {
            highRisk++;
          }
        }
      });

      return {
        total,
        active,
        trimester1,
        trimester2,
        trimester3,
        highRisk,
        delivered
      };
    } catch (err) {
      console.error('[MaternalService] Failed to compute stats:', err);
      return { total: 0, active: 0, trimester1: 0, trimester2: 0, trimester3: 0, highRisk: 0, delivered: 0 };
    }
  },

  /**
   * 2. Query Maternal Records with Filters
   */
  async getMaternalRecords({ query = '', status = 'all', trimester = 'all', riskLevel = 'all', village = 'all' } = {}) {
    try {
      let records = await db.maternalRecords.toArray();
      const allPatients = await db.patients.filter(p => !p.isDeleted).toArray();
      const patientMap = new Map();
      allPatients.forEach(p => {
        if (p.id) patientMap.set(p.id, p);
        if (p.patientId) patientMap.set(p.patientId, p);
      });
      const allVisits = await db.antenatalVisits.toArray();

      // Group visits by maternalRecordId
      const visitsByRecord = new Map();
      allVisits.forEach(v => {
        const list = visitsByRecord.get(v.maternalRecordId) || [];
        list.push(v);
        visitsByRecord.set(v.maternalRecordId, list);
      });

      const now = new Date();

      let enriched = records.map(r => {
        const patient = patientMap.get(r.patientId) || {
          name: 'Unknown Mother',
          age: 25,
          contactNumber: '',
          villageHamlet: 'Unknown Hamlet'
        };

        const visits = visitsByRecord.get(r.id) || [];
        visits.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        const latestVisit = visits[0] || null;

        const ga = ClinicalCalculators.calculateGestationalAge(r.lmp, now);
        const eddCalc = ClinicalCalculators.calculateEdd(r.lmp);
        const hrp = ClinicalCalculators.evaluateHighRiskPregnancy(
          { ...r, age: patient.age },
          latestVisit ? {
            systolicBp: latestVisit.systolicBp,
            diastolicBp: latestVisit.diastolicBp,
            hemoglobin: latestVisit.hemoglobin,
            urineProtein: latestVisit.urineProtein
          } : {}
        );

        return {
          ...r,
          patient,
          visits,
          visitCount: visits.length,
          latestVisit,
          gestationalAge: ga,
          calculatedEdd: eddCalc,
          hrp
        };
      });

      // Filter by Search Query
      if (query.trim()) {
        const q = query.toLowerCase().trim();
        enriched = enriched.filter(item =>
          item.patient.name?.toLowerCase().includes(q) ||
          item.patient.patientId?.toLowerCase().includes(q) ||
          item.patient.contactNumber?.includes(q) ||
          item.patient.villageHamlet?.toLowerCase().includes(q)
        );
      }

      // Filter by Status
      if (status !== 'all') {
        enriched = enriched.filter(item => item.status === status);
      }

      // Filter by Trimester
      if (trimester !== 'all') {
        const triNum = parseInt(trimester, 10);
        enriched = enriched.filter(item => item.gestationalAge.trimester === triNum);
      }

      // Filter by Risk Level
      if (riskLevel === 'high') {
        enriched = enriched.filter(item => item.hrp.isHighRisk);
      } else if (riskLevel === 'normal') {
        enriched = enriched.filter(item => !item.hrp.isHighRisk);
      }

      // Filter by Village
      if (village !== 'all') {
        enriched = enriched.filter(item => item.patient.villageHamlet === village);
      }

      // Sort by creation or update descending
      enriched.sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));

      return enriched;
    } catch (err) {
      console.error('[MaternalService] Failed to load maternal records:', err);
      return [];
    }
  },

  /**
   * 3. Get Single Maternal Record with Full History
   */
  async getMaternalRecordById(id) {
    try {
      const record = await db.maternalRecords.get(id);
      if (!record) return null;

      let patient = await db.patients.get(record.patientId);
      if (!patient) {
        patient = await db.patients.where('patientId').equals(record.patientId).first() || null;
      }
      let visits = await db.antenatalVisits.where('maternalRecordId').equals(id).toArray();
      visits.sort((a, b) => (a.visitNumber || 0) - (b.visitNumber || 0));

      const referrals = await db.referrals.where('patientId').equals(record.patientId).toArray();
      const followUps = await db.followUps.where('patientId').equals(record.patientId).toArray();

      const ga = ClinicalCalculators.calculateGestationalAge(record.lmp);
      const edd = ClinicalCalculators.calculateEdd(record.lmp);
      const schedule = ClinicalCalculators.getAncSchedule(record.lmp, visits);

      const latestVisit = visits[visits.length - 1] || null;
      const hrp = ClinicalCalculators.evaluateHighRiskPregnancy(
        { ...record, age: patient?.age },
        latestVisit ? {
          systolicBp: latestVisit.systolicBp,
          diastolicBp: latestVisit.diastolicBp,
          hemoglobin: latestVisit.hemoglobin,
          urineProtein: latestVisit.urineProtein
        } : {}
      );

      return {
        ...record,
        patient,
        visits,
        referrals,
        followUps,
        gestationalAge: ga,
        eddInfo: edd,
        schedule,
        hrp
      };
    } catch (err) {
      console.error('[MaternalService] Failed to get record by id:', err);
      return null;
    }
  },

  /**
   * 4. Register a New Pregnancy
   */
  async registerPregnancy(data, user) {
    const timestamp = new Date().toISOString();
    const id = `mat-${Date.now()}`;

    const eddResult = ClinicalCalculators.calculateEdd(data.lmp);
    const gaResult = ClinicalCalculators.calculateGestationalAge(data.lmp);

    const record = {
      id,
      patientId: data.patientId,
      lmp: data.lmp,
      edd: eddResult.edd,
      trimester: gaResult.trimester,
      gravidity: parseInt(data.gravidity, 10) || 1,
      parity: parseInt(data.parity, 10) || 0,
      livingChildren: parseInt(data.livingChildren, 10) || 0,
      abortions: parseInt(data.abortions, 10) || 0,
      bloodGroup: data.bloodGroup || '',
      expectedDeliveryPlace: data.expectedDeliveryPlace || 'PHC / Community Health Centre',
      highRiskFactors: data.highRiskFactors || [],
      isMultipleGestation: Boolean(data.isMultipleGestation),
      previousCesarean: Boolean(data.previousCesarean),
      previousStillbirth: Boolean(data.previousStillbirth),
      notes: data.notes || '',
      status: 'active',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.maternalRecords.add(record);

    // Update patient table
    await db.patients.update(data.patientId, {
      isPregnant: true,
      category: 'maternal',
      riskLevel: record.highRiskFactors.length > 0 ? 'high' : 'normal',
      updatedAt: timestamp
    });

    // Automatically schedule ANC-1 follow-up if within 1st trimester
    const schedule = ClinicalCalculators.getAncSchedule(data.lmp);
    const firstDue = schedule[0]?.targetDueDate || timestamp.slice(0, 10);

    const followUpId = `fu-${Date.now()}`;
    await db.followUps.add({
      id: followUpId,
      patientId: data.patientId,
      scheduledDate: firstDue,
      visitType: 'ANC Visit #1 (Early Registration)',
      priority: record.highRiskFactors.length > 0 ? 'urgent' : 'routine',
      isCompleted: false,
      notes: `Target ANC visit for pregnancy registered on ${timestamp.slice(0, 10)}. EDD: ${eddResult.formatted}`,
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    });

    // Queue into syncQueue
    await db.syncQueue.add({
      entity: 'maternalRecords',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Log to auditLogs
    await db.auditLogs.add({
      entity: 'maternalRecords',
      entityId: id,
      action: 'PREGNANCY_REGISTERED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Registered pregnancy for patient ${data.patientId}. LMP: ${data.lmp}, EDD: ${record.edd}, Risk factors: ${record.highRiskFactors.length}`
    });

    return record;
  },

  /**
   * 5. Record an Antenatal Care (ANC) Visit
   */
  async recordAntenatalVisit(data, user) {
    const timestamp = new Date().toISOString();
    const id = `anc-${Date.now()}`;

    const maternalRecord = await db.maternalRecords.get(data.maternalRecordId);
    if (!maternalRecord) throw new Error('Maternal record not found');

    const patient = await db.patients.get(data.patientId) || {};

    const sys = parseInt(data.systolicBp, 10);
    const dia = parseInt(data.diastolicBp, 10);
    const hb = parseFloat(data.hemoglobin);

    // Evaluate HRP for this visit
    const hrp = ClinicalCalculators.evaluateHighRiskPregnancy(
      { ...maternalRecord, age: patient.age },
      { systolicBp: sys, diastolicBp: dia, hemoglobin: hb, urineProtein: data.urineProtein, symptoms: data.symptoms || [] }
    );

    const visit = {
      id,
      patientId: data.patientId,
      maternalRecordId: data.maternalRecordId,
      visitNumber: parseInt(data.visitNumber, 10) || 1,
      visitDate: data.visitDate || timestamp.slice(0, 10),
      systolicBp: sys || null,
      diastolicBp: dia || null,
      weightKg: parseFloat(data.weightKg) || null,
      fundalHeightCm: parseFloat(data.fundalHeightCm) || null,
      fetalHeartRate: parseInt(data.fetalHeartRate, 10) || null,
      fetalLie: data.fetalLie || 'Longitudinal',
      fetalMovement: data.fetalMovement || 'Present',
      hemoglobin: hb || null,
      urineProtein: data.urineProtein || 'Nil',
      urineSugar: data.urineSugar || 'Nil',
      tdVaccineDose: data.tdVaccineDose || 'None', // Td-1, Td-2, Td-Booster
      ifaTabletsGiven: parseInt(data.ifaTabletsGiven, 10) || 0,
      calciumTabletsGiven: parseInt(data.calciumTabletsGiven, 10) || 0,
      symptoms: data.symptoms || [],
      warningSigns: hrp.riskFactors.map(rf => rf.factor),
      dangerSignsIdentified: hrp.isEmergency,
      assessedBy: user?.name || 'Local Healthcare Worker',
      notes: data.notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.antenatalVisits.add(visit);

    // Update maternal record with latest vitals & HRP status
    const updatedHighRiskFactors = Array.from(new Set([
      ...(maternalRecord.highRiskFactors || []),
      ...hrp.riskFactors.map(rf => rf.factor)
    ]));

    await db.maternalRecords.update(maternalRecord.id, {
      latestVitals: {
        systolicBp: sys,
        diastolicBp: dia,
        weightKg: visit.weightKg,
        hemoglobin: hb,
        urineProtein: visit.urineProtein,
        date: visit.visitDate
      },
      highRiskFactors: updatedHighRiskFactors,
      updatedAt: timestamp
    });

    // Update patient riskLevel
    await db.patients.update(data.patientId, {
      riskLevel: hrp.isHighRisk ? 'high' : 'normal',
      updatedAt: timestamp
    });

    // If Obstetric Emergency, auto-create Emergency Referral
    let generatedReferral = null;
    if (hrp.isEmergency) {
      const refId = `ref-${Date.now()}`;
      generatedReferral = {
        id: refId,
        patientId: data.patientId,
        urgency: 'emergency',
        status: 'referred',
        referralFacility: 'Community Health Centre / First Referral Unit (Obstetrics)',
        reason: `Obstetric Emergency at ANC Visit #${visit.visitNumber}: ${hrp.riskFactors.map(r => r.factor).join(', ')}`,
        referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'ASHA Worker',
        doctorFeedback: '',
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      };
      await db.referrals.add(generatedReferral);
      await db.syncQueue.add({
        entity: 'referrals',
        entityId: refId,
        operation: 'CREATE',
        payload: generatedReferral,
        status: 'pending',
        retryCount: 0,
        createdAt: timestamp
      });
    }

    // Schedule Next ANC Follow-up
    const nextVisitNum = visit.visitNumber + 1;
    if (nextVisitNum <= 4) {
      const schedule = ClinicalCalculators.getAncSchedule(maternalRecord.lmp);
      const nextDue = schedule[nextVisitNum - 1]?.targetDueDate || timestamp.slice(0, 10);

      const nextFuId = `fu-${Date.now()}-anc${nextVisitNum}`;
      await db.followUps.add({
        id: nextFuId,
        patientId: data.patientId,
        scheduledDate: nextDue,
        visitType: `ANC Visit #${nextVisitNum}`,
        priority: hrp.isHighRisk ? 'urgent' : 'routine',
        isCompleted: false,
        notes: `Next sequential antenatal care checkup (ANC #${nextVisitNum}).`,
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });
    }

    // Queue into syncQueue
    await db.syncQueue.add({
      entity: 'antenatalVisits',
      entityId: id,
      operation: 'CREATE',
      payload: visit,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit Log
    await db.auditLogs.add({
      entity: 'antenatalVisits',
      entityId: id,
      action: 'ANC_VISIT_RECORDED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `ANC Visit #${visit.visitNumber} logged for patient ${data.patientId}. BP: ${sys}/${dia}, Hb: ${hb}, Warnings: ${visit.warningSigns.length}`
    });

    return {
      visit,
      hrp,
      referralCreated: Boolean(generatedReferral)
    };
  },

  /**
   * 6. Record Delivery & Postnatal Care (PNC) Initialization
   */
  async recordDelivery(maternalRecordId, deliveryData, user) {
    const timestamp = new Date().toISOString();
    const maternal = await db.maternalRecords.get(maternalRecordId);
    if (!maternal) throw new Error('Maternal record not found');

    // Update maternal status
    await db.maternalRecords.update(maternalRecordId, {
      status: 'delivered',
      deliveryDate: deliveryData.deliveryDate || timestamp.slice(0, 10),
      deliveryPlace: deliveryData.deliveryPlace || 'Institutional (PHC/CHC)',
      deliveryType: deliveryData.deliveryType || 'Normal Vaginal Delivery',
      birthOutcome: deliveryData.birthOutcome || 'Live Birth',
      newbornCount: parseInt(deliveryData.newbornCount, 10) || 1,
      maternalComplications: deliveryData.maternalComplications || 'None',
      updatedAt: timestamp
    });

    // Update mother patient profile
    await db.patients.update(maternal.patientId, {
      isPregnant: false,
      riskLevel: 'normal',
      updatedAt: timestamp
    });

    // Schedule Standard PNC Home Visits (48 hours, 7 days, 14 days, 28 days)
    const delDate = new Date(deliveryData.deliveryDate || timestamp);
    const msPerDay = 24 * 60 * 60 * 1000;

    const pncVisits = [
      { days: 2, label: 'PNC 1 (Within 48h Home Check)' },
      { days: 7, label: 'PNC 2 (Day 7 Home Visit)' },
      { days: 14, label: 'PNC 3 (Day 14 Home Visit)' },
      { days: 28, label: 'PNC 4 (Day 28 Home Visit)' }
    ];

    for (const pnc of pncVisits) {
      const dueDate = new Date(delDate.getTime() + (pnc.days * msPerDay)).toISOString().slice(0, 10);
      const fuId = `fu-${Date.now()}-pnc${pnc.days}`;
      await db.followUps.add({
        id: fuId,
        patientId: maternal.patientId,
        scheduledDate: dueDate,
        visitType: pnc.label,
        priority: 'routine',
        isCompleted: false,
        notes: `Surveillance of maternal recovery, lochia, breast feeding, and newborn temperature/color.`,
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });
    }

    // If live birth and child details provided, create Child Patient and Child Record
    let childPatient = null;
    if (deliveryData.birthOutcome === 'Live Birth' && deliveryData.childGender) {
      const childPatientId = `PAT-CH-${Date.now().toString().slice(-4)}`;
      const cId = `pat-${Date.now()}`;
      const mother = await db.patients.get(maternal.patientId) || {};

      childPatient = {
        id: cId,
        patientId: childPatientId,
        name: deliveryData.childName || `Baby of ${mother.name}`,
        gender: deliveryData.childGender,
        age: 0,
        dateOfBirth: deliveryData.deliveryDate || timestamp.slice(0, 10),
        contactNumber: mother.contactNumber,
        emergencyContact: `${mother.contactNumber} (Mother - ${mother.name})`,
        villageHamlet: mother.villageHamlet,
        wardNumber: mother.wardNumber,
        houseNumber: mother.houseNumber,
        bloodGroup: '',
        riskLevel: parseFloat(deliveryData.birthWeight) < 2.5 ? 'high' : 'normal',
        category: 'child',
        isPregnant: false,
        chronicConditions: parseFloat(deliveryData.birthWeight) < 2.5 ? ['Low Birth Weight (LBW)'] : [],
        allergies: 'None',
        consentGiven: true,
        syncStatus: 'pending',
        version: 1,
        isDeleted: false,
        createdAt: timestamp,
        updatedAt: timestamp,
        deviceId
      };

      await db.patients.add(childPatient);

      const chRecordId = `ch-${Date.now()}`;
      await db.childRecords.add({
        id: chRecordId,
        patientId: cId,
        motherId: maternal.patientId,
        birthWeight: parseFloat(deliveryData.birthWeight) || 2.8,
        gestationalAge: parseInt(deliveryData.gestationalAgeAtDelivery, 10) || 38,
        deliveryType: deliveryData.deliveryType || 'Institutional',
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      });

      // Add zero dose immunizations (BCG, OPV-0, Hepatitis B-0)
      const zeroVax = [
        { name: 'BCG', dose: 1 },
        { name: 'OPV-0', dose: 1 },
        { name: 'Hepatitis B (Birth Dose)', dose: 1 }
      ];

      for (const v of zeroVax) {
        const immId = `imm-${Date.now()}-${v.name.slice(0, 3)}`;
        await db.immunizations.add({
          id: immId,
          childId: chRecordId,
          patientId: cId,
          vaccineName: v.name,
          doseNumber: v.dose,
          dueDate: deliveryData.deliveryDate || timestamp.slice(0, 10),
          givenDate: deliveryData.vaccinesGivenAtBirth?.includes(v.name) ? deliveryData.deliveryDate : null,
          status: deliveryData.vaccinesGivenAtBirth?.includes(v.name) ? 'administered' : 'scheduled',
          administeredBy: user?.name || 'PHC Staff Nurse',
          syncStatus: 'pending',
          version: 1,
          createdAt: timestamp,
          deviceId
        });
      }
    }

    // Sync queue
    await db.syncQueue.add({
      entity: 'maternalRecords',
      entityId: maternalRecordId,
      operation: 'UPDATE',
      payload: { id: maternalRecordId, status: 'delivered' },
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'maternalRecords',
      entityId: maternalRecordId,
      action: 'DELIVERY_RECORDED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Delivery logged for maternal record ${maternalRecordId}. Outcome: ${deliveryData.birthOutcome}`
    });

    return { success: true, childCreated: Boolean(childPatient) };
  },

  /**
   * 7. 1-Click Referral Dispatch from Maternal View
   */
  async createReferralFromMaternal(maternalRecord, reason, facility, urgency = 'urgent', user) {
    const timestamp = new Date().toISOString();
    const id = `ref-${Date.now()}`;

    const record = {
      id,
      patientId: maternalRecord.patientId,
      urgency,
      status: 'referred',
      referralFacility: facility || 'Community Health Centre / FRU (Obstetrics)',
      reason: reason || 'Maternal healthcare escalation required',
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'ASHA Worker',
      doctorFeedback: '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.referrals.add(record);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'referrals',
      entityId: id,
      action: 'MATERNAL_REFERRAL_DISPATCHED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Referral dispatched for pregnant mother ${maternalRecord.patientId} to ${record.referralFacility}`
    });

    return record;
  },

  /**
   * 8. 1-Click Follow-up Scheduler from Maternal View
   */
  async scheduleFollowUpFromMaternal(maternalRecord, visitType, scheduledDate, notes, priority = 'routine', user) {
    const timestamp = new Date().toISOString();
    const id = `fu-${Date.now()}`;

    const record = {
      id,
      patientId: maternalRecord.patientId,
      scheduledDate: scheduledDate || timestamp.slice(0, 10),
      visitType: visitType || 'Maternal Home Surveillance',
      priority,
      isCompleted: false,
      notes: notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.followUps.add(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  }
};
