import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';
import { ClinicalCalculators } from '../utils/clinicalCalculators';

const deviceId = getOrCreateDeviceId();

export const ChronicService = {
  /**
   * 1. Live NCD Dashboard Statistics
   */
  async getDashboardStats() {
    try {
      const allPatients = await db.patients.filter(p => !p.isDeleted).toArray();
      const allConditions = await db.chronicConditions.toArray();
      const allAssessments = await db.healthAssessments.toArray();

      // Filter patients enrolled in NCD
      const ncdPatientIds = new Set();
      allConditions.forEach(c => ncdPatientIds.add(c.patientId));
      allPatients.forEach(p => {
        if (p.category === 'chronic' || (p.chronicConditions && p.chronicConditions.length > 0)) {
          ncdPatientIds.add(p.id);
          if (p.patientId) ncdPatientIds.add(p.patientId);
        }
      });

      // Latest assessment by patient
      const latestAssessments = new Map();
      allAssessments.forEach(a => {
        const cur = latestAssessments.get(a.patientId);
        if (!cur || new Date(a.createdAt || 0) > new Date(cur.createdAt || 0)) {
          latestAssessments.set(a.patientId, a);
        }
      });

      let total = 0;
      let controlled = 0;
      let uncontrolledDiabetes = 0;
      let uncontrolledHypertension = 0;
      let complicationFlags = 0;
      let defaulters = 0;

      const evaluatedPatients = allPatients.filter(p => ncdPatientIds.has(p.id) || ncdPatientIds.has(p.patientId));
      total = evaluatedPatients.length;

      evaluatedPatients.forEach(p => {
        const vitals = latestAssessments.get(p.id) || latestAssessments.get(p.patientId) || {};
        const condList = allConditions.filter(c => c.patientId === p.id || c.patientId === p.patientId);

        const adherence = condList.find(c => c.medicationAdherence)?.medicationAdherence || vitals.medicationAdherence || 'Regular';
        if (adherence.toLowerCase().includes('default') || adherence.toLowerCase().includes('stop')) {
          defaulters++;
        }

        const control = ClinicalCalculators.evaluateNcdControlStatus(condList, { ...vitals, medicationAdherence: adherence });
        if (control.isUncontrolled || control.isEmergency) {
          if (control.bpControl.includes('Uncontrolled') || control.bpControl.includes('Emergency')) {
            uncontrolledHypertension++;
          }
          if (control.glucoseControl.includes('Uncontrolled') || control.glucoseControl.includes('Hyperglycemia') || control.glucoseControl.includes('Hypoglycemia')) {
            uncontrolledDiabetes++;
          }
        } else {
          controlled++;
        }

        if (control.alerts.length > 0) {
          complicationFlags++;
        }
      });

      return {
        total,
        controlled,
        uncontrolledDiabetes,
        uncontrolledHypertension,
        complicationFlags,
        defaulters
      };
    } catch (err) {
      console.error('[ChronicService] Failed to compute stats:', err);
      return { total: 0, controlled: 0, uncontrolledDiabetes: 0, uncontrolledHypertension: 0, complicationFlags: 0, defaulters: 0 };
    }
  },

  /**
   * 2. Query NCD Patients Cohort with Filters
   */
  async getNcdPatients({ query = '', conditionFilter = 'all', controlFilter = 'all', adherenceFilter = 'all', village = 'all' } = {}) {
    try {
      const allPatients = await db.patients.filter(p => !p.isDeleted).toArray();
      const allConditions = await db.chronicConditions.toArray();
      const allAssessments = await db.healthAssessments.toArray();

      const conditionsByPatient = new Map();
      allConditions.forEach(c => {
        const list = conditionsByPatient.get(c.patientId) || [];
        list.push(c);
        conditionsByPatient.set(c.patientId, list);
      });

      const assessmentsByPatient = new Map();
      allAssessments.forEach(a => {
        const list = assessmentsByPatient.get(a.patientId) || [];
        list.push(a);
        assessmentsByPatient.set(a.patientId, list);
      });

      // Filter cohort
      const ncdList = allPatients.filter(p => {
        const conds = conditionsByPatient.get(p.id) || conditionsByPatient.get(p.patientId) || [];
        return p.category === 'chronic' || conds.length > 0 || (p.chronicConditions && p.chronicConditions.length > 0);
      });

      let enriched = ncdList.map(patient => {
        const conds = conditionsByPatient.get(patient.id) || conditionsByPatient.get(patient.patientId) || [];
        const assessments = assessmentsByPatient.get(patient.id) || assessmentsByPatient.get(patient.patientId) || [];
        assessments.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        const latestVitals = assessments[0] || null;

        const latestCond = conds[0] || null;
        const adherence = latestCond?.medicationAdherence || latestVitals?.medicationAdherence || 'Regular';

        const control = ClinicalCalculators.evaluateNcdControlStatus(conds, {
          systolicBp: latestVitals?.systolicBp,
          diastolicBp: latestVitals?.diastolicBp,
          bloodGlucose: latestVitals?.bloodGlucose,
          glucoseContext: latestVitals?.glucoseContext,
          medicationAdherence: adherence
        });

        return {
          ...patient,
          patient,
          conditions: conds,
          latestVitals,
          vitalsCount: assessments.length,
          adherence,
          control
        };
      });

      // Query Search
      if (query.trim()) {
        const q = query.toLowerCase().trim();
        enriched = enriched.filter(p =>
          p.name?.toLowerCase().includes(q) ||
          p.patientId?.toLowerCase().includes(q) ||
          p.contactNumber?.includes(q) ||
          p.villageHamlet?.toLowerCase().includes(q)
        );
      }

      // Condition Filter
      if (conditionFilter !== 'all') {
        const cLower = conditionFilter.toLowerCase();
        enriched = enriched.filter(p =>
          p.conditions.some(c => c.conditionName?.toLowerCase().includes(cLower)) ||
          p.chronicConditions?.some(c => c.toLowerCase().includes(cLower))
        );
      }

      // Control Status Filter
      if (controlFilter === 'controlled') {
        enriched = enriched.filter(p => !p.control.isUncontrolled && !p.control.isEmergency);
      } else if (controlFilter === 'uncontrolled') {
        enriched = enriched.filter(p => p.control.isUncontrolled);
      } else if (controlFilter === 'emergency') {
        enriched = enriched.filter(p => p.control.isEmergency);
      }

      // Adherence Filter
      if (adherenceFilter === 'defaulter') {
        enriched = enriched.filter(p => p.adherence.toLowerCase().includes('default') || p.adherence.toLowerCase().includes('stop'));
      } else if (adherenceFilter === 'irregular') {
        enriched = enriched.filter(p => p.adherence.toLowerCase().includes('irregular'));
      } else if (adherenceFilter === 'regular') {
        enriched = enriched.filter(p => p.adherence.toLowerCase().includes('regular'));
      }

      // Village Filter
      if (village !== 'all') {
        enriched = enriched.filter(p => p.villageHamlet === village);
      }

      enriched.sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));

      return enriched;
    } catch (err) {
      console.error('[ChronicService] Failed to load NCD patients:', err);
      return [];
    }
  },

  /**
   * 3. Get Full NCD Patient Profile by ID
   */
  async getNcdPatientById(id) {
    try {
      let patient = await db.patients.get(id);
      if (!patient) {
        patient = await db.patients.where('patientId').equals(id).first() || null;
      }
      if (!patient) return null;

      let conditions = await db.chronicConditions.where('patientId').equals(patient.id).toArray();
      if (conditions.length === 0) {
        conditions = await db.chronicConditions.where('patientId').equals(patient.patientId).toArray();
      }

      let assessments = await db.healthAssessments.where('patientId').equals(patient.id).toArray();
      if (assessments.length === 0) {
        assessments = await db.healthAssessments.where('patientId').equals(patient.patientId).toArray();
      }
      assessments.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));

      const referrals = await db.referrals.where('patientId').equals(patient.id).toArray();
      const followUps = await db.followUps.where('patientId').equals(patient.id).toArray();

      const latestVitals = assessments[assessments.length - 1] || null;
      const adherence = conditions[0]?.medicationAdherence || latestVitals?.medicationAdherence || 'Regular';

      const control = ClinicalCalculators.evaluateNcdControlStatus(conditions, {
        systolicBp: latestVitals?.systolicBp,
        diastolicBp: latestVitals?.diastolicBp,
        bloodGlucose: latestVitals?.bloodGlucose,
        glucoseContext: latestVitals?.glucoseContext,
        medicationAdherence: adherence
      });

      return {
        patient,
        conditions,
        assessments,
        referrals,
        followUps,
        latestVitals,
        control,
        adherence
      };
    } catch (err) {
      console.error('[ChronicService] Failed to get NCD patient by id:', err);
      return null;
    }
  },

  /**
   * 4. Enroll Patient in Chronic Condition Registry
   */
  async enrollCondition(data, user) {
    const timestamp = new Date().toISOString();
    const id = `cc-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      conditionName: data.conditionName, // Type 2 Diabetes, Primary Hypertension, COPD, etc.
      severity: data.severity || 'moderate', // mild, moderate, uncontrolled
      diagnosedDate: data.diagnosedDate || timestamp.slice(0, 10),
      lastChecked: timestamp.slice(0, 10),
      medications: data.medications || [], // ['Metformin 500mg', 'Amlodipine 5mg']
      medicationAdherence: data.medicationAdherence || 'Regular (Daily adherence)',
      notes: data.notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.chronicConditions.add(record);

    // Update patient table
    const patient = await db.patients.get(data.patientId);
    if (patient) {
      const updatedConds = Array.from(new Set([...(patient.chronicConditions || []), data.conditionName]));
      await db.patients.update(data.patientId, {
        category: 'chronic',
        chronicConditions: updatedConds,
        riskLevel: data.severity === 'uncontrolled' ? 'high' : patient.riskLevel,
        updatedAt: timestamp
      });
    }

    // Schedule Monthly Follow-up for Medication Refill & Vitals Check
    const nextMonthDate = new Date(new Date().getTime() + (30 * 24 * 60 * 60 * 1000)).toISOString().slice(0, 10);
    const fuId = `fu-${Date.now()}-ncd`;
    await db.followUps.add({
      id: fuId,
      patientId: data.patientId,
      scheduledDate: nextMonthDate,
      visitType: `NCD Follow-up: ${data.conditionName} Check & Drug Refill`,
      priority: data.severity === 'uncontrolled' ? 'urgent' : 'routine',
      isCompleted: false,
      notes: `Review blood pressure, blood glucose, and refill ${data.medications?.join(', ') || 'prescribed medicines'}.`,
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    });

    // Queue sync
    await db.syncQueue.add({
      entity: 'chronicConditions',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'chronicConditions',
      entityId: id,
      action: 'NCD_ENROLLED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Enrolled patient ${data.patientId} for ${data.conditionName}. Severity: ${data.severity}`
    });

    return record;
  },

  /**
   * 5. Record NCD Follow-Up Vitals & Medication Check
   */
  async recordNcdVitals(data, user) {
    const timestamp = new Date().toISOString();
    const id = `ha-${Date.now()}`;

    const sys = parseInt(data.systolicBp, 10);
    const dia = parseInt(data.diastolicBp, 10);
    const glu = parseFloat(data.bloodGlucose);

    // Evaluate control
    const control = ClinicalCalculators.evaluateNcdControlStatus([], {
      systolicBp: sys,
      diastolicBp: dia,
      bloodGlucose: glu,
      glucoseContext: data.glucoseContext || 'random',
      medicationAdherence: data.medicationAdherence
    });

    // Complications check
    const complications = ClinicalCalculators.evaluateNcdComplications(data.symptoms || []);

    const assessment = {
      id,
      patientId: data.patientId,
      assessmentType: 'Chronic NCD Surveillance',
      assessmentDate: data.visitDate || timestamp.slice(0, 10),
      systolicBp: sys || null,
      diastolicBp: dia || null,
      bloodGlucose: glu || null,
      glucoseContext: data.glucoseContext || 'random',
      pulse: parseInt(data.pulse, 10) || null,
      spo2: parseInt(data.spo2, 10) || null,
      weight: parseFloat(data.weightKg) || null,
      height: parseFloat(data.heightCm) || null,
      medicationAdherence: data.medicationAdherence || 'Regular',
      daysOfMedicineRemaining: parseInt(data.daysOfMedicineRemaining, 10) || 0,
      symptoms: data.symptoms || [],
      warningSigns: [...control.alerts, ...complications.redFlags.map(r => r.text)],
      observations: data.notes || '',
      status: control.isEmergency || complications.isEmergency ? 'requires_urgent_escalation' : 'completed',
      riskLevel: control.isEmergency || complications.isEmergency ? 'high' : 'normal',
      assessedBy: user?.name || 'Local Healthcare Worker',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.healthAssessments.add(assessment);

    // Update chronic condition table's lastChecked
    const conditions = await db.chronicConditions.where('patientId').equals(data.patientId).toArray();
    for (const c of conditions) {
      await db.chronicConditions.update(c.id, {
        lastChecked: timestamp.slice(0, 10),
        medicationAdherence: data.medicationAdherence || c.medicationAdherence,
        severity: control.isEmergency ? 'uncontrolled' : control.isUncontrolled ? 'uncontrolled' : 'controlled'
      });
    }

    // Auto-create Emergency Referral if crisis (hypertensive emergency, hypoglycemia, stroke signs, chest pain)
    let referralDispatched = null;
    if (control.isEmergency || complications.isEmergency) {
      const refId = `ref-${Date.now()}`;
      referralDispatched = {
        id: refId,
        patientId: data.patientId,
        urgency: 'emergency',
        status: 'referred',
        referralFacility: 'Community Health Centre (Emergency) / District Hospital',
        reason: `NCD Medical Emergency: ${assessment.warningSigns.join(', ')}`,
        referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'ASHA Worker',
        doctorFeedback: '',
        syncStatus: 'pending',
        version: 1,
        createdAt: timestamp,
        deviceId
      };
      await db.referrals.add(referralDispatched);
      await db.syncQueue.add({
        entity: 'referrals',
        entityId: refId,
        operation: 'CREATE',
        payload: referralDispatched,
        status: 'pending',
        retryCount: 0,
        createdAt: timestamp
      });
    }

    // Queue sync
    await db.syncQueue.add({
      entity: 'healthAssessments',
      entityId: id,
      operation: 'CREATE',
      payload: assessment,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'healthAssessments',
      entityId: id,
      action: 'NCD_VITALS_RECORDED',
      performedBy: user?.name || 'Local Healthcare Worker',
      role: user?.role || 'asha',
      timestamp,
      details: `Recorded NCD vitals for ${data.patientId}. BP: ${sys}/${dia}, Glucose: ${glu}, Status: ${control.overallStatus}`
    });

    return { assessment, control, complications, referralDispatched };
  },

  /**
   * 6. 1-Click Referral Dispatch from Chronic View
   */
  async createReferralFromNcd(patient, reason, facility, urgency = 'urgent', user) {
    const timestamp = new Date().toISOString();
    const id = `ref-${Date.now()}`;

    const record = {
      id,
      patientId: patient.id || patient.patientId,
      urgency,
      status: 'referred',
      referralFacility: facility || 'Taluka Hospital / NCD Clinic',
      reason: reason || 'Chronic disease specialist evaluation required',
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Community Worker',
      doctorFeedback: '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.referrals.add(record);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  },

  /**
   * 7. 1-Click Follow-Up Scheduling for NCD Patient
   */
  async scheduleFollowUpFromNcd(patient, visitType, scheduledDate, notes, priority = 'routine', user) {
    const timestamp = new Date().toISOString();
    const id = `fu-${Date.now()}`;

    const record = {
      id,
      patientId: patient.id || patient.patientId,
      scheduledDate: scheduledDate || timestamp.slice(0, 10),
      visitType: visitType || 'NCD Home Surveillance & Vitals Check',
      priority,
      isCompleted: false,
      notes: notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.followUps.add(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  }
};
