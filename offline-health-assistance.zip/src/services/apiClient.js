/**
 * OFFLINE HEALTH - Central Cloud API Client
 * - Communicates with Express Backend via /api
 * - Manages JWT access and refresh tokens
 * - Resilient offline fallback: never throws uncaught network errors
 */

class ApiClient {
  constructor() {
    this.baseUrl = '/api';
    this.accessToken = localStorage.getItem('offline_health_access_token') || null;
    this.refreshToken = localStorage.getItem('offline_health_refresh_token') || null;
  }

  setTokens(access, refresh) {
    this.accessToken = access;
    this.refreshToken = refresh;
    if (access) localStorage.setItem('offline_health_access_token', access);
    else localStorage.removeItem('offline_health_access_token');
    if (refresh) localStorage.setItem('offline_health_refresh_token', refresh);
    else localStorage.removeItem('offline_health_refresh_token');
  }

  async checkServerHealth() {
    try {
      const res = await fetch(`${this.baseUrl}/health`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(3000)
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      try {
        const directRes = await fetch('http://127.0.0.1:5000/api/health', {
          method: 'GET',
          headers: { 'Accept': 'application/json' },
          signal: AbortSignal.timeout(3000)
        });
        if (directRes.ok) {
          return await directRes.json();
        }
      } catch {
        // Fall through
      }
    }
    return { reachable: false, error: 'Server unreachable' };
  }

  async login(username, password) {
    try {
      const res = await fetch(`${this.baseUrl}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
        signal: AbortSignal.timeout(5000)
      });
      const data = await res.json();
      if (res.ok && data.success) {
        this.setTokens(data.tokens.accessToken, data.tokens.refreshToken);
        return { success: true, user: data.user, tokens: data.tokens };
      }
      return { success: false, error: data.error || 'Authentication failed' };
    } catch (err) {
      console.warn('[ApiClient] Server unreachable for login, falling back to local auth mode:', err.message);
      return { success: false, isOffline: true, error: 'Server unreachable. Working in offline mode.' };
    }
  }

  async refreshAccessToken() {
    if (!this.refreshToken) return null;
    try {
      const res = await fetch(`${this.baseUrl}/auth/refresh-token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        this.setTokens(data.accessToken, this.refreshToken);
        return data.accessToken;
      }
    } catch {
      // Fall through
    }
    return null;
  }

  async request(path, options = {}) {
    const url = `${this.baseUrl}${path.startsWith('/') ? path : '/' + path}`;
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    if (this.accessToken && !headers.Authorization) {
      headers.Authorization = `Bearer ${this.accessToken}`;
    }

    try {
      let fetchUrl = url;
      let res;
      try {
        res = await fetch(fetchUrl, {
          ...options,
          headers,
          signal: options.signal || AbortSignal.timeout(8000)
        });
      } catch {
        fetchUrl = `http://127.0.0.1:5000/api${path.startsWith('/') ? path : '/' + path}`;
        res = await fetch(fetchUrl, {
          ...options,
          headers,
          signal: options.signal || AbortSignal.timeout(8000)
        });
      }

      // Handle token expiration
      if (res.status === 401 && this.refreshToken) {
        const newToken = await this.refreshAccessToken();
        if (newToken) {
          headers.Authorization = `Bearer ${newToken}`;
          res = await fetch(url, {
            ...options,
            headers,
            signal: options.signal || AbortSignal.timeout(8000)
          });
        }
      }

      const text = await res.text();
      let data = {};
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }

      return {
        ok: res.ok,
        status: res.status,
        data
      };
    } catch (err) {
      return {
        ok: false,
        status: 0,
        isNetworkError: true,
        error: err.message
      };
    }
  }

  /**
   * Push batched synchronization operations to cloud
   */
  async pushSyncBatch(operations) {
    return this.request('/sync/push', {
      method: 'POST',
      body: JSON.stringify({ operations })
    });
  }

  /**
   * Pull updated records from cloud since last sync cursor
   */
  async pullSyncUpdates(cursor) {
    const q = cursor ? `?cursor=${encodeURIComponent(cursor)}` : '';
    return this.request(`/sync/pull${q}`, {
      method: 'GET'
    });
  }
}

export const apiClient = new ApiClient();
