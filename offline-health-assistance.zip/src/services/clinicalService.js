import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';

/**
 * Service to execute 100% offline CRUD operations across:
 * - Health Assessments
 * - Maternal & Antenatal Visits
 * - Child Health & Growth
 * - Immunizations
 * - Chronic Conditions
 * - Referrals
 * - Follow-up Schedules
 */

const deviceId = getOrCreateDeviceId();

export const ClinicalService = {
  // ================= HEALTH ASSESSMENTS ================= //
  async createAssessment(data, user) {
    const timestamp = new Date().toISOString();
    const id = `ha-${Date.now()}`;

    // Clinical screening warning rules
    const warningSigns = [];
    const sys = parseInt(data.systolicBp, 10);
    const dia = parseInt(data.diastolicBp, 10);
    const glu = parseInt(data.bloodGlucose, 10);
    const spo2 = parseInt(data.spo2, 10);

    if (sys >= 140 || dia >= 90) {
      warningSigns.push(`Hypertension Alert (BP ${sys}/${dia} mmHg)`);
    }
    if (sys >= 160 || dia >= 100) {
      warningSigns.push(`Severe Hypertensive Urgency (BP ${sys}/${dia} mmHg)`);
    }
    if (glu >= 200) {
      warningSigns.push(`Hyperglycemia Warning (RBS ${glu} mg/dL)`);
    }
    if (glu > 0 && glu < 70) {
      warningSigns.push(`Hypoglycemia Critical Warning (RBS ${glu} mg/dL)`);
    }
    if (spo2 > 0 && spo2 < 95) {
      warningSigns.push(`Hypoxia Warning (SpO2 ${spo2}%)`);
    }

    // BMI calculation if height and weight present
    let bmi = null;
    const h = parseFloat(data.height);
    const w = parseFloat(data.weight);
    if (h > 0 && w > 0) {
      const hm = h / 100;
      bmi = parseFloat((w / (hm * hm)).toFixed(1));
    }

    const record = {
      id,
      patientId: data.patientId,
      systolicBp: sys || null,
      diastolicBp: dia || null,
      pulse: parseInt(data.pulse, 10) || null,
      spo2: spo2 || null,
      bloodGlucose: glu || null,
      temperature: parseFloat(data.temperature) || null,
      respiratoryRate: parseInt(data.respiratoryRate, 10) || null,
      height: h || null,
      weight: w || null,
      bmi,
      warningSigns,
      assessedBy: user?.name || 'Local Health Worker',
      notes: data.notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.healthAssessments.add(record);

    // Sync queue entry
    await db.syncQueue.add({
      entity: 'healthAssessments',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'healthAssessments',
      entityId: id,
      action: 'VITAL_ASSESSMENT_RECORDED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Vitals recorded for ${data.patientId}. BP: ${sys}/${dia}, Warning signs: ${warningSigns.length}`
    });

    return record;
  },

  async getAssessmentsByPatient(patientId) {
    return await db.healthAssessments
      .where('patientId')
      .equals(patientId)
      .reverse()
      .sortBy('createdAt');
  },

  // ================= MATERNAL & ANTENATAL CARE ================= //
  async registerPregnancy(data, user) {
    const timestamp = new Date().toISOString();
    const id = `mat-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      lmp: data.lmp,
      edd: data.edd,
      trimester: parseInt(data.trimester, 10) || 1,
      gravidity: parseInt(data.gravidity, 10) || 1,
      parity: parseInt(data.parity, 10) || 0,
      highRiskFactors: data.highRiskFactors || [],
      status: 'active',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.maternalRecords.add(record);

    // Update patient maternal status
    await db.patients.update(data.patientId, {
      isPregnant: true,
      category: 'maternal',
      riskLevel: data.highRiskFactors && data.highRiskFactors.length > 0 ? 'high' : 'normal',
      updatedAt: timestamp
    });

    // Sync queue
    await db.syncQueue.add({
      entity: 'maternalRecords',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'maternalRecords',
      entityId: id,
      action: 'PREGNANCY_REGISTERED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Pregnancy registered for ${data.patientId}. EDD: ${data.edd}`
    });

    return record;
  },

  async recordAntenatalVisit(data, user) {
    const timestamp = new Date().toISOString();
    const id = `anc-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      maternalRecordId: data.maternalRecordId || '',
      visitNumber: parseInt(data.visitNumber, 10) || 1,
      systolicBp: parseInt(data.systolicBp, 10),
      diastolicBp: parseInt(data.diastolicBp, 10),
      weightKg: parseFloat(data.weightKg),
      fundalHeightCm: parseFloat(data.fundalHeightCm) || null,
      fetalHeartRate: parseInt(data.fetalHeartRate, 10) || null,
      urineProtein: data.urineProtein || 'Nil',
      hemoglobin: parseFloat(data.hemoglobin) || null,
      warningSigns: data.warningSigns || 'None',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.antenatalVisits.add(record);

    await db.syncQueue.add({
      entity: 'antenatalVisits',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'antenatalVisits',
      entityId: id,
      action: 'ANC_VISIT_RECORDED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `ANC Visit #${data.visitNumber} logged for patient ${data.patientId}`
    });

    return record;
  },

  // ================= CHILD HEALTH & IMMUNIZATION ================= //
  async recordChildGrowth(data, user) {
    const timestamp = new Date().toISOString();
    const id = `gr-${Date.now()}`;

    const muac = parseFloat(data.muacCm);
    let nutritionGrade = 'Normal Growth';
    if (muac > 0 && muac < 11.5) {
      nutritionGrade = 'Severe Acute Malnutrition (SAM)';
    } else if (muac >= 11.5 && muac < 12.5) {
      nutritionGrade = 'Moderate Acute Malnutrition (MAM)';
    }

    const record = {
      id,
      childId: data.childId || data.patientId,
      patientId: data.patientId,
      ageMonths: parseInt(data.ageMonths, 10) || 0,
      weightKg: parseFloat(data.weightKg) || 0,
      heightCm: parseFloat(data.heightCm) || 0,
      muacCm: muac || 0,
      nutritionGrade,
      measuredBy: user?.name || 'ASHA Worker',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.growthRecords.add(record);

    await db.syncQueue.add({
      entity: 'growthRecords',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  },

  async updateImmunization(data, user) {
    const timestamp = new Date().toISOString();
    const id = data.id || `imm-${Date.now()}`;

    const record = {
      id,
      childId: data.childId || data.patientId,
      patientId: data.patientId,
      vaccineName: data.vaccineName,
      doseNumber: parseInt(data.doseNumber, 10) || 1,
      dueDate: data.dueDate,
      givenDate: data.givenDate || timestamp.slice(0, 10),
      status: data.status || 'administered',
      administeredBy: user?.name || 'ANM Worker',
      syncStatus: 'pending',
      version: (data.version || 0) + 1,
      createdAt: data.createdAt || timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.immunizations.put(record);

    await db.syncQueue.add({
      entity: 'immunizations',
      entityId: id,
      operation: 'UPDATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  },

  // ================= REFERRALS & FOLLOW-UPS ================= //
  async createReferral(data, user) {
    const timestamp = new Date().toISOString();
    const id = `ref-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      urgency: data.urgency || 'urgent', // emergency, urgent, routine
      status: 'referred',
      referralFacility: data.referralFacility,
      reason: data.reason,
      referredBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Community Worker',
      doctorFeedback: '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.referrals.add(record);

    await db.syncQueue.add({
      entity: 'referrals',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'referrals',
      entityId: id,
      action: 'REFERRAL_CREATED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Emergency referral created for ${data.patientId} to ${data.referralFacility}`
    });

    return record;
  },

  async scheduleFollowUp(data, user) {
    const timestamp = new Date().toISOString();
    const id = `fu-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      scheduledDate: data.scheduledDate,
      visitType: data.visitType,
      priority: data.priority || 'routine',
      isCompleted: false,
      notes: data.notes || '',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      deviceId
    };

    await db.followUps.add(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  },

  async toggleFollowUpComplete(id, completed = true, user) {
    const timestamp = new Date().toISOString();
    const record = await db.followUps.get(id);
    if (!record) return;

    record.isCompleted = completed;
    record.completedDate = completed ? timestamp : null;
    record.syncStatus = 'pending';
    record.version = (record.version || 1) + 1;

    await db.followUps.put(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'UPDATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return record;
  }
};
