import { db } from '../db/db';

/**
 * OFFLINE HEALTH - Intelligent Healthcare NLP Knowledge Engine
 * 100% Offline deterministic matching using verified National Health Mission,
 * WHO, and IMNCI approved guidelines.
 * Supports: English, ಕನ್ನಡ (Kannada), and हिन्दी (Hindi).
 */

// Comprehensive knowledge database for offline matching
const APPROVED_KNOWLEDGE_LIBRARY = [
  // 1. PREGNANCY DANGER SIGNS & PREECLAMPSIA
  {
    id: 'kb-preeclampsia',
    category: 'maternal',
    keywords: [
      'pregnancy', 'pregnant', 'danger', 'warning', 'preeclampsia', 'eclampsia', 'headache', 'swelling', 'high bp', 'blood pressure',
      'ಗರ್ಭಾವಸ್ಥೆ', 'ಗರ್ಭಿಣಿ', 'ಅಪಾಯ', 'ಲಕ್ಷಣಗಳು', 'ತಲೆನೋವು', 'ಊತ', 'ರಕ್ತದೊತ್ತಡ', 'ಬಿಪಿ',
      'गर्भावस्था', 'गर्भवती', 'खतरे', 'लक्षण', 'सिरदर्द', 'सूजन', 'रक्तचाप', 'बीपी'
    ],
    sources: [
      'Ministry of Health and Family Welfare (MoHFW) - Guidelines for Antenatal Care',
      'National Health Mission (NHM) - Maternal & Newborn Health',
      'WHO Recommendations on Antenatal Care for a Positive Pregnancy Experience'
    ],
    emergency: true,
    responses: {
      en: `### Warning Signs During Pregnancy (Maternal Alert)

Immediate medical evaluation is needed if a pregnant woman experiences:
1. **Severe High Blood Pressure (>= 140/90 mmHg)** or persistent frontal headache.
2. **Visual disturbances:** Blurring of vision, seeing spots or flashes of light.
3. **Severe swelling:** Sudden edema of the face, hands, or eyelids.
4. **Vaginal bleeding:** Any bleeding during pregnancy requires emergency evaluation.
5. **Reduced fetal movement:** Noticeable reduction in daily fetal kicks in the third trimester.
6. **Severe abdominal pain:** Epigastric or upper-right quadrant abdominal pain.

**Field Escalation:** If BP is >= 140/90 with headache, immediately arrange urgent transport to the nearest PHC / CHC. Call 108 emergency ambulance.`,
      kn: `### ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಕಂಡುಬರುವ ಅಪಾಯಕಾರಿ ಲಕ್ಷಣಗಳು

ಗರ್ಭಿಣಿ ಮಹಿಳೆಯಲ್ಲಿ ಈ ಕೆಳಗಿನ ಲಕ್ಷಣಗಳು ಕಂಡುಬಂದರೆ ತಕ್ಷಣ ವೈದ್ಯಕೀಯ ಚಿಕಿತ್ಸೆ ಕೊಡಿಸಬೇಕು:
1. **ಅತಿಯಾದ ರಕ್ತದೊತ್ತಡ (BP >= 140/90 mmHg)** ಅಥವಾ ನಿರಂತರ ತೀವ್ರ ತಲೆನೋವು.
2. **ದೃಷ್ಟಿ ಮಂದವಾಗುವುದು:** ಕಣ್ಣು ಮಂಜಾಗುವುದು ಅಥವಾ ಬೆಳಕಿನ ಮಿಂಚು ಕಾಣಿಸುವುದು.
3. **ಮುಖ ಮತ್ತು ಕೈಗಳಲ್ಲಿ ಹಠಾತ್ ಊತ:** ಕಣ್ಣು ರೆಪ್ಪೆಗಳು ಮತ್ತು ಮುಖ ಊದಿಕೊಳ್ಳುವುದು.
4. **ಯೋನಿಯಿಂದ ರಕ್ತಸ್ರಾವ:** ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಯಾವುದೇ ರಕ್ತಸ್ರಾವವು ಅತ್ಯಂತ ಅಪಾಯಕಾರಿ.
5. **ಮಗುವಿನ ಚಲನೆ ಕಡಿಮೆಯಾಗುವುದು:** ಗರ್ಭದಲ್ಲಿ ಮಗುವಿನ ಒದೆಯುವಿಕೆ ಕಡಿಮೆಯಾಗುವುದು.
6. **ಹೊಟ್ಟೆಯ ಮೇಲ್ಭಾಗದಲ್ಲಿ ತೀವ್ರ ನೋವು.**

**ತುರ್ತು ಕ್ರಮ:** ತಕ್ಷಣ ರೋಗಿಯನ್ನು ಸಮುದಾಯ ಆರೋಗ್ಯ ಕೇಂದ್ರಕ್ಕೆ (CHC) ಕರೆದೊಯ್ಯಿರಿ. 108 ಆಂಬ್ಯುಲೆನ್ಸ್‌ಗೆ ಕರೆ ಮಾಡಿ.`,
      hi: `### गर्भावस्था में खतरे के मुख्य लक्षण (मातृ चेतावनी)

गर्भवती महिला में इनमें से कोई भी लक्षण दिखने पर तुरंत डॉक्टर को दिखाएं:
1. **अत्यधिक उच्च रक्तचाप (BP >= 140/90)** या लगातार तेज सिरदर्द।
2. **आंखों के आगे धुंधलापन आना:** या रोशनी की चमक दिखाई देना।
3. **चेहरे और हाथों में अचानक सूजन आना।**
4. **योनि से रक्तस्राव (ब्लीडिंग):** गर्भावस्था में ब्लीडिंग होना आपातकाल का संकेत है।
5. **शिशु की हलचल कम होना:** तीसरे ट्राइमेस्टर में गर्भ में बच्चे की हलचल कम होना।
6. **पेट के ऊपरी हिस्से में तेज दर्द।**

**तत्काल कदम:** 108 एंबुलेंस बुलाकर तुरंत नजदीकी प्राथमिक स्वास्थ्य केंद्र (PHC/CHC) ले जाएं।`
    }
  },

  // 2. SNAKEBITE EMERGENCY PROTOCOL
  {
    id: 'kb-snakebite',
    category: 'emergency',
    keywords: [
      'snake', 'snakebite', 'bite', 'venom', 'poison', 'cpr',
      'ಹಾವು', 'ಹಾವು ಕಡಿತ', 'ವಿಷ', 'ಹಾವುಕಡಿತ',
      'सांप', 'सर्पदंश', 'सांप काटना', 'जहर'
    ],
    sources: [
      'National Snakebite Protocol - Ministry of Health & Family Welfare, India',
      'WHO Guidelines for the Management of Snakebites in South-East Asia'
    ],
    emergency: true,
    responses: {
      en: `### Snakebite Emergency Protocol (DOs & DON'Ts)

1. **Immediate DOs:**
   - Keep victim completely calm and still. Movement accelerates venom absorption.
   - Immobilize the bitten limb with a rigid splint at or below heart level.
   - Remove rings, bangles, anklets, and tight clothing before swelling begins.
   - Rush patient to the nearest hospital / CHC equipped with Anti-Snake Venom (ASV).
   - Note the exact time of bite and monitor for ptosis (drooping eyelids).

2. **Dangerous DON'Ts (Never Do):**
   - **DO NOT** apply a tourniquet (risk of arterial gangrene and amputation).
   - **DO NOT** cut, pierce, or slash the bite wound.
   - **DO NOT** suck venom with mouth or vacuum devices.
   - **DO NOT** apply ice, herbal pastes, potassium permanganate, or cow dung.`,
      kn: `### ಹಾವು ಕಡಿತದ ತುರ್ತು ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ಮಾರ್ಗಸೂಚಿ

1. **ಮಾಡಬೇಕಾದ ಮುಖ್ಯ ಕ್ರಮಗಳು:**
   - ರೋಗಿಯನ್ನು ಗಾಬರಿಗೊಳಿಸದೆ ಶಾಂತವಾಗಿ ಮಲಗಿಸಿ. ಓಡಾಡಿದರೆ ವಿಷ ರಕ್ತದಲ್ಲಿ ವೇಗವಾಗಿ ಹರಡುತ್ತದೆ.
   - ಕಚ್ಚಿದ ಕೈ ಅಥವಾ ಕಾಲನ್ನು ಅಲ್ಲಾಡಿಸದಂತೆ ಕಟ್ಟಿಗೆಯ ಪಟ್ಟಿಯಿಂದ ಬಿಗಿಯಿರಿ (ಸ್ಪ್ಲಿಂಟ್ ಮಾಡಿ).
   - ಕೈಬಳೆ, ಉಂಗುರ, ಕಾಲುಂಗುರಗಳನ್ನು ತಕ್ಷಣ ತೆಗೆಯಿರಿ (ಊತ ಬರುವ ಮುನ್ನ).
   - ಆಂಟಿ-ಸ್ನೇಕ್ ವೆನಮ್ (ASV) ಔಷಧಿ ಲಭ್ಯವಿರುವ ಸಮುದಾಯ ಆರೋಗ್ಯ ಕೇಂದ್ರಕ್ಕೆ ತಕ್ಷಣ ಕರೆದೊಯ್ಯಿರಿ.

2. **ಮಾಡಬಾರದ ತಪ್ಪುಗಳು (ಅಪಾಯಕಾರಿ):**
   - ಗಾಯಕ್ಕೆ ರಕ್ತ ಕಟ್ಟಿಹಾಕುವಂತೆ ಅತಿಯಾಗಿ ಬಿಗಿಯಬೇಡಿ (ಟಾರ್ನಿಕೆಟ್ ಕಟ್ಟಬೇಡಿ).
   - ಬ್ಲೇಡ್‌ನಿಂದ ಗಾಯ ಕೊಯ್ಯಬೇಡಿ.
   - ಬಾಯಿಯಿಂದ ವಿಷ ಹೀರುವ ಪ್ರಯತ್ನ ಮಾಡಬೇಡಿ.
   - ಗಾಯಕ್ಕೆ ಯಾವುದೇ ಗಿಡಮೂಲಿಕೆ, ಸುಣ್ಣ ಅಥವಾ ಬೆರಣಿ ಹಚ್ಚಬೇಡಿ.`,
      hi: `### सर्पदंश (सांप काटने पर) आपातकालीन प्रोटोकॉल

1. **क्या करें:**
   - मरीज को बिल्कुल शांत और स्थिर रखें। चलने-फिरने से जहर तेजी से फैलता है।
   - काटे गए अंग (हाथ या पैर) को खपच्ची (Splint) बांधकर स्थिर करें।
   - सूजन आने से पहले तुरंत अंगूठी, चूड़ी, पायल आदि उतार लें।
   - मरीज को तुरंत उस अस्पताल ले जाएं जहां एंटी-स्नेक वेनम (ASV) उपलब्ध हो।

2. **क्या कभी न करें:**
   - काटे हुए स्थान पर चीरा या कट न लगाएं।
   - बहुत टाइट पट्टी (टॉर्निकेट) न बांधें।
   - मुंह से जहर चूसने की कोशिश न करें।
   - कोई जड़ी-बूटी, चूना या राख न लगाएं।`
    }
  },

  // 3. DIARRHEA, DEHYDRATION & ORS PREPARATION
  {
    id: 'kb-ors-diarrhea',
    category: 'general',
    keywords: [
      'diarrhea', 'dehydration', 'ors', 'vomiting', 'loose stool', 'water', 'zinc',
      'ಭೇದಿ', 'ವಾಂತಿ', 'ನಿರ್ಜಲೀಕರಣ', 'ಓಆರ್‌ಎಸ್', 'ಜಿಂಕ್',
      'दस्त', 'उल्टी', 'ओआरएस', 'निर्जलीकरण', 'जिंक', 'डायरिया'
    ],
    sources: [
      'WHO / UNICEF Joint Statement: Management of Acute Diarrhoea',
      'National Health Mission (NHM) - Intensified Diarrhoea Control Fortnight (IDCF)'
    ],
    emergency: false,
    responses: {
      en: `### Management of Dehydration and ORS Preparation

1. **Signs of Dehydration:**
   - Sunken eyes, extreme thirst, dry tongue/lips, skin pinch returns slowly (>2 seconds), sunken fontanelle in infants, lethargy.

2. **Correct ORS Preparation (Zero Error):**
   - Wash hands thoroughly with soap.
   - Mix the **entire packet of ORS into exactly 1 liter** of clean drinking or boiled-and-cooled water.
   - Stir until fully dissolved.
   - Give frequent sips with a clean spoon or cup.
   - **Do not boil** prepared ORS. Discard any solution left after 24 hours.

3. **Zinc Supplementation:**
   - Give 20 mg elemental Zinc daily for 14 continuous days (10 mg daily for infants under 6 months) to repair intestinal lining.`,
      kn: `### ನಿರ್ಜಲೀಕರಣ ಮತ್ತು ಓಆರ್‌ಎಸ್ (ORS) ತಯಾರಿಸುವ ಸರಿಯಾದ ವಿಧಾನ

1. **ನಿರ್ಜಲೀಕರಣದ ಮುಖ್ಯ ಲಕ್ಷಣಗಳು:**
   - ಕುಳಿಬಿದ್ದ ಕಣ್ಣುಗಳು, ಒಣಗಿದ ಬಾಯಿ ಮತ್ತು ನಾಲಿಗೆ, ಚರ್ಮವನ್ನು ಎಳೆದರೆ ತಕ್ಷಣ ಮೊದಲಿನ ಸ್ಥಿತಿಗೆ ಮರಳದಿರುವುದು, ವಿಪರೀತ ಬಾಯಾರಿಕೆ.

2. **ಓಆರ್‌ಎಸ್ ದ್ರಾವಣ ತಯಾರಿಸುವ ವಿಧಾನ:**
   - ಕೈಗಳನ್ನು ಸಾಬೂನಿನಿಂದ ಸ್ವಚ್ಛವಾಗಿ ತೊಳೆಯಿರಿ.
   - **ಪೂರ್ಣ ಒಂದು ಪ್ಯಾಕೆಟ್ ಓಆರ್‌ಎಸ್ ಪುಡಿಯನ್ನು ಸರಿಯಾಗಿ 1 ಲೀಟರ್ ಶುದ್ಧ ಕುಡಿಯುವ ನೀರಿನಲ್ಲಿ** ಹಾಕಿ ಕಲಸಿ.
   - ಚಮಚ ಅಥವಾ ಕಪ್ ಮೂಲಕ ಸಣ್ಣ ಸಣ್ಣ ಪ್ರಮಾಣದಲ್ಲಿ ಪದೇ ಪದೇ ಕುಡಿಸಿ.
   - ತಯಾರಿಸಿದ ದ್ರಾವಣವನ್ನು ಕಾಯಿಸಬೇಡಿ. 24 ಗಂಟೆಗಳ ನಂತರ ಉಳಿದ ದ್ರಾವಣವನ್ನು ಬಳಸಬೇಡಿ.

3. **ಜಿಂಕ್ ಮಾತ್ರೆಗಳು:**
   - ಕರುಳಿನ ಶಕ್ತಿಯನ್ನು ಪುನರುಜ್ಜೀವನಗೊಳಿಸಲು 14 ದಿನಗಳ ಕಾಲ ಸತತವಾಗಿ ಜಿಂಕ್ ಮಾತ್ರೆಗಳನ್ನು ನೀಡಿ.`,
      hi: `### निर्जलीकरण (डिहाइड्रेशन) और ओआरएस (ORS) बनाने का तरीका

1. **निर्जलीकरण के मुख्य लक्षण:**
   - धंसी हुई आंखें, सूखा मुंह और जीभ, त्वचा को खींचने पर धीरे-धीरे वापस जाना, अत्यधिक प्यास लगना।

2. **ओआरएस (ORS) घोल बनाने का सही तरीका:**
   - हाथ साबुन से अच्छी तरह धोएं।
   - **ओआरएस का पूरा पैकेट ठीक 1 लीटर साफ पीने के पानी में** पूरी तरह घोलें।
   - चम्मच या कटोरी से थोड़े-थोड़े अंतराल पर पिलाएं।
   - बने हुए घोल को उबालें नहीं। 24 घंटे के बाद बचा हुआ घोल फेंक दें।

3. **जिंक की गोली:**
   - 14 दिनों तक रोजाना जिंक की गोली अवश्य दें (6 माह से छोटे बच्चों को 10mg, बड़ों को 20mg)।`
    }
  },

  // 4. CHILD IMMUNIZATION IMPORTANCE & UIP SCHEDULE
  {
    id: 'kb-immunization',
    category: 'child',
    keywords: [
      'immunization', 'vaccine', 'vaccination', 'polio', 'bcg', 'pentavalent', 'measles', 'child vaccine',
      'ಲಸಿಕೆ', 'ಚುಚ್ಚುಮದ್ದು', 'ಪೋಲಿಯೋ', 'ಬಿಸಿಜಿ', 'ಪೆಂಟಾವಲೆಂಟ್', 'ದಡಾರ',
      'टीकाकरण', 'वैक्सीन', 'पोलियो', 'बीसीजी', 'पेंटावेलेंट', 'खसरा', 'टीका'
    ],
    sources: [
      'Universal Immunization Programme (UIP) - Ministry of Health and Family Welfare',
      'WHO Vaccine-Preventable Diseases Surveillance Standards'
    ],
    emergency: false,
    responses: {
      en: `### Child Immunization & Universal Schedule (UIP India)

Immunization protects infants from 12 life-threatening vaccine-preventable diseases.

1. **At Birth:**
   - BCG (Tuberculosis protection)
   - Oral Polio Vaccine (OPV-0)
   - Hepatitis B birth dose (within 24 hours)

2. **At 6, 10, and 14 Weeks:**
   - Pentavalent (Diphtheria, Pertussis, Tetanus, Hep B, Hib)
   - Rotavirus Vaccine (ROTA) - Severe diarrhea protection
   - Inactivated Polio Vaccine (fIPV)
   - Pneumococcal Conjugate Vaccine (PCV)

3. **At 9-12 Months:**
   - Measles-Rubella (MR 1st dose)
   - Vitamin A 1st dose (1 lakh IU)
   - PCV Booster & Japanese Encephalitis (where endemic)

**Adverse Event Protocol:** Mild fever or swelling at the injection site is normal. If persistent high fever (>102°F) or excessive crying occurs, consult the PHC medical officer.`,
      kn: `### ಮಕ್ಕಳ ಲಸಿಕಾ ಕಾರ್ಯಕ್ರಮ (ಸಾರ್ವತ್ರಿಕ ಲಸಿಕಾ ವೇಳಾಪಟ್ಟಿ)

ಲಸಿಕೆಯು ಮಕ್ಕಳನ್ನು ಮಾರಣಾಂತಿಕ ಕಾಯಿಲೆಗಳಿಂದ ರಕ್ಷಿಸುವ ಅತ್ಯಂತ ಸುರಕ್ಷಿತ ಕವಚವಾಗಿದೆ.

1. **ಹುಟ್ಟಿದ ತಕ್ಷಣ:**
   - ಬಿಸಿಜಿ (BCG - ಕ್ಷಯರೋಗ ತಡೆಗಟ್ಟಲು)
   - ಒಪಿವಿ-0 (OPV - ಪೋಲಿಯೋ ಹನಿ)
   - ಹೆಪಟೈಟಿಸ್-ಬಿ (ಜನನದ 24 ಗಂಟೆಯೊಳಗೆ)

2. **6, 10 ಮತ್ತು 14 ವಾರಗಳಲ್ಲಿ:**
   - ಪೆಂಟಾವಲೆಂಟ್ (ಘಂಟಲಮಾರಿ, ಧನುರ್ವಾಯು, ಹೆಪಟೈಟಿಸ್ ಬಿ, ಇತ್ಯಾದಿ 5 ರೋಗಗಳ ರಕ್ಷಣೆ)
   - ರೋಟಾವೈರಸ್ ಹನಿ (ತೀವ್ರ ಭೇದಿ ತಡೆಗೆ)
   - ಐಪಿವಿ (ಪೋಲಿಯೋ ಇಂಜೆಕ್ಷನ್) ಮತ್ತು ಪಿಸಿವಿ (ನ್ಯುಮೋನಿಯಾ ರಕ್ಷಣೆ)

3. **9 ರಿಂದ 12 ತಿಂಗಳಲ್ಲಿ:**
   - ದಡಾರ-ರುಬೆಲ್ಲಾ (MR ಮೊದಲ ಡೋಸ್)
   - ವಿಟಮಿನ್-ಎ ಮೊದಲ ಡೋಸ್

**ಮುನ್ನೆಚ್ಚರಿಕೆ:** ಲಸಿಕೆ ನಂತರ ಸಣ್ಣ ಜ್ವರ ಸಾಮಾನ್ಯ. ಜ್ವರ ಹೆಚ್ಚಾದರೆ ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರದ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.`,
      hi: `### बाल टीकाकरण और सार्वभौमिक टीकाकरण कार्यक्रम (UIP)

टीकाकरण बच्चों को 12 जानलेवा बीमारियों से बचाता है।

1. **जन्म के समय:**
   - बीसीजी (टीबी से बचाव)
   - पोलियो खुराक (OPV-0)
   - हेपेटाइटिस-बी (24 घंटे के भीतर)

2. **6, 10 और 14 सप्ताह में:**
   - पेंटावेलेंट (गलघोंटू, काली खांसी, टिटनेस, हेप-बी, हिब)
   - रोटावायरस (गंभीर दस्त से बचाव)
   - आईपीवी और पीसीवी (निमोनिया से बचाव)

3. **9 से 12 महीने में:**
   - एमआर (खसरा-रूबेला पहला टीका)
   - विटामिन-ए पहली खुराक

**ध्यान दें:** टीके के बाद हल्का बुखार सामान्य है। तेज बुखार होने पर तुरंत आशा या एएनएम से संपर्क करें।`
    }
  },

  // 5. PNEUMONIA AND SEVERE BREATHING DIFFICULTY
  {
    id: 'kb-pneumonia',
    category: 'child',
    keywords: [
      'breathing', 'breath', 'pneumonia', 'chest', 'cough', 'stridor', 'respiratory',
      'ಉಸಿರಾಟ', 'ಉಸಿರು', 'ನ್ಯುಮೋನಿಯಾ', 'ಎದೆ ಉಬ್ಬಸ', 'ಕೆಮ್ಮು',
      'सांस', 'सांस फूलना', 'निमोनिया', 'सीने में खिंचाव', 'खांसी'
    ],
    sources: [
      'Integrated Management of Neonatal and Childhood Illness (IMNCI)',
      'WHO / UNICEF Guidelines on Childhood Pneumonia Management'
    ],
    emergency: true,
    responses: {
      en: `### Recognizing Childhood Pneumonia and Respiratory Distress

1. **Fast Breathing Thresholds:**
   - Under 2 months: >= 60 breaths per minute.
   - 2 to 11 months: >= 50 breaths per minute.
   - 12 to 59 months: >= 40 breaths per minute.

2. **Critical Danger Signs (Immediate Referral Needed):**
   - **Chest indrawing:** The lower chest wall moves inwards when the child breathes in.
   - **Stridor:** Harsh whistling noise while breathing in when calm.
   - Inability to drink or breastfeed, or excessive sleepiness/lethargy.

**Emergency Action:** Keep the child upright and warm. Immediately refer to the Community Health Centre (CHC) or District Hospital for oxygen and pediatric antibiotic protocol.`,
      kn: `### ಮಕ್ಕಳಲ್ಲಿ ನ್ಯುಮೋನಿಯಾ ಮತ್ತು ತೀವ್ರ ಉಸಿರಾಟದ ತೊಂದರೆಯ ಲಕ್ಷಣಗಳು

1. **ವೇಗದ ಉಸಿರಾಟದ ಮಿತಿ:**
   - 2 ತಿಂಗಳ ಒಳಗಿನ ಶಿಶು: ನಿಮಿಷಕ್ಕೆ 60 ಕ್ಕಿಂತ ಹೆಚ್ಚು ಉಸಿರಾಟ.
   - 2 ರಿಂದ 11 ತಿಂಗಳು: ನಿಮಿಷಕ್ಕೆ 50 ಕ್ಕಿಂತ ಹೆಚ್ಚು ಉಸಿರಾಟ.
   - 1 ರಿಂದ 5 ವರ್ಷ: ನಿಮಿಷಕ್ಕೆ 40 ಕ್ಕಿಂತ ಹೆಚ್ಚು ಉಸಿರಾಟ.

2. **ತೀವ್ರ ಅಪಾಯದ ಲಕ್ಷಣಗಳು (ತಕ್ಷಣ ರೆಫರ್ ಮಾಡಿ):**
   - **ಎದೆ ಕುಸಿಯುವುದು:** ಮಗು ಉಸಿರೆಳೆದಾಗ ಎದೆಯ ಕೆಳಭಾಗ ಒಳಕ್ಕೆ ಹೋಗುವುದು.
   - ಉಸಿರೆಳೆಯುವಾಗ ಶಬ್ದ (ಸ್ಟ್ರೈಡರ್) ಬರುವುದು.
   - ಎದೆಹಾಲು ಕುಡಿಯಲು ಅಥವಾ ತಿನ್ನಲು ಸಾಧ್ಯವಾಗದಿರುವುದು, ಮಂಪರು ಬರುವುದು.

**ತುರ್ತು ಕ್ರಮ:** ಮಗುವನ್ನು ಬೆಚ್ಚಗಿರಿಸಿ ತಕ್ಷಣ ತಾಲೂಕು ಆಸ್ಪತ್ರೆಗೆ ಅಥವಾ ಸಮುದಾಯ ಆರೋಗ್ಯ ಕೇಂದ್ರಕ್ಕೆ ಕರೆದೊಯ್ಯಿರಿ.`,
      hi: `### बच्चों में निमोनिया और सांस लेने में गंभीर तकलीफ के लक्षण

1. **तेज सांस की पहचान:**
   - 2 महीने से छोटे बच्चे: प्रति मिनट 60 या अधिक सांसें।
   - 2 से 11 महीने के बच्चे: प्रति मिनट 50 या अधिक सांसें।
   - 1 से 5 वर्ष के बच्चे: प्रति मिनट 40 या अधिक सांसें।

2. **गंभीर खतरे के संकेत:**
   - **सीने का अंदर धंसना:** सांस लेते समय सीने का निचला हिस्सा अंदर खिंचना।
   - सांस लेते समय सीटी जैसी आवाज (स्ट्राइडोर) आना।
   - स्तनपान या दूध पीने में असमर्थ होना, बेहोशी जैसी स्थिति।

**आपातकालीन कार्रवाई:** बच्चे को गर्म रखें और तुरंत अस्पताल (CHC) ले जाएं जहां ऑक्सीजन उपलब्ध हो।`
    }
  },

  // 6. HIGH FEVER FIRST AID
  {
    id: 'kb-fever',
    category: 'general',
    keywords: [
      'fever', 'temperature', 'hot', 'sponge', 'chills',
      'ಜ್ವರ', 'ತಾಪಮಾನ', 'ಮೈಬಿಸಿ', 'ಚಳಿ',
      'बुखार', 'तापमान', 'ठंड लगना', 'तेज बुखार'
    ],
    sources: [
      'National Health Mission - Clinical Practice Guidelines',
      'Indian Academy of Pediatrics (IAP) Guidelines on Fever'
    ],
    emergency: false,
    responses: {
      en: `### Field Management of High Fever

1. **Step-by-Step Care:**
   - Keep patient in a well-ventilated, shaded room with light cotton clothing.
   - **Tepid Sponging:** Use normal tap water (NOT ice water) on forehead, neck, and armpits.
   - Encourage plenty of fluids (boiled water, rice water, lemon water, ORS) to prevent dehydration.
   - Paracetamol suspension/tablets as per standard age/weight dosage (10-15 mg/kg per dose).

2. **Danger Signs Requiring Escalation:**
   - Fever lasting more than 3 continuous days.
   - Stiff neck, extreme lethargy, or inability to wake up.
   - Convulsions or fits (Febrile seizures).
   - Purple spots or rash appearing on the skin.`,
      kn: `### ತೀವ್ರ ಜ್ವರಕ್ಕೆ ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ಕ್ರಮಗಳು

1. **ಮಾಡಬೇಕಾದ ಉಪಶಮನ ಕ್ರಮಗಳು:**
   - ರೋಗಿಯನ್ನು ಗಾಳಿಯಾಡುವ ಕೋಣೆಯಲ್ಲಿ ಇರಿಸಿ ಮತ್ತು ತೆಳುವಾದ ಹತ್ತಿ ಬಟ್ಟೆ ಹಾಕಿ.
   - **ತಣ್ಣೀರಿನ ಪಟ್ಟಿ:** ಹಣೆ, ಕುತ್ತಿಗೆ ಮತ್ತು ಕಂಕುಳುಗಳಿಗೆ ಸಾಮಾನ್ಯ ನೀರಿನಲ್ಲಿ ಒದ್ದೆ ಮಾಡಿದ ಬಟ್ಟೆಯಿಂದ ಒರೆಸಿ (ಐಸ್ ನೀರು ಬಳಸಬೇಡಿ).
   - ರೋಗಿಗೆ ಗಂಜಿ, ನಿಂಬೆಹಣ್ಣಿನ ನೀರು, ಓಆರ್‌ಎಸ್ ಅಥವಾ ಕುದಿಸಿ ಆರಿಸಿದ ನೀರನ್ನು ಹೆಚ್ಚಾಗಿ ಕುಡಿಸಿ.

2. **ವೈದ್ಯರ ಬಳಿಗೆ ಹೋಗಬೇಕಾದ ಅಪಾಯದ ಲಕ್ಷಣಗಳು:**
   - ಜ್ವರ 3 ದಿನಗಳಿಗಿಂತ ಹೆಚ್ಚು ಕಾಲ ಮುಂದುವರಿದರೆ.
   - ಕುತ್ತಿಗೆ ಬಿಗಿಯಾಗುವುದು ಅಥವಾ ರೋಗಿ ಪ್ರಜ್ಞೆ ತಪ್ಪುವುದು.
   - ಜ್ವರದ ಜೊತೆಗೆ ಫಿಟ್ಸ್ (ಸೆಳವು) ಬರುವುದು.
   - ಮೈಮೇಲೆ ಕೆಂಪು ಅಥವಾ ನೇರಳೆ ಬಣ್ಣದ ದದ್ದುಗಳು ಕಾಣಿಸಿಕೊಳ್ಳುವುದು.`,
      hi: `### तेज बुखार का प्राथमिक उपचार

1. **बुखार कम करने के तरीके:**
   - मरीज को हवादार कमरे में रखें और हल्के सूती कपड़े पहनाएं।
   - **साधारण पानी की पट्टी:** माथे, गर्दन और बगलों पर सामान्य नल के पानी की पट्टी रखें (बर्फ का पानी बिल्कुल न लगाएं)।
   - खूब तरल पदार्थ (दलिया का पानी, नींबू पानी, ओआरएस) पिलाएं ताकि पानी की कमी न हो।

2. **खतरे के संकेत (तुरंत डॉक्टर को दिखाएं):**
   - बुखार 3 दिन से ज्यादा रहे।
   - गर्दन में अकड़न या बेहोशी छाना।
   - बुखार के साथ झटके (दौरे/फिक्स) आना।
   - त्वचा पर लाल या बैंगनी चकत्ते उभरना।`
    }
  },

  // 7. HYPERTENSION & BLOOD PRESSURE MONITORING
  {
    id: 'kb-hypertension',
    category: 'chronic',
    keywords: [
      'blood pressure', 'hypertension', 'bp', 'systolic', 'diastolic', 'ncd',
      'ರಕ್ತದೊತ್ತಡ', 'ಬಿಪಿ', 'ಅಧಿಕ ರಕ್ತದೊತ್ತಡ',
      'रक्तचाप', 'बीपी', 'हाई बीपी', 'हाइपरटेंशन'
    ],
    sources: [
      'National Programme for Prevention and Control of Non-Communicable Diseases (NP-NCD)',
      'Indian Council of Medical Research (ICMR) Guidelines for Management of Hypertension'
    ],
    emergency: false,
    responses: {
      en: `### Blood Pressure Monitoring & Hypertension Awareness

1. **Blood Pressure Categories (Adults):**
   - **Normal:** Systolic < 120 and Diastolic < 80 mmHg.
   - **Pre-hypertension:** 120-139 / 80-89 mmHg.
   - **Stage 1 Hypertension:** 140-159 / 90-99 mmHg.
   - **Stage 2 Hypertension:** >= 160 / >= 100 mmHg.

2. **Accurate Measurement Protocol:**
   - Patient should rest quietly for 5 minutes before measurement.
   - No caffeine, smoking, or exertion 30 minutes prior.
   - Arm supported at heart level with correct cuff size.

3. **Lifestyle & Treatment Adherence:**
   - Reduce dietary salt to less than 5 grams (1 teaspoon) per day.
   - Daily 30 minutes of brisk walking.
   - Emphasize to patient that anti-hypertensive medications must NOT be stopped without physician approval.`,
      kn: `### ರಕ್ತದೊತ್ತಡ (BP) ತಪಾಸಣೆ ಮತ್ತು ಅಧಿಕ ರಕ್ತದೊತ್ತಡದ ಜಾಗೃತಿ

1. **ರಕ್ತದೊತ್ತಡದ ಮಟ್ಟಗಳು:**
   - **ಸಾಮಾನ್ಯ ಮಟ್ಟ:** 120/80 mmHg ಗಿಂತ ಕಡಿಮೆ.
   - **ಹೈಪರ್‌ಟೆನ್ಷನ್ ಹಂತ 1:** 140-159 / 90-99 mmHg.
   - **ಹೈಪರ್‌ಟೆನ್ಷನ್ ಹಂತ 2 (ಅಪಾಯಕಾರಿ):** 160/100 mmHg ಗಿಂತ ಹೆಚ್ಚು.

2. **ತಪಾಸಣೆ ಮಾಡುವ ಸರಿಯಾದ ವಿಧಾನ:**
   - ಬಿಪಿ ಪರೀಕ್ಷೆ ಮಾಡುವ ಮುನ್ನ ರೋಗಿ 5 ನಿಮಿಷ ವಿಶ್ರಾಂತಿಯಲ್ಲಿರಬೇಕು.
   - ಕೈಯನ್ನು ಹೃದಯದ ಮಟ್ಟದಲ್ಲಿ ಇರಿಸಬೇಕು.

3. **ಆಹಾರ ಮತ್ತು ಔಷಧಿ ನಿಯಮಗಳು:**
   - ಆಹಾರದಲ್ಲಿ ಉಪ್ಪಿನ ಪ್ರಮಾಣವನ್ನು ದಿನಕ್ಕೆ 5 ಗ್ರಾಂ (ಒಂದು ಚಮಚ) ಗಿಂತ ಕಡಿಮೆ ಮಾಡಿ.
   - ದಿನಕ್ಕೆ ಕನಿಷ್ಠ 30 ನಿಮಿಷ ನಡಿಗೆ ಮಾಡಿ.
   - ವೈದ್ಯರ ಸಲಹೆಯಿಲ್ಲದೆ ಬಿಪಿ ಔಷಧಿಯನ್ನು ಎಂದಿಗೂ ನಿಲ್ಲಿಸಬಾರದು.`,
      hi: `### रक्तचाप (बीपी) की निगरानी और उच्च रक्तचाप की रोकथाम

1. **रक्तचाप का वर्गीकरण:**
   - **सामान्य:** 120/80 mmHg से कम।
   - **स्टेज 1 हाइपरटेंशन:** 140-159 / 90-99 mmHg।
   - **स्टेज 2 हाइपरटेंशन (गंभीर):** 160/100 mmHg या उससे अधिक।

2. **सही जांच का तरीका:**
   - बीपी नापने से पहले मरीज को 5 मिनट शांत बैठने दें।
   - हाथ को दिल की सीध में सहारा देकर रखें।

3. **सावधानियां और सलाह:**
   - भोजन में नमक दिनभर में 1 चम्मच (5 ग्राम) से कम रखें।
   - रोजाना 30 मिनट तेज चलें।
   - बीपी की दवा बिना डॉक्टर की सलाह के कभी बंद न करें।`
    }
  }
];

export const KnowledgeEngine = {
  /**
   * Process query offline using keyword scoring, language detection, and rule evaluation
   */
  async query(userText, preferredLang = 'en') {
    if (!userText || !userText.trim()) {
      return null;
    }

    const raw = userText.toLowerCase().trim();

    // 1. Automatic language detection heuristic based on Unicode script ranges
    let detectedLang = preferredLang;
    if (/[\u0C80-\u0CFF]/.test(userText)) {
      detectedLang = 'kn'; // Kannada
    } else if (/[\u0900-\u097F]/.test(userText)) {
      detectedLang = 'hi'; // Hindi (Devanagari)
    }

    // 2. Tokenize and extract clean search stems
    const tokens = raw.replace(/[?,.!;:'"()]/g, ' ').split(/\s+/).filter(t => t.length >= 2);

    // 3. Match against approved local knowledge library
    let bestMatch = null;
    let highestScore = 0;

    for (const article of APPROVED_KNOWLEDGE_LIBRARY) {
      let score = 0;
      for (const kw of article.keywords) {
        const kwLower = kw.toLowerCase();
        if (raw.includes(kwLower)) {
          score += 5; // Direct phrase match
        } else {
          for (const token of tokens) {
            if (kwLower === token || (token.length >= 4 && kwLower.includes(token))) {
              score += 2;
            }
          }
        }
      }

      if (score > highestScore) {
        highestScore = score;
        bestMatch = article;
      }
    }

    // 4. Threshold check: minimum score of 3 required for a verified clinical match
    const timestamp = new Date().toISOString();

    if (highestScore >= 3 && bestMatch) {
      const responseText = bestMatch.responses[detectedLang] || bestMatch.responses['en'];

      const result = {
        matched: true,
        articleId: bestMatch.id,
        category: bestMatch.category,
        language: detectedLang,
        emergency: bestMatch.emergency,
        text: responseText,
        sources: bestMatch.sources,
        timestamp
      };

      // Persist to IndexedDB assistantHistory
      try {
        if (db.assistantHistory) {
          await db.assistantHistory.add({
            role: 'assistant',
            text: responseText,
            language: detectedLang,
            sources: bestMatch.sources,
            emergencyFlag: bestMatch.emergency,
            timestamp
          });
        }
      } catch (e) {
        console.warn('[KnowledgeEngine] History log skipped:', e);
      }

      return result;
    }

    // 5. Safe Fallback when no approved guideline matches
    const fallbacks = {
      en: "I could not find verified National Health Mission or WHO guidelines matching this specific query in the local offline database. Please refer the patient to the Primary Health Centre Medical Officer for clinical examination.",
      kn: "ಈ ನಿರ್ದಿಷ್ಟ ಪ್ರಶ್ನೆಗೆ ಸ್ಥಳೀಯ ಆಫ್‌ಲೈನ್ ಡೇಟಾಬೇಸ್‌ನಲ್ಲಿ ಅನುಮೋದಿತ ಮಾರ್ಗಸೂಚಿ ಲಭ್ಯವಿಲ್ಲ. ರೋಗಿಯನ್ನು ತಕ್ಷಣ ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರದ ವೈದ್ಯಾಧಿಕಾರಿಗಳ ಬಳಿಗೆ ಕಳುಹಿಸಿ.",
      hi: "इस प्रश्न के लिए स्थानीय ऑफलाइन डेटाबेस में प्रमाणित दिशानिर्देश नहीं मिला। कृपया मरीज को प्राथमिक स्वास्थ्य केंद्र के चिकित्सा अधिकारी के पास भेजें।"
    };

    return {
      matched: false,
      language: detectedLang,
      emergency: false,
      text: fallbacks[detectedLang] || fallbacks['en'],
      sources: ['National Health Mission (NHM) Protocol: Unknown symptoms must be escalated to a Medical Officer.'],
      timestamp
    };
  },

  /**
   * Get all suggested questions across supported languages
   */
  getSuggestedQuestions(lang = 'en') {
    const list = {
      en: [
        'What are the warning signs during pregnancy?',
        'How can I prepare ORS for dehydration?',
        'What are the emergency first-aid steps for snakebite?',
        'What is the child immunization schedule?',
        'What are the danger signs of childhood pneumonia?',
        'How should blood pressure be monitored?'
      ],
      kn: [
        'ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಕಂಡುಬರುವ ಅಪಾಯಕಾರಿ ಲಕ್ಷಣಗಳೇನು?',
        'ನಿರ್ಜಲೀಕರಣಕ್ಕೆ ಓಆರ್‌ಎಸ್ ತಯಾರಿಸುವುದು ಹೇಗೆ?',
        'ಹಾವು ಕಡಿತಕ್ಕೆ ತುರ್ತು ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ ಏನು?',
        'ಮಕ್ಕಳ ಲಸಿಕಾ ವೇಳಾಪಟ್ಟಿ ಯಾವುದು?',
        'ಮಕ್ಕಳಲ್ಲಿ ನ್ಯುಮೋನಿಯಾ ಲಕ್ಷಣಗಳೇನು?',
        'ರಕ್ತದೊತ್ತಡ ತಪಾಸಣೆ ಮಾಡುವುದು ಹೇಗೆ?'
      ],
      hi: [
        'गर्भावस्था के दौरान खतरे के संकेत क्या हैं?',
        'निर्जलीकरण के लिए ओआरएस कैसे बनाएं?',
        'सांप काटने पर प्राथमिक उपचार क्या है?',
        'बच्चों का टीकाकरण कार्यक्रम क्या है?',
        'बच्चों में निमोनिया के लक्षण क्या हैं?',
        'रक्तचाप (बीपी) की सही जांच कैसे करें?'
      ]
    };
    return list[lang] || list['en'];
  }
};
