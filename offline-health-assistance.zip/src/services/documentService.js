import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';
import { apiClient } from './apiClient';

/**
 * Local-first service for AI Document Analysis records.
 * Stores analyzed reports in IndexedDB, queues cloud sync operations,
 * and optionally requests cloud AI summaries when online.
 */
export const DocumentService = {
  async getAllAnalyses() {
    const rows = await db.documentAnalyses
      .filter((d) => !d.isDeleted)
      .toArray();
    return rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },

  async saveAnalysis(recordData, user) {
    const timestamp = new Date().toISOString();
    const deviceId = getOrCreateDeviceId();
    const id = `doc-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

    const record = {
      id,
      patientId: recordData.patientId || null,
      patientName: recordData.patientName || 'Unlinked Document',
      documentType: recordData.documentType || 'lab_report',
      fileName: recordData.fileName || 'Captured Document',
      rawText: recordData.rawText || '',
      findings: recordData.findings || [],
      medications: recordData.medications || [],
      riskLevel: recordData.riskLevel || 'normal',
      summary: recordData.summary || '',
      recommendations: recordData.recommendations || [],
      analyzedMode: recordData.analyzedMode || 'offline-rules',
      language: recordData.language || 'en',
      analyzedBy: user?.name || 'Local Health Worker',
      syncStatus: 'pending',
      isDeleted: false,
      version: 1,
      deviceId,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    await db.documentAnalyses.add(record);

    await db.syncQueue.add({
      entity: 'documentAnalyses',
      entityId: record.id,
      operation: 'CREATE',
      payload: record,
      retryCount: 0,
      status: 'pending',
      createdAt: timestamp,
    });

    await db.auditLogs.add({
      entity: 'documentAnalyses',
      entityId: record.id,
      action: 'DOCUMENT_ANALYZED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'asha',
      timestamp,
      details: `Analyzed ${record.documentType} (${record.riskLevel}) for ${record.patientName}`,
    });

    return record;
  },

  async deleteAnalysis(id, user) {
    const existing = await db.documentAnalyses.get(id);
    if (!existing) return;

    const timestamp = new Date().toISOString();
    await db.documentAnalyses.update(id, {
      isDeleted: true,
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp,
    });

    await db.syncQueue.add({
      entity: 'documentAnalyses',
      entityId: id,
      operation: 'DELETE',
      payload: { id, isDeleted: true },
      retryCount: 0,
      status: 'pending',
      createdAt: timestamp,
    });

    await db.auditLogs.add({
      entity: 'documentAnalyses',
      entityId: id,
      action: 'DOCUMENT_DELETED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'asha',
      timestamp,
      details: `Deleted document analysis ${id}`,
    });
  },

  async enhanceWithCloudAI({ text, documentType, language, findings }) {
    if (!apiClient.accessToken) {
      await apiClient.login('asha_sunita', 'offline123');
    }

    const res = await apiClient.request('/documents/analyze', {
      method: 'POST',
      body: JSON.stringify({ text, documentType, language, findings }),
    });

    if (!res.ok || !res.data?.success) {
      throw new Error(res.data?.error || res.error || `HTTP ${res.status}`);
    }

    return res.data.analysis;
  },
};
