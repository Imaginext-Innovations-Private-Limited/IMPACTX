/**
 * OFFLINE HEALTH - Network Reachability & Health Check Service
 * Does NOT rely solely on navigator.onLine (which only checks local network interface)
 * Probes actual HTTP endpoint with timeout to ensure true server reachability
 */

class NetworkService {
  constructor() {
    this.isOnline = navigator.onLine;
    this.lastChecked = new Date();
    this.listeners = new Set();
    this.checkIntervalMs = 15000;
    this.timer = null;

    // Listen to standard browser events
    window.addEventListener('online', () => this.verifyConnectivity(true));
    window.addEventListener('offline', () => this.handleOffline());

    // Periodic heartbeat reachability probe
    this.startPeriodicCheck();
  }

  addListener(callback) {
    this.listeners.add(callback);
    callback({ isOnline: this.isOnline, lastChecked: this.lastChecked });
    return () => this.listeners.delete(callback);
  }

  notify() {
    this.listeners.forEach(cb => {
      try {
        cb({ isOnline: this.isOnline, lastChecked: this.lastChecked });
      } catch (err) {
        console.error('[NetworkService] Callback error:', err);
      }
    });
  }

  startPeriodicCheck() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.verifyConnectivity(), this.checkIntervalMs);
  }

  handleOffline() {
    this.isOnline = false;
    this.lastChecked = new Date();
    console.log('[NetworkService] Browser reported OFFLINE mode.');
    this.notify();
  }

  /**
   * Probe server reachability with a short timeout
   */
  async verifyConnectivity(forceNotify = false) {
    if (!navigator.onLine) {
      if (this.isOnline || forceNotify) {
        this.isOnline = false;
        this.lastChecked = new Date();
        this.notify();
      }
      return false;
    }

    try {
      // Use controller or health check ping with cache-busting
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);

      // Probe a small static asset with cache-bust to verify actual HTTP connection
      const response = await fetch(`/manifest.json?_t=${Date.now()}`, {
        method: 'HEAD',
        cache: 'no-store',
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      const reachable = response.ok || response.status === 304;
      const statusChanged = this.isOnline !== reachable;
      this.isOnline = reachable;
      this.lastChecked = new Date();

      if (statusChanged || forceNotify) {
        this.notify();
      }
      return reachable;
    } catch (err) {
      const statusChanged = this.isOnline !== false;
      this.isOnline = false;
      this.lastChecked = new Date();
      if (statusChanged || forceNotify) {
        this.notify();
      }
      return false;
    }
  }

  /**
   * Manual override toggle for simulated offline field testing
   */
  setSimulatedStatus(online) {
    this.isOnline = Boolean(online);
    this.lastChecked = new Date();
    this.notify();
  }
}

export const networkService = new NetworkService();
