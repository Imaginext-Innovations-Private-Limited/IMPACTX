import { db } from '../db/db';
import { getOrCreateDeviceId } from '../utils/crypto';

const deviceId = getOrCreateDeviceId();

export const FollowUpService = {
  /**
   * Get follow-up metrics for dashboard counters
   */
  async getDashboardStats() {
    const all = await db.followUps.toArray();
    const todayStr = new Date().toISOString().slice(0, 10);
    
    const weekFromNow = new Date();
    weekFromNow.setDate(weekFromNow.getDate() + 7);
    const weekStr = weekFromNow.toISOString().slice(0, 10);

    return {
      total: all.length,
      dueToday: all.filter(f => f.scheduledDate === todayStr && !f.isCompleted).length,
      overdue: all.filter(f => f.scheduledDate < todayStr && !f.isCompleted).length,
      urgentPriority: all.filter(f => f.priority === 'urgent' && !f.isCompleted).length,
      completed: all.filter(f => f.isCompleted).length,
      upcomingWeek: all.filter(f => f.scheduledDate > todayStr && f.scheduledDate <= weekStr && !f.isCompleted).length
    };
  },

  /**
   * Get follow-ups list with joined patient data and filters
   */
  async getFollowUps({ query = '', dateFilter = 'all', priorityFilter = 'all', statusFilter = 'all', visitTypeFilter = 'all', villageFilter = 'all' } = {}) {
    const [followUps, patients] = await Promise.all([
      db.followUps.toArray(),
      db.patients.toArray()
    ]);

    const todayStr = new Date().toISOString().slice(0, 10);
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().slice(0, 10);

    const weekFromNow = new Date();
    weekFromNow.setDate(weekFromNow.getDate() + 7);
    const weekStr = weekFromNow.toISOString().slice(0, 10);

    // Build patient map supporting both internal id and formatted patientId
    const patientMap = {};
    patients.forEach(p => {
      if (p.id) patientMap[p.id] = p;
      if (p.patientId) patientMap[p.patientId] = p;
    });

    let combined = followUps.map(fu => {
      const pat = patientMap[fu.patientId] || {};
      const isOverdue = fu.scheduledDate < todayStr && !fu.isCompleted;
      const isToday = fu.scheduledDate === todayStr && !fu.isCompleted;

      return {
        ...fu,
        isOverdue,
        isToday,
        patientName: pat.name || 'Unknown Patient',
        patientAge: pat.age,
        patientGender: pat.gender,
        patientVillage: pat.villageHamlet || 'Unknown Village',
        patientContact: pat.contactNumber,
        patientAbha: pat.abhaId,
        patientRiskLevel: pat.riskLevel || 'normal'
      };
    });

    // Sort order: Overdue first, then today, then chronological
    combined.sort((a, b) => {
      if (a.isOverdue && !b.isOverdue) return -1;
      if (!a.isOverdue && b.isOverdue) return 1;
      if (a.isToday && !b.isToday) return -1;
      if (!a.isToday && b.isToday) return 1;
      return new Date(a.scheduledDate) - new Date(b.scheduledDate);
    });

    // Search query filter
    if (query.trim()) {
      const q = query.toLowerCase().trim();
      combined = combined.filter(f =>
        (f.id && f.id.toLowerCase().includes(q)) ||
        (f.patientName && f.patientName.toLowerCase().includes(q)) ||
        (f.patientId && f.patientId.toLowerCase().includes(q)) ||
        (f.visitType && f.visitType.toLowerCase().includes(q)) ||
        (f.notes && f.notes.toLowerCase().includes(q))
      );
    }

    // Date filters
    if (dateFilter === 'today') {
      combined = combined.filter(f => f.scheduledDate === todayStr && !f.isCompleted);
    } else if (dateFilter === 'tomorrow') {
      combined = combined.filter(f => f.scheduledDate === tomorrowStr && !f.isCompleted);
    } else if (dateFilter === 'overdue') {
      combined = combined.filter(f => f.isOverdue);
    } else if (dateFilter === 'this_week') {
      combined = combined.filter(f => f.scheduledDate >= todayStr && f.scheduledDate <= weekStr && !f.isCompleted);
    } else if (dateFilter === 'completed') {
      combined = combined.filter(f => f.isCompleted);
    }

    // Priority filter
    if (priorityFilter !== 'all') {
      combined = combined.filter(f => f.priority === priorityFilter);
    }

    // Status filter
    if (statusFilter === 'pending') {
      combined = combined.filter(f => !f.isCompleted);
    } else if (statusFilter === 'completed') {
      combined = combined.filter(f => f.isCompleted);
    } else if (statusFilter === 'overdue') {
      combined = combined.filter(f => f.isOverdue);
    }

    // Visit type filter
    if (visitTypeFilter !== 'all') {
      combined = combined.filter(f => f.visitType && f.visitType.includes(visitTypeFilter));
    }

    // Village filter
    if (villageFilter !== 'all') {
      combined = combined.filter(f => f.patientVillage === villageFilter);
    }

    return combined;
  },

  /**
   * Schedule a new field follow-up visit
   */
  async scheduleFollowUp(data, user) {
    const timestamp = new Date().toISOString();
    const id = `fu-${Date.now()}`;

    const record = {
      id,
      patientId: data.patientId,
      scheduledDate: data.scheduledDate,
      visitType: data.visitType || 'General Health Follow-up',
      priority: data.priority || 'routine', // urgent, high, routine
      isCompleted: false,
      notes: data.notes || '',
      checklist: data.checklist || [
        'Check vital signs (Blood Pressure & Pulse)',
        'Review current medications & adherence',
        'Inquire about clinical red-flag symptoms'
      ],
      assignedWorker: user?.name || data.assignedWorker || 'Local ASHA Worker',
      syncStatus: 'pending',
      version: 1,
      createdAt: timestamp,
      updatedAt: timestamp,
      deviceId
    };

    await db.followUps.add(record);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'CREATE',
      payload: record,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'followUps',
      entityId: id,
      action: 'FOLLOW_UP_SCHEDULED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Follow-up visit scheduled for ${data.patientId} on ${data.scheduledDate} (${record.visitType})`
    });

    return record;
  },

  /**
   * Mark a follow-up visit as completed with outcome notes
   */
  async completeFollowUp(id, completionData = {}, user) {
    const timestamp = new Date().toISOString();
    const existing = await db.followUps.get(id);
    if (!existing) throw new Error(`Follow-up with ID ${id} not found.`);

    const updated = {
      ...existing,
      isCompleted: true,
      completedDate: timestamp.slice(0, 10),
      completionNotes: completionData.notes || 'Visit completed successfully. Patient assessed.',
      vitalsRecorded: completionData.vitals || null,
      completedBy: user?.name || 'Local ASHA Worker',
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.followUps.put(updated);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    await db.auditLogs.add({
      entity: 'followUps',
      entityId: id,
      action: 'FOLLOW_UP_COMPLETED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Follow-up ${id} marked completed by ${updated.completedBy}`
    });

    return updated;
  },

  /**
   * Quick toggle completion status
   */
  async toggleComplete(id, completed = true, user) {
    const timestamp = new Date().toISOString();
    const existing = await db.followUps.get(id);
    if (!existing) throw new Error(`Follow-up with ID ${id} not found.`);

    const updated = {
      ...existing,
      isCompleted: completed,
      completedDate: completed ? timestamp.slice(0, 10) : null,
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.followUps.put(updated);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return updated;
  },

  /**
   * Reschedule a follow-up visit to a new date
   */
  async rescheduleFollowUp(id, newDate, reason = '', user) {
    const timestamp = new Date().toISOString();
    const existing = await db.followUps.get(id);
    if (!existing) throw new Error(`Follow-up with ID ${id} not found.`);

    const updated = {
      ...existing,
      scheduledDate: newDate,
      rescheduleHistory: [
        ...(existing.rescheduleHistory || []),
        { from: existing.scheduledDate, to: newDate, reason, timestamp }
      ],
      syncStatus: 'pending',
      version: (existing.version || 1) + 1,
      updatedAt: timestamp
    };

    await db.followUps.put(updated);

    await db.syncQueue.add({
      entity: 'followUps',
      entityId: id,
      operation: 'UPDATE',
      payload: updated,
      status: 'pending',
      retryCount: 0,
      createdAt: timestamp
    });

    return updated;
  }
};
