import React, { useState, useEffect } from 'react';
import { FollowUpService } from '../../services/followUpService';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
  ClipboardCheck
} from 'lucide-react';

export default function CompleteFollowUpModal({ isOpen, onClose, onSuccess, followUp, currentUser }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [notes, setNotes] = useState('');
  const [systolicBp, setSystolicBp] = useState('');
  const [diastolicBp, setDiastolicBp] = useState('');
  const [pulse, setPulse] = useState('');

  useEffect(() => {
    if (followUp) {
      setNotes(followUp.completionNotes || '');
      setSystolicBp('');
      setDiastolicBp('');
      setPulse('');
    }
  }, [followUp]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!followUp) return;

    setLoading(true);
    setError(null);

    try {
      const vitals = (systolicBp && diastolicBp) ? {
        systolicBp: parseInt(systolicBp, 10),
        diastolicBp: parseInt(diastolicBp, 10),
        pulse: pulse ? parseInt(pulse, 10) : null
      } : null;

      await FollowUpService.completeFollowUp(followUp.id, {
        notes: notes || 'Visit completed. Patient condition evaluated.',
        vitals
      }, currentUser);

      onSuccess();
      onClose();
    } catch (err) {
      console.error('Failed to complete follow-up:', err);
      setError(err.message || 'Failed to complete visit.');
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen || !followUp) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Complete Field Visit</h3>
              <p className="text-xs text-gray-500">
                {followUp.patientName} • {followUp.visitType}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-xs text-gray-700">
            <div className="font-semibold text-gray-900 mb-1">Scheduled Objectives:</div>
            <div>{followUp.notes || 'Routine field follow-up and clinical surveillance.'}</div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Visit Outcome & Observations *
            </label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Patient found in good health. Blood pressure verified. Taking medication regularly. No signs of dizziness or edema."
              rows={3}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Stethoscope className="w-3.5 h-3.5 text-emerald-600" />
              Recorded Vitals During Visit (Optional)
            </label>
            <div className="grid grid-cols-3 gap-2 bg-gray-50 p-3 rounded-xl border border-gray-100">
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Systolic (mmHg)</span>
                <input
                  type="number"
                  placeholder="120"
                  value={systolicBp}
                  onChange={e => setSystolicBp(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Diastolic (mmHg)</span>
                <input
                  type="number"
                  placeholder="80"
                  value={diastolicBp}
                  onChange={e => setDiastolicBp(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Pulse (bpm)</span>
                <input
                  type="number"
                  placeholder="76"
                  value={pulse}
                  onChange={e => setPulse(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-200 rounded-xl text-gray-700 text-sm font-medium hover:bg-gray-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium transition flex items-center gap-2 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              {loading ? 'Completing...' : 'Mark Visit Complete'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
