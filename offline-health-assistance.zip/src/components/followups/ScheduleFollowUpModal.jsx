import React, { useState, useEffect } from 'react';
import { db } from '../../db/db';
import { FollowUpService } from '../../services/followUpService';
import {
  X,
  CalendarClock,
  User,
  AlertTriangle,
  CheckCircle2,
  ListTodo
} from 'lucide-react';

const VISIT_TYPES = [
  'ANC Checkup (Antenatal Visit)',
  'Postnatal Home Visit (PNC Day 3/7/14/28)',
  'Child Immunization Catch-up & Growth',
  'Malnutrition Review & MUAC Rescreening',
  'NCD Surveillance (Blood Pressure & Glucose)',
  'Post-Referral Hospital Outcome Check',
  'Tuberculosis Treatment (DOTS) Adherence',
  'Elderly Palliative & Chronic Care'
];

export default function ScheduleFollowUpModal({ isOpen, onClose, onSuccess, currentUser, initialPatientId = null }) {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().slice(0, 10);

  const [formData, setFormData] = useState({
    patientId: initialPatientId || '',
    scheduledDate: tomorrowStr,
    visitType: 'ANC Checkup (Antenatal Visit)',
    priority: 'routine', // urgent, high, routine
    notes: '',
    checkVitals: true,
    checkMedication: true,
    checkWarningSigns: true
  });

  useEffect(() => {
    if (isOpen) {
      loadPatients();
      if (initialPatientId) {
        setFormData(prev => ({ ...prev, patientId: initialPatientId }));
      }
    }
  }, [isOpen, initialPatientId]);

  async function loadPatients() {
    try {
      const list = await db.patients.toArray();
      setPatients(list.filter(p => !p.isDeleted));
      if (!initialPatientId && list.length > 0 && !formData.patientId) {
        setFormData(prev => ({ ...prev, patientId: list[0].id || list[0].patientId }));
      }
    } catch (err) {
      console.error('Failed to load patients for follow-up:', err);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!formData.patientId) {
      setError('Please select a patient.');
      return;
    }
    if (!formData.scheduledDate) {
      setError('Please pick a scheduled date.');
      return;
    }

    setLoading(true);
    setError(null);

    const checklist = [];
    if (formData.checkVitals) checklist.push('Check vital signs (Blood Pressure, Pulse, SpO2)');
    if (formData.checkMedication) checklist.push('Verify medication adherence and pill stock');
    if (formData.checkWarningSigns) checklist.push('Inquire about red-flag warning symptoms');

    try {
      await FollowUpService.scheduleFollowUp({
        ...formData,
        checklist
      }, currentUser);
      onSuccess();
      onClose();
    } catch (err) {
      console.error('Error scheduling follow-up:', err);
      setError(err.message || 'Failed to schedule follow-up');
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CalendarClock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Schedule Field Follow-Up</h3>
              <p className="text-xs text-gray-500">
                Community home visit or sub-centre appointment
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Select Patient *
            </label>
            <select
              value={formData.patientId}
              onChange={e => setFormData({ ...formData, patientId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm bg-gray-50/50"
              required
            >
              <option value="">-- Choose Patient --</option>
              {patients.map(p => (
                <option key={p.id || p.patientId} value={p.id || p.patientId}>
                  {p.name} ({p.patientId || p.id}) • {p.age}y/{p.gender} • {p.villageHamlet || 'Village'}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Scheduled Visit Date *
              </label>
              <input
                type="date"
                value={formData.scheduledDate}
                onChange={e => setFormData({ ...formData, scheduledDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Visit Priority *
              </label>
              <select
                value={formData.priority}
                onChange={e => setFormData({ ...formData, priority: e.target.value })}
                className={`w-full px-3 py-2 border rounded-xl text-sm font-medium ${
                  formData.priority === 'urgent'
                    ? 'border-red-300 bg-red-50 text-red-700'
                    : formData.priority === 'high'
                    ? 'border-amber-300 bg-amber-50 text-amber-800'
                    : 'border-blue-300 bg-blue-50 text-blue-700'
                }`}
              >
                <option value="routine">Routine Visit</option>
                <option value="high">High Priority</option>
                <option value="urgent">Urgent Follow-Up</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Visit Purpose / Type *
            </label>
            <select
              value={formData.visitType}
              onChange={e => setFormData({ ...formData, visitType: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
              required
            >
              {VISIT_TYPES.map(vt => (
                <option key={vt} value={vt}>
                  {vt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Field Visit Instructions & Objectives
            </label>
            <textarea
              value={formData.notes}
              onChange={e => setFormData({ ...formData, notes: e.target.value })}
              placeholder="e.g. Inquire about persistent headache or vision blurriness. Check if taking Iron-Folic tablets daily after food."
              rows={2}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
            />
          </div>

          {/* Visit Checklist */}
          <div className="bg-gray-50 border border-gray-100 p-3 rounded-xl space-y-2">
            <span className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
              <ListTodo className="w-4 h-4 text-emerald-600" />
              Field Visit Action Checklist
            </span>
            <div className="space-y-1.5 text-xs text-gray-600">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.checkVitals}
                  onChange={e => setFormData({ ...formData, checkVitals: e.target.checked })}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Screen Vital Signs (Blood Pressure, Pulse, SpO2)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.checkMedication}
                  onChange={e => setFormData({ ...formData, checkMedication: e.target.checked })}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Review Medication Adherence & Pill Stocks</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.checkWarningSigns}
                  onChange={e => setFormData({ ...formData, checkWarningSigns: e.target.checked })}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Inquire About Clinical Red-Flag Symptoms</span>
              </label>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-200 rounded-xl text-gray-700 text-sm font-medium hover:bg-gray-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium transition flex items-center gap-2 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              {loading ? 'Scheduling...' : 'Schedule Visit'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
