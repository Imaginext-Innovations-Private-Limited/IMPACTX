import React from 'react';
import {
  X,
  Printer,
  Share2,
  Building2,
  User,
  Heart,
  AlertTriangle,
  Ambulance,
  CheckCircle2,
  ShieldCheck,
  Stethoscope
} from 'lucide-react';

export default function ReferralSlipModal({ isOpen, onClose, referral }) {
  if (!isOpen || !referral) return null;

  const isEmergency = referral.urgency === 'emergency';

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[92vh] flex flex-col">
        {/* Header bar */}
        <div className="flex items-center justify-between pb-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              National Health Mission • Referral Escalation Slip
            </span>
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
              isEmergency ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
            }`}>
              {referral.urgency?.toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="space-y-6 pt-5 overflow-y-auto pr-1 flex-1 printable-area text-gray-900">
          {/* Slip Header */}
          <div className="text-center pb-4 border-b border-gray-100">
            <h2 className="text-lg font-bold tracking-tight text-gray-900">
              COMMUNITY HEALTHCARE REFERRAL & EMERGENCY ESCALATION FORM
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Sub-Centre / Health & Wellness Centre • Ramanagara District
            </p>
            <div className="flex items-center justify-center gap-4 mt-2 text-xs text-gray-600">
              <span><strong>Slip ID:</strong> {referral.id}</span>
              <span>•</span>
              <span><strong>Date & Time:</strong> {new Date(referral.createdAt).toLocaleString()}</span>
              <span>•</span>
              <span><strong>Referred To:</strong> {referral.referralFacility}</span>
            </div>
          </div>

          {/* Patient Profile Card */}
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-gray-500 block">Patient Name:</span>
                <span className="font-bold text-gray-900 text-sm">{referral.patientName}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Patient ID:</span>
                <span className="font-semibold text-gray-800">{referral.patientId}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Age / Gender:</span>
                <span className="font-semibold text-gray-800">{referral.patientAge} yrs / {referral.patientGender}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Village / Hamlet:</span>
                <span className="font-semibold text-gray-800">{referral.patientVillage}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Contact Phone:</span>
                <span className="font-medium text-gray-800">{referral.patientContact || 'N/A'}</span>
              </div>
              <div>
                <span className="text-gray-500 block">ABHA Health ID:</span>
                <span className="font-medium text-gray-800">{referral.patientAbha || 'ABHA-PENDING'}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Triage Status:</span>
                <span className="font-bold capitalize text-emerald-700">{referral.status?.replace('_', ' ')}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Referred By:</span>
                <span className="font-medium text-gray-800">{referral.referredBy || 'ASHA Worker'}</span>
              </div>
            </div>
          </div>

          {/* Clinical Escalation Rationale */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Clinical Findings & Reasons for Referral
            </h4>
            <div className="p-3.5 bg-red-50/60 border border-red-200 rounded-xl space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-red-950">
                    Primary Reason: <span className="font-normal text-red-900">{referral.reason}</span>
                  </p>
                </div>
              </div>
              {referral.provisionalDiagnosis && (
                <div className="pl-6 text-xs text-gray-800">
                  <strong>Provisional Working Diagnosis:</strong> {referral.provisionalDiagnosis}
                </div>
              )}
            </div>
          </div>

          {/* Vitals Recorded at Escalation */}
          {referral.vitalsAtReferral && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">
                Vital Signs at Field Escalation
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-gray-50 border border-gray-100 p-3 rounded-xl text-xs">
                <div>
                  <span className="text-gray-500 block">Blood Pressure:</span>
                  <span className="font-bold text-gray-900">
                    {referral.vitalsAtReferral.systolicBp && referral.vitalsAtReferral.diastolicBp
                      ? `${referral.vitalsAtReferral.systolicBp}/${referral.vitalsAtReferral.diastolicBp} mmHg`
                      : 'Not recorded'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block">Pulse Rate:</span>
                  <span className="font-bold text-gray-900">
                    {referral.vitalsAtReferral.pulse ? `${referral.vitalsAtReferral.pulse} bpm` : 'Not recorded'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block">SpO2 (Oxygen):</span>
                  <span className="font-bold text-gray-900">
                    {referral.vitalsAtReferral.spo2 ? `${referral.vitalsAtReferral.spo2}%` : 'Not recorded'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block">Blood Glucose:</span>
                  <span className="font-bold text-gray-900">
                    {referral.vitalsAtReferral.bloodGlucose ? `${referral.vitalsAtReferral.bloodGlucose} mg/dL` : 'Not recorded'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Transport & Escort Logistics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
              <span className="font-bold text-emerald-950 flex items-center gap-1.5 mb-1">
                <Ambulance className="w-4 h-4 text-emerald-700" />
                Transport Logistics:
              </span>
              <p className="text-gray-700">{referral.transportation || '108 Emergency Ambulance'}</p>
              {referral.ambulanceDetails && (
                <p className="text-[11px] text-gray-600 mt-1 font-mono">{referral.ambulanceDetails}</p>
              )}
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
              <span className="font-bold text-blue-950 flex items-center gap-1.5 mb-1">
                <User className="w-4 h-4 text-blue-700" />
                Field Escort Status:
              </span>
              <p className="text-gray-700">
                {referral.accompaniedByAsha
                  ? '✅ Accompanied in-person by community health worker'
                  : 'Self-travel with family'}
              </p>
              <p className="text-[11px] text-gray-600 mt-1">Escort Worker: {referral.ashaWorkerName || referral.referredBy}</p>
            </div>
          </div>

          {/* Doctor Feedback Section */}
          <div className="border border-gray-200 rounded-xl p-4 bg-gray-50/70">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 mb-2 flex items-center gap-1.5">
              <Stethoscope className="w-4 h-4 text-blue-600" />
              Receiving Hospital Doctor Triage & Feedback Loop
            </h4>

            {referral.doctorFeedback ? (
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-gray-500">Attending Doctor: </span>
                  <span className="font-bold text-gray-900">{referral.doctorName || 'Attending MO'}</span>
                  <span className="text-gray-400"> • </span>
                  <span className="font-medium text-gray-700">{referral.hospitalName || referral.referralFacility}</span>
                </div>
                <div>
                  <span className="text-gray-500">Triage Decision: </span>
                  <span className="font-semibold text-emerald-800">{referral.triageDecision}</span>
                </div>
                <div className="p-2.5 bg-white border border-gray-200 rounded-lg">
                  <span className="font-semibold block text-gray-800 mb-0.5">Clinical Feedback / Discharge Summary:</span>
                  <p className="text-gray-700">{referral.doctorFeedback}</p>
                </div>
                {referral.treatmentPrescribed && (
                  <div className="text-gray-700">
                    <span className="font-semibold">Treatment / Action Plan for ASHA: </span>
                    {referral.treatmentPrescribed}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 bg-white border border-dashed border-gray-300 rounded-lg text-center text-xs text-gray-500">
                Doctor feedback pending. Patient currently under transit or hospital admission.
              </div>
            )}
          </div>

          {/* Signatures Footer */}
          <div className="pt-6 border-t border-gray-200 grid grid-cols-2 gap-8 text-xs text-center text-gray-500">
            <div>
              <div className="h-10 border-b border-gray-300 mb-1"></div>
              <span>Signature of Referring ASHA / ANM</span>
            </div>
            <div>
              <div className="h-10 border-b border-gray-300 mb-1"></div>
              <span>Signature & Seal of Receiving Medical Officer</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
