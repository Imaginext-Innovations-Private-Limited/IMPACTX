import React, { useState, useEffect } from 'react';
import { ReferralService } from '../../services/referralService';
import {
  X,
  Stethoscope,
  Building2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  UserCheck
} from 'lucide-react';

export default function DoctorFeedbackModal({ isOpen, onClose, onSuccess, referral, currentUser }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    doctorName: '',
    hospitalName: '',
    triageDecision: 'Admitted for Inpatient Care',
    doctorFeedback: '',
    treatmentPrescribed: '',
    status: 'accepted'
  });

  useEffect(() => {
    if (referral) {
      setFormData({
        doctorName: referral.doctorName || (currentUser?.role === 'doctor' ? currentUser.name : 'Dr. R. Sharma, MBBS, MS'),
        hospitalName: referral.hospitalName || referral.referralFacility || 'Community Health Centre',
        triageDecision: referral.triageDecision || 'Admitted for Inpatient Care',
        doctorFeedback: referral.doctorFeedback || '',
        treatmentPrescribed: referral.treatmentPrescribed || '',
        status: referral.status === 'completed' ? 'completed' : 'accepted'
      });
    }
  }, [referral, currentUser]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!referral) return;

    if (!formData.doctorFeedback.trim()) {
      setError('Please provide clinical review notes or discharge advice.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await ReferralService.updateDoctorFeedback(referral.id, formData, currentUser);
      onSuccess();
      onClose();
    } catch (err) {
      console.error('Failed to update doctor feedback:', err);
      setError(err.message || 'Failed to save doctor feedback.');
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen || !referral) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Hospital Doctor Review & Feedback</h3>
              <p className="text-xs text-gray-500">
                Case #{referral.id} • {referral.patientName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* Summary of Escort */}
          <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-xs text-gray-700 space-y-1">
            <div className="font-semibold text-gray-900">Initial Escalation Summary:</div>
            <div><span className="text-gray-500">Reason:</span> {referral.reason}</div>
            {referral.provisionalDiagnosis && (
              <div><span className="text-gray-500">Provisional:</span> {referral.provisionalDiagnosis}</div>
            )}
            <div><span className="text-gray-500">Facility:</span> {referral.referralFacility}</div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Attending Doctor Name
              </label>
              <input
                type="text"
                value={formData.doctorName}
                onChange={e => setFormData({ ...formData, doctorName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Hospital / Ward
              </label>
              <input
                type="text"
                value={formData.hospitalName}
                onChange={e => setFormData({ ...formData, hospitalName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Triage & Admission Decision *
            </label>
            <select
              value={formData.triageDecision}
              onChange={e => {
                const dec = e.target.value;
                const newStatus = dec === 'Outpatient Treated & Discharged' ? 'completed' : 'accepted';
                setFormData({ ...formData, triageDecision: dec, status: newStatus });
              }}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm font-medium"
            >
              <option value="Admitted for Inpatient Care">🏥 Admitted for Inpatient Care</option>
              <option value="Admitted to ICU / HDU">🚨 Admitted to High-Dependency / ICU</option>
              <option value="Outpatient Treated & Discharged">✅ Outpatient Treated & Discharged</option>
              <option value="Referred to Tertiary Care (Higher Centre)">↗️ Transferred to Tertiary Specialty Hospital</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Doctor Clinical Findings & Feedback *
            </label>
            <textarea
              value={formData.doctorFeedback}
              onChange={e => setFormData({ ...formData, doctorFeedback: e.target.value })}
              placeholder="e.g. Patient stabilized with IV labetalol and magnesium sulfate. Vitals currently stable at 134/86 mmHg. Advise bed rest."
              rows={3}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Treatment / Post-Discharge Action Plan for ASHA
            </label>
            <input
              type="text"
              value={formData.treatmentPrescribed}
              onChange={e => setFormData({ ...formData, treatmentPrescribed: e.target.value })}
              placeholder="e.g. Daily BP monitoring for 5 days. Ensure medication compliance. Check for pitting edema."
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Update Referral Status
            </label>
            <select
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm"
            >
              <option value="accepted">Accepted / In Treatment</option>
              <option value="completed">Completed / Discharged</option>
              <option value="pending_doctor_review">Pending Further Investigations</option>
            </select>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-200 rounded-xl text-gray-700 text-sm font-medium hover:bg-gray-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-medium transition flex items-center gap-2 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              {loading ? 'Saving Feedback...' : 'Save Doctor Review'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
