import React, { useState, useEffect } from 'react';
import { db } from '../../db/db';
import { ReferralService } from '../../services/referralService';
import {
  X,
  Share2,
  AlertTriangle,
  Ambulance,
  Building2,
  User,
  Heart,
  Stethoscope,
  Clock,
  ShieldAlert,
  CheckCircle2
} from 'lucide-react';

const FACILITIES = [
  { name: 'Rampur Primary Health Centre (PHC)', type: 'Primary Health Centre' },
  { name: 'Channapatna Community Health Centre (CHC)', type: 'Community Health Centre' },
  { name: 'Ramanagara Taluka General Hospital', type: 'Taluka Hospital' },
  { name: 'Mandya District Hospital', type: 'District Hospital' },
  { name: 'Vani Vilas Women & Children Hospital (Tertiary)', type: 'Tertiary Hospital' },
  { name: 'Jayadeva Institute of Cardiovascular Sciences', type: 'Super-Specialty Hospital' }
];

export default function CreateReferralModal({ isOpen, onClose, onSuccess, currentUser, initialPatientId = null }) {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    patientId: initialPatientId || '',
    urgency: 'urgent', // emergency, urgent, routine
    referralFacility: 'Channapatna Community Health Centre (CHC)',
    facilityType: 'Community Health Centre',
    reason: '',
    provisionalDiagnosis: '',
    transportation: '108 Ambulance',
    ambulanceDispatched: true,
    ambulanceDetails: '108 Toll-Free Dispatch Requested',
    accompaniedByAsha: true,
    systolicBp: '',
    diastolicBp: '',
    pulse: '',
    spo2: '',
    bloodGlucose: '',
    temperature: '',
    autoScheduleFollowUp: true
  });

  useEffect(() => {
    if (isOpen) {
      loadPatients();
      if (initialPatientId) {
        setFormData(prev => ({ ...prev, patientId: initialPatientId }));
      }
    }
  }, [isOpen, initialPatientId]);

  async function loadPatients() {
    try {
      const list = await db.patients.toArray();
      setPatients(list.filter(p => !p.isDeleted));
      if (!initialPatientId && list.length > 0 && !formData.patientId) {
        setFormData(prev => ({ ...prev, patientId: list[0].id || list[0].patientId }));
      }
    } catch (err) {
      console.error('Failed to load patients for referral:', err);
    }
  }

  function handleFacilityChange(e) {
    const val = e.target.value;
    const matched = FACILITIES.find(f => f.name === val);
    setFormData(prev => ({
      ...prev,
      referralFacility: val,
      facilityType: matched ? matched.type : 'Community Health Centre'
    }));
  }

  function handleTransportationChange(e) {
    const val = e.target.value;
    const is108 = val === '108 Ambulance';
    setFormData(prev => ({
      ...prev,
      transportation: val,
      ambulanceDispatched: is108,
      urgency: is108 ? 'emergency' : prev.urgency
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!formData.patientId) {
      setError('Please select a patient.');
      return;
    }
    if (!formData.reason.trim()) {
      setError('Please provide a clinical rationale or reason for referral.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await ReferralService.createReferral(formData, currentUser);
      onSuccess();
      onClose();
    } catch (err) {
      console.error('Error creating referral:', err);
      setError(err.message || 'Failed to create referral record');
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  const isEmergency = formData.urgency === 'emergency';

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isEmergency ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
            }`}>
              {isEmergency ? <ShieldAlert className="w-6 h-6 animate-pulse" /> : <Share2 className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                {isEmergency ? 'Emergency Clinical Escalation' : 'New Patient Referral'}
              </h3>
              <p className="text-xs text-gray-500">
                Structured clinical transfer slip with offline Dexie queueing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 overflow-y-auto pr-1 flex-1">
          {/* Patient Selection */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Select Patient *
            </label>
            <select
              value={formData.patientId}
              onChange={e => setFormData({ ...formData, patientId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-gray-50/50"
              required
            >
              <option value="">-- Choose Patient --</option>
              {patients.map(p => (
                <option key={p.id || p.patientId} value={p.id || p.patientId}>
                  {p.name} ({p.patientId || p.id}) • {p.age}y/{p.gender} • {p.villageHamlet || 'Village'}
                </option>
              ))}
            </select>
          </div>

          {/* Urgency & Facility Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Triage Urgency Level *
              </label>
              <select
                value={formData.urgency}
                onChange={e => setFormData({ ...formData, urgency: e.target.value })}
                className={`w-full px-3 py-2 border rounded-xl font-medium text-sm ${
                  formData.urgency === 'emergency'
                    ? 'border-red-300 bg-red-50 text-red-700 focus:ring-red-500'
                    : formData.urgency === 'urgent'
                    ? 'border-amber-300 bg-amber-50 text-amber-800 focus:ring-amber-500'
                    : 'border-blue-300 bg-blue-50 text-blue-700 focus:ring-blue-500'
                }`}
              >
                <option value="emergency">🚨 Emergency (Immediate / 108 Ambulance)</option>
                <option value="urgent">⚠️ Urgent (Within 24 to 48 Hours)</option>
                <option value="routine">ℹ️ Routine (Elective / Specialist Consultation)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Destination Health Facility *
              </label>
              <select
                value={formData.referralFacility}
                onChange={handleFacilityChange}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                required
              >
                {FACILITIES.map(f => (
                  <option key={f.name} value={f.name}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Reason & Provisional Diagnosis */}
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Clinical Reason & Warning Signs *
              </label>
              <textarea
                value={formData.reason}
                onChange={e => setFormData({ ...formData, reason: e.target.value })}
                placeholder="e.g. Severe pre-eclampsia, systolic BP > 160 mmHg with persistent epigastric pain and headache"
                rows={2}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Provisional Diagnosis / Suspected Condition
              </label>
              <input
                type="text"
                value={formData.provisionalDiagnosis}
                onChange={e => setFormData({ ...formData, provisionalDiagnosis: e.target.value })}
                placeholder="e.g. Gestational Hypertension with Impending Eclampsia / Acute Coronary Syndrome"
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm"
              />
            </div>
          </div>

          {/* Vitals at Referral */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Stethoscope className="w-3.5 h-3.5 text-emerald-600" />
              Patient Vitals at Escalation (Optional but Recommended)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-gray-50 p-3 rounded-xl border border-gray-100">
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Systolic (mmHg)</span>
                <input
                  type="number"
                  placeholder="140"
                  value={formData.systolicBp}
                  onChange={e => setFormData({ ...formData, systolicBp: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Diastolic (mmHg)</span>
                <input
                  type="number"
                  placeholder="90"
                  value={formData.diastolicBp}
                  onChange={e => setFormData({ ...formData, diastolicBp: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">Pulse (bpm)</span>
                <input
                  type="number"
                  placeholder="88"
                  value={formData.pulse}
                  onChange={e => setFormData({ ...formData, pulse: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 block mb-0.5">SpO2 (%)</span>
                <input
                  type="number"
                  placeholder="98"
                  value={formData.spo2}
                  onChange={e => setFormData({ ...formData, spo2: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
            </div>
          </div>

          {/* Transportation & Logistics */}
          <div className="bg-emerald-50/50 border border-emerald-100 p-3.5 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
              <Ambulance className="w-4 h-4 text-emerald-600" />
              Transport & Community Escort Logistics
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-gray-600 mb-1">
                  Arranged Transport Mode
                </label>
                <select
                  value={formData.transportation}
                  onChange={handleTransportationChange}
                  className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-medium"
                >
                  <option value="108 Ambulance">🚑 108 Emergency Ambulance</option>
                  <option value="ASHA Accompanied Auto">🛺 ASHA Accompanied Auto / Taxi</option>
                  <option value="Government Mobile Medical Unit">🚐 Mobile Medical Unit (MMU)</option>
                  <option value="Private / Family Vehicle">🚗 Family / Private Vehicle</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-gray-600 mb-1">
                  Ambulance Dispatch Notes / Contact
                </label>
                <input
                  type="text"
                  value={formData.ambulanceDetails}
                  onChange={e => setFormData({ ...formData, ambulanceDetails: e.target.value })}
                  placeholder="e.g. 108 Driver ph: 9876543210 (ETA 15 min)"
                  className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-700">
                <input
                  type="checkbox"
                  checked={formData.accompaniedByAsha}
                  onChange={e => setFormData({ ...formData, accompaniedByAsha: e.target.checked })}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Accompanied to Hospital by ASHA / ANM Worker</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-700">
                <input
                  type="checkbox"
                  checked={formData.autoScheduleFollowUp}
                  onChange={e => setFormData({ ...formData, autoScheduleFollowUp: e.target.checked })}
                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Auto-schedule Post-Referral Checkup in Follow-ups</span>
              </label>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-200 rounded-xl text-gray-700 text-sm font-medium hover:bg-gray-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className={`px-5 py-2 rounded-xl text-white text-sm font-medium transition flex items-center gap-2 shadow-sm ${
                isEmergency
                  ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500'
                  : 'bg-emerald-600 hover:bg-emerald-700 focus:ring-emerald-500'
              }`}
            >
              {loading ? (
                <>Saving Offline...</>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  {isEmergency ? 'Dispatch Emergency Referral' : 'Create Referral Slip'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
