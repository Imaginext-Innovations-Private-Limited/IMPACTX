import React, { useState } from 'react';
import { ChildService } from '../../services/childService';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Building2,
  Syringe
} from 'lucide-react';

export default function ImmunizationModal({ isOpen, onClose, child, targetVaccine, onImmunized, currentUser }) {
  const [formData, setFormData] = useState({
    vaccineName: targetVaccine?.vaccineName || 'Pentavalent-1 (DPT + HepB + Hib)',
    vaccineKey: targetVaccine?.vaccineKey || 'Penta-1',
    doseNumber: targetVaccine?.doseNumber || 1,
    givenDate: new Date().toISOString().slice(0, 10),
    batchNumber: 'BA-2026-' + Math.floor(1000 + Math.random() * 9000),
    administeredBy: currentUser?.name || 'ANM Healthcare Staff'
  });

  React.useEffect(() => {
    if (targetVaccine && isOpen) {
      setFormData(prev => ({
        ...prev,
        vaccineName: targetVaccine.vaccineName || prev.vaccineName,
        vaccineKey: targetVaccine.vaccineKey || prev.vaccineKey,
        doseNumber: targetVaccine.doseNumber !== undefined ? targetVaccine.doseNumber : 1,
        givenDate: new Date().toISOString().slice(0, 10)
      }));
    }
  }, [targetVaccine, isOpen]);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !child) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.vaccineName) {
      setError('Vaccine name is required.');
      return;
    }
    if (!formData.givenDate) {
      setError('Date administered is required.');
      return;
    }

    setSaving(true);
    try {
      await ChildService.recordImmunization({
        id: targetVaccine?.recordId || null,
        patientId: child.id || child.patientId,
        childId: child.birth?.id || child.id,
        vaccineName: formData.vaccineName,
        vaccineKey: formData.vaccineKey,
        doseNumber: formData.doseNumber,
        dueDate: targetVaccine?.targetDueDate || formData.givenDate,
        givenDate: formData.givenDate,
        batchNumber: formData.batchNumber,
        administeredBy: formData.administeredBy
      }, currentUser);

      onImmunized();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to record immunization.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-600 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <ShieldCheck className="w-6 h-6 text-blue-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Administer Universal Vaccine</h2>
              <p className="text-xs text-blue-100">
                Child: {child.name} ({child.patientId})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Vaccine Name *</label>
            <input
              type="text"
              required
              value={formData.vaccineName}
              onChange={(e) => setFormData({ ...formData, vaccineName: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-slate-900"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Dose Number</label>
              <input
                type="number"
                min="0"
                max="5"
                value={formData.doseNumber}
                onChange={(e) => setFormData({ ...formData, doseNumber: parseInt(e.target.value, 10) || 1 })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Date Administered *</label>
              <input
                type="date"
                required
                value={formData.givenDate}
                onChange={(e) => setFormData({ ...formData, givenDate: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-medium"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Vaccine Vial Batch / Lot #</label>
            <input
              type="text"
              placeholder="e.g. BA-2026-9182"
              value={formData.batchNumber}
              onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Administered By</label>
            <input
              type="text"
              value={formData.administeredBy}
              onChange={(e) => setFormData({ ...formData, administeredBy: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-medium"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold shadow-md shadow-blue-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Recording...' : 'Confirm Vaccination'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
