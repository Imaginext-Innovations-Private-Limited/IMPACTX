import React, { useState, useEffect } from 'react';
import { ChildService } from '../../services/childService';
import {
  X,
  Baby,
  Scale,
  ShieldCheck,
  Calendar,
  AlertTriangle,
  User,
  CheckCircle2,
  Share2,
  Printer,
  Activity,
  Heart,
  Pill,
  Clock,
  Building2,
  Sparkles
} from 'lucide-react';

export default function ChildDetailModal({ isOpen, onClose, childId, onRecordUpdated, onOpenGrowthModal, onOpenVaxModal, currentUser }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('card'); // card, growth, immunizations
  const [referralReason, setReferralReason] = useState('');
  const [showReferralBox, setShowReferralBox] = useState(false);
  const [referring, setReferring] = useState(false);

  useEffect(() => {
    if (!isOpen || !childId) return;
    loadDetails();
  }, [isOpen, childId]);

  async function loadDetails() {
    setLoading(true);
    try {
      const details = await ChildService.getChildById(childId);
      setData(details);
    } catch (err) {
      console.error('Failed to load child details:', err);
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  const handleCreateReferral = async () => {
    if (!data) return;
    setReferring(true);
    try {
      await ChildService.createReferralFromChild(
        data.patient,
        referralReason || 'Severe acute malnutrition or pediatric complication requiring specialist care',
        'Nutrition Rehabilitation Centre (NRC) / Taluka Hospital',
        'emergency',
        currentUser
      );
      setShowReferralBox(false);
      setReferralReason('');
      await loadDetails();
      if (onRecordUpdated) onRecordUpdated();
    } catch (err) {
      alert('Failed to dispatch referral: ' + err.message);
    } finally {
      setReferring(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-700 via-teal-700 to-emerald-700 px-6 py-4 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Baby className="w-6 h-6 text-indigo-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Child Health & Immunization Card (Mamta Card)</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-white border border-white/30 uppercase">
                  Universal Immunization Programme
                </span>
              </div>
              <p className="text-xs text-indigo-100">
                Child: {data?.patient?.name} ({data?.patient?.patientId}) • DOB: {data?.patient?.dateOfBirth}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              title="Print Summary"
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-4 flex-wrap flex-shrink-0">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('card')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'card'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Mamta Card Overview
            </button>
            <button
              onClick={() => setActiveTab('growth')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'growth'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Growth Tracking & MUAC ({data?.growths?.length || 0})
            </button>
            <button
              onClick={() => setActiveTab('immunizations')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'immunizations'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              UIP Immunization Checklist
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                if (onOpenGrowthModal) onOpenGrowthModal(data.patient);
              }}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Scale className="w-3.5 h-3.5" />
              <span>+ Record Growth</span>
            </button>

            <button
              onClick={() => {
                onClose();
                if (onOpenVaxModal) onOpenVaxModal(data.patient);
              }}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>+ Administer Vaccine</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-xs font-medium">
            Loading child healthcare profile...
          </div>
        ) : !data ? (
          <div className="p-12 text-center text-rose-500 text-xs font-medium">
            Child record not found.
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Tab 1: Mamta Card Overview */}
            {activeTab === 'card' && (
              <div className="space-y-6">
                
                {/* Child Anthropometry & Nutrition Status Banner */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-50 via-teal-50 to-emerald-50 border border-indigo-200">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-indigo-950">{data.patient.name}</span>
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white text-indigo-800 border border-indigo-200">
                          {data.patient.age} years ({data.patient.gender})
                        </span>
                      </div>
                      <p className="text-xs text-indigo-800 mt-1">
                        DOB: <span className="font-bold">{data.patient.dateOfBirth}</span> • Birth Weight: <span className="font-bold">{data.birth?.birthWeight || '2.8'} kg</span>
                        {data.mother && (
                          <span className="ml-2 font-semibold">Mother: {data.mother.name} ({data.mother.patientId})</span>
                        )}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {data.growths.length > 0 && (
                        <span className="px-3 py-1.5 rounded-xl text-xs font-bold border bg-white text-slate-800 shadow-sm">
                          {data.growths[data.growths.length - 1].nutritionGrade}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Emergency Referral Action Bar for Malnutrition / Sickness */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">Pediatric Escalation & NRC Referral</h4>
                      <p className="text-[11px] text-slate-500">Immediate referral to Nutrition Rehabilitation Centre (NRC) or Taluka Hospital.</p>
                    </div>

                    <button
                      onClick={() => setShowReferralBox(!showReferralBox)}
                      className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Dispatch Pediatric Referral</span>
                    </button>
                  </div>

                  {showReferralBox && (
                    <div className="pt-3 border-t border-slate-200 space-y-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Clinical Indication for Referral</label>
                        <textarea
                          rows="2"
                          placeholder="e.g. Severe Acute Malnutrition (MUAC 11.2 cm), bilateral pedal edema, fast breathing..."
                          value={referralReason}
                          onChange={(e) => setReferralReason(e.target.value)}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowReferralBox(false)}
                          className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={referring}
                          onClick={handleCreateReferral}
                          className="px-4 py-1.5 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold rounded-xl shadow-sm"
                        >
                          {referring ? 'Dispatching...' : 'Confirm Referral (Offline Stored)'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Birth & Family Summary */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Birth Details</h3>
                    <div className="text-xs space-y-1.5 text-slate-700">
                      <p><span className="font-semibold text-slate-500">Birth Weight:</span> {data.birth?.birthWeight ? `${data.birth.birthWeight} kg` : 'N/A'}</p>
                      <p><span className="font-semibold text-slate-500">Gestation at Birth:</span> {data.birth?.gestationalAge ? `${data.birth.gestationalAge} weeks` : 'Term'}</p>
                      <p><span className="font-semibold text-slate-500">Delivery Setting:</span> {data.birth?.deliveryType || 'Institutional'}</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Family & Location</h3>
                    <div className="text-xs space-y-1.5 text-slate-700">
                      <p><span className="font-semibold text-slate-500">Village Hamlet:</span> {data.patient.villageHamlet}</p>
                      <p><span className="font-semibold text-slate-500">Emergency Phone:</span> {data.patient.contactNumber || 'None'}</p>
                      <p><span className="font-semibold text-slate-500">Chronic Conditions:</span> {data.patient.chronicConditions?.join(', ') || 'None'}</p>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* Tab 2: Growth Tracking & MUAC */}
            {activeTab === 'growth' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Growth Surveillance History ({data.growths.length} records)
                  </h3>
                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenGrowthModal) onOpenGrowthModal(data.patient);
                    }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1"
                  >
                    <Scale className="w-3.5 h-3.5" />
                    <span>+ New Measurement</span>
                  </button>
                </div>

                {data.growths.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-xs text-slate-400">
                    No growth measurements recorded yet. Click '+ New Measurement' to record weight and MUAC.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {data.growths.map((g, idx) => (
                      <div key={g.id || idx} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-800 text-xs font-black flex items-center justify-center">
                              #{idx + 1}
                            </span>
                            <div>
                              <h4 className="text-xs font-bold text-slate-900">Age: {g.ageMonths} Months</h4>
                              <p className="text-[10px] text-slate-400">{g.createdAt?.slice(0, 10)} • Measured by {g.measuredBy || 'ASHA'}</p>
                            </div>
                          </div>

                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            g.nutritionGrade?.includes('SAM')
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : g.nutritionGrade?.includes('MAM')
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          }`}>
                            {g.nutritionGrade}
                          </span>
                        </div>

                        <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Weight</span>
                            <span className="font-bold text-slate-800">{g.weightKg} kg</span>
                          </div>
                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Height / Length</span>
                            <span className="font-bold text-slate-800">{g.heightCm ? `${g.heightCm} cm` : '--'}</span>
                          </div>
                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">MUAC (Arm Circumference)</span>
                            <span className={`font-bold ${g.muacCm && g.muacCm < 11.5 ? 'text-rose-600' : 'text-slate-800'}`}>
                              {g.muacCm ? `${g.muacCm} cm` : '--'}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: UIP Immunization Checklist */}
            {activeTab === 'immunizations' && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 leading-relaxed">
                  <strong>Universal Immunization Schedule:</strong> National vaccine milestones automatically computed from child date of birth ({data.patient.dateOfBirth}).
                </div>

                <div className="space-y-2.5">
                  {data.uipSchedule.map((vax, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-2xl border flex items-center justify-between gap-3 text-xs ${
                        vax.status === 'administered'
                          ? 'bg-emerald-50/60 border-emerald-200'
                          : vax.status === 'overdue'
                          ? 'bg-rose-50/60 border-rose-200'
                          : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-900">{vax.vaccineName}</h4>
                          <span className="text-[10px] text-slate-500 font-medium">({vax.milestone})</span>
                        </div>
                        <p className="text-[10px] text-slate-500 truncate mt-0.5">
                          Protects: {vax.protectsAgainst} • Route: {vax.route}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          vax.status === 'administered'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : vax.status === 'overdue'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-slate-100 text-slate-700 border border-slate-300'
                        }`}>
                          {vax.status === 'administered' ? `Given: ${vax.givenDate}` : vax.status === 'overdue' ? `Overdue (Due: ${vax.targetDueDate})` : `Due: ${vax.targetDueDate}`}
                        </span>

                        {vax.status !== 'administered' && (
                          <button
                            onClick={() => {
                              onClose();
                              if (onOpenVaxModal) onOpenVaxModal(data.patient, vax);
                            }}
                            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold transition-colors"
                          >
                            Administer
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
}
