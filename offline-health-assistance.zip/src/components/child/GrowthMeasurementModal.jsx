import React, { useState } from 'react';
import { ChildService } from '../../services/childService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  Scale,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Sparkles,
  ShieldAlert,
  Info
} from 'lucide-react';

export default function GrowthMeasurementModal({ isOpen, onClose, child, onGrowthRecorded, currentUser }) {
  const [formData, setFormData] = useState({
    ageMonths: child?.age ? String(child.age * 12) : '12',
    weightKg: '',
    heightCm: '',
    muacCm: ''
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !child) return null;

  // Live Pediatric Growth Evaluation
  const growthEval = ClinicalCalculators.classifyPediatricGrowth(
    formData.ageMonths,
    child.gender || 'male',
    formData.weightKg,
    formData.heightCm,
    formData.muacCm
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.weightKg || parseFloat(formData.weightKg) <= 0) {
      setError('Child weight is mandatory for growth monitoring.');
      return;
    }

    setSaving(true);
    try {
      await ChildService.recordGrowthMeasurement({
        patientId: child.id || child.patientId,
        childId: child.birth?.id || child.id,
        ageMonths: formData.ageMonths,
        weightKg: formData.weightKg,
        heightCm: formData.heightCm,
        muacCm: formData.muacCm
      }, currentUser);

      onGrowthRecorded();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to record growth measurement.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Scale className="w-6 h-6 text-emerald-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Record Growth & Malnutrition Screen</h2>
              <p className="text-xs text-emerald-100">
                Child: {child.name} ({child.patientId}) • {child.gender}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Current Age (Months) *</label>
              <input
                type="number"
                min="0"
                max="60"
                required
                value={formData.ageMonths}
                onChange={(e) => setFormData({ ...formData, ageMonths: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Weight (kg) *</label>
              <input
                type="number"
                step="0.05"
                required
                placeholder="e.g. 7.5"
                value={formData.weightKg}
                onChange={(e) => setFormData({ ...formData, weightKg: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold text-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Height / Length (cm)</label>
              <input
                type="number"
                step="0.1"
                placeholder="e.g. 72.0"
                value={formData.heightCm}
                onChange={(e) => setFormData({ ...formData, heightCm: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">MUAC (cm) - 6 to 59m</label>
              <input
                type="number"
                step="0.1"
                placeholder="e.g. 11.2 (Red Zone)"
                value={formData.muacCm}
                onChange={(e) => setFormData({ ...formData, muacCm: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold"
              />
            </div>
          </div>

          {/* Live Nutrition Grade Evaluation */}
          <div className={`p-4 rounded-2xl border space-y-2 ${growthEval.overallBadge}`}>
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs">{growthEval.overallGrade}</span>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-white/70">
                {growthEval.weightForAgeTier}
              </span>
            </div>

            <p className="text-[11px] leading-relaxed opacity-95">
              {growthEval.actionRecommendation}
            </p>

            {growthEval.isEmergency && (
              <div className="pt-2 border-t border-rose-300 text-[10px] font-bold text-rose-900 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 flex-shrink-0" />
                <span>Automatic Alert: Saving will generate an Emergency NRC Referral in local queue.</span>
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Recording...' : 'Save Growth Measurement'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
