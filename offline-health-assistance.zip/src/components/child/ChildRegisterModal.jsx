import React, { useState, useEffect } from 'react';
import { db } from '../../db/db';
import { ChildService } from '../../services/childService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  Baby,
  Calendar,
  AlertTriangle,
  User,
  ShieldCheck,
  CheckCircle2,
  Heart,
  Scale
} from 'lucide-react';

export default function ChildRegisterModal({ isOpen, onClose, onRegistered, currentUser }) {
  const [mothers, setMothers] = useState([]);
  const [selectedMotherId, setSelectedMotherId] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    gender: 'male',
    dateOfBirth: new Date().toISOString().slice(0, 10),
    contactNumber: '',
    villageHamlet: 'Main Village Center',
    wardNumber: 'Ward 1',
    houseNumber: '',
    bloodGroup: '',
    birthWeight: '2.8',
    gestationalAge: '38',
    deliveryType: 'Institutional (PHC)',
    vaccinesGivenAtBirth: ['BCG', 'OPV-0', 'HepB-0'],
    allergies: 'None'
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    async function loadMothers() {
      try {
        const femalePatients = await db.patients.filter(p => !p.isDeleted && p.gender === 'female').toArray();
        setMothers(femalePatients);
      } catch (err) {
        console.error('Failed to load mothers:', err);
      }
    }
    loadMothers();
  }, [isOpen]);

  if (!isOpen) return null;

  const bwEval = ClinicalCalculators.classifyBirthWeight(formData.birthWeight, formData.gestationalAge);

  const handleVaxToggle = (key) => {
    setFormData(prev => {
      const exists = prev.vaccinesGivenAtBirth.includes(key);
      return {
        ...prev,
        vaccinesGivenAtBirth: exists
          ? prev.vaccinesGivenAtBirth.filter(k => k !== key)
          : [...prev.vaccinesGivenAtBirth, key]
      };
    });
  };

  const handleMotherSelect = (e) => {
    const mId = e.target.value;
    setSelectedMotherId(mId);
    const m = mothers.find(p => p.id === mId || p.patientId === mId);
    if (m) {
      setFormData(prev => ({
        ...prev,
        contactNumber: m.contactNumber || prev.contactNumber,
        villageHamlet: m.villageHamlet || prev.villageHamlet,
        wardNumber: m.wardNumber || prev.wardNumber,
        houseNumber: m.houseNumber || prev.houseNumber
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.name.trim()) {
      setError('Child name is required.');
      return;
    }
    if (!formData.dateOfBirth) {
      setError('Date of birth is required.');
      return;
    }
    if (!formData.birthWeight || parseFloat(formData.birthWeight) <= 0) {
      setError('Valid birth weight in kg is required.');
      return;
    }

    setSaving(true);
    try {
      const mother = mothers.find(p => p.id === selectedMotherId);
      const payload = {
        ...formData,
        motherId: selectedMotherId,
        motherName: mother?.name || '',
        emergencyContact: mother ? `${mother.contactNumber} (Mother: ${mother.name})` : formData.contactNumber
      };

      await ChildService.registerChild(payload, currentUser);
      onRegistered();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to register child.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 via-teal-600 to-emerald-700 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Baby className="w-6 h-6 text-indigo-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Register Infant / Child (0 - 5 Years)</h2>
              <p className="text-xs text-indigo-100">Universal Immunization Programme • WHO Growth Standards</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Section 1: Child Demographics */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              1. Child Identity & Demographics
            </label>

            <div className="grid sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Child Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Aarav Patil / Baby of Sunita"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Gender *</label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Birth *</label>
                <input
                  type="date"
                  required
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Link Mother (Optional)</label>
                <select
                  value={selectedMotherId}
                  onChange={handleMotherSelect}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Select Mother from Registry</option>
                  {mothers.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.patientId}) - {m.villageHamlet}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Village Hamlet *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rampur Hamlet 2"
                  value={formData.villageHamlet}
                  onChange={(e) => setFormData({ ...formData, villageHamlet: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Birth Anthropometry & Gestation */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                2. Birth Anthropometry & Gestation
              </label>
              <span className="text-[10px] text-indigo-700 font-semibold">Neonatal Risk Stratification</span>
            </div>

            <div className="grid sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Birth Weight (kg) *</label>
                <input
                  type="number"
                  step="0.05"
                  required
                  placeholder="e.g. 2.8"
                  value={formData.birthWeight}
                  onChange={(e) => setFormData({ ...formData, birthWeight: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Gestational Age (weeks)</label>
                <input
                  type="number"
                  min="24"
                  max="44"
                  value={formData.gestationalAge}
                  onChange={(e) => setFormData({ ...formData, gestationalAge: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Setting</label>
                <select
                  value={formData.deliveryType}
                  onChange={(e) => setFormData({ ...formData, deliveryType: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Institutional (PHC)">Institutional (PHC)</option>
                  <option value="Institutional (CHC/District)">Institutional (CHC/District)</option>
                  <option value="Institutional (Private)">Institutional (Private)</option>
                  <option value="Home Delivery (ANM Attended)">Home Delivery (ANM Attended)</option>
                  <option value="Home Delivery (Untrained)">Home Delivery (Untrained)</option>
                </select>
              </div>
            </div>

            {/* Live Birth Weight Advisory */}
            <div className={`p-3 rounded-2xl border text-xs flex items-center justify-between ${bwEval.weightBadge}`}>
              <div>
                <span className="font-bold">{bwEval.weightTier}</span>
                <p className="text-[11px] opacity-90 mt-0.5">{bwEval.recommendation}</p>
              </div>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-white/70">
                {bwEval.termTier}
              </span>
            </div>
          </div>

          {/* Section 3: Universal Immunization Birth Doses */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              3. Universal Immunization Programme (Birth Doses)
            </label>

            <div className="grid sm:grid-cols-3 gap-2.5">
              {[
                { key: 'BCG', label: 'BCG (Tuberculosis)' },
                { key: 'OPV-0', label: 'OPV-0 (Polio Birth Dose)' },
                { key: 'HepB-0', label: 'Hepatitis B (Within 24h)' }
              ].map(vax => (
                <label
                  key={vax.key}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer text-xs transition-colors ${
                    formData.vaccinesGivenAtBirth.includes(vax.key)
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-900 font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={formData.vaccinesGivenAtBirth.includes(vax.key)}
                    onChange={() => handleVaxToggle(vax.key)}
                    className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                  />
                  <span>{vax.label}</span>
                </label>
              ))}
            </div>

            <p className="text-[11px] text-slate-500">
              * Checking these marks them as administered at birth. Unchecked vaccines will be queued as scheduled/due in the local immunization tracker.
            </p>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-teal-600 hover:from-indigo-700 hover:to-teal-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Registering...' : 'Register Child (Offline Saved)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
