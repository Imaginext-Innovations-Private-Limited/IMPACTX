import React, { useState } from 'react';
import { db } from '../../db/db';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  PlusCircle,
  FileText,
  ShieldCheck,
  Save,
  Trash2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function ArticleManagerModal({ isOpen, onClose, onSaved }) {
  const { currentUser } = useAuth();

  const [formData, setFormData] = useState({
    title: '',
    category: 'maternal',
    language: 'en',
    authority: 'Ministry of Health and Family Welfare (MoHFW)',
    version: 'v1.0',
    reviewDate: '2026-11-20',
    approvalStatus: 'approved',
    summary: '',
    content: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.content.trim()) {
      setError('Title and guideline content are required.');
      return;
    }

    setSubmitting(true);
    try {
      const id = `kb-admin-${Date.now()}`;
      const newArticle = {
        id,
        category: formData.category,
        title: formData.title,
        language: formData.language,
        summary: formData.summary || formData.title,
        content: formData.content,
        authority: formData.authority,
        version: formData.version,
        reviewDate: formData.reviewDate,
        approvalStatus: formData.approvalStatus,
        lastUpdated: new Date().toISOString().slice(0, 10)
      };

      await db.knowledgeArticles.add(newArticle);

      await db.auditLogs.add({
        entity: 'knowledgeArticles',
        entityId: id,
        action: 'GUIDELINE_PUBLISHED',
        performedBy: currentUser?.name || 'Administrator',
        role: currentUser?.role || 'admin',
        timestamp: new Date().toISOString(),
        details: `Published approved guideline: "${formData.title}" (${formData.authority})`
      });

      if (onSaved) onSaved(newArticle);
      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to save guideline');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <ShieldCheck className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Clinical Guideline Publisher</h2>
              <p className="text-xs text-teal-100">Add or review approved healthcare educational content</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Guideline Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Neonatal Jaundice Surveillance Protocol"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              >
                <option value="maternal">Maternal & ANC</option>
                <option value="child">Child Health</option>
                <option value="first_aid">First Aid Emergency</option>
                <option value="chronic">Chronic NCDs</option>
                <option value="nutrition">Nutrition & ORS</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Language</label>
              <select
                value={formData.language}
                onChange={(e) => setFormData({ ...formData, language: e.target.value })}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              >
                <option value="en">English</option>
                <option value="kn">ಕನ್ನಡ (Kannada)</option>
                <option value="hi">हिन्दी (Hindi)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Version</label>
              <input
                type="text"
                placeholder="v1.0"
                value={formData.version}
                onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Publishing Authority / Citation</label>
              <input
                type="text"
                placeholder="e.g. National Health Mission (NHM) / WHO"
                value={formData.authority}
                onChange={(e) => setFormData({ ...formData, authority: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Review Date</label>
              <input
                type="date"
                value={formData.reviewDate}
                onChange={(e) => setFormData({ ...formData, reviewDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Summary (1-2 sentences)</label>
            <input
              type="text"
              placeholder="Brief summary for quick field reference..."
              value={formData.summary}
              onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Detailed Clinical Content & Protocol (Markdown supported) <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows="6"
              placeholder="Step-by-step instructions, DOs and DONTs, warning sign thresholds..."
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 font-mono text-xs"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={submitting}
            className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center gap-1.5 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{submitting ? 'Publishing...' : 'Publish Guideline'}</span>
          </button>
        </div>

      </div>
    </div>
  );
}
