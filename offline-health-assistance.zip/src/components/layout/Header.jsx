import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { networkService } from '../../services/networkService';
import {
  Menu,
  Search,
  Bell,
  Wifi,
  WifiOff,
  Globe,
  User,
  ShieldCheck,
  RefreshCw,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  X
} from 'lucide-react';

export default function Header({ onMenuClick }) {
  const { currentUser, isOnline, setIsOnline, language, changeLanguage, logout, loginAsDemo } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsub = networkService.addListener(({ isOnline: online }) => {
      setIsOnline(online);
    });
    return () => unsub();
  }, []);

  const handleToggleOnline = () => {
    const nextState = !isOnline;
    setIsOnline(nextState);
    networkService.setSimulatedStatus(nextState);
  };

  const notifications = [
    {
      id: 1,
      type: 'warning',
      title: 'High-Risk Maternal Alert',
      desc: 'Geeta Devi (BP: 154/98) scheduled for urgent follow-up today.',
      time: '10m ago',
      unread: true
    },
    {
      id: 2,
      type: 'info',
      title: 'Immunization Due',
      desc: '3 infants in Ward 2 due for Pentavalent-3 today.',
      time: '1h ago',
      unread: true
    },
    {
      id: 3,
      type: 'sync',
      title: 'Offline Records Pending',
      desc: '5 patient updates saved locally, awaiting sync.',
      time: '2h ago',
      unread: false
    }
  ];

  return (
    <header className="sticky top-0 z-30 h-20 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Left: Mobile Toggle & Search */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search patients by name, Aadhaar, ABHA, or Village ID... (Offline enabled)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-100/80 border border-slate-200/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Offline / Online Status Pill with manual toggle for testing */}
        <button
          onClick={handleToggleOnline}
          title={`Click to simulate ${isOnline ? 'going offline' : 'going online'}`}
          className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
            isOnline
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
              : 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
          }`}
        >
          {isOnline ? (
            <>
              <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline">Online (Live)</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
              <span className="hidden md:inline">Offline Mode</span>
            </>
          )}
        </button>

        {/* Language Selector */}
        <div className="relative">
          <select
            value={language}
            onChange={(e) => changeLanguage(e.target.value)}
            className="text-xs font-medium bg-slate-100 border border-slate-200 text-slate-700 rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 cursor-pointer"
          >
            <option value="en">English</option>
            <option value="kn">ಕನ್ನಡ (Kannada)</option>
            <option value="hi">हिन्दी (Hindi)</option>
          </select>
        </div>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfileMenu(false);
            }}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-4 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold text-slate-900 text-sm">Notifications & Alerts</h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">2 New</span>
                </div>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto mt-2">
                {notifications.map((item) => (
                  <div key={item.id} className={`py-3 px-2 rounded-xl transition-colors hover:bg-slate-50 ${item.unread ? 'bg-teal-50/40' : ''}`}>
                    <div className="flex items-start gap-2.5">
                      {item.type === 'warning' ? (
                        <AlertTriangle className="w-4 h-4 text-rose-500 mt-0.5 flex-shrink-0" />
                      ) : item.type === 'sync' ? (
                        <RefreshCw className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                      ) : (
                        <Calendar className="w-4 h-4 text-teal-600 mt-0.5 flex-shrink-0" />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-slate-800">{item.title}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
                        <span className="text-[10px] text-slate-400 mt-1 block">{item.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-100 text-center">
                <span className="text-[11px] text-teal-600 font-semibold cursor-pointer hover:underline">
                  Mark all as read
                </span>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Pill & Quick Role Switcher */}
        <div className="relative">
          <button
            onClick={() => {
              setShowProfileMenu(!showProfileMenu);
              setShowNotifications(false);
            }}
            className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-teal-600 to-emerald-600 text-white font-bold flex items-center justify-center text-xs shadow-sm">
              {currentUser?.avatar || 'HW'}
            </div>
            <div className="hidden sm:block">
              <p className="text-xs font-semibold text-slate-900 leading-none">{currentUser?.name?.split(' ')[0]}</p>
              <span className="text-[10px] text-teal-700 font-medium">{currentUser?.role?.toUpperCase()}</span>
            </div>
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-4">
              <div className="pb-3 border-b border-slate-100">
                <p className="text-sm font-bold text-slate-900">{currentUser?.name}</p>
                <p className="text-xs text-teal-700 font-medium">{currentUser?.roleLabel}</p>
                <p className="text-xs text-slate-400 mt-1">{currentUser?.village}</p>
              </div>

              {/* Quick Role Switcher for seamless testing */}
              <div className="py-3">
                <p className="text-[11px] font-bold uppercase text-slate-400 tracking-wider mb-2">Switch Active Role</p>
                <div className="space-y-1.5">
                  <button
                    onClick={() => { loginAsDemo('asha'); setShowProfileMenu(false); }}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between ${
                      currentUser?.role === 'asha' ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>ASHA Health Worker</span>
                    {currentUser?.role === 'asha' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                  </button>
                  <button
                    onClick={() => { loginAsDemo('doctor'); setShowProfileMenu(false); }}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between ${
                      currentUser?.role === 'doctor' ? 'bg-teal-50 text-teal-800 font-semibold' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>PHC Doctor</span>
                    {currentUser?.role === 'doctor' && <CheckCircle2 className="w-4 h-4 text-teal-600" />}
                  </button>
                  <button
                    onClick={() => { loginAsDemo('admin'); setShowProfileMenu(false); }}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between ${
                      currentUser?.role === 'admin' ? 'bg-blue-50 text-blue-800 font-semibold' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>District Admin</span>
                    {currentUser?.role === 'admin' && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                  </button>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => { logout(); setShowProfileMenu(false); }}
                  className="w-full py-2 text-center text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                >
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
