import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../hooks/useTranslation';
import { PatientService } from '../../db/patientService';
import {
  LayoutDashboard,
  Users,
  Activity,
  HeartHandshake,
  Baby,
  Stethoscope,
  Share2,
  CalendarClock,
  BookOpen,
  FileBarChart2,
  RefreshCw,
  ShieldAlert,
  LogOut,
  ChevronRight,
  Wifi,
  WifiOff,
  Cross,
  Bot,
  FileSearch
} from 'lucide-react';

export default function Sidebar({ isOpen, setIsOpen }) {
  const { currentUser, logout, isOnline } = useAuth();
  const { t } = useTranslation();
  const location = useLocation();
  const [counts, setCounts] = useState({ total: 7, maternal: 2, child: 2, highRisk: 2, pendingSync: 0 });

  useEffect(() => {
    PatientService.getCounts().then(setCounts).catch(console.error);
  }, [location.pathname]);

  const navigationItems = [
    {
      group: t('nav.clinicalServices'),
      items: [
        { name: t('nav.dashboard'), path: '/', icon: LayoutDashboard },
        { name: t('nav.patients'), path: '/patients', icon: Users, badge: counts.total ? `${counts.total}` : '7' },
        { name: t('nav.assessments'), path: '/assessments', icon: Activity, tag: 'Vitals' },
        { name: t('nav.maternal'), path: '/maternal', icon: HeartHandshake, badge: counts.maternal ? `${counts.maternal} ANC` : '2 ANC' },
        { name: t('nav.child'), path: '/child', icon: Baby, badge: counts.child ? `${counts.child} Under-5` : '2 Under-5' },
        { name: t('nav.chronic'), path: '/chronic', icon: Stethoscope, tag: 'NCD' },
      ]
    },
    {
      group: t('nav.careCoordination'),
      items: [
        { name: t('nav.referrals'), path: '/referrals', icon: Share2, badge: '3 Urgent' },
        { name: t('nav.followups'), path: '/follow-ups', icon: CalendarClock, badge: '6 Today' },
      ]
    },
    {
      group: t('nav.knowledgeAnalytics'),
      items: [
        { name: t('nav.assistant'), path: '/assistant', icon: Bot, tag: 'Offline AI' },
        { name: t('nav.documentAnalysis'), path: '/document-analysis', icon: FileSearch, tag: 'OCR AI' },
        { name: t('nav.knowledge'), path: '/knowledge', icon: BookOpen, tag: 'Offline' },
        { name: t('nav.reports'), path: '/reports', icon: FileBarChart2 },
        { name: t('nav.sync'), path: '/sync', icon: RefreshCw, badge: counts.pendingSync > 0 ? `${counts.pendingSync} Pending` : 'Up to Date', badgeClass: counts.pendingSync > 0 ? 'bg-amber-100 text-amber-800 font-semibold' : 'bg-emerald-50 text-emerald-700' },
      ]
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-20 px-6 flex items-center justify-between border-b border-slate-100 bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <Cross className="w-6 h-6 text-emerald-300 stroke-[2.5]" />
            </div>
            <div>
              <div className="font-bold text-lg tracking-tight leading-none text-white">
                OFFLINE <span className="text-emerald-300 font-extrabold">HEALTH</span>
              </div>
              <p className="text-[10px] text-teal-100 font-medium tracking-wide mt-1 uppercase">
                Rural Healthcare Assistance
              </p>
            </div>
          </div>
        </div>

        {/* Offline Status Banner */}
        <div className={`px-4 py-2.5 text-xs font-medium flex items-center justify-between border-b ${
          isOnline 
            ? 'bg-emerald-50 text-emerald-800 border-emerald-100' 
            : 'bg-amber-50 text-amber-900 border-amber-200'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            <span>{isOnline ? 'Network Connected' : 'Offline Mode (Local-First)'}</span>
          </div>
          <span className="text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded bg-white/70">
            {isOnline ? 'Online' : 'IndexedDB'}
          </span>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {navigationItems.map((group, groupIdx) => (
            <div key={groupIdx}>
              <h3 className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                {group.group}
              </h3>
              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;

                  return (
                    <NavLink
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsOpen(false)}
                      className={`group flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-sm shadow-teal-700/20'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <Icon
                          className={`w-5 h-5 flex-shrink-0 transition-transform group-hover:scale-110 ${
                            isActive ? 'text-white' : 'text-slate-400 group-hover:text-teal-600'
                          }`}
                        />
                        <span className="truncate">{item.name}</span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {item.tag && (
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                            isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.tag}
                          </span>
                        )}
                        {item.badge && (
                          <span
                            className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${
                              item.badgeClass || (isActive ? 'bg-white/25 text-white' : 'bg-teal-50 text-teal-700')
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                    </NavLink>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* User Card & Logout */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-600 to-emerald-700 text-white font-bold flex items-center justify-center text-sm shadow-sm">
              {currentUser?.avatar || 'HW'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-900 truncate">
                {currentUser?.name || 'Healthcare Worker'}
              </p>
              <p className="text-xs text-slate-500 truncate">
                {currentUser?.roleLabel || 'ASHA Volunteer'}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs text-slate-500">
            <span className="truncate max-w-[170px]">{currentUser?.village}</span>
            <button
              onClick={logout}
              title="Logout / Switch User"
              className="text-slate-400 hover:text-rose-600 p-1 rounded-lg hover:bg-rose-50 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
