import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Wifi,
  WifiOff,
  AlertTriangle,
  MessageSquare,
  Minimize2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTranslation } from '../../hooks/useTranslation';
import { KnowledgeEngine } from '../../services/knowledgeEngine';
import { apiClient } from '../../services/apiClient';

export default function FloatingChatbot() {
  const { isOnline } = useAuth();
  const { language } = useTranslation();

  const [isOpen, setIsOpen] = useState(false);
  const [useCloudAI, setUseCloudAI] = useState(false);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Namaste! Ask me about maternal danger signs, ORS, child immunization, fever, or first aid. Works 100% offline.',
      emergency: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const endRef = useRef(null);
  const quickPrompts = KnowledgeEngine.getSuggestedQuestions(language).slice(0, 3);

  useEffect(() => {
    if (isOpen) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const sendMessage = async (overrideText) => {
    const query = (overrideText ?? input).trim();
    if (!query || isLoading) return;

    const userMsg = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!overrideText) setInput('');
    setIsLoading(true);

    try {
      let replyText = '';
      let emergency = false;
      let sources = [];

      if (useCloudAI && isOnline) {
        if (!apiClient.accessToken) {
          await apiClient.login('asha_sunita', 'offline123');
        }
        const res = await apiClient.request('/assistant/chat', {
          method: 'POST',
          body: JSON.stringify({
            message: query,
            language,
            history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
          }),
        });

        if (res.ok && res.data?.success && res.data.reply) {
          replyText = res.data.reply;
          emergency = Boolean(res.data.emergency);
          sources = res.data.sources || ['Cloud Clinical AI'];
        }
      }

      if (!replyText) {
        const offlineRes = await KnowledgeEngine.query(query, language);
        replyText = offlineRes.text;
        emergency = Boolean(offlineRes.emergency);
        sources = offlineRes.sources || [];
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: replyText,
          emergency,
          sources,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Unable to process message right now. For emergencies, call 108.',
          emergency: false,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-3 rounded-full bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-lg shadow-teal-700/30 font-semibold text-sm transition-transform hover:scale-105"
        aria-label="Open Health Chatbot"
      >
        <MessageSquare className="w-5 h-5" />
        <span className="hidden sm:inline">Health Chatbot</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 w-[92vw] max-w-sm h-[520px] bg-white rounded-2xl border border-slate-200 shadow-2xl flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-teal-700 to-emerald-700 text-white flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-white/15 flex items-center justify-center">
            <Bot className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <h3 className="text-sm font-bold leading-tight">OFFLINE HEALTH Bot</h3>
            <p className="text-[11px] text-teal-100 flex items-center gap-1">
              {isOnline && useCloudAI ? (
                <>
                  <Wifi className="w-3 h-3" /> Hybrid Cloud AI
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3" /> Offline Guidelines
                </>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {isOnline && (
            <button
              type="button"
              onClick={() => setUseCloudAI((v) => !v)}
              className={`px-2 py-1 rounded-lg text-[10px] font-semibold border transition ${
                useCloudAI
                  ? 'bg-emerald-400/25 border-emerald-200 text-white'
                  : 'bg-white/10 border-white/20 text-teal-100'
              }`}
              title="Toggle Cloud AI mode"
            >
              <Sparkles className="w-3 h-3 inline mr-1" />
              {useCloudAI ? 'Cloud On' : 'Offline'}
            </button>
          )}
          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="p-1 rounded-lg hover:bg-white/15"
            aria-label="Close Chatbot"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div key={msg.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-line ${
                  isUser
                    ? 'bg-teal-600 text-white rounded-br-sm'
                    : msg.emergency
                    ? 'bg-rose-50 border border-rose-200 text-rose-900 rounded-bl-sm'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-bl-sm shadow-sm'
                }`}
              >
                {msg.emergency && (
                  <div className="flex items-center gap-1 font-bold text-rose-700 mb-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>URGENT ESCALATION</span>
                  </div>
                )}
                <p>{msg.text}</p>
                {msg.sources?.length > 0 && (
                  <p className="mt-1.5 pt-1 border-t border-slate-200/70 text-[10px] text-slate-500">
                    Source: {msg.sources[0]}
                  </p>
                )}
                <span
                  className={`block text-[9px] mt-1 ${
                    isUser ? 'text-teal-100 text-right' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="text-xs text-slate-500 italic px-2">Thinking...</div>
        )}
        <div ref={endRef} />
      </div>

      {/* Quick Prompts */}
      <div className="px-3 py-2 bg-white border-t border-slate-100 flex gap-1.5 overflow-x-auto">
        {quickPrompts.map((q, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => sendMessage(q)}
            className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition"
          >
            {q.length > 34 ? `${q.slice(0, 34)}...` : q}
          </button>
        ))}
      </div>

      {/* Input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendMessage();
        }}
        className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask in English, ಕನ್ನಡ, or हिन्दी..."
          className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="p-2 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-40 text-white transition"
          aria-label="Send message"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
