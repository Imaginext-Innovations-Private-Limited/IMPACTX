import React, { useState } from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';

export default function PatientDeleteModal({ isOpen, onClose, patient, onConfirm }) {
  const [reason, setReason] = useState('Duplicate registration / clerical correction');
  const [customNote, setCustomNote] = useState('');
  const [deleting, setDeleting] = useState(false);

  if (!isOpen || !patient) return null;

  const handleConfirm = async () => {
    setDeleting(true);
    try {
      const fullReason = customNote.trim() ? `${reason}: ${customNote.trim()}` : reason;
      await onConfirm(patient.id, fullReason);
      onClose();
    } catch (e) {
      console.error('Failed to delete patient:', e);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        <div className="p-6">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
            <AlertTriangle className="w-6 h-6" />
          </div>

          <h3 className="text-lg font-bold text-slate-900">Confirm Patient Deletion</h3>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Are you sure you want to delete patient record <span className="font-bold text-slate-800">{patient.name}</span> ({patient.patientId})?
          </p>

          <div className="mt-4 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
            <p className="font-semibold">Clinical Audit Notice:</p>
            <p className="text-[11px] mt-0.5">
              This action soft-deletes the record in local IndexedDB and dispatches a tombstone event to the sync queue for central audit compliance.
            </p>
          </div>

          <div className="mt-4 space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Reason for Removal <span className="text-rose-500">*</span>
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20"
              >
                <option value="Duplicate registration / clerical correction">Duplicate registration / clerical correction</option>
                <option value="Migrated permanently outside catchment area">Migrated permanently outside catchment area</option>
                <option value="Patient registered under wrong Sub-Centre">Patient registered under wrong Sub-Centre</option>
                <option value="Deceased resident">Deceased resident</option>
                <option value="Other administrative reason">Other administrative reason</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Additional Notes (Optional)
              </label>
              <input
                type="text"
                placeholder="Enter audit notes..."
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20"
              />
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-xl"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={deleting}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center gap-1.5 disabled:opacity-50"
          >
            <Trash2 className="w-4 h-4" />
            <span>{deleting ? 'Deleting...' : 'Confirm & Delete'}</span>
          </button>
        </div>

      </div>
    </div>
  );
}
