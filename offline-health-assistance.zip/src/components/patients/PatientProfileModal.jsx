import React, { useState, useEffect } from 'react';
import { PatientService } from '../../db/patientService';
import { db } from '../../db/db';
import {
  X,
  User,
  Phone,
  MapPin,
  Calendar,
  Heart,
  Activity,
  AlertTriangle,
  Clock,
  ShieldCheck,
  Edit,
  Trash2,
  RefreshCw,
  Baby,
  HeartHandshake,
  FileText,
  History
} from 'lucide-react';

export default function PatientProfileModal({ isOpen, onClose, patient, onEdit, onDelete }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [auditLogs, setAuditLogs] = useState([]);
  const [patientAssessments, setPatientAssessments] = useState([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  useEffect(() => {
    if (patient && isOpen) {
      loadLogs();
    }
  }, [patient, isOpen]);

  const loadLogs = async () => {
    if (!patient) return;
    setLoadingLogs(true);
    try {
      const [logs, assList] = await Promise.all([
        PatientService.getPatientAuditLogs(patient.id),
        db.healthAssessments.where('patientId').equals(patient.id).reverse().sortBy('createdAt')
      ]);
      setAuditLogs(logs);
      setPatientAssessments(assList);
    } catch (e) {
      console.error('Failed to load logs:', e);
    } finally {
      setLoadingLogs(false);
    }
  };

  if (!isOpen || !patient) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header Banner */}
        <div className="px-6 py-6 border-b border-slate-100 bg-gradient-to-r from-teal-800 via-teal-700 to-emerald-800 text-white relative">
          <button
            onClick={onClose}
            className="absolute right-5 top-5 p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pr-8">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-xl font-bold border border-white/20 shadow-inner">
                {patient.name?.slice(0, 2).toUpperCase() || 'PT'}
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h2 className="text-xl font-bold">{patient.name}</h2>
                  <span className={`text-[11px] font-bold uppercase px-2.5 py-0.5 rounded-full ${
                    patient.riskLevel === 'high'
                      ? 'bg-rose-500 text-white'
                      : patient.riskLevel === 'moderate'
                      ? 'bg-amber-400 text-slate-900'
                      : 'bg-emerald-400 text-slate-900'
                  }`}>
                    {patient.riskLevel} Risk
                  </span>
                </div>
                <p className="text-xs text-teal-100 mt-1 flex items-center gap-2">
                  <span className="font-mono font-semibold">{patient.patientId}</span>
                  <span>•</span>
                  <span>{patient.age} Yrs, {patient.gender}</span>
                  <span>•</span>
                  <span className="font-semibold text-emerald-300">Blood Group: {patient.bloodGroup || 'N/A'}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-center">
              <span className={`text-xs px-2.5 py-1 rounded-xl font-semibold flex items-center gap-1.5 ${
                patient.syncStatus === 'synced'
                  ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30'
                  : 'bg-amber-500/20 text-amber-200 border border-amber-400/30'
              }`}>
                <RefreshCw className="w-3 h-3" />
                <span>{patient.syncStatus === 'synced' ? 'Cloud Synced' : 'Pending Sync'}</span>
              </span>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-2 mt-6 pt-2 border-t border-white/10">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'overview'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-teal-100 hover:bg-white/10'
              }`}
            >
              Overview & Demographics
            </button>
            <button
              onClick={() => setActiveTab('clinical')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'clinical'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-teal-100 hover:bg-white/10'
              }`}
            >
              Clinical Profile
            </button>
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'audit'
                  ? 'bg-white text-teal-900 shadow-sm'
                  : 'text-teal-100 hover:bg-white/10'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Audit Trail ({auditLogs.length})</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Identity & Address Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-teal-600" />
                  <span>Village Location & Identity Details</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block font-medium">Village Hamlet / Ward</span>
                    <span className="text-slate-800 font-semibold text-sm">
                      {patient.villageHamlet} ({patient.wardNumber || 'General'})
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">House Number & Landmark</span>
                    <span className="text-slate-800 font-semibold text-sm">
                      {patient.houseNumber || 'Not specified'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">ABHA Health ID</span>
                    <span className="font-mono text-teal-700 font-bold text-sm">
                      {patient.abhaId || 'Not linked'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">Aadhaar (Last 4)</span>
                    <span className="font-mono text-slate-800 font-semibold text-sm">
                      {patient.aadhaarLast4 ? `•••• •••• ${patient.aadhaarLast4}` : 'Not provided'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-teal-600" />
                  <span>Contact Information</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block font-medium">Primary Mobile</span>
                    <span className="text-slate-800 font-semibold text-sm">
                      {patient.contactNumber ? `+91 ${patient.contactNumber}` : 'No phone number'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block font-medium">Emergency Contact</span>
                    <span className="text-slate-800 font-semibold text-sm">
                      {patient.emergencyContact || 'None listed'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Administrative info */}
              <div className="p-4 rounded-2xl bg-teal-50/60 border border-teal-100 flex items-center justify-between text-xs text-teal-900">
                <div>
                  <p className="font-semibold">Registered by: {patient.lastModifiedBy || 'ASHA Staff'}</p>
                  <p className="text-[11px] text-teal-700 mt-0.5">
                    Record Version: v{patient.version || 1} • Registered on: {new Date(patient.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Consent Verified</span>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: CLINICAL PROFILE */}
          {activeTab === 'clinical' && (
            <div className="space-y-6">
              
              {/* Risk Banner */}
              <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
                patient.riskLevel === 'high'
                  ? 'bg-rose-50 border-rose-200 text-rose-900'
                  : patient.riskLevel === 'moderate'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                  patient.riskLevel === 'high' ? 'text-rose-600' : 'text-amber-600'
                }`} />
                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider">
                    {patient.riskLevel.toUpperCase()} CLINICAL RISK PROFILE
                  </h4>
                  <p className="text-xs mt-1 leading-relaxed">
                    {patient.riskLevel === 'high'
                      ? 'Patient requires prioritized field monitoring, weekly vitals, and prompt escalation to Medical Officer / CHC if warning signs present.'
                      : patient.riskLevel === 'moderate'
                      ? 'Patient has non-critical chronic conditions or pregnancy factors. Scheduled monthly surveillance advised.'
                      : 'Standard preventive care schedule. Up to date on community wellness parameters.'}
                  </p>
                </div>
              </div>

              {/* Maternal / Pregnancy Details */}
              {patient.isPregnant && (
                <div className="p-4 rounded-2xl bg-pink-50 border border-pink-200">
                  <h4 className="text-xs font-bold text-pink-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <HeartHandshake className="w-4 h-4 text-pink-600" />
                    <span>Maternal Health Tracking (Active Pregnancy)</span>
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mt-3">
                    <div>
                      <span className="text-pink-600 font-medium block">LMP</span>
                      <span className="font-bold text-slate-800">{patient.pregnancyDetails?.lmp || 'Logged in ANC'}</span>
                    </div>
                    <div>
                      <span className="text-pink-600 font-medium block">Est. Delivery (EDD)</span>
                      <span className="font-bold text-slate-800">{patient.pregnancyDetails?.edd || 'Calculated'}</span>
                    </div>
                    <div>
                      <span className="text-pink-600 font-medium block">Trimester</span>
                      <span className="font-bold text-slate-800">Trimester {patient.pregnancyDetails?.trimester || 3}</span>
                    </div>
                    <div>
                      <span className="text-pink-600 font-medium block">Gravida / Para</span>
                      <span className="font-bold text-slate-800">G{patient.pregnancyDetails?.gravida || 2} P{patient.pregnancyDetails?.para || 1}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Child Health Details */}
              {patient.category === 'child' && (
                <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200">
                  <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <Baby className="w-4 h-4 text-indigo-600" />
                    <span>Pediatric Under-5 Growth Surveillance</span>
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs mt-3">
                    <div>
                      <span className="text-indigo-600 font-medium block">Birth Weight</span>
                      <span className="font-bold text-slate-800">{patient.childDetails?.birthWeightKg || '2.8'} kg</span>
                    </div>
                    <div>
                      <span className="text-indigo-600 font-medium block">Current Weight</span>
                      <span className="font-bold text-slate-800">{patient.childDetails?.currentWeightKg || '7.1'} kg</span>
                    </div>
                    <div>
                      <span className="text-indigo-600 font-medium block">Immunization Status</span>
                      <span className="font-bold text-slate-800">{patient.childDetails?.immunizationStatus || 'Up to date'}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Chronic Conditions & Allergies */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Documented Medical Conditions
                </h4>
                
                <div className="flex flex-wrap gap-2">
                  {patient.chronicConditions && patient.chronicConditions.length > 0 ? (
                    patient.chronicConditions.map((cond, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 rounded-xl text-xs font-semibold bg-teal-100 text-teal-800 border border-teal-200"
                      >
                        {cond}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-slate-500 italic">No chronic illnesses recorded.</span>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-200/60">
                  <span className="text-xs text-slate-500 font-medium block">Allergies & Contraindications:</span>
                  <span className="text-xs font-semibold text-rose-700">
                    {patient.allergies || 'None known.'}
                  </span>
                </div>
              </div>

              {/* Recent Health Assessments */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-teal-600" />
                    <span>Recent Health Assessments ({patientAssessments.length})</span>
                  </h4>
                  <a
                    href="/assessments"
                    className="text-xs text-teal-700 font-bold hover:underline"
                  >
                    Assessments Module →
                  </a>
                </div>

                {patientAssessments.length > 0 ? (
                  <div className="space-y-2">
                    {patientAssessments.slice(0, 3).map((ass) => (
                      <div key={ass.id} className="p-3 bg-white rounded-xl border border-slate-200 text-xs flex items-center justify-between">
                        <div>
                          <span className="font-bold text-slate-900 block">{ass.assessmentType || 'General Screening'}</span>
                          <span className="text-[11px] text-slate-500">
                            BP: {ass.systolicBp && ass.diastolicBp ? `${ass.systolicBp}/${ass.diastolicBp} mmHg` : 'NR'} • Pulse: {ass.pulse ? `${ass.pulse} bpm` : 'NR'} • SpO2: {ass.spo2 ? `${ass.spo2}%` : 'NR'}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            ass.isEmergency ? 'bg-rose-100 text-rose-800' : ass.warningSigns?.length > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {ass.classification || ass.status || 'Recorded'}
                          </span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            {ass.assessmentDate || ass.createdAt?.slice(0, 10)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">No health assessments recorded yet for this patient.</p>
                )}
              </div>

            </div>
          )}

          {/* TAB 3: AUDIT TRAIL */}
          {activeTab === 'audit' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Local Record Version & Modifications History
                </h4>
                <span className="text-[11px] text-slate-400">IndexedDB Table: auditLogs</span>
              </div>

              {loadingLogs ? (
                <div className="py-8 text-center text-xs text-slate-400">Loading audit history...</div>
              ) : auditLogs.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No previous audit events recorded for this patient.
                </div>
              ) : (
                <div className="space-y-3">
                  {auditLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs flex items-start gap-3"
                    >
                      <div className="p-2 rounded-xl bg-teal-100 text-teal-800 mt-0.5">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900">{log.action}</span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(log.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-slate-600 mt-1">{log.details}</p>
                        <p className="text-[10px] text-teal-700 font-medium mt-1">
                          By: {log.performedBy} ({log.role})
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onDelete(patient);
            }}
            className="px-3.5 py-2 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-colors flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Patient</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onEdit(patient);
              }}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Edit className="w-4 h-4" />
              <span>Edit Details</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 rounded-xl transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
