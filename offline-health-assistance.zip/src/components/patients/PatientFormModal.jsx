import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  User,
  Phone,
  MapPin,
  Heart,
  ShieldCheck,
  AlertCircle,
  Save,
  Baby,
  HeartHandshake,
  Activity,
  FileCheck
} from 'lucide-react';

export default function PatientFormModal({ isOpen, onClose, patient = null, onSaved }) {
  const { currentUser } = useAuth();

  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'female',
    dateOfBirth: '',
    contactNumber: '',
    emergencyContact: '',
    abhaId: '',
    aadhaarLast4: '',
    villageHamlet: 'Rampur Hamlet 2',
    wardNumber: 'Ward 2',
    houseNumber: '',
    bloodGroup: 'B+',
    riskLevel: 'normal',
    category: 'general',
    isPregnant: false,
    chronicConditions: [],
    allergies: '',
    consentGiven: true
  });

  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (patient) {
      setFormData({
        name: patient.name || '',
        age: patient.age !== undefined ? String(patient.age) : '',
        gender: patient.gender || 'female',
        dateOfBirth: patient.dateOfBirth || '',
        contactNumber: patient.contactNumber || '',
        emergencyContact: patient.emergencyContact || '',
        abhaId: patient.abhaId || '',
        aadhaarLast4: patient.aadhaarLast4 || '',
        villageHamlet: patient.villageHamlet || 'Rampur Hamlet 2',
        wardNumber: patient.wardNumber || 'Ward 2',
        houseNumber: patient.houseNumber || '',
        bloodGroup: patient.bloodGroup || 'B+',
        riskLevel: patient.riskLevel || 'normal',
        category: patient.category || 'general',
        isPregnant: Boolean(patient.isPregnant),
        chronicConditions: patient.chronicConditions || [],
        allergies: patient.allergies || '',
        consentGiven: patient.consentGiven !== undefined ? patient.consentGiven : true
      });
    } else {
      // Reset for new registration
      setFormData({
        name: '',
        age: '',
        gender: 'female',
        dateOfBirth: '',
        contactNumber: '',
        emergencyContact: '',
        abhaId: '',
        aadhaarLast4: '',
        villageHamlet: 'Rampur Hamlet 2',
        wardNumber: 'Ward 2',
        houseNumber: '',
        bloodGroup: 'B+',
        riskLevel: 'normal',
        category: 'general',
        isPregnant: false,
        chronicConditions: [],
        allergies: '',
        consentGiven: true
      });
    }
    setErrors({});
  }, [patient, isOpen]);

  if (!isOpen) return null;

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = 'Patient name is required';
    if (!formData.age || isNaN(formData.age) || parseInt(formData.age, 10) < 0 || parseInt(formData.age, 10) > 120) {
      errs.age = 'Please enter a valid age (0-120)';
    }
    if (formData.contactNumber && !/^\d{10}$/.test(formData.contactNumber.replace(/[\s-]/g, ''))) {
      errs.contactNumber = 'Enter a valid 10-digit mobile number';
    }
    if (formData.aadhaarLast4 && !/^\d{4}$/.test(formData.aadhaarLast4)) {
      errs.aadhaarLast4 = 'Enter exactly last 4 digits of Aadhaar';
    }
    if (!formData.villageHamlet) errs.villageHamlet = 'Village hamlet is required';
    if (!formData.consentGiven) errs.consentGiven = 'Consent must be documented';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      await onSaved(formData, patient?.id);
      onClose();
    } catch (err) {
      console.error('Failed to save patient:', err);
      setErrors({ form: err.message || 'Failed to save patient record' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleChronicToggle = (condition) => {
    setFormData(prev => {
      const exists = prev.chronicConditions.includes(condition);
      return {
        ...prev,
        chronicConditions: exists
          ? prev.chronicConditions.filter(c => c !== condition)
          : [...prev.chronicConditions, condition]
      };
    });
  };

  const commonConditions = [
    'Hypertension',
    'Type 2 Diabetes',
    'Asthma / COPD',
    'Heart Disease',
    'Tuberculosis',
    'Severe Anemia'
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-slate-100 bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <User className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">
                {patient ? 'Edit Patient Record' : 'Register New Village Resident'}
              </h2>
              <p className="text-xs text-teal-100">
                {patient ? `Updating ID: ${patient.patientId}` : 'Generates local offline medical ID'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {errors.form && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errors.form}</span>
            </div>
          )}

          {/* Section 1: Demographics */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <User className="w-4 h-4 text-teal-600" />
              <span>1. Basic Demographics</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Savita Bai or Raju Kumar"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                    errors.name ? 'border-rose-400 ring-rose-200' : 'border-slate-200 focus:border-teal-600 focus:ring-teal-500/20'
                  }`}
                />
                {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Age (Years) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  placeholder="e.g. 26"
                  min="0"
                  max="120"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className={`w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                    errors.age ? 'border-rose-400 ring-rose-200' : 'border-slate-200 focus:border-teal-600 focus:ring-teal-500/20'
                  }`}
                />
                {errors.age && <p className="text-[11px] text-rose-500 mt-1">{errors.age}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Gender <span className="text-rose-500">*</span>
                </label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                >
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Blood Group
                </label>
                <select
                  value={formData.bloodGroup}
                  onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                >
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="Unknown">Unknown</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Date of Birth (Optional)
                </label>
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Contact, Location & Identity */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-teal-600" />
              <span>2. Contact & Village Address</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mobile Number
                </label>
                <input
                  type="tel"
                  placeholder="10-digit number"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                  className={`w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                    errors.contactNumber ? 'border-rose-400 ring-rose-200' : 'border-slate-200 focus:border-teal-600 focus:ring-teal-500/20'
                  }`}
                />
                {errors.contactNumber && <p className="text-[11px] text-rose-500 mt-1">{errors.contactNumber}</p>}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Emergency Contact (Name & Relationship)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 9845112233 (Father - Ramesh)"
                  value={formData.emergencyContact}
                  onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Village Hamlet <span className="text-rose-500">*</span>
                </label>
                <select
                  value={formData.villageHamlet}
                  onChange={(e) => setFormData({ ...formData, villageHamlet: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                >
                  <option value="Main Village Center">Main Village Center</option>
                  <option value="Rampur Hamlet 2">Rampur Hamlet 2</option>
                  <option value="South Hamlet">South Hamlet</option>
                  <option value="North Hamlet">North Hamlet</option>
                  <option value="Rampur Hamlet 4">Rampur Hamlet 4</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ward Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ward 2"
                  value={formData.wardNumber}
                  onChange={(e) => setFormData({ ...formData, wardNumber: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  House No. / Landmark
                </label>
                <input
                  type="text"
                  placeholder="e.g. H.No 45, Near School"
                  value={formData.houseNumber}
                  onChange={(e) => setFormData({ ...formData, houseNumber: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ABHA ID (Ayushman Bharat Digital Health ID)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 91-4523-8891-2301"
                  value={formData.abhaId}
                  onChange={(e) => setFormData({ ...formData, abhaId: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Aadhaar (Last 4 Digits)
                </label>
                <input
                  type="text"
                  maxLength="4"
                  placeholder="•••• 4192"
                  value={formData.aadhaarLast4}
                  onChange={(e) => setFormData({ ...formData, aadhaarLast4: e.target.value })}
                  className={`w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                    errors.aadhaarLast4 ? 'border-rose-400 ring-rose-200' : 'border-slate-200 focus:border-teal-600 focus:ring-teal-500/20'
                  }`}
                />
                {errors.aadhaarLast4 && <p className="text-[11px] text-rose-500 mt-1">{errors.aadhaarLast4}</p>}
              </div>
            </div>
          </div>

          {/* Section 3: Clinical Category & Risk Stratification */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <span>3. Clinical Category & Risk Stratification</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinical Stream / Category
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({
                    ...formData,
                    category: e.target.value,
                    isPregnant: e.target.value === 'maternal' ? true : formData.isPregnant
                  })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                >
                  <option value="general">General Village Resident</option>
                  <option value="maternal">Maternal Care (ANC/PNC)</option>
                  <option value="child">Child Healthcare (0-5 Years)</option>
                  <option value="chronic">Chronic Disease (NCD)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Triage Risk Level
                </label>
                <select
                  value={formData.riskLevel}
                  onChange={(e) => setFormData({ ...formData, riskLevel: e.target.value })}
                  className={`w-full px-3 py-2 text-xs sm:text-sm border rounded-xl font-medium focus:outline-none focus:ring-2 ${
                    formData.riskLevel === 'high'
                      ? 'bg-rose-50 text-rose-800 border-rose-300'
                      : formData.riskLevel === 'moderate'
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  }`}
                >
                  <option value="normal">Normal (Routine Monitoring)</option>
                  <option value="moderate">Moderate Risk (Close Follow-up)</option>
                  <option value="high">High Risk (Requires Medical Officer Review)</option>
                </select>
              </div>

              <div className="flex items-center pt-5">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPregnant}
                    onChange={(e) => setFormData({
                      ...formData,
                      isPregnant: e.target.checked,
                      category: e.target.checked ? 'maternal' : formData.category
                    })}
                    className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 border-slate-300"
                  />
                  <span className="text-xs font-semibold text-slate-800">
                    Currently Pregnant (Enable ANC Monitoring)
                  </span>
                </label>
              </div>
            </div>

            {/* Chronic Conditions Tags */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Chronic Medical Conditions (Select applicable)
              </label>
              <div className="flex flex-wrap gap-2">
                {commonConditions.map((cond) => {
                  const isSelected = formData.chronicConditions.includes(cond);
                  return (
                    <button
                      type="button"
                      key={cond}
                      onClick={() => handleChronicToggle(cond)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                        isSelected
                          ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {cond}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Allergies */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Known Drug or Environmental Allergies
              </label>
              <input
                type="text"
                placeholder="e.g. Penicillin, Sulfa drugs, or None"
                value={formData.allergies}
                onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          {/* Section 4: Consent & Audit Confirmation */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs space-y-2">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.consentGiven}
                onChange={(e) => setFormData({ ...formData, consentGiven: e.target.checked })}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 border-slate-300 mt-0.5"
              />
              <span className="text-slate-700 leading-relaxed font-medium">
                Informed consent obtained from patient / guardian for local offline healthcare record maintenance and National Health Mission coordination.
              </span>
            </label>
            {errors.consentGiven && (
              <p className="text-rose-500 text-[11px] pl-6 font-semibold">{errors.consentGiven}</p>
            )}
            <p className="text-[11px] text-slate-400 pl-6">
              Worker: <span className="font-semibold text-slate-600">{currentUser?.name} ({currentUser?.roleLabel})</span> • IndexedDB Local Storage
            </p>
          </div>
        </form>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 rounded-xl transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={submitting}
            className="px-5 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-teal-700/20 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{submitting ? 'Saving to IndexedDB...' : patient ? 'Save Changes' : 'Register Patient'}</span>
          </button>
        </div>

      </div>
    </div>
  );
}
