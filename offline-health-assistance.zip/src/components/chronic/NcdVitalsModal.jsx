import React, { useState } from 'react';
import { ChronicService } from '../../services/chronicService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  Activity,
  Heart,
  Droplet,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Pill,
  ShieldAlert,
  Info
} from 'lucide-react';

export default function NcdVitalsModal({ isOpen, onClose, patient, onVitalsRecorded, currentUser }) {
  const [formData, setFormData] = useState({
    visitDate: new Date().toISOString().slice(0, 10),
    systolicBp: '',
    diastolicBp: '',
    bloodGlucose: '',
    glucoseContext: 'random',
    pulse: '',
    spo2: '',
    weightKg: '',
    heightCm: '',
    medicationAdherence: 'Regular (Daily adherence)',
    daysOfMedicineRemaining: '15',
    symptoms: [],
    notes: ''
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !patient) return null;

  // Live Evaluator
  const controlEval = ClinicalCalculators.evaluateNcdControlStatus([], {
    systolicBp: formData.systolicBp,
    diastolicBp: formData.diastolicBp,
    bloodGlucose: formData.bloodGlucose,
    glucoseContext: formData.glucoseContext,
    medicationAdherence: formData.medicationAdherence
  });

  const complicationsEval = ClinicalCalculators.evaluateNcdComplications(formData.symptoms);

  const complicationOptions = [
    { id: 'chest_pain', label: 'Chest Discomfort / Angina' },
    { id: 'stroke_fast', label: 'Sudden Numbness / Weakness (Stroke Screen)' },
    { id: 'diabetic_foot', label: 'Diabetic Foot Ulcer / Non-healing wound' },
    { id: 'visual_blurring', label: 'Visual Blurring / Eye Floaters' }
  ];

  const handleToggleSymptom = (id) => {
    setFormData(prev => {
      const exists = prev.symptoms.includes(id);
      return {
        ...prev,
        symptoms: exists ? prev.symptoms.filter(s => s !== id) : [...prev.symptoms, id]
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.systolicBp && !formData.bloodGlucose) {
      setError('Please enter either Blood Pressure or Blood Glucose reading.');
      return;
    }

    setSaving(true);
    try {
      await ChronicService.recordNcdVitals({
        patientId: patient.id || patient.patientId,
        visitDate: formData.visitDate,
        systolicBp: formData.systolicBp,
        diastolicBp: formData.diastolicBp,
        bloodGlucose: formData.bloodGlucose,
        glucoseContext: formData.glucoseContext,
        pulse: formData.pulse,
        spo2: formData.spo2,
        weightKg: formData.weightKg,
        heightCm: formData.heightCm,
        medicationAdherence: formData.medicationAdherence,
        daysOfMedicineRemaining: formData.daysOfMedicineRemaining,
        symptoms: formData.symptoms,
        notes: formData.notes
      }, currentUser);

      onVitalsRecorded();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to save NCD vitals.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 to-cyan-800 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Activity className="w-6 h-6 text-teal-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Record NCD Surveillance Vitals</h2>
              <p className="text-xs text-teal-100">
                Patient: {patient.name} ({patient.patientId})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Blood Pressure */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Blood Pressure (mmHg)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Systolic BP</label>
                <input
                  type="number"
                  placeholder="e.g. 138"
                  value={formData.systolicBp}
                  onChange={(e) => setFormData({ ...formData, systolicBp: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Diastolic BP</label>
                <input
                  type="number"
                  placeholder="e.g. 88"
                  value={formData.diastolicBp}
                  onChange={(e) => setFormData({ ...formData, diastolicBp: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
                />
              </div>
            </div>
          </div>

          {/* Blood Glucose */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Blood Glucose (mg/dL)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Blood Sugar Level</label>
                <input
                  type="number"
                  placeholder="e.g. 142"
                  value={formData.bloodGlucose}
                  onChange={(e) => setFormData({ ...formData, bloodGlucose: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Measurement Context</label>
                <select
                  value={formData.glucoseContext}
                  onChange={(e) => setFormData({ ...formData, glucoseContext: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium"
                >
                  <option value="random">Random Blood Sugar (RBS)</option>
                  <option value="fasting">Fasting Blood Sugar (FBS)</option>
                  <option value="post_prandial">Post-Meal (PPBS)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Medication Supply & Adherence */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Adherence Status</label>
              <select
                value={formData.medicationAdherence}
                onChange={(e) => setFormData({ ...formData, medicationAdherence: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium"
              >
                <option value="Regular (Daily adherence)">Regular (≥80%)</option>
                <option value="Irregular (Missed doses)">Irregular (50-79%)</option>
                <option value="Defaulted (Stopped medication)">Defaulted (&lt;50%)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Days of Medicine Left</label>
              <input
                type="number"
                min="0"
                max="90"
                value={formData.daysOfMedicineRemaining}
                onChange={(e) => setFormData({ ...formData, daysOfMedicineRemaining: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-semibold"
              />
            </div>
          </div>

          {/* Complications Checklist */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              NCD Complication Red-Flags Screen
            </label>
            <div className="grid sm:grid-cols-2 gap-2">
              {complicationOptions.map(opt => (
                <label
                  key={opt.id}
                  className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs cursor-pointer ${
                    formData.symptoms.includes(opt.id)
                      ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={formData.symptoms.includes(opt.id)}
                    onChange={() => handleToggleSymptom(opt.id)}
                    className="w-4 h-4 text-rose-600 rounded"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Live Advisory Banner */}
          {(controlEval.alerts.length > 0 || complicationsEval.hasComplications) && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-xs space-y-1.5 text-amber-900">
              <div className="flex items-center gap-2 font-bold">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Clinical Triage Findings:</span>
              </div>
              <ul className="list-disc pl-5 space-y-0.5 text-[11px]">
                {controlEval.alerts.map((a, i) => <li key={i}>{a}</li>)}
                {complicationsEval.redFlags.map((r, i) => <li key={i} className="text-rose-700 font-bold">{r.text}</li>)}
              </ul>
            </div>
          )}

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-700 to-cyan-800 hover:from-teal-800 hover:to-cyan-900 text-white text-xs font-bold shadow-md shadow-teal-700/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save NCD Vitals (Local Stored)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
