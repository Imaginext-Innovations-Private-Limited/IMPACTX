import React, { useState, useEffect } from 'react';
import { ChronicService } from '../../services/chronicService';
import {
  X,
  Stethoscope,
  Activity,
  Calendar,
  AlertTriangle,
  User,
  CheckCircle2,
  Share2,
  Printer,
  Pill,
  Heart,
  Droplet,
  Clock,
  TrendingUp,
  ShieldAlert
} from 'lucide-react';

export default function NcdDetailModal({ isOpen, onClose, patientId, onRecordUpdated, onOpenVitalsModal, currentUser }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [referralReason, setReferralReason] = useState('');
  const [showReferralBox, setShowReferralBox] = useState(false);
  const [referring, setReferring] = useState(false);

  useEffect(() => {
    if (!isOpen || !patientId) return;
    loadDetails();
  }, [isOpen, patientId]);

  async function loadDetails() {
    setLoading(true);
    try {
      const details = await ChronicService.getNcdPatientById(patientId);
      setData(details);
    } catch (err) {
      console.error('Failed to load NCD patient details:', err);
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  const handleCreateReferral = async () => {
    if (!data) return;
    setReferring(true);
    try {
      await ChronicService.createReferralFromNcd(
        data.patient,
        referralReason || `NCD Complication Review: ${data.control.alerts.join(', ') || 'Specialist Evaluation'}`,
        'Taluka Hospital / District NCD Clinic',
        data.control.isEmergency ? 'emergency' : 'urgent',
        currentUser
      );
      setShowReferralBox(false);
      setReferralReason('');
      await loadDetails();
      if (onRecordUpdated) onRecordUpdated();
    } catch (err) {
      alert('Failed to dispatch referral: ' + err.message);
    } finally {
      setReferring(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-800 via-emerald-800 to-cyan-900 px-6 py-4 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Stethoscope className="w-6 h-6 text-teal-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Chronic Disease Management Passport</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-white border border-white/30 uppercase">
                  NPCDCS Guideline
                </span>
              </div>
              <p className="text-xs text-teal-200">
                Patient: {data?.patient?.name} ({data?.patient?.patientId}) • {data?.patient?.villageHamlet}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              title="Print Passport"
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-xs font-medium">
            Loading chronic disease record...
          </div>
        ) : !data ? (
          <div className="p-12 text-center text-rose-500 text-xs font-medium">
            Patient record not found.
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Status & Control Summary Banner */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-slate-900">{data.patient.name}</span>
                  <span className="text-xs text-slate-500 font-semibold">• {data.patient.age}y ({data.patient.gender})</span>
                </div>
                <div className="flex flex-wrap gap-2 mt-1.5">
                  {data.conditions.map(c => (
                    <span key={c.id} className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200">
                      {c.conditionName} ({c.severity})
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${data.control.overallBadge}`}>
                  {data.control.overallStatus}
                </span>

                <button
                  onClick={() => {
                    onClose();
                    if (onOpenVitalsModal) onOpenVitalsModal(data.patient);
                  }}
                  className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>+ Record Vitals</span>
                </button>
              </div>
            </div>

            {/* Clinical Control Indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                <div className="flex items-center gap-1.5 text-slate-500 font-semibold">
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>Blood Pressure Status</span>
                </div>
                <div className="text-base font-bold text-slate-900">{data.control.bpControl}</div>
                <p className="text-[10px] text-slate-400">Target: &lt;140/90 mmHg</p>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                <div className="flex items-center gap-1.5 text-slate-500 font-semibold">
                  <Droplet className="w-4 h-4 text-blue-500" />
                  <span>Blood Glucose Status</span>
                </div>
                <div className="text-base font-bold text-slate-900">{data.control.glucoseControl}</div>
                <p className="text-[10px] text-slate-400">Target: RBS &lt;140 mg/dL / FBS &lt;126 mg/dL</p>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                <div className="flex items-center gap-1.5 text-slate-500 font-semibold">
                  <Pill className="w-4 h-4 text-emerald-500" />
                  <span>Medication Adherence</span>
                </div>
                <div className="text-base font-bold text-slate-900">{data.control.adherenceTier}</div>
                <p className="text-[10px] text-slate-400">{data.adherence}</p>
              </div>
            </div>

            {/* Complications & Danger Sign Warnings */}
            {data.control.alerts.length > 0 && (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  <span>Active Clinical Alerts & Complication Risks ({data.control.alerts.length})</span>
                </div>
                <ul className="list-disc pl-5 text-xs text-amber-800 space-y-1 font-medium">
                  {data.control.alerts.map((alert, i) => (
                    <li key={i}>{alert}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* 1-Click Referral Action Bar */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Specialist Clinical Escalation</h4>
                  <p className="text-[11px] text-slate-500">Escalate uncontrolled parameters or complications to Taluka NCD Clinic.</p>
                </div>

                <button
                  onClick={() => setShowReferralBox(!showReferralBox)}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Dispatch Specialist Referral</span>
                </button>
              </div>

              {showReferralBox && (
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Reason for Referral</label>
                    <textarea
                      rows="2"
                      placeholder="e.g. Uncontrolled fasting hyperglycemia >200 mg/dL despite metformin adherence..."
                      value={referralReason}
                      onChange={(e) => setReferralReason(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReferralBox(false)}
                      className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={referring}
                      onClick={handleCreateReferral}
                      className="px-4 py-1.5 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold rounded-xl shadow-sm"
                    >
                      {referring ? 'Dispatching...' : 'Confirm Referral (Offline Stored)'}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Longitudinal Vitals Registry */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Longitudinal Vitals Surveillance ({data.assessments.length} readings)
              </h3>

              {data.assessments.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-xs text-slate-400">
                  No surveillance vitals logged yet. Click '+ Record Vitals' to log first follow-up check.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {data.assessments.map((a, idx) => (
                    <div key={a.id || idx} className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-between text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{a.assessmentDate || a.createdAt?.slice(0, 10)}</span>
                          <span className="text-slate-400">• By {a.assessedBy || 'ASHA Worker'}</span>
                        </div>
                        <div className="flex gap-4 mt-1 font-semibold text-slate-700">
                          <span>BP: <strong>{a.systolicBp ? `${a.systolicBp}/${a.diastolicBp} mmHg` : '--'}</strong></span>
                          <span>Glucose: <strong>{a.bloodGlucose ? `${a.bloodGlucose} mg/dL (${a.glucoseContext || 'random'})` : '--'}</strong></span>
                          {a.weight && <span>Weight: {a.weight} kg</span>}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {a.warningSigns && a.warningSigns.length > 0 && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                            {a.warningSigns.length} Warnings
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
