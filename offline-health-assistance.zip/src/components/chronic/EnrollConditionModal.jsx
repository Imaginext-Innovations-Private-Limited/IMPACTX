import React, { useState, useEffect } from 'react';
import { db } from '../../db/db';
import { ChronicService } from '../../services/chronicService';
import {
  X,
  Stethoscope,
  Calendar,
  AlertTriangle,
  User,
  ShieldCheck,
  CheckCircle2,
  Heart,
  Pill
} from 'lucide-react';

export default function EnrollConditionModal({ isOpen, onClose, onEnrolled, currentUser }) {
  const [patients, setPatients] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    conditionName: 'Type 2 Diabetes Mellitus',
    severity: 'moderate',
    diagnosedDate: new Date().toISOString().slice(0, 10),
    medications: ['Metformin 500mg BD'],
    medicationAdherence: 'Regular (Daily adherence)',
    notes: ''
  });

  const [customMed, setCustomMed] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    async function loadPatients() {
      try {
        const all = await db.patients.filter(p => !p.isDeleted).toArray();
        setPatients(all);
        if (all.length > 0 && !selectedPatientId) {
          setSelectedPatientId(all[0].id);
        }
      } catch (err) {
        console.error('Failed to load patients:', err);
      }
    }
    loadPatients();
  }, [isOpen]);

  if (!isOpen) return null;

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  const commonConditions = [
    'Type 2 Diabetes Mellitus',
    'Primary Essential Hypertension',
    'Cardiovascular Disease (CVD) / Ischemia',
    'Bronchial Asthma / COPD',
    'Chronic Kidney Disease (CKD)',
    'Osteoarthritis'
  ];

  const handleAddMed = () => {
    if (customMed.trim()) {
      setFormData(prev => ({
        ...prev,
        medications: [...prev.medications, customMed.trim()]
      }));
      setCustomMed('');
    }
  };

  const handleRemoveMed = (idx) => {
    setFormData(prev => ({
      ...prev,
      medications: prev.medications.filter((_, i) => i !== idx)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!selectedPatientId) {
      setError('Please select a patient to enroll.');
      return;
    }

    setSaving(true);
    try {
      await ChronicService.enrollCondition({
        patientId: selectedPatientId,
        conditionName: formData.conditionName,
        severity: formData.severity,
        diagnosedDate: formData.diagnosedDate,
        medications: formData.medications,
        medicationAdherence: formData.medicationAdherence,
        notes: formData.notes
      }, currentUser);

      onEnrolled();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to enroll condition.');
    } finally {
      setSaving(false);
    }
  };

  const filteredPatients = patients.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.contactNumber?.includes(searchTerm)
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 via-emerald-700 to-cyan-800 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Stethoscope className="w-6 h-6 text-teal-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Enroll in Chronic Disease Registry</h2>
              <p className="text-xs text-teal-100">NPCDCS Community Protocol • NCD Surveillance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Patient Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Select Patient
            </label>
            <div className="grid sm:grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Search patient..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl font-semibold text-slate-800"
              >
                {filteredPatients.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId}) - {p.age}y
                  </option>
                ))}
              </select>
            </div>

            {selectedPatient && (
              <div className="p-2.5 bg-teal-50/60 border border-teal-100 rounded-xl text-xs text-teal-900 flex items-center justify-between">
                <span><strong>{selectedPatient.name}</strong> • {selectedPatient.villageHamlet}</span>
                <span className="text-[10px] text-teal-700">Age: {selectedPatient.age}y</span>
              </div>
            )}
          </div>

          {/* Condition & Severity */}
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Chronic Condition *</label>
              <select
                value={formData.conditionName}
                onChange={(e) => setFormData({ ...formData, conditionName: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
              >
                {commonConditions.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Severity / Control</label>
              <select
                value={formData.severity}
                onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-semibold"
              >
                <option value="mild">Mild (Controlled with single drug / diet)</option>
                <option value="moderate">Moderate (Dual drug therapy)</option>
                <option value="uncontrolled">Uncontrolled (High risk of complications)</option>
              </select>
            </div>
          </div>

          {/* Diagnosis Date & Adherence */}
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Initial Diagnosis</label>
              <input
                type="date"
                value={formData.diagnosedDate}
                onChange={(e) => setFormData({ ...formData, diagnosedDate: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Medication Adherence Status</label>
              <select
                value={formData.medicationAdherence}
                onChange={(e) => setFormData({ ...formData, medicationAdherence: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium"
              >
                <option value="Regular (Daily adherence)">Regular (Daily adherence ≥80%)</option>
                <option value="Irregular (Missed doses)">Irregular (Missed doses 50-79%)</option>
                <option value="Defaulted (Stopped medication)">Defaulted (Stopped medication &lt;50%)</option>
              </select>
            </div>
          </div>

          {/* Current Prescribed Medications */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Prescribed Medications
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. Amlodipine 5mg OD / Metformin 500mg BD"
                value={customMed}
                onChange={(e) => setCustomMed(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl"
              />
              <button
                type="button"
                onClick={handleAddMed}
                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold"
              >
                + Add
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {formData.medications.map((m, idx) => (
                <span key={idx} className="px-2.5 py-1 bg-teal-50 border border-teal-200 text-teal-800 rounded-lg text-xs font-semibold flex items-center gap-1.5">
                  <Pill className="w-3 h-3 text-teal-600" />
                  <span>{m}</span>
                  <button type="button" onClick={() => handleRemoveMed(idx)} className="text-teal-400 hover:text-rose-600">×</button>
                </span>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Remarks & Diet Counseling</label>
            <textarea
              rows="2"
              placeholder="Lifestyle advice given (salt reduction, walking 30 min daily, avoiding tobacco)..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-700 to-emerald-700 hover:from-teal-800 hover:to-emerald-800 text-white text-xs font-bold shadow-md shadow-teal-700/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Enrolling...' : 'Enroll Patient (Local Stored)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
