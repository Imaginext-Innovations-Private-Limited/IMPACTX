import React, { useState } from 'react';
import { MaternalService } from '../../services/maternalService';
import {
  X,
  Baby,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Heart,
  ShieldCheck,
  Building2
} from 'lucide-react';

export default function DeliveryModal({ isOpen, onClose, maternalRecord, onDeliveryLogged, currentUser }) {
  const [formData, setFormData] = useState({
    deliveryDate: new Date().toISOString().slice(0, 10),
    deliveryTime: '12:00',
    deliveryPlace: 'Primary Health Centre (PHC)',
    deliveryType: 'Normal Vaginal Delivery',
    birthOutcome: 'Live Birth',
    newbornCount: 1,
    childName: '',
    childGender: 'female',
    birthWeight: '2.8',
    gestationalAgeAtDelivery: '38',
    maternalComplications: 'None',
    vaccinesGivenAtBirth: ['BCG', 'OPV-0', 'Hepatitis B (Birth Dose)']
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !maternalRecord) return null;

  const handleVaxToggle = (vax) => {
    setFormData(prev => {
      const exists = prev.vaccinesGivenAtBirth.includes(vax);
      return {
        ...prev,
        vaccinesGivenAtBirth: exists
          ? prev.vaccinesGivenAtBirth.filter(v => v !== vax)
          : [...prev.vaccinesGivenAtBirth, vax]
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.deliveryDate) {
      setError('Delivery date is required.');
      return;
    }
    if (formData.birthOutcome === 'Live Birth' && (!formData.birthWeight || parseFloat(formData.birthWeight) <= 0)) {
      setError('Valid birth weight is required for live birth record.');
      return;
    }

    setSaving(true);
    try {
      await MaternalService.recordDelivery(maternalRecord.id, formData, currentUser);
      onDeliveryLogged();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to log delivery.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Baby className="w-6 h-6 text-pink-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Log Delivery & Birth Outcome</h2>
              <p className="text-xs text-pink-100">
                Mother: {maternalRecord.patient?.name} ({maternalRecord.patient?.patientId})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Delivery Date & Facility */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Delivery *</label>
              <input
                type="date"
                required
                value={formData.deliveryDate}
                onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Place</label>
              <select
                value={formData.deliveryPlace}
                onChange={(e) => setFormData({ ...formData, deliveryPlace: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-medium"
              >
                <option value="Primary Health Centre (PHC)">Primary Health Centre (PHC)</option>
                <option value="Community Health Centre (CHC)">Community Health Centre (CHC)</option>
                <option value="Taluka Hospital / SDH">Taluka Hospital / SDH</option>
                <option value="District Hospital">District Hospital</option>
                <option value="Private Nursing Home">Private Nursing Home</option>
                <option value="Home Delivery (Attended by ANM)">Home Delivery (Attended by ANM)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Type of Delivery</label>
              <select
                value={formData.deliveryType}
                onChange={(e) => setFormData({ ...formData, deliveryType: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-medium"
              >
                <option value="Normal Vaginal Delivery">Normal Vaginal Delivery</option>
                <option value="Caesarean Section (LSCS)">Caesarean Section (LSCS)</option>
                <option value="Instrumental (Forceps/Vacuum)">Instrumental (Forceps/Vacuum)</option>
                <option value="Assisted Breech Delivery">Assisted Breech Delivery</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Birth Outcome</label>
              <select
                value={formData.birthOutcome}
                onChange={(e) => setFormData({ ...formData, birthOutcome: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-bold"
              >
                <option value="Live Birth">Live Birth</option>
                <option value="Stillbirth">Stillbirth (Intrauterine Death)</option>
                <option value="Early Neonatal Death">Early Neonatal Death</option>
              </select>
            </div>
          </div>

          {/* Newborn Profile (If Live Birth) */}
          {formData.birthOutcome === 'Live Birth' && (
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                  Newborn Health Record
                </label>
                <span className="text-[10px] text-pink-600 font-semibold">Auto-Registers Infant</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Baby Gender *</label>
                  <select
                    value={formData.childGender}
                    onChange={(e) => setFormData({ ...formData, childGender: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-bold"
                  >
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Birth Weight (kg) *</label>
                  <input
                    type="number"
                    step="0.05"
                    required
                    placeholder="e.g. 2.8"
                    value={formData.birthWeight}
                    onChange={(e) => setFormData({ ...formData, birthWeight: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Gestational Age (w)</label>
                  <input
                    type="number"
                    value={formData.gestationalAgeAtDelivery}
                    onChange={(e) => setFormData({ ...formData, gestationalAgeAtDelivery: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              {parseFloat(formData.birthWeight) < 2.5 && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  <span>Low Birth Weight (&lt;2.5 kg): Requires kangaroo mother care (KMC) and thermal protection.</span>
                </div>
              )}

              {/* Zero Dose Vaccines at Birth */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  Universal Immunization Birth Doses Administered:
                </label>
                <div className="flex flex-wrap gap-2">
                  {['BCG', 'OPV-0', 'Hepatitis B (Birth Dose)'].map(vax => (
                    <label key={vax} className="p-2 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2 text-xs cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.vaccinesGivenAtBirth.includes(vax)}
                        onChange={() => handleVaxToggle(vax)}
                        className="w-4 h-4 text-rose-600 rounded"
                      />
                      <span>{vax}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Maternal Recovery & Postnatal Follow-ups Notice */}
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-900 leading-relaxed">
            <strong>Postnatal Care (PNC) Automation:</strong> Logging this delivery will automatically schedule 4 home surveillance visits (48 hours, Day 7, Day 14, Day 28) for the mother in the local offline follow-up queue.
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white text-xs font-bold shadow-md shadow-rose-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Recording...' : 'Log Delivery & Generate PNC Schedule'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
