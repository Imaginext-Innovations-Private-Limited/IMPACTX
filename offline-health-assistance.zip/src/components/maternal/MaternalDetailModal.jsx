import React, { useState, useEffect } from 'react';
import { MaternalService } from '../../services/maternalService';
import {
  X,
  HeartHandshake,
  Calendar,
  AlertTriangle,
  User,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Clock,
  Printer,
  TrendingUp,
  FileText,
  Activity,
  Heart,
  Pill,
  Baby,
  ChevronRight,
  ExternalLink
} from 'lucide-react';

export default function MaternalDetailModal({ isOpen, onClose, maternalId, onRecordUpdated, onOpenAncModal, onOpenDeliveryModal, currentUser }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('mcp'); // mcp, visits, schedule
  const [referralReason, setReferralReason] = useState('');
  const [showReferralBox, setShowReferralBox] = useState(false);
  const [referring, setReferring] = useState(false);

  useEffect(() => {
    if (!isOpen || !maternalId) return;
    loadDetails();
  }, [isOpen, maternalId]);

  async function loadDetails() {
    setLoading(true);
    try {
      const details = await MaternalService.getMaternalRecordById(maternalId);
      setData(details);
    } catch (err) {
      console.error('Failed to load maternal details:', err);
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  const handleCreateReferral = async () => {
    if (!data) return;
    setReferring(true);
    try {
      await MaternalService.createReferralFromMaternal(
        data,
        referralReason || `Obstetric Referral: ${data.hrp.riskFactors.map(r => r.factor).join(', ') || 'Specialist Evaluation'}`,
        'Community Health Centre / First Referral Unit (FRU)',
        data.hrp.isEmergency ? 'emergency' : 'urgent',
        currentUser
      );
      setShowReferralBox(false);
      setReferralReason('');
      await loadDetails();
      if (onRecordUpdated) onRecordUpdated();
    } catch (err) {
      alert('Failed to dispatch referral: ' + err.message);
    } finally {
      setReferring(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-pink-700 px-6 py-4 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <HeartHandshake className="w-6 h-6 text-pink-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Mother & Child Protection (MCP) Card</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-white border border-white/30 uppercase">
                  NHM RCH Portal Compatible
                </span>
              </div>
              <p className="text-xs text-pink-100">
                Ref ID: {data?.id} • Patient: {data?.patient?.name} ({data?.patient?.patientId})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              title="Print Summary"
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-4 flex-wrap flex-shrink-0">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('mcp')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'mcp'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              MCP Overview & Risk
            </button>
            <button
              onClick={() => setActiveTab('visits')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'visits'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              ANC Visit Timeline ({data?.visits?.length || 0})
            </button>
            <button
              onClick={() => setActiveTab('schedule')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'schedule'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              Standard 4-Visit Tracker
            </button>
          </div>

          <div className="flex items-center gap-2">
            {data?.status !== 'delivered' && (
              <>
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenAncModal) onOpenAncModal(data);
                  }}
                  className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>+ Record ANC Visit</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenDeliveryModal) onOpenDeliveryModal(data);
                  }}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Baby className="w-3.5 h-3.5" />
                  <span>Log Delivery</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Modal Body */}
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-xs font-medium">
            Loading maternal clinical profile...
          </div>
        ) : !data ? (
          <div className="p-12 text-center text-rose-500 text-xs font-medium">
            Maternal record not found.
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            {/* Tab 1: MCP Overview */}
            {activeTab === 'mcp' && (
              <div className="space-y-6">
                
                {/* Gestational Age & Progress Banner */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-pink-50 via-rose-50 to-orange-50 border border-pink-200">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-pink-900">{data.gestationalAge.text}</span>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${data.gestationalAge.trimesterBadge}`}>
                          {data.gestationalAge.trimesterLabel}
                        </span>
                        {data.status === 'delivered' && (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            Delivered
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-pink-800 mt-1">
                        LMP: <span className="font-bold">{data.lmp}</span> • EDD: <span className="font-bold">{data.eddInfo.formatted}</span>
                        {data.status !== 'delivered' && (
                          <span className="ml-2 text-pink-700">({data.gestationalAge.daysToEdd} days remaining)</span>
                        )}
                      </p>
                    </div>

                    <span className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${data.hrp.badge}`}>
                      {data.hrp.riskTier}
                    </span>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full bg-white/80 rounded-full h-2.5 overflow-hidden border border-pink-200">
                    <div
                      className="bg-gradient-to-r from-pink-500 to-rose-600 h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${data.gestationalAge.progressPercent}%` }}
                    />
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-pink-700 font-semibold mt-1">
                    <span>LMP (Week 0)</span>
                    <span>Week 12 (T1)</span>
                    <span>Week 28 (T2)</span>
                    <span>EDD 40 Weeks</span>
                  </div>
                </div>

                {/* High-Risk Pregnancy (HRP) Analysis Banner */}
                {data.hrp.riskFactors.length > 0 ? (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                        <span>Identified High-Risk Factors ({data.hrp.riskFactors.length})</span>
                      </div>
                      <span className="text-[10px] bg-amber-200/60 text-amber-900 px-2 py-0.5 rounded-md font-semibold">
                        Intensified Surveillance Required
                      </span>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-2">
                      {data.hrp.riskFactors.map((rf, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-white border border-amber-200 text-xs flex items-center justify-between">
                          <span className="font-bold text-slate-800">{rf.factor}</span>
                          <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                            rf.severity === 'critical' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {rf.severity}
                          </span>
                        </div>
                      ))}
                    </div>

                    <p className="text-[11px] text-amber-900 pt-1 leading-relaxed">
                      <strong>Clinical Action Plan:</strong> {data.hrp.actionRecommendation}
                    </p>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 text-xs text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    <span><strong>Normal Risk Pregnancy:</strong> No critical obstetric danger signs identified. Continue routine ANC surveillance.</span>
                  </div>
                )}

                {/* Demographics & Obstetric Background Card */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Mother's Profile</h3>
                    <div className="text-xs space-y-1.5 text-slate-700">
                      <p><span className="font-semibold text-slate-500">Name:</span> {data.patient?.name}</p>
                      <p><span className="font-semibold text-slate-500">Age:</span> {data.patient?.age} years</p>
                      <p><span className="font-semibold text-slate-500">Phone:</span> {data.patient?.contactNumber || 'Not documented'}</p>
                      <p><span className="font-semibold text-slate-500">Village Hamlet:</span> {data.patient?.villageHamlet}</p>
                      <p><span className="font-semibold text-slate-500">Blood Group:</span> <strong className="text-slate-900">{data.bloodGroup || data.patient?.bloodGroup || 'Not Tested'}</strong></p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Obstetric History & Delivery Plan</h3>
                    <div className="text-xs space-y-1.5 text-slate-700">
                      <p><span className="font-semibold text-slate-500">Gravidity / Parity:</span> G{data.gravidity} P{data.parity} L{data.livingChildren} A{data.abortions}</p>
                      <p><span className="font-semibold text-slate-500">Planned Hospital:</span> {data.expectedDeliveryPlace || 'Primary Health Centre'}</p>
                      <p><span className="font-semibold text-slate-500">Multiple Gestation:</span> {data.isMultipleGestation ? 'Yes (Twins)' : 'Singleton'}</p>
                      <p><span className="font-semibold text-slate-500">Previous C-Section:</span> {data.previousCesarean ? 'Yes (High Risk)' : 'No'}</p>
                      <p><span className="font-semibold text-slate-500">Registered On:</span> {data.createdAt?.slice(0, 10)}</p>
                    </div>
                  </div>
                </div>

                {/* 1-Click Referral & Follow-up Action Bar */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">Care Coordination & Emergency Referral</h4>
                      <p className="text-[11px] text-slate-500">Escalate high-risk pregnancy to CHC/FRU or schedule community follow-up.</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowReferralBox(!showReferralBox)}
                        className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Dispatch Emergency Referral</span>
                      </button>
                    </div>
                  </div>

                  {showReferralBox && (
                    <div className="pt-3 border-t border-slate-200 space-y-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Clinical Reason for Referral</label>
                        <textarea
                          rows="2"
                          placeholder="e.g. Severe preeclampsia with BP 154/98 at 32 weeks, proteinuria 1+..."
                          value={referralReason}
                          onChange={(e) => setReferralReason(e.target.value)}
                          className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowReferralBox(false)}
                          className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={referring}
                          onClick={handleCreateReferral}
                          className="px-4 py-1.5 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold rounded-xl shadow-sm"
                        >
                          {referring ? 'Dispatching...' : 'Confirm Referral (Offline Stored)'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* Tab 2: ANC Visits Timeline */}
            {activeTab === 'visits' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Recorded Antenatal Checkups ({data.visits.length})
                  </h3>
                  {data.status !== 'delivered' && (
                    <button
                      onClick={() => {
                        onClose();
                        if (onOpenAncModal) onOpenAncModal(data);
                      }}
                      className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex items-center gap-1"
                    >
                      <Activity className="w-3.5 h-3.5" />
                      <span>+ Record New Visit</span>
                    </button>
                  )}
                </div>

                {data.visits.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-xs text-slate-400">
                    No ANC visits recorded yet. Click '+ Record New Visit' to enter ANC 1 vitals.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {data.visits.map((v, idx) => (
                      <div key={v.id || idx} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                          <div className="flex items-center gap-2">
                            <span className="w-7 h-7 rounded-xl bg-teal-100 text-teal-800 text-xs font-black flex items-center justify-center">
                              #{v.visitNumber}
                            </span>
                            <div>
                              <h4 className="text-xs font-bold text-slate-900">ANC Visit #{v.visitNumber}</h4>
                              <p className="text-[10px] text-slate-400">{v.visitDate} • Assessed by {v.assessedBy || 'ASHA Worker'}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            {v.dangerSignsIdentified && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                                Danger Sign Alert
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Vitals Grid */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Blood Pressure</span>
                            <span className={`font-bold ${v.systolicBp >= 140 ? 'text-rose-600' : 'text-slate-800'}`}>
                              {v.systolicBp ? `${v.systolicBp}/${v.diastolicBp} mmHg` : 'N/A'}
                            </span>
                          </div>

                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Weight</span>
                            <span className="font-bold text-slate-800">{v.weightKg ? `${v.weightKg} kg` : 'N/A'}</span>
                          </div>

                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Fundal Ht / FHR</span>
                            <span className="font-bold text-slate-800">
                              {v.fundalHeightCm ? `${v.fundalHeightCm} cm` : '--'} / {v.fetalHeartRate ? `${v.fetalHeartRate} bpm` : '--'}
                            </span>
                          </div>

                          <div className="p-2 bg-slate-50 rounded-xl">
                            <span className="text-[10px] text-slate-400 block">Hb / Urine Protein</span>
                            <span className="font-bold text-slate-800">
                              {v.hemoglobin ? `${v.hemoglobin} g/dL` : '--'} / {v.urineProtein || 'Nil'}
                            </span>
                          </div>
                        </div>

                        {/* Supplements & Td */}
                        <div className="text-[11px] text-slate-600 flex flex-wrap gap-3 pt-1">
                          <span>Td Dose: <strong>{v.tdVaccineDose || 'None'}</strong></span>
                          <span>IFA Tablets: <strong>{v.ifaTabletsGiven || 0}</strong></span>
                          <span>Calcium: <strong>{v.calciumTabletsGiven || 0}</strong></span>
                        </div>

                        {v.warningSigns && v.warningSigns.length > 0 && (
                          <div className="p-2 bg-rose-50 border border-rose-200 rounded-xl text-[11px] text-rose-800">
                            <strong>Warning Signs:</strong> {v.warningSigns.join(', ')}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: Standard 4-Visit Tracker */}
            {activeTab === 'schedule' && (
              <div className="space-y-4">
                <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 leading-relaxed">
                  <strong>National Health Mission (NHM) Protocol:</strong> Minimum 4 comprehensive antenatal care checkups are required for every pregnant woman to prevent maternal and neonatal mortality.
                </div>

                <div className="space-y-3">
                  {data.schedule.map((item) => (
                    <div
                      key={item.visitNumber}
                      className={`p-4 rounded-2xl border transition-all ${
                        item.completed
                          ? 'bg-emerald-50/60 border-emerald-200'
                          : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center ${
                            item.completed ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                          }`}>
                            {item.visitNumber}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                          <span className="text-[10px] text-slate-500 font-medium">({item.timingWeeks})</span>
                        </div>

                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          item.completed
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}>
                          {item.completed ? 'Completed' : `Target: ${item.targetDueDate}`}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-600 space-y-1">
                        <p className="font-semibold text-slate-700">Recommended Clinical Actions:</p>
                        <div className="flex flex-wrap gap-1.5">
                          {item.keyActivities.map((act, i) => (
                            <span key={i} className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] text-slate-600">
                              • {act}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Disclaimer */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[10px] text-slate-500 leading-relaxed text-center">
              Community Health Decision-Support Aid • Complies with NHM RCH Guidelines • In obstetric emergencies, transport immediately via 108 Ambulance.
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
