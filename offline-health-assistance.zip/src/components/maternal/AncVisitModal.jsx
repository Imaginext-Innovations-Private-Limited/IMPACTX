import React, { useState, useEffect } from 'react';
import { MaternalService } from '../../services/maternalService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  Stethoscope,
  Activity,
  AlertTriangle,
  Heart,
  Pill,
  ShieldAlert,
  CheckCircle2,
  Calendar,
  Sparkles,
  Info
} from 'lucide-react';

export default function AncVisitModal({ isOpen, onClose, maternalRecord, onVisitRecorded, currentUser }) {
  const [formData, setFormData] = useState({
    visitNumber: 1,
    visitDate: new Date().toISOString().slice(0, 10),
    systolicBp: '',
    diastolicBp: '',
    weightKg: '',
    fundalHeightCm: '',
    fetalHeartRate: '',
    fetalLie: 'Longitudinal',
    fetalMovement: 'Present',
    hemoglobin: '',
    urineProtein: 'Nil',
    urineSugar: 'Nil',
    tdVaccineDose: 'None',
    ifaTabletsGiven: 30,
    calciumTabletsGiven: 30,
    symptoms: [],
    notes: ''
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen || !maternalRecord) return;
    const nextVisit = (maternalRecord.visitCount || 0) + 1;
    setFormData(prev => ({
      ...prev,
      visitNumber: Math.min(4, nextVisit),
      visitDate: new Date().toISOString().slice(0, 10)
    }));
  }, [isOpen, maternalRecord]);

  if (!isOpen || !maternalRecord) return null;

  // Real-time Clinical Evaluators
  const bpResult = ClinicalCalculators.classifyBloodPressure(
    formData.systolicBp,
    formData.diastolicBp,
    { isPregnant: true }
  );

  const hbVal = parseFloat(formData.hemoglobin);
  let anemiaStatus = null;
  if (!isNaN(hbVal) && hbVal > 0) {
    if (hbVal < 7.0) {
      anemiaStatus = { tier: 'Severe Anemia (<7.0 g/dL)', color: 'text-rose-700 bg-rose-50 border-rose-300 font-bold', alert: true };
    } else if (hbVal < 11.0) {
      anemiaStatus = { tier: 'Moderate Anemia (7.0 - 10.9 g/dL)', color: 'text-amber-800 bg-amber-50 border-amber-300', alert: true };
    } else {
      anemiaStatus = { tier: 'Normal Hemoglobin (≥11.0 g/dL)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200', alert: false };
    }
  }

  const dangerSignsOptions = [
    { id: 'severe_headache', label: 'Severe Persistent Headache' },
    { id: 'blurred_vision', label: 'Visual Blurring / Flashes' },
    { id: 'vaginal_bleeding', label: 'Vaginal Bleeding (APH Alert)' },
    { id: 'swelling_face_hands', label: 'Facial / Hand Edema' },
    { id: 'decreased_fetal_movement', label: 'Reduced Fetal Movements' },
    { id: 'epigastric_pain', label: 'Severe Upper Abdominal Pain' }
  ];

  const toggleSymptom = (id) => {
    setFormData(prev => {
      const exists = prev.symptoms.includes(id);
      return {
        ...prev,
        symptoms: exists ? prev.symptoms.filter(s => s !== id) : [...prev.symptoms, id]
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.systolicBp || !formData.diastolicBp) {
      setError('Blood pressure measurement is mandatory for maternal screening.');
      return;
    }
    if (!formData.weightKg) {
      setError('Maternal weight is required to monitor gestational weight gain.');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        patientId: maternalRecord.patientId,
        maternalRecordId: maternalRecord.id,
        visitNumber: formData.visitNumber,
        visitDate: formData.visitDate,
        systolicBp: formData.systolicBp,
        diastolicBp: formData.diastolicBp,
        weightKg: formData.weightKg,
        fundalHeightCm: formData.fundalHeightCm,
        fetalHeartRate: formData.fetalHeartRate,
        fetalLie: formData.fetalLie,
        fetalMovement: formData.fetalMovement,
        hemoglobin: formData.hemoglobin,
        urineProtein: formData.urineProtein,
        urineSugar: formData.urineSugar,
        tdVaccineDose: formData.tdVaccineDose,
        ifaTabletsGiven: formData.ifaTabletsGiven,
        calciumTabletsGiven: formData.calciumTabletsGiven,
        symptoms: formData.symptoms,
        notes: formData.notes
      };

      await MaternalService.recordAntenatalVisit(payload, currentUser);
      onVisitRecorded();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to save ANC visit.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Stethoscope className="w-6 h-6 text-teal-200" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Record Antenatal Care (ANC) Visit</h2>
              <p className="text-xs text-teal-200">
                {maternalRecord.patient?.name} ({maternalRecord.patient?.patientId}) • {maternalRecord.gestationalAge?.longText}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Section 1: Visit Sequence & Date */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">ANC Visit Number</label>
              <select
                value={formData.visitNumber}
                onChange={(e) => setFormData({ ...formData, visitNumber: parseInt(e.target.value, 10) })}
                className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
              >
                <option value={1}>ANC 1 (Within 12 weeks / Early Registration)</option>
                <option value={2}>ANC 2 (14 - 26 weeks / Second Trimester)</option>
                <option value={3}>ANC 3 (28 - 34 weeks / Third Trimester)</option>
                <option value={4}>ANC 4 (36 - 40 weeks / Pre-delivery)</option>
                <option value={5}>Additional / Emergency ANC Visit</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Visit Date</label>
              <input
                type="date"
                required
                value={formData.visitDate}
                onChange={(e) => setFormData({ ...formData, visitDate: e.target.value })}
                className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium"
              />
            </div>
          </div>

          {/* Section 2: Vitals & Maternal Screening */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                Maternal Vitals & Blood Pressure
              </label>
              <span className="text-[10px] text-teal-700 font-semibold">Preeclampsia Surveillance</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Systolic BP (mmHg) *</label>
                <input
                  type="number"
                  placeholder="e.g. 120"
                  required
                  value={formData.systolicBp}
                  onChange={(e) => setFormData({ ...formData, systolicBp: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Diastolic BP (mmHg) *</label>
                <input
                  type="number"
                  placeholder="e.g. 80"
                  required
                  value={formData.diastolicBp}
                  onChange={(e) => setFormData({ ...formData, diastolicBp: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Maternal Weight (kg) *</label>
                <input
                  type="number"
                  step="0.1"
                  placeholder="e.g. 56.5"
                  required
                  value={formData.weightKg}
                  onChange={(e) => setFormData({ ...formData, weightKg: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-semibold"
                />
              </div>
            </div>

            {/* Live BP Advisory Banner */}
            {bpResult.isAlert && (
              <div className={`p-3 rounded-2xl border flex items-center gap-2.5 text-xs ${bpResult.badge}`}>
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{bpResult.recommendation}</span>
              </div>
            )}
          </div>

          {/* Section 3: Obstetric Measurements (Fundal Height, FHR, Fetal Movement) */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Obstetric Examination & Fetal Health
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Fundal Height (cm)</label>
                <input
                  type="number"
                  step="0.5"
                  placeholder="e.g. 28"
                  value={formData.fundalHeightCm}
                  onChange={(e) => setFormData({ ...formData, fundalHeightCm: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Fetal Heart Rate (bpm)</label>
                <input
                  type="number"
                  placeholder="120 - 160"
                  value={formData.fetalHeartRate}
                  onChange={(e) => setFormData({ ...formData, fetalHeartRate: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Fetal Lie</label>
                <select
                  value={formData.fetalLie}
                  onChange={(e) => setFormData({ ...formData, fetalLie: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                >
                  <option value="Longitudinal">Longitudinal</option>
                  <option value="Transverse">Transverse (Cross)</option>
                  <option value="Oblique">Oblique</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Fetal Movement</label>
                <select
                  value={formData.fetalMovement}
                  onChange={(e) => setFormData({ ...formData, fetalMovement: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                >
                  <option value="Present">Present & Active</option>
                  <option value="Reduced">Reduced Movements</option>
                  <option value="Absent">Absent Movements (Emergency)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 4: Laboratory Tests (Hb, Urine Albumin, Sugar) */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Laboratory Tests & Anemia Screening
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Hemoglobin (g/dL)</label>
                <input
                  type="number"
                  step="0.1"
                  placeholder="e.g. 11.2"
                  value={formData.hemoglobin}
                  onChange={(e) => setFormData({ ...formData, hemoglobin: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Urine Protein (Albumin)</label>
                <select
                  value={formData.urineProtein}
                  onChange={(e) => setFormData({ ...formData, urineProtein: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                >
                  <option value="Nil">Nil / Negative</option>
                  <option value="Trace">Trace</option>
                  <option value="1+">1+ (30 mg/dL)</option>
                  <option value="2+">2+ (100 mg/dL)</option>
                  <option value="3+">3+ (300 mg/dL)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Urine Sugar (Glucose)</label>
                <select
                  value={formData.urineSugar}
                  onChange={(e) => setFormData({ ...formData, urineSugar: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                >
                  <option value="Nil">Nil / Negative</option>
                  <option value="Trace">Trace</option>
                  <option value="1+">1+ (Mild Glycosuria)</option>
                  <option value="2+">2+ (Moderate)</option>
                </select>
              </div>
            </div>

            {anemiaStatus && (
              <div className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 ${anemiaStatus.color}`}>
                <Info className="w-4 h-4 flex-shrink-0" />
                <span>{anemiaStatus.tier}</span>
              </div>
            )}
          </div>

          {/* Section 5: Vaccines & Nutrition Supplementation */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Vaccines & Nutrition Supplementation
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Tetanus Toxoid (Td Dose)</label>
                <select
                  value={formData.tdVaccineDose}
                  onChange={(e) => setFormData({ ...formData, tdVaccineDose: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                >
                  <option value="None">None Given Today</option>
                  <option value="Td-1">Td-1 (Early Pregnancy)</option>
                  <option value="Td-2">Td-2 (4 Weeks after Td-1)</option>
                  <option value="Td-Booster">Td-Booster (Pregnancy within 3 yrs)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">IFA Tablets Given</label>
                <input
                  type="number"
                  value={formData.ifaTabletsGiven}
                  onChange={(e) => setFormData({ ...formData, ifaTabletsGiven: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Calcium Tablets Given</label>
                <input
                  type="number"
                  value={formData.calciumTabletsGiven}
                  onChange={(e) => setFormData({ ...formData, calciumTabletsGiven: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Section 6: Danger Signs Checklist */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                Obstetric Danger Signs Screen
              </label>
              <span className="text-[10px] text-rose-600 font-semibold">Immediate Action Required</span>
            </div>

            <div className="grid sm:grid-cols-2 gap-2">
              {dangerSignsOptions.map(opt => (
                <label
                  key={opt.id}
                  className={`p-2.5 rounded-xl border flex items-center gap-2.5 cursor-pointer text-xs transition-colors ${
                    formData.symptoms.includes(opt.id)
                      ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={formData.symptoms.includes(opt.id)}
                    onChange={() => toggleSymptom(opt.id)}
                    className="w-4 h-4 text-rose-600 rounded focus:ring-rose-500"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Clinical Remarks & Counseling</label>
            <textarea
              rows="2"
              placeholder="Advice on nutrition, rest, signs of labor, birth companion preparation..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-bold shadow-md shadow-teal-600/20 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save ANC Visit (Local-First)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
