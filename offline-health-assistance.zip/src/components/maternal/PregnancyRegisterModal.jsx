import React, { useState, useEffect } from 'react';
import { db } from '../../db/db';
import { MaternalService } from '../../services/maternalService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  HeartHandshake,
  Calendar,
  AlertTriangle,
  User,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Info
} from 'lucide-react';

export default function PregnancyRegisterModal({ isOpen, onClose, onRegistered, currentUser }) {
  const [patients, setPatients] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState({
    lmp: '',
    gravidity: '1',
    parity: '0',
    livingChildren: '0',
    abortions: '0',
    bloodGroup: '',
    expectedDeliveryPlace: 'Primary Health Centre (PHC)',
    isMultipleGestation: false,
    previousCesarean: false,
    previousStillbirth: false,
    selectedRisks: [],
    notes: ''
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Load eligible female patients
  useEffect(() => {
    if (!isOpen) return;
    async function loadCandidates() {
      try {
        const all = await db.patients.filter(p => !p.isDeleted && p.gender === 'female').toArray();
        setPatients(all);
        if (all.length > 0 && !selectedPatientId) {
          setSelectedPatientId(all[0].id);
        }
      } catch (err) {
        console.error('Failed to load patient candidates:', err);
      }
    }
    loadCandidates();
  }, [isOpen]);

  if (!isOpen) return null;

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  // Live Calculations
  const eddInfo = ClinicalCalculators.calculateEdd(formData.lmp);
  const gaInfo = ClinicalCalculators.calculateGestationalAge(formData.lmp);

  const commonRiskList = [
    'Previous Caesarean Section',
    'History of previous stillbirth / recurrent pregnancy loss',
    'Multiple Gestation (Twins)',
    'Known Chronic Hypertension',
    'Known Pre-existing Diabetes Mellitus',
    'Severe Anemia History',
    'Severe Obesity or Malnutrition',
    'Rh Negative Blood with Rh Positive Husband'
  ];

  const handleRiskToggle = (risk) => {
    setFormData(prev => {
      const exists = prev.selectedRisks.includes(risk);
      return {
        ...prev,
        selectedRisks: exists
          ? prev.selectedRisks.filter(r => r !== risk)
          : [...prev.selectedRisks, risk]
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!selectedPatientId) {
      setError('Please select a female patient to register.');
      return;
    }
    if (!formData.lmp) {
      setError('Last Menstrual Period (LMP) date is required.');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        patientId: selectedPatientId,
        lmp: formData.lmp,
        gravidity: formData.gravidity,
        parity: formData.parity,
        livingChildren: formData.livingChildren,
        abortions: formData.abortions,
        bloodGroup: formData.bloodGroup || selectedPatient?.bloodGroup || '',
        expectedDeliveryPlace: formData.expectedDeliveryPlace,
        isMultipleGestation: formData.isMultipleGestation,
        previousCesarean: formData.previousCesarean,
        previousStillbirth: formData.previousStillbirth,
        highRiskFactors: [
          ...formData.selectedRisks,
          ...(formData.previousCesarean ? ['Previous Caesarean Section'] : []),
          ...(formData.previousStillbirth ? ['Previous Stillbirth / Recurrent Abortion'] : []),
          ...(formData.isMultipleGestation ? ['Multiple Gestation (Twins)'] : [])
        ],
        notes: formData.notes
      };

      await MaternalService.registerPregnancy(payload, currentUser);
      onRegistered();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to register pregnancy.');
    } finally {
      setSaving(false);
    }
  };

  const filteredPatients = patients.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.contactNumber?.includes(searchTerm)
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-pink-700 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <HeartHandshake className="w-6 h-6 text-pink-100" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Register Antenatal Mother (ANC)</h2>
              <p className="text-xs text-pink-100">National Health Mission • Maternal & Child Health Protocol</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-700">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Section 1: Patient Selection */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              1. Select Pregnant Mother
            </label>
            
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <input
                  type="text"
                  placeholder="Filter female patients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500"
                />
              </div>

              <div>
                <select
                  value={selectedPatientId}
                  onChange={(e) => setSelectedPatientId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 font-medium"
                >
                  {filteredPatients.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.patientId}) - {p.age}y, {p.villageHamlet}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedPatient && (
              <div className="p-3 bg-pink-50/60 border border-pink-100 rounded-2xl flex items-center justify-between text-xs text-pink-950">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-pink-600" />
                  <span className="font-bold">{selectedPatient.name}</span>
                  <span className="text-pink-700">• {selectedPatient.age} yrs • {selectedPatient.villageHamlet}</span>
                </div>
                <span className="text-[11px] font-semibold text-pink-700 bg-white px-2 py-0.5 rounded-full border border-pink-200">
                  Blood Group: {selectedPatient.bloodGroup || 'Not Tested'}
                </span>
              </div>
            )}
          </div>

          {/* Section 2: LMP & Automatic EDD / Gestational Age */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              2. Obstetric Dates & Gestational Timeline
            </label>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Last Menstrual Period (LMP) *
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="date"
                    required
                    value={formData.lmp}
                    onChange={(e) => setFormData({ ...formData, lmp: e.target.value })}
                    className="w-full pl-9 pr-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Expected Date of Delivery (EDD)
                </label>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 flex items-center justify-between">
                  <span>{eddInfo.formatted || 'Calculated from LMP'}</span>
                  {eddInfo.isValid && (
                    <span className="text-[10px] bg-pink-100 text-pink-800 px-2 py-0.5 rounded-full">
                      Naegele's Rule (+280d)
                    </span>
                  )}
                </div>
              </div>
            </div>

            {gaInfo.isValid && (
              <div className="p-3.5 bg-gradient-to-r from-pink-50 to-rose-50 border border-pink-200 rounded-2xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-pink-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-pink-600" />
                    <span>Current Gestational Age: {gaInfo.longText}</span>
                  </div>
                  <p className="text-[11px] text-pink-700 mt-0.5">
                    {gaInfo.daysToEdd} days remaining until estimated delivery date.
                  </p>
                </div>
                <span className={`px-2.5 py-1 text-xs font-bold rounded-xl border ${gaInfo.trimesterBadge}`}>
                  {gaInfo.trimesterLabel}
                </span>
              </div>
            )}
          </div>

          {/* Section 3: Obstetric History (Gravida, Para, Living, Abortions) */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              3. Obstetric History (G P L A)
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Gravidity (G)</label>
                <input
                  type="number"
                  min="1"
                  max="15"
                  value={formData.gravidity}
                  onChange={(e) => setFormData({ ...formData, gravidity: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Parity (P)</label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={formData.parity}
                  onChange={(e) => setFormData({ ...formData, parity: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Living (L)</label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={formData.livingChildren}
                  onChange={(e) => setFormData({ ...formData, livingChildren: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Abortions (A)</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={formData.abortions}
                  onChange={(e) => setFormData({ ...formData, abortions: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Section 4: High-Risk Factors & Surgical History */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
                4. High-Risk Pregnancy (HRP) Screening Checklist
              </label>
              <span className="text-[10px] text-pink-600 font-semibold">PMSMA Protocol</span>
            </div>

            <div className="grid sm:grid-cols-2 gap-2.5">
              <label className="p-3 rounded-xl border border-slate-200 hover:border-pink-300 bg-slate-50 hover:bg-pink-50/40 flex items-center gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.previousCesarean}
                  onChange={(e) => setFormData({ ...formData, previousCesarean: e.target.checked })}
                  className="w-4 h-4 text-pink-600 rounded focus:ring-pink-500"
                />
                <span className="font-semibold text-slate-800">Previous Caesarean Section (C-Section)</span>
              </label>

              <label className="p-3 rounded-xl border border-slate-200 hover:border-pink-300 bg-slate-50 hover:bg-pink-50/40 flex items-center gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.previousStillbirth}
                  onChange={(e) => setFormData({ ...formData, previousStillbirth: e.target.checked })}
                  className="w-4 h-4 text-pink-600 rounded focus:ring-pink-500"
                />
                <span className="font-semibold text-slate-800">History of Stillbirth / Recurrent Abortions</span>
              </label>

              <label className="p-3 rounded-xl border border-slate-200 hover:border-pink-300 bg-slate-50 hover:bg-pink-50/40 flex items-center gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.isMultipleGestation}
                  onChange={(e) => setFormData({ ...formData, isMultipleGestation: e.target.checked })}
                  className="w-4 h-4 text-pink-600 rounded focus:ring-pink-500"
                />
                <span className="font-semibold text-slate-800">Multiple Gestation (Twins / Multiples)</span>
              </label>

              {commonRiskList.slice(3).map((risk, idx) => (
                <label key={idx} className="p-3 rounded-xl border border-slate-200 hover:border-pink-300 bg-slate-50 hover:bg-pink-50/40 flex items-center gap-2.5 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={formData.selectedRisks.includes(risk)}
                    onChange={() => handleRiskToggle(risk)}
                    className="w-4 h-4 text-pink-600 rounded focus:ring-pink-500"
                  />
                  <span className="font-medium text-slate-700">{risk}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Section 5: Delivery Planning & Facility */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              5. Delivery Planning & Institutional Facility
            </label>

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Planned Place of Delivery</label>
                <select
                  value={formData.expectedDeliveryPlace}
                  onChange={(e) => setFormData({ ...formData, expectedDeliveryPlace: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                >
                  <option value="Primary Health Centre (PHC)">Primary Health Centre (PHC)</option>
                  <option value="Community Health Centre (CHC)">Community Health Centre (CHC)</option>
                  <option value="Taluka Hospital / Sub-District Hospital">Taluka Hospital / Sub-District Hospital</option>
                  <option value="District Hospital / Medical College">District Hospital / Medical College</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Maternal Blood Group</label>
                <select
                  value={formData.bloodGroup}
                  onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500/20 font-medium"
                >
                  <option value="">Select Blood Group</option>
                  <option value="A+">A Positive (A+)</option>
                  <option value="A-">A Negative (A-)</option>
                  <option value="B+">B Positive (B+)</option>
                  <option value="B-">B Negative (B-)</option>
                  <option value="O+">O Positive (O+)</option>
                  <option value="O-">O Negative (O-)</option>
                  <option value="AB+">AB Positive (AB+)</option>
                  <option value="AB-">AB Negative (AB-)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Clinical Notes & Observations</label>
              <textarea
                rows="2"
                placeholder="Birth preparedness, companion support, transport arrangements (108 Ambulance orientation)..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3.5 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold shadow-md shadow-pink-600/20 transition-all flex items-center gap-2"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>{saving ? 'Registering...' : 'Register Pregnancy (Offline Saved)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
