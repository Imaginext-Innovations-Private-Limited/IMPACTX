import React, { useState } from 'react';
import {
  X,
  Printer,
  FileDown,
  ShieldAlert,
  AlertTriangle,
  Calendar,
  Clock,
  MapPin,
  User,
  Heart,
  Activity,
  Share2,
  CalendarClock,
  Edit3,
  CheckCircle2,
  FileText,
  History,
  Scale
} from 'lucide-react';
import { AssessmentService } from '../../services/assessmentService';

export default function AssessmentDetailModal({
  assessment,
  isOpen,
  onClose,
  onEdit,
  onUpdated,
  currentUser
}) {
  if (!isOpen || !assessment) return null;

  const [actionLoading, setActionLoading] = useState(false);
  const [showReferralForm, setShowReferralForm] = useState(false);
  const [showFollowUpForm, setShowFollowUpForm] = useState(false);
  const [referralFacility, setReferralFacility] = useState('Rampur Primary Health Centre');
  const [referralUrgency, setReferralUrgency] = useState(assessment.isEmergency ? 'emergency' : 'urgent');
  const [followUpDate, setFollowUpDate] = useState(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
  const [followUpType, setFollowUpType] = useState('Follow-up Review & Vital Signs Check');

  const handlePrint = () => {
    window.print();
  };

  const handleCreateReferral = async () => {
    setActionLoading(true);
    try {
      await AssessmentService.createReferralFromAssessment(
        assessment.id,
        {
          referralFacility,
          urgency: referralUrgency,
          reason: assessment.warningSigns?.join(', ') || 'Clinical screening alert'
        },
        currentUser
      );
      setShowReferralForm(false);
      if (onUpdated) onUpdated();
    } catch (e) {
      console.error(e);
      alert('Failed to dispatch referral: ' + e.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleScheduleFollowUp = async () => {
    setActionLoading(true);
    try {
      await AssessmentService.scheduleFollowUpFromAssessment(
        assessment.id,
        {
          scheduledDate: followUpDate,
          visitType: followUpType
        },
        currentUser
      );
      setShowFollowUpForm(false);
      if (onUpdated) onUpdated();
    } catch (e) {
      console.error(e);
      alert('Failed to schedule follow-up: ' + e.message);
    } finally {
      setActionLoading(false);
    }
  };

  const warnings = assessment.warningSigns || assessment.warningIndicators || [];
  const p = assessment.patient;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-teal-700 to-emerald-800 text-white flex items-center justify-between flex-shrink-0 print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <FileText className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Community Health Assessment Report</h2>
              <p className="text-xs text-teal-100">
                Ref ID: {assessment.id} • {assessment.assessmentDate || assessment.createdAt?.slice(0, 10)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 text-white/90 hover:text-white hover:bg-white/10 rounded-xl transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="Print or Export PDF Report"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Printable Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 print:p-0 print:space-y-4">
          
          {/* Printable Header (Visible during Print) */}
          <div className="hidden print:block border-b pb-4 mb-4">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-xl font-bold text-teal-900">OFFLINE HEALTH ASSISTANCE</h1>
                <p className="text-xs text-slate-500">Primary Health Centre Clinical Screening Report</p>
              </div>
              <div className="text-right text-xs text-slate-500">
                <p>Report ID: {assessment.id}</p>
                <p>Date: {assessment.assessmentDate || assessment.createdAt}</p>
              </div>
            </div>
          </div>

          {/* Patient Demographic Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white font-bold flex items-center justify-center text-base shadow-sm flex-shrink-0">
                {assessment.patientName?.slice(0, 2).toUpperCase() || 'PT'}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-slate-900">{assessment.patientName || p?.name}</h3>
                  <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-white border text-slate-700">
                    {assessment.patientId}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Age: {assessment.patientAge || p?.age || 'N/A'}y • Gender: {assessment.patientGender || p?.gender} • Village: {assessment.patientVillage || p?.villageHamlet || 'N/A'}
                  {assessment.isPregnant && ' • (Active Pregnancy - ANC)'}
                </p>
              </div>
            </div>

            <div className="text-right flex sm:flex-col items-center sm:items-end justify-between gap-1 text-xs text-slate-500">
              <span>Assessed By: <strong>{assessment.assessedBy}</strong></span>
              <span>Location: {assessment.location || 'Sub-Centre'}</span>
            </div>
          </div>

          {/* Classification & Risk Badge */}
          <div className={`p-4 rounded-2xl border ${
            assessment.isEmergency
              ? 'bg-rose-50 border-rose-300 text-rose-900'
              : warnings.length > 0
              ? 'bg-amber-50 border-amber-300 text-amber-900'
              : 'bg-emerald-50 border-emerald-300 text-emerald-900'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm font-extrabold">{assessment.classification || 'Assessment Recorded'}</span>
              </div>
              <span className="text-xs font-mono uppercase font-bold">
                Version {assessment.version || 1} • {assessment.syncStatus === 'synced' ? 'Cloud Synced' : 'Offline Stored'}
              </span>
            </div>

            {warnings.length > 0 && (
              <div className="mt-3 pt-2.5 border-t border-rose-200/60 text-xs">
                <span className="font-bold">Identified Warning Signs:</span>
                <ul className="list-disc pl-5 mt-1 space-y-0.5">
                  {warnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Vital Signs Table Grid */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-teal-600" />
              <span>Recorded Vital Signs & Measurements</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Blood Pressure</p>
                <p className="text-base font-extrabold text-slate-900 mt-0.5">
                  {assessment.systolicBp && assessment.diastolicBp ? `${assessment.systolicBp}/${assessment.diastolicBp} mmHg` : 'Not recorded'}
                </p>
                <p className="text-[10px] text-slate-400 mt-1">{assessment.vitalSigns?.bpPosition || 'Sitting'}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Pulse Rate</p>
                <p className="text-base font-extrabold text-slate-900 mt-0.5">
                  {assessment.pulse ? `${assessment.pulse} bpm` : 'Not recorded'}
                </p>
                <p className="text-[10px] text-slate-400 mt-1">Normal: 60-100</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">SpO2 Oxygen</p>
                <p className="text-base font-extrabold text-slate-900 mt-0.5">
                  {assessment.spo2 ? `${assessment.spo2}%` : 'Not recorded'}
                </p>
                <p className="text-[10px] text-slate-400 mt-1">Normal: ≥95%</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Temperature</p>
                <p className="text-base font-extrabold text-slate-900 mt-0.5">
                  {assessment.temperature ? `${assessment.temperature}°C` : 'Not recorded'}
                </p>
                <p className="text-[10px] text-slate-400 mt-1">Normal: 36.5 - 37.5</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Height & Weight</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5">
                  {assessment.height ? `${assessment.height} cm` : 'NR'} / {assessment.weight ? `${assessment.weight} kg` : 'NR'}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Calculated BMI</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5">
                  {assessment.bmi ? `${assessment.bmi} kg/m²` : 'NR'}
                </p>
                <p className="text-[10px] text-teal-700 font-semibold">{assessment.calculatedIndicators?.bmiCategory || ''}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Blood Glucose</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5">
                  {assessment.bloodGlucose ? `${assessment.bloodGlucose} mg/dL` : 'NR'}
                </p>
                <p className="text-[10px] text-slate-400 uppercase">{assessment.glucoseContext || 'random'}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[11px] text-slate-500">Respiratory Rate</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5">
                  {assessment.respiratoryRate ? `${assessment.respiratoryRate} /min` : 'NR'}
                </p>
              </div>
            </div>
          </div>

          {/* Clinical Observations */}
          {assessment.observations && (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <h5 className="text-xs font-bold text-slate-800">Healthcare Worker Clinical Notes:</h5>
              <p className="text-xs text-slate-600 leading-relaxed">{assessment.observations}</p>
            </div>
          )}

          {/* Audit Trail Section */}
          {assessment.auditHistory && assessment.auditHistory.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <h5 className="font-bold text-slate-500 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5" />
                <span>Audit & Revision History ({assessment.auditHistory.length})</span>
              </h5>
              <div className="space-y-1.5">
                {assessment.auditHistory.map((ah, i) => (
                  <div key={i} className="p-2 rounded-xl bg-slate-50 border text-[11px] text-slate-600 flex justify-between">
                    <span><strong>{ah.action}:</strong> {ah.reason || 'Record updated'} by {ah.performedBy}</span>
                    <span className="text-slate-400">{new Date(ah.timestamp).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Clinical Disclaimer Requirement */}
          <div className="p-3.5 rounded-xl bg-slate-100/80 border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
            <strong>Clinical Safety Disclaimer:</strong> This community health assessment is an initial primary screening record conducted by frontline community health workers using NHM/WHO guidelines. A normal screening result does not guarantee absence of disease. It does not replace a definitive medical diagnosis or qualified physician evaluation.
          </div>

          {/* Inline Action Forms for Referral / Follow-up */}
          {showReferralForm && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-300 space-y-3 animate-in fade-in">
              <h5 className="text-xs font-bold text-rose-900">Dispatch Emergency Clinical Referral</h5>
              <div className="grid sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Referral Facility</label>
                  <select
                    value={referralFacility}
                    onChange={(e) => setReferralFacility(e.target.value)}
                    className="w-full p-2 bg-white border border-rose-200 rounded-xl"
                  >
                    <option value="Rampur Primary Health Centre">Rampur Primary Health Centre</option>
                    <option value="Mandya Community Health Centre">Mandya Community Health Centre</option>
                    <option value="Mandya District Hospital">Mandya District Hospital</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Urgency</label>
                  <select
                    value={referralUrgency}
                    onChange={(e) => setReferralUrgency(e.target.value)}
                    className="w-full p-2 bg-white border border-rose-200 rounded-xl"
                  >
                    <option value="emergency">Emergency (Immediate)</option>
                    <option value="urgent">Urgent (&lt;24 hours)</option>
                    <option value="routine">Routine</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowReferralForm(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateReferral}
                  disabled={actionLoading}
                  className="px-4 py-1.5 text-xs font-bold bg-rose-600 text-white rounded-lg hover:bg-rose-700"
                >
                  {actionLoading ? 'Dispatching...' : 'Confirm Referral'}
                </button>
              </div>
            </div>
          )}

          {showFollowUpForm && (
            <div className="p-4 rounded-2xl bg-teal-50 border border-teal-300 space-y-3 animate-in fade-in">
              <h5 className="text-xs font-bold text-teal-900">Schedule Clinical Follow-up</h5>
              <div className="grid sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full p-2 bg-white border border-teal-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Visit Type</label>
                  <input
                    type="text"
                    value={followUpType}
                    onChange={(e) => setFollowUpType(e.target.value)}
                    className="w-full p-2 bg-white border border-teal-200 rounded-xl"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowFollowUpForm(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleScheduleFollowUp}
                  disabled={actionLoading}
                  className="px-4 py-1.5 text-xs font-bold bg-teal-700 text-white rounded-lg hover:bg-teal-800"
                >
                  {actionLoading ? 'Scheduling...' : 'Save Follow-up'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 px-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-wrap gap-2 flex-shrink-0 print:hidden">
          <div className="flex items-center gap-2">
            {!assessment.referralId && !showReferralForm && (
              <button
                onClick={() => setShowReferralForm(true)}
                className="px-3.5 py-2 bg-rose-50 text-rose-700 border border-rose-300 hover:bg-rose-100 rounded-xl text-xs font-bold flex items-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Create Referral</span>
              </button>
            )}

            {!assessment.followUpId && !showFollowUpForm && (
              <button
                onClick={() => setShowFollowUpForm(true)}
                className="px-3.5 py-2 bg-teal-50 text-teal-800 border border-teal-300 hover:bg-teal-100 rounded-xl text-xs font-bold flex items-center gap-1.5"
              >
                <CalendarClock className="w-3.5 h-3.5" />
                <span>Schedule Follow-up</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                if (onEdit) onEdit(assessment);
              }}
              className="px-3.5 py-2 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Record</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
