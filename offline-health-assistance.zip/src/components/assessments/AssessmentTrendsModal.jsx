import React, { useState, useEffect } from 'react';
import { AssessmentService } from '../../services/assessmentService';
import {
  X,
  TrendingUp,
  Activity,
  Heart,
  Scale,
  Calendar,
  AlertTriangle,
  Clock
} from 'lucide-react';

export default function AssessmentTrendsModal({
  patientId,
  patientName,
  isOpen,
  onClose
}) {
  if (!isOpen || !patientId) return null;

  const [history, setHistory] = useState({ records: [], bpTrends: [], glucoseTrends: [], bmiTrends: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    AssessmentService.getPatientHistory(patientId)
      .then(data => setHistory(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [patientId]);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-teal-700 to-emerald-800 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <TrendingUp className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-base font-bold">Longitudinal Vitals & Clinical Trends</h2>
              <p className="text-xs text-teal-100">Patient: {patientName || patientId} • Historical Trajectory</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-white/80 hover:text-white rounded-xl">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {loading ? (
            <div className="text-center py-12 text-slate-400 text-xs font-semibold">
              Loading historical assessment records...
            </div>
          ) : history.records.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No previous assessment records found for this patient.
            </div>
          ) : (
            <>
              {/* Blood Pressure Progression Card */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Heart className="w-4 h-4 text-teal-600" />
                    <span>Blood Pressure Trajectory (mmHg)</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">{history.bpTrends.length} readings</span>
                </div>

                {history.bpTrends.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    {history.bpTrends.map((bp, i) => (
                      <div key={i} className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                        <span className="text-[10px] text-slate-400 block">{bp.date}</span>
                        <span className={`text-sm font-extrabold block mt-0.5 ${
                          bp.systolic >= 140 || bp.diastolic >= 90 ? 'text-rose-600' : 'text-slate-900'
                        }`}>
                          {bp.systolic}/{bp.diastolic}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {bp.systolic >= 140 || bp.diastolic >= 90 ? 'Elevated' : 'Normal'}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">No blood pressure history recorded.</p>
                )}
              </div>

              {/* Glycemic History Card */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Activity className="w-4 h-4 text-teal-600" />
                    <span>Blood Glucose Progression (mg/dL)</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">{history.glucoseTrends.length} readings</span>
                </div>

                {history.glucoseTrends.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    {history.glucoseTrends.map((g, i) => (
                      <div key={i} className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                        <span className="text-[10px] text-slate-400 block">{g.date}</span>
                        <span className={`text-sm font-extrabold block mt-0.5 ${
                          g.glucose >= 200 || g.glucose < 70 ? 'text-rose-600' : 'text-slate-900'
                        }`}>
                          {g.glucose} mg/dL
                        </span>
                        <span className="text-[10px] text-slate-500 uppercase">{g.context}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">No blood glucose history recorded.</p>
                )}
              </div>

              {/* Chronological Table of Assessments */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Chronological Assessment Registry
                </h4>
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
                  <div className="grid grid-cols-12 bg-slate-100 p-3 font-bold text-slate-600 border-b">
                    <div className="col-span-3">Date</div>
                    <div className="col-span-3">Type</div>
                    <div className="col-span-3">BP / Glucose</div>
                    <div className="col-span-3 text-right">Status</div>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                    {history.records.map((r) => (
                      <div key={r.id} className="grid grid-cols-12 p-3 items-center hover:bg-slate-50">
                        <div className="col-span-3 font-semibold text-slate-800">
                          {r.assessmentDate || r.createdAt?.slice(0, 10)}
                        </div>
                        <div className="col-span-3 text-slate-600 truncate">{r.assessmentType}</div>
                        <div className="col-span-3 font-mono text-slate-700">
                          {r.systolicBp && r.diastolicBp ? `${r.systolicBp}/${r.diastolicBp}` : '-'} | {r.bloodGlucose ? `${r.bloodGlucose}mg` : '-'}
                        </div>
                        <div className="col-span-3 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            r.isEmergency ? 'bg-rose-100 text-rose-800' : r.warningSigns?.length > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {r.status || 'recorded'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-900"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
