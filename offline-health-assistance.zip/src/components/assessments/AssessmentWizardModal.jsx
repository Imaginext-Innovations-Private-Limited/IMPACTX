import React, { useState, useEffect, useMemo } from 'react';
import { db } from '../../db/db';
import { AssessmentService } from '../../services/assessmentService';
import { ClinicalCalculators } from '../../utils/clinicalCalculators';
import {
  X,
  Search,
  User,
  Heart,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  ChevronRight,
  ChevronLeft,
  Stethoscope,
  Baby,
  HeartHandshake,
  ShieldAlert,
  Flame,
  Wind,
  Plus,
  Scale,
  Sparkles,
  Info
} from 'lucide-react';

export default function AssessmentWizardModal({ isOpen, onClose, onAssessmentCreated, initialPatient = null, currentUser }) {
  if (!isOpen) return null;

  // Wizard Steps: 1: Patient, 2: Info & Vitals, 3: Screenings, 4: Observations & Review
  const [step, setStep] = useState(initialPatient ? 2 : 1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Step 1: Patient Search
  const [patients, setPatients] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(initialPatient || null);

  // Step 2 & 3 Form States
  const [formData, setFormData] = useState({
    assessmentType: initialPatient?.isPregnant ? 'Maternal Healthcare' : initialPatient?.age < 5 ? 'Child Healthcare' : 'General Health Screening',
    assessmentDate: new Date().toISOString().slice(0, 10),
    assessmentTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    location: initialPatient?.villageHamlet || 'Community Field Visit',

    // Vitals
    systolicBp: '',
    diastolicBp: '',
    repeatSystolicBp: '',
    repeatDiastolicBp: '',
    bpPosition: 'Sitting',
    bpArm: 'Right Arm',
    hasRepeatBp: false,

    pulse: '',
    temperature: '',
    respiratoryRate: '',
    spo2: '',
    height: '',
    weight: '',
    bloodGlucose: '',
    glucoseContext: 'random',
    glucoseMethod: 'Capillary Strip',
    muacCm: '',

    // Screenings
    symptoms: [],
    diabetesAnswers: {
      physicalActivity: 'moderate',
      familyHistory: 'none',
      waistCm: ''
    },
    lifestyle: {
      tobaccoUse: 'no',
      alcoholUse: 'no',
      sleepHours: '7-8 hours',
      dietQuality: 'balanced'
    },
    maternalANC: {
      gestationalWeeks: '',
      fundalHeightCm: '',
      fetalHeartRate: '',
      urineProtein: 'Nil'
    },

    // Review & Notes
    observations: '',
    notes: '',
    triggerReferral: false,
    referralFacility: 'Rampur Primary Health Centre',
    referralUrgency: 'urgent',
    referralReason: '',
    scheduleFollowUp: false,
    followUpDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    followUpVisitType: 'Repeat Blood Pressure & Vitals Review'
  });

  // Load patients on mount
  useEffect(() => {
    db.patients
      .filter(p => !p.isDeleted)
      .toArray()
      .then(setPatients)
      .catch(console.error);
  }, []);

  // Filtered Patient Search
  const filteredPatients = useMemo(() => {
    if (!searchQuery.trim()) return patients.slice(0, 12);
    const q = searchQuery.toLowerCase().trim();
    return patients.filter(p =>
      (p.name && p.name.toLowerCase().includes(q)) ||
      (p.patientId && p.patientId.toLowerCase().includes(q)) ||
      (p.villageHamlet && p.villageHamlet.toLowerCase().includes(q)) ||
      (p.contactNumber && p.contactNumber.includes(q))
    ).slice(0, 12);
  }, [patients, searchQuery]);

  // Real-time BMI Calculation
  const realTimeBmi = useMemo(() => {
    return ClinicalCalculators.calculateBmi(
      formData.height,
      formData.weight,
      selectedPatient ? { age: selectedPatient.age, isPregnant: selectedPatient.isPregnant } : {}
    );
  }, [formData.height, formData.weight, selectedPatient]);

  // Real-time Blood Pressure Classification
  const realTimeBp = useMemo(() => {
    return ClinicalCalculators.classifyBloodPressure(
      formData.systolicBp,
      formData.diastolicBp,
      selectedPatient ? { age: selectedPatient.age, isPregnant: selectedPatient.isPregnant } : {}
    );
  }, [formData.systolicBp, formData.diastolicBp, selectedPatient]);

  // Real-time Blood Glucose Classification
  const realTimeGlucose = useMemo(() => {
    return ClinicalCalculators.classifyBloodGlucose(
      formData.bloodGlucose,
      formData.glucoseContext
    );
  }, [formData.bloodGlucose, formData.glucoseContext]);

  // Real-time IDRS Score
  const realTimeIdrs = useMemo(() => {
    if (!selectedPatient) return null;
    return ClinicalCalculators.calculateIdrs(
      {
        ...formData.diabetesAnswers,
        bmi: realTimeBmi.bmi
      },
      selectedPatient
    );
  }, [formData.diabetesAnswers, realTimeBmi.bmi, selectedPatient]);

  // Real-time Overall Risk Evaluator
  const realTimeRisk = useMemo(() => {
    return ClinicalCalculators.evaluateAssessment(
      {
        systolicBp: formData.systolicBp,
        diastolicBp: formData.diastolicBp,
        bloodGlucose: formData.bloodGlucose,
        glucoseContext: formData.glucoseContext,
        respiratoryRate: formData.respiratoryRate,
        spo2: formData.spo2,
        temperature: formData.temperature,
        muacCm: formData.muacCm,
        symptoms: formData.symptoms
      },
      selectedPatient ? { age: selectedPatient.age, isPregnant: selectedPatient.isPregnant } : {}
    );
  }, [formData, selectedPatient]);

  const handleSelectPatient = (patient) => {
    setSelectedPatient(patient);
    setFormData(prev => ({
      ...prev,
      assessmentType: patient.isPregnant ? 'Maternal Healthcare' : patient.age < 5 ? 'Child Healthcare' : 'General Health Screening',
      location: patient.villageHamlet || prev.location
    }));
    setStep(2);
  };

  const handleSymptomToggle = (symptomId) => {
    setFormData(prev => {
      const current = prev.symptoms || [];
      const updated = current.includes(symptomId)
        ? current.filter(s => s !== symptomId)
        : [...current, symptomId];
      return { ...prev, symptoms: updated };
    });
  };

  const handleSubmit = async () => {
    if (!selectedPatient) {
      setError('Please select a patient before saving the assessment.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const repeatBpList = [];
      if (formData.hasRepeatBp && formData.repeatSystolicBp && formData.repeatDiastolicBp) {
        repeatBpList.push({
          systolic: parseInt(formData.repeatSystolicBp, 10),
          diastolic: parseInt(formData.repeatDiastolicBp, 10),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
      }

      // Create Assessment Payload
      const assessmentPayload = {
        patientId: selectedPatient.id,
        assessmentType: formData.assessmentType,
        assessmentDate: formData.assessmentDate,
        assessmentTime: formData.assessmentTime,
        location: formData.location,
        systolicBp: formData.systolicBp,
        diastolicBp: formData.diastolicBp,
        repeatBp: repeatBpList,
        bpPosition: formData.bpPosition,
        bpArm: formData.bpArm,
        pulse: formData.pulse,
        temperature: formData.temperature,
        respiratoryRate: formData.respiratoryRate,
        spo2: formData.spo2,
        height: formData.height,
        weight: formData.weight,
        bloodGlucose: formData.bloodGlucose,
        glucoseContext: formData.glucoseContext,
        glucoseMethod: formData.glucoseMethod,
        muacCm: formData.muacCm,
        symptoms: formData.symptoms,
        screeningResponses: {
          diabetes: formData.diabetesAnswers,
          lifestyle: formData.lifestyle,
          maternal: selectedPatient.isPregnant ? formData.maternalANC : null
        },
        observations: formData.observations,
        notes: formData.notes,
        isAncVisit: Boolean(selectedPatient.isPregnant)
      };

      const created = await AssessmentService.createAssessment(assessmentPayload, currentUser);

      // Handle Immediate Referral if requested or emergency
      if (formData.triggerReferral || (realTimeRisk.isEmergency && formData.referralReason)) {
        await AssessmentService.createReferralFromAssessment(
          created.id,
          {
            referralFacility: formData.referralFacility,
            urgency: formData.referralUrgency || (realTimeRisk.isEmergency ? 'emergency' : 'urgent'),
            reason: formData.referralReason || created.warningSigns?.join(', ') || 'Screening Alert'
          },
          currentUser
        );
      }

      // Handle Immediate Follow-up if scheduled
      if (formData.scheduleFollowUp && formData.followUpDate) {
        await AssessmentService.scheduleFollowUpFromAssessment(
          created.id,
          {
            scheduledDate: formData.followUpDate,
            visitType: formData.followUpVisitType,
            priority: created.warningSigns?.length > 0 ? 'urgent' : 'routine'
          },
          currentUser
        );
      }

      onAssessmentCreated(created);
      onClose();
    } catch (err) {
      console.error('[AssessmentWizard] Failed to create assessment:', err);
      setError(err.message || 'Failed to record health assessment.');
    } finally {
      setLoading(false);
    }
  };

  const symptomList = [
    { id: 'fever', label: 'Fever' },
    { id: 'cough', label: 'Cough' },
    { id: 'breathing_difficulty', label: 'Shortness of Breath' },
    { id: 'chest_pain', label: 'Chest Discomfort / Pain' },
    { id: 'headache', label: 'Severe Headache' },
    { id: 'dizziness', label: 'Dizziness / Syncope' },
    { id: 'vomiting', label: 'Persistent Vomiting' },
    { id: 'diarrhea', label: 'Diarrhea / Dehydration' },
    { id: 'fatigue', label: 'Excessive Fatigue' },
    { id: 'stiff_neck', label: 'Neck Stiffness' },
    { id: 'blurred_vision', label: 'Blurred Vision' },
    { id: 'vaginal_bleeding', label: 'Vaginal Bleeding (Maternal)' }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Activity className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">New Community Health Assessment</h2>
              <p className="text-xs text-teal-100">
                Step {step} of 4 • {step === 1 ? 'Patient Selection' : step === 2 ? 'Clinical Vitals' : step === 3 ? 'Targeted Screenings' : 'Action Plan & Review'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator Progress Bar */}
        <div className="grid grid-cols-4 bg-slate-100 text-xs font-semibold border-b border-slate-200 flex-shrink-0">
          <button
            onClick={() => setStep(1)}
            className={`py-3 px-4 text-center transition-colors flex items-center justify-center gap-1.5 ${
              step === 1 ? 'bg-white text-teal-800 border-b-2 border-teal-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>1. Patient</span>
            {selectedPatient && <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />}
          </button>
          <button
            onClick={() => selectedPatient && setStep(2)}
            disabled={!selectedPatient}
            className={`py-3 px-4 text-center transition-colors flex items-center justify-center gap-1.5 ${
              step === 2 ? 'bg-white text-teal-800 border-b-2 border-teal-600 font-bold' : 'text-slate-500 disabled:opacity-50'
            }`}
          >
            <span>2. Vital Signs</span>
          </button>
          <button
            onClick={() => selectedPatient && setStep(3)}
            disabled={!selectedPatient}
            className={`py-3 px-4 text-center transition-colors flex items-center justify-center gap-1.5 ${
              step === 3 ? 'bg-white text-teal-800 border-b-2 border-teal-600 font-bold' : 'text-slate-500 disabled:opacity-50'
            }`}
          >
            <span>3. Screenings</span>
          </button>
          <button
            onClick={() => selectedPatient && setStep(4)}
            disabled={!selectedPatient}
            className={`py-3 px-4 text-center transition-colors flex items-center justify-center gap-1.5 ${
              step === 4 ? 'bg-white text-teal-800 border-b-2 border-teal-600 font-bold' : 'text-slate-500 disabled:opacity-50'
            }`}
          >
            <span>4. Review & Save</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {error && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: PATIENT SELECTION */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Select Patient for Assessment</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Search local village registry. Assessments will link to existing medical records with zero data duplication.
                </p>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by Name, ID (PAT-RAM-...), Village Hamlet, or Phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all placeholder:text-slate-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[45vh] overflow-y-auto pr-1">
                {filteredPatients.map(p => {
                  const isSelected = selectedPatient?.id === p.id;
                  return (
                    <div
                      key={p.id}
                      onClick={() => handleSelectPatient(p)}
                      className={`p-4 rounded-2xl border text-left cursor-pointer transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                          : 'border-slate-200 hover:border-teal-400 bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900">{p.name}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-100 rounded text-slate-600">
                              {p.patientId || p.id}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">
                            {p.age}y • {p.gender} • {p.villageHamlet || 'Village'}
                          </p>
                        </div>
                        {p.isPregnant ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-100 text-pink-800">
                            Maternal ANC
                          </span>
                        ) : p.age < 5 ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                            Child &lt;5y
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                            General
                          </span>
                        )}
                      </div>

                      {p.allergies && p.allergies !== 'None' && (
                        <div className="mt-2 text-[11px] text-amber-700 bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
                          Allergies: {p.allergies}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: METADATA & VITAL SIGNS */}
          {step === 2 && selectedPatient && (
            <div className="space-y-6">
              {/* Selected Patient Banner */}
              <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200 flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-600 text-white font-bold flex items-center justify-center text-sm">
                    {selectedPatient.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900">{selectedPatient.name}</span>
                      <span className="text-xs text-slate-500">({selectedPatient.patientId})</span>
                    </div>
                    <p className="text-xs text-slate-600">
                      {selectedPatient.age} years • {selectedPatient.gender} • {selectedPatient.villageHamlet}
                      {selectedPatient.isPregnant && ' • (Active Pregnancy)'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs font-bold text-teal-700 hover:underline"
                >
                  Change Patient
                </button>
              </div>

              {/* Assessment Context Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Assessment Type</label>
                  <select
                    value={formData.assessmentType}
                    onChange={(e) => setFormData({ ...formData, assessmentType: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                  >
                    <option value="General Health Screening">General Health Screening</option>
                    <option value="Hypertension & NCD Screening">Hypertension & NCD Screening</option>
                    <option value="Maternal Healthcare">Maternal Healthcare (ANC)</option>
                    <option value="Child Healthcare">Child Healthcare & Wellness</option>
                    <option value="Respiratory Screening">Respiratory Screening</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Date</label>
                  <input
                    type="date"
                    value={formData.assessmentDate}
                    onChange={(e) => setFormData({ ...formData, assessmentDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Location / Village</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="e.g. Rampur Hamlet 2"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              {/* Vital Signs Grid */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Heart className="w-4 h-4 text-teal-600" />
                  <span>Cardiovascular & Vital Signs</span>
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Systolic BP <span className="text-[10px] text-slate-400">(mmHg)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 120"
                      value={formData.systolicBp}
                      onChange={(e) => setFormData({ ...formData, systolicBp: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Diastolic BP <span className="text-[10px] text-slate-400">(mmHg)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 80"
                      value={formData.diastolicBp}
                      onChange={(e) => setFormData({ ...formData, diastolicBp: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Pulse Rate <span className="text-[10px] text-slate-400">(bpm)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 72"
                      value={formData.pulse}
                      onChange={(e) => setFormData({ ...formData, pulse: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      SpO2 Saturation <span className="text-[10px] text-slate-400">(%)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 98"
                      value={formData.spo2}
                      onChange={(e) => setFormData({ ...formData, spo2: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                </div>

                {/* Real-time BP Classification Notice */}
                {realTimeBp.stage !== 'Unrecorded' && (
                  <div className={`p-3 rounded-xl border text-xs flex items-center justify-between ${realTimeBp.badge}`}>
                    <span><strong>Blood Pressure:</strong> {realTimeBp.stage}</span>
                    <span className="text-[11px] opacity-90">{realTimeBp.recommendation}</span>
                  </div>
                )}
              </div>

              {/* Anthropometry & Glucose */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-teal-600" />
                  <span>Anthropometry & Glycemic Screening</span>
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Height <span className="text-[10px] text-slate-400">(cm)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 165"
                      value={formData.height}
                      onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Weight <span className="text-[10px] text-slate-400">(kg)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 62"
                      value={formData.weight}
                      onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Temperature <span className="text-[10px] text-slate-400">(°C)</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="e.g. 37.0"
                      value={formData.temperature}
                      onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Respiratory Rate <span className="text-[10px] text-slate-400">(breaths/min)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 16"
                      value={formData.respiratoryRate}
                      onChange={(e) => setFormData({ ...formData, respiratoryRate: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    />
                  </div>
                </div>

                {/* Blood Glucose Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Blood Glucose <span className="text-[10px] text-slate-400">(mg/dL)</span>
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 110"
                      value={formData.bloodGlucose}
                      onChange={(e) => setFormData({ ...formData, bloodGlucose: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Measurement Context</label>
                    <select
                      value={formData.glucoseContext}
                      onChange={(e) => setFormData({ ...formData, glucoseContext: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    >
                      <option value="random">Random Blood Sugar (RBS)</option>
                      <option value="fasting">Fasting Blood Sugar (FBS, ≥8 hrs)</option>
                      <option value="post_meal">Post-Meal / Postprandial (2 hrs post-food)</option>
                    </select>
                  </div>
                </div>

                {/* Automatic BMI Calculation Banner */}
                {realTimeBmi.isValid && (
                  <div className={`p-4 rounded-2xl border ${realTimeBmi.border} ${realTimeBmi.bg} space-y-1`}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800">
                        Calculated BMI: <span className="text-base text-slate-900 font-extrabold">
                          {realTimeBmi.bmi?.toFixed ? realTimeBmi.bmi.toFixed(1) : realTimeBmi.bmi} kg/m²
                        </span>
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${realTimeBmi.color} bg-white shadow-xs`}>
                        {realTimeBmi.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{realTimeBmi.interpretation}</p>
                    <p className="text-[10px] text-slate-400 pt-1 border-t border-slate-200/50">
                      Formula: {realTimeBmi.formula} • Source: {realTimeBmi.source}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 3: TARGETED SCREENINGS */}
          {step === 3 && selectedPatient && (
            <div className="space-y-6">
              {/* Symptoms Checklist */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    A. Current Symptoms & Warning Signs
                  </h4>
                  <span className="text-[11px] text-slate-400">Select all that apply</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {symptomList.map(s => {
                    const isChecked = formData.symptoms.includes(s.id);
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => handleSymptomToggle(s.id)}
                        className={`p-2.5 rounded-xl border text-xs font-medium text-left transition-all flex items-center justify-between ${
                          isChecked
                            ? 'bg-teal-50 border-teal-500 text-teal-900 font-semibold shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <span>{s.label}</span>
                        {isChecked && <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Diabetes Risk Screening (IDRS) */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    B. Diabetes Risk Assessment (Indian Diabetes Risk Score - IDRS)
                  </h4>
                  {realTimeIdrs && (
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${realTimeIdrs.badge}`}>
                      IDRS: {realTimeIdrs.score}/100 ({realTimeIdrs.riskTier})
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Physical Activity Level</label>
                    <select
                      value={formData.diabetesAnswers.physicalActivity}
                      onChange={(e) => setFormData({
                        ...formData,
                        diabetesAnswers: { ...formData.diabetesAnswers, physicalActivity: e.target.value }
                      })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    >
                      <option value="strenuous">Vigorous Exercise / Heavy Labor (0 pts)</option>
                      <option value="moderate">Moderate Physical Activity / Walking (10 pts)</option>
                      <option value="sedentary">Sedentary / Minimal Physical Activity (20 pts)</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Family History of Diabetes</label>
                    <select
                      value={formData.diabetesAnswers.familyHistory}
                      onChange={(e) => setFormData({
                        ...formData,
                        diabetesAnswers: { ...formData.diabetesAnswers, familyHistory: e.target.value }
                      })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    >
                      <option value="none">No Parental History (0 pts)</option>
                      <option value="one_parent">One Parent Diabetic (10 pts)</option>
                      <option value="both_parents">Both Parents Diabetic (20 pts)</option>
                    </select>
                  </div>
                </div>

                {realTimeIdrs && (
                  <p className="text-xs text-slate-600 bg-white p-2.5 rounded-xl border border-slate-200/60">
                    {realTimeIdrs.action}
                  </p>
                )}
              </div>

              {/* Child MUAC Check (If Under 5) */}
              {selectedPatient.age < 5 && (
                <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-2">
                  <h4 className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                    <Baby className="w-4 h-4 text-indigo-700" />
                    <span>Pediatric Nutrition & MUAC Tape Assessment</span>
                  </h4>
                  <div className="max-w-xs">
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Mid-Upper Arm Circumference (MUAC in cm)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="e.g. 12.8"
                      value={formData.muacCm}
                      onChange={(e) => setFormData({ ...formData, muacCm: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-indigo-200 rounded-xl"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: REVIEW & ACTION PLAN */}
          {step === 4 && selectedPatient && (
            <div className="space-y-6">
              {/* Identified Alerts & Clinical Triage */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Clinical Findings & Triage Summary
                </h4>

                <div className={`p-4 rounded-2xl border ${realTimeRisk.overallBadge} space-y-2`}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-extrabold flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      <span>{realTimeRisk.classification}</span>
                    </span>
                    <span className="text-xs uppercase font-mono">Status: Ready to Save</span>
                  </div>

                  {realTimeRisk.warnings.length > 0 ? (
                    <div className="pt-2 border-t border-slate-200/60 space-y-1">
                      <p className="text-xs font-bold text-rose-800">Active Warning Indicators:</p>
                      <ul className="list-disc pl-5 text-xs space-y-0.5 text-rose-900">
                        {realTimeRisk.warnings.map((w, idx) => (
                          <li key={idx}>{w}</li>
                        ))}
                      </ul>
                    </div>
                  ) : (
                    <p className="text-xs text-emerald-800 pt-1">
                      All screening parameters are within standard acceptable limits. Continue periodic wellness surveillance.
                    </p>
                  )}
                </div>
              </div>

              {/* Clinical Notes & Observations */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 block">
                  Healthcare Worker Observations & Recommendations
                </label>
                <textarea
                  rows="3"
                  value={formData.observations}
                  onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
                  placeholder="Record clinical impressions, dietary counseling provided, medication adherence..."
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              {/* Action Plan: Referral & Follow-up Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                {/* 1-Click Referral Option */}
                <div className={`p-4 rounded-2xl border transition-all ${
                  formData.triggerReferral ? 'bg-rose-50 border-rose-300' : 'bg-slate-50 border-slate-200'
                }`}>
                  <label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={formData.triggerReferral}
                      onChange={(e) => setFormData({ ...formData, triggerReferral: e.target.checked })}
                      className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs font-bold text-slate-900">Dispatch Emergency Clinical Referral</span>
                  </label>

                  {formData.triggerReferral && (
                    <div className="space-y-2 mt-3 pt-2 border-t border-rose-200 text-xs">
                      <div>
                        <label className="font-semibold text-slate-700 block mb-1">Referral Facility</label>
                        <select
                          value={formData.referralFacility}
                          onChange={(e) => setFormData({ ...formData, referralFacility: e.target.value })}
                          className="w-full p-2 bg-white border border-rose-200 rounded-xl"
                        >
                          <option value="Rampur Primary Health Centre">Rampur Primary Health Centre</option>
                          <option value="Mandya Community Health Centre">Mandya Community Health Centre</option>
                          <option value="Mandya District Hospital">Mandya District Hospital</option>
                        </select>
                      </div>
                      <div>
                        <label className="font-semibold text-slate-700 block mb-1">Urgency</label>
                        <select
                          value={formData.referralUrgency}
                          onChange={(e) => setFormData({ ...formData, referralUrgency: e.target.value })}
                          className="w-full p-2 bg-white border border-rose-200 rounded-xl"
                        >
                          <option value="emergency">Emergency (Immediate Escalation)</option>
                          <option value="urgent">Urgent (&lt;24 hours)</option>
                          <option value="routine">Routine Referral</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* 1-Click Follow-up Schedule Option */}
                <div className={`p-4 rounded-2xl border transition-all ${
                  formData.scheduleFollowUp ? 'bg-teal-50 border-teal-300' : 'bg-slate-50 border-slate-200'
                }`}>
                  <label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={formData.scheduleFollowUp}
                      onChange={(e) => setFormData({ ...formData, scheduleFollowUp: e.target.checked })}
                      className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
                    />
                    <span className="text-xs font-bold text-slate-900">Schedule Follow-up Visit</span>
                  </label>

                  {formData.scheduleFollowUp && (
                    <div className="space-y-2 mt-3 pt-2 border-t border-teal-200 text-xs">
                      <div>
                        <label className="font-semibold text-slate-700 block mb-1">Scheduled Date</label>
                        <input
                          type="date"
                          value={formData.followUpDate}
                          onChange={(e) => setFormData({ ...formData, followUpDate: e.target.value })}
                          className="w-full p-2 bg-white border border-teal-200 rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="font-semibold text-slate-700 block mb-1">Follow-up Reason</label>
                        <input
                          type="text"
                          value={formData.followUpVisitType}
                          onChange={(e) => setFormData({ ...formData, followUpVisitType: e.target.value })}
                          className="w-full p-2 bg-white border border-teal-200 rounded-xl"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 px-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-shrink-0">
          <div>
            {step > 1 && (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-200 flex items-center gap-1.5 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
            >
              Cancel
            </button>

            {step < 4 ? (
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                disabled={!selectedPatient}
                className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
              >
                <span>Continue</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="px-6 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-teal-700/20 transition-all disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{loading ? 'Saving Assessment...' : 'Complete & Save Assessment'}</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
