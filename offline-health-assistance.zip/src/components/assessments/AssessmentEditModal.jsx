import React, { useState } from 'react';
import { AssessmentService } from '../../services/assessmentService';
import {
  X,
  Edit3,
  CheckCircle2,
  AlertTriangle,
  History
} from 'lucide-react';

export default function AssessmentEditModal({
  assessment,
  isOpen,
  onClose,
  onSaved,
  currentUser
}) {
  if (!isOpen || !assessment) return null;

  const [formData, setFormData] = useState({
    systolicBp: assessment.systolicBp || '',
    diastolicBp: assessment.diastolicBp || '',
    pulse: assessment.pulse || '',
    spo2: assessment.spo2 || '',
    temperature: assessment.temperature || '',
    respiratoryRate: assessment.respiratoryRate || '',
    height: assessment.height || '',
    weight: assessment.weight || '',
    bloodGlucose: assessment.bloodGlucose || '',
    glucoseContext: assessment.glucoseContext || 'random',
    observations: assessment.observations || assessment.notes || '',
    auditReason: ''
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.auditReason.trim()) {
      setError('An audit reason is required when modifying clinical records to preserve audit integrity.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const updates = {
        systolicBp: parseInt(formData.systolicBp, 10) || null,
        diastolicBp: parseInt(formData.diastolicBp, 10) || null,
        pulse: parseInt(formData.pulse, 10) || null,
        spo2: parseInt(formData.spo2, 10) || null,
        temperature: parseFloat(formData.temperature) || null,
        respiratoryRate: parseInt(formData.respiratoryRate, 10) || null,
        height: parseFloat(formData.height) || null,
        weight: parseFloat(formData.weight) || null,
        bloodGlucose: parseFloat(formData.bloodGlucose) || null,
        glucoseContext: formData.glucoseContext,
        observations: formData.observations,
        notes: formData.observations
      };

      const updated = await AssessmentService.updateAssessment(
        assessment.id,
        updates,
        formData.auditReason,
        currentUser
      );

      if (onSaved) onSaved(updated);
      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to update assessment.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-5 bg-teal-800 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <Edit3 className="w-5 h-5 text-emerald-300" />
            <div>
              <h2 className="text-base font-bold">Edit Clinical Assessment (Audit Logged)</h2>
              <p className="text-xs text-teal-200">Assessment ID: {assessment.id} • Patient: {assessment.patientName || assessment.patientId}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-white/80 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
            <strong>Audit Requirement:</strong> In compliance with clinical data protection guidelines, all modifications are permanently timestamped and attributed in the clinical audit history without erasing prior readings.
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Systolic BP (mmHg)</label>
              <input
                type="number"
                value={formData.systolicBp}
                onChange={(e) => setFormData({ ...formData, systolicBp: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Diastolic BP (mmHg)</label>
              <input
                type="number"
                value={formData.diastolicBp}
                onChange={(e) => setFormData({ ...formData, diastolicBp: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Pulse Rate (bpm)</label>
              <input
                type="number"
                value={formData.pulse}
                onChange={(e) => setFormData({ ...formData, pulse: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">SpO2 (%)</label>
              <input
                type="number"
                value={formData.spo2}
                onChange={(e) => setFormData({ ...formData, spo2: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Height (cm)</label>
              <input
                type="number"
                value={formData.height}
                onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Weight (kg)</label>
              <input
                type="number"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Blood Glucose (mg/dL)</label>
              <input
                type="number"
                value={formData.bloodGlucose}
                onChange={(e) => setFormData({ ...formData, bloodGlucose: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Glucose Context</label>
              <select
                value={formData.glucoseContext}
                onChange={(e) => setFormData({ ...formData, glucoseContext: e.target.value })}
                className="w-full p-2 text-xs bg-slate-50 border rounded-xl"
              >
                <option value="random">Random</option>
                <option value="fasting">Fasting</option>
                <option value="post_meal">Post-Meal</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Clinical Observations & Notes</label>
            <textarea
              rows="2"
              value={formData.observations}
              onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
              className="w-full p-2.5 text-xs bg-slate-50 border rounded-xl"
            />
          </div>

          {/* Audit Reason Input (Mandatory) */}
          <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200">
            <label className="text-xs font-bold text-teal-900 block mb-1 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-teal-700" />
              <span>Mandatory Audit Reason for Edit *</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Corrected systolic BP transcription error from paper field register"
              value={formData.auditReason}
              onChange={(e) => setFormData({ ...formData, auditReason: e.target.value })}
              className="w-full p-2 text-xs bg-white border border-teal-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/30"
            />
            <p className="text-[10px] text-teal-700 mt-1">This explanation will be permanently recorded in the audit trail.</p>
          </div>

          <div className="pt-3 border-t flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold bg-teal-700 text-white hover:bg-teal-800 rounded-xl shadow-sm disabled:opacity-50 flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{loading ? 'Saving...' : 'Save Audit Revision'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
