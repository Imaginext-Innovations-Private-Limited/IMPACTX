import Dexie from 'dexie';
import { getOrCreateDeviceId } from '../utils/crypto';

export class OfflineHealthDB extends Dexie {
  constructor() {
    super('OfflineHealthDB');

    // Version 1: Initial schema
    this.version(1).stores({
      users: 'id, username, role, village, district, createdAt',
      patients: 'id, patientId, name, gender, age, contactNumber, abhaId, villageHamlet, bloodGroup, riskLevel, category, syncStatus, isDeleted, createdAt, updatedAt',
      assessments: 'id, patientId, systolicBp, diastolicBp, pulse, spo2, assessedBy, syncStatus, createdAt',
      maternalRecords: 'id, patientId, lmp, edd, trimester, syncStatus, createdAt',
      childRecords: 'id, patientId, motherId, birthWeight, syncStatus, createdAt',
      immunizations: 'id, childId, patientId, vaccineName, status, dueDate, syncStatus',
      chronicConditions: 'id, patientId, conditionName, severity, syncStatus',
      referrals: 'id, patientId, urgency, status, referralFacility, syncStatus, createdAt',
      reminders: 'id, patientId, reminderType, scheduledDate, isCompleted, syncStatus',
      knowledgeArticles: 'id, category, title, language, lastUpdated',
      syncQueue: '++id, entity, entityId, operation, status, createdAt',
      auditLogs: '++id, entity, entityId, action, performedBy, timestamp'
    });

    // Version 3: AI Healthcare Assistant, Guidelines & Multilingual Translation Caches
    this.version(3).stores({
      users: 'id, username, role, village, district, createdAt',
      patients: 'id, patientId, name, gender, age, contactNumber, abhaId, villageHamlet, bloodGroup, riskLevel, category, syncStatus, isDeleted, version, createdAt, updatedAt, deviceId',
      healthAssessments: 'id, patientId, systolicBp, diastolicBp, pulse, spo2, bloodGlucose, assessedBy, syncStatus, version, createdAt, deviceId',
      maternalRecords: 'id, patientId, lmp, edd, trimester, status, syncStatus, version, createdAt, deviceId',
      antenatalVisits: 'id, patientId, maternalRecordId, visitNumber, systolicBp, diastolicBp, weightKg, syncStatus, version, createdAt, deviceId',
      childRecords: 'id, patientId, motherId, birthWeight, syncStatus, version, createdAt, deviceId',
      growthRecords: 'id, childId, patientId, ageMonths, weightKg, heightCm, muacCm, syncStatus, version, createdAt, deviceId',
      immunizations: 'id, childId, patientId, vaccineName, status, dueDate, syncStatus, version, createdAt, deviceId',
      chronicConditions: 'id, patientId, conditionName, severity, syncStatus, version, createdAt, deviceId',
      referrals: 'id, patientId, urgency, status, referralFacility, syncStatus, version, createdAt, deviceId',
      followUps: 'id, patientId, scheduledDate, visitType, priority, isCompleted, syncStatus, version, createdAt, deviceId',
      knowledgeArticles: 'id, category, title, language, lastUpdated',
      syncQueue: '++id, entity, entityId, operation, status, retryCount, idempotencyKey, createdAt, lastAttempt',
      syncLogs: '++id, status, itemsSynced, itemsFailed, durationMs, timestamp',
      auditLogs: '++id, entity, entityId, action, performedBy, timestamp',
      assessments: 'id, patientId, syncStatus, createdAt',
      reminders: 'id, patientId, syncStatus, scheduledDate',
      // AI Assistant Knowledge & History Stores
      assistantHistory: '++id, role, text, language, emergencyFlag, timestamp',
      approvedGuidelines: 'id, category, title, authority, version, reviewDate',
      healthAlerts: '++id, patientId, alertType, severity, timestamp',
      knowledgeTranslations: 'id, articleId, language, title',
      assistantSettings: 'id, mode, activeLanguage'
    }).upgrade(tx => {
      console.log('[DB] Upgraded to OfflineHealthDB v3 with AI Assistant stores.');
    });

    // Version 4: AI Medical Document Analysis store (inherits v3 stores)
    this.version(4).stores({
      documentAnalyses: 'id, patientId, documentType, riskLevel, syncStatus, isDeleted, version, createdAt, updatedAt, deviceId'
    }).upgrade(() => {
      console.log('[DB] Upgraded to OfflineHealthDB v4 with AI Document Analysis store.');
    });
  }
}

export const db = new OfflineHealthDB();

// Verified Offline Medical Knowledge Base
export const SEED_KNOWLEDGE = [
  {
    id: 'kb-firstaid-01',
    category: 'first_aid',
    title: 'Snakebite Emergency Protocol (DOs and DONTs)',
    language: 'en',
    lastUpdated: '2026-11-20',
    summary: 'Essential field first aid for snakebite cases in rural areas.',
    content: `
### Snakebite Emergency Protocol for Community Health Workers

1. **Immediate Actions (DOs):**
   - Keep patient calm and completely still. Movement spreads venom rapidly.
   - Immobilize the bitten limb using a splint or sling at or slightly below heart level.
   - Gently wash the bite site with clean water. Remove tight rings, bangles, or anklets before swelling occurs.
   - Immediately arrange transport to the nearest PHC / CHC equipped with Anti-Snake Venom (ASV).
   - Document the exact time of the bite and note any progressive symptoms (ptosis, drooping eyelids, difficulty swallowing, bleeding gums).

2. **Dangerous Practices (DON'Ts):**
   - **DO NOT** apply a tight tourniquet (cuts off arterial circulation, causes gangrene).
   - **DO NOT** cut, pierce, or slash the bite wound.
   - **DO NOT** suck the venom by mouth or mechanical suction devices.
   - **DO NOT** apply ice, potassium permanganate, electric shocks, or herbal pastes.
   - **DO NOT** give caffeine, alcohol, or pain medications like aspirin (increases bleeding risk).
    `
  },
  {
    id: 'kb-firstaid-01-kn',
    category: 'first_aid',
    title: 'ಹಾವು ಕಡಿತದ ತುರ್ತು ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ (ಮಾಡಬೇಕಾದ ಮತ್ತು ಮಾಡಬಾರದ ನಿಯಮಗಳು)',
    language: 'kn',
    lastUpdated: '2026-11-20',
    summary: 'ಗ್ರಾಮೀಣ ಭಾಗಗಳಲ್ಲಿ ಹಾವು ಕಡಿತಕ್ಕೆ ತುರ್ತು ಮಾರ್ಗಸೂಚಿ.',
    content: `
### ಆಶಾ ಮತ್ತು ಆರೋಗ್ಯ ಕಾರ್ಯಕರ್ತರಿಗೆ ಹಾವು ಕಡಿತದ ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ

1. **ತಕ್ಷಣ ಮಾಡಬೇಕಾದ ಕ್ರಮಗಳು:**
   - ರೋಗಿಯನ್ನು ಗಾಬರಿಯಾಗದಂತೆ ಸಮಾಧಾನಪಡಿಸಿ. ರೋಗಿಯು ಓಡಾಡದಂತೆ ಸಂಪೂರ್ಣ ವಿಶ್ರಾಂತಿ ಕೊಡಿ.
   - ಕಚ್ಚಿದ ಕೈ ಅಥವಾ ಕಾಲನ್ನು ಅಲ್ಲಾಡಿಸದಂತೆ ಕಟ್ಟಿಗೆಯ ಪಟ್ಟಿಯಿಂದ ಬಿಗಿಯಿರಿ (ಸ್ಪ್ಲಿಂಟ್ ಮಾಡಿ).
   - ಗಾಯದ ಸುತ್ತಲಿನ ಉಂಗುರ, ಬಳೆ ಅಥವಾ ಕಾಲುಂಗುರಗಳನ್ನು ತಕ್ಷಣ ತೆಗೆಯಿರಿ (ಊತ ಬರುವುದಕ್ಕಿಂತ ಮುಂಚೆ).
   - ರೋಗಿಯನ್ನು ತಕ್ಷಣ ಆಂಟಿ-ಸ್ನೇಕ್ ವೆನಮ್ (ASV) ಲಭ್ಯವಿರುವ ಸಮುದಾಯ ಆರೋಗ್ಯ ಕೇಂದ್ರಕ್ಕೆ ಕರೆದೊಯ್ಯಿರಿ.

2. **ಮಾಡಬಾರದ ತಪ್ಪುಗಳು:**
   - ಗಾಯಕ್ಕೆ ರಕ್ತ ಕಟ್ಟಿಹಾಕುವಂತೆ ಅತಿಯಾಗಿ ಬಿಗಿಯಬೇಡಿ (ಗ್ಯಾಂಗ್ರೀನ್ ಅಪಾಯ).
   - ಬ್ಲೇಡ್‌ನಿಂದ ಗಾಯವನ್ನು ಕೊಯ್ಯಬೇಡಿ.
   - ಬಾಯಿಯಿಂದ ವಿಷ ಹೀರುವ ಪ್ರಯತ್ನ ಮಾಡಬೇಡಿ.
   - ಗಾಯಕ್ಕೆ ಸುಣ್ಣ, ಬೆರಣಿ ಅಥವಾ ಗಿಡಮೂಲಿಕೆ ಹಚ್ಚಬೇಡಿ.
    `
  },
  {
    id: 'kb-firstaid-01-hi',
    category: 'first_aid',
    title: 'सर्पदंश (सांप के काटने पर) आपातकालीन प्राथमिक उपचार',
    language: 'hi',
    lastUpdated: '2026-11-20',
    summary: 'ग्रामीण क्षेत्रों में सांप के काटने पर आशा कार्यकर्ताओं के लिए जरूरी दिशा-निर्देश।',
    content: `
### सर्पदंश प्राथमिक उपचार प्रोटोकॉल

1. **क्या करें:**
   - मरीज को बिल्कुल शांत रखें और चलने-फिरने न दें।
   - काटे गए अंग (हाथ या पैर) को खपच्ची (Splint) बांधकर स्थिर रखें।
   - तुरंत अंगूठी, चूड़ी, पायल आदि उतार लें ताकि सूजन आने पर रुकावट न हो।
   - बिना देर किए मरीज को प्राथमिक स्वास्थ्य केंद्र (PHC/CHC) ले जाएं जहां एंटी-स्नेक वेनम (ASV) उपलब्ध हो।

2. **क्या न करें:**
   - काटे हुए स्थान पर चीरा न लगाएं।
   - मुंह से जहर चूसने का प्रयास न करें।
   - बहुत टाइट पट्टी (टॉर्निकेट) न बांधें।
   - कोई जड़ी-बूटी, चूना या गोबर न लगाएं।
    `
  },
  {
    id: 'kb-maternal-01',
    category: 'maternal',
    title: 'Danger Signs in Pregnancy & Preeclampsia Alert',
    language: 'en',
    lastUpdated: '2026-11-15',
    summary: 'Clinical warning signs requiring emergency obstetric referral.',
    content: `
### Obstetric Warning Signs for Field Surveillance

1. **Severe Preeclampsia / Eclampsia Signs:**
   - Systolic BP >= 140 mmHg or Diastolic BP >= 90 mmHg.
   - Persistent severe frontal headache not relieved by rest.
   - Visual disturbances (blurring, double vision, flashes of light).
   - Severe epigastric or right upper-quadrant abdominal pain.
   - Sudden swelling of face, hands, and eyelids.
   - Immediate action: Urgent referral to CHC/FRU; administer single loading dose Magnesium Sulfate if ANM trained.

2. **Antepartum & Postpartum Hemorrhage (APH/PPH):**
   - Any vaginal bleeding during pregnancy is abnormal.
   - Post-delivery: Soaking more than 2 sanitary pads in 30 minutes, pallor, dizziness, cold clammy extremities.
   - Keep patient warm, elevate lower limbs, initiate urgent emergency ambulance transport (108).
    `
  },
  {
    id: 'kb-child-01',
    category: 'child',
    title: 'Recognizing Pneumonia and Severe Malnutrition (SAM) in Under-5s',
    language: 'en',
    lastUpdated: '2026-11-18',
    summary: 'WHO/IMNCI guidelines for respiratory distress and nutritional faltering.',
    content: `
### IMNCI Warning Signs in Infants and Toddlers

1. **Fast Breathing & Chest Indrawing (Pneumonia):**
   - Age 2 to 11 months: >= 50 breaths per minute.
   - Age 12 to 59 months: >= 40 breaths per minute.
   - Lower chest wall indrawing (chest moves in when child breathes in).
   - Stridor in calm child or inability to drink / breastfeed.
   - Immediate referral for pediatric antibiotic coverage.

2. **Severe Acute Malnutrition (SAM):**
   - Mid-Upper Arm Circumference (MUAC) < 11.5 cm (Red color on Shakir tape).
   - Bilateral pitting edema of both feet.
   - Visible severe wasting of buttocks and ribs.
   - Action: Enroll in Village Nutrition Rehabilitation Centre (NRC).
    `
  },
  {
    id: 'kb-nutrition-01',
    category: 'nutrition',
    title: 'ORS Preparation and Zinc for Acute Childhood Diarrhea',
    language: 'en',
    lastUpdated: '2026-11-10',
    summary: 'Correct preparation of Oral Rehydration Salts to prevent fatal dehydration.',
    content: `
### Proper ORS Preparation (Zero Measurement Error)

1. **How to Prepare:**
   - Wash hands thoroughly with soap and water.
   - Pour the entire 1 liter ORS packet into 1 liter of clean drinking or boiled-and-cooled water.
   - Mix thoroughly until completely dissolved.
   - **Do not boil the prepared solution.** Discard any unused solution after 24 hours.

2. **Dosage & Zinc Supplementation:**
   - Give 1 teaspoon every 2-3 minutes. If the child vomits, wait 10 minutes and resume slowly.
   - Provide 20 mg elemental Zinc tablets daily for 14 continuous days (10 mg for infants under 6 months) to rebuild gut mucosa.
    `
  }
];

// Initial realistic database cohort
export async function initializeDatabase() {
  try {
    const patientCount = await db.patients.count();
    const deviceId = getOrCreateDeviceId();
    const timestamp = new Date().toISOString();

    if (patientCount === 0) {
      console.log('[DB] Seeding core clinical datasets in IndexedDB...');

      // 1. Seed Patients
      const patientsData = [
        {
          id: 'pat-101',
          patientId: 'PAT-RAM-0101',
          name: 'Geeta Devi',
          age: 24,
          gender: 'female',
          dateOfBirth: '2002-04-12',
          contactNumber: '9845123401',
          emergencyContact: '9845123402 (Husband - Ramesh)',
          abhaId: '91-4523-8891-2301',
          aadhaarLast4: '4192',
          villageHamlet: 'Rampur Hamlet 2',
          wardNumber: 'Ward 2',
          houseNumber: 'H.No 42, Near Temple Tree',
          bloodGroup: 'B+',
          riskLevel: 'high',
          category: 'maternal',
          isPregnant: true,
          chronicConditions: ['Gestational Hypertension'],
          allergies: 'Penicillin allergy noted',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-10-15T09:30:00.000Z',
          updatedAt: '2026-11-20T11:15:00.000Z',
          deviceId
        },
        {
          id: 'pat-102',
          patientId: 'PAT-RAM-0102',
          name: 'Aniket Kumar',
          age: 1,
          gender: 'male',
          dateOfBirth: '2025-09-10',
          contactNumber: '9845123403',
          emergencyContact: '9845123403 (Mother - Sunita)',
          abhaId: '91-4523-8891-2302',
          aadhaarLast4: '6102',
          villageHamlet: 'Rampur Hamlet 4',
          wardNumber: 'Ward 4',
          houseNumber: 'H.No 19, River Road',
          bloodGroup: 'O+',
          riskLevel: 'high',
          category: 'child',
          isPregnant: false,
          chronicConditions: ['Severe Acute Malnutrition Screening (SAM)'],
          allergies: 'None',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-09-12T08:00:00.000Z',
          updatedAt: '2026-11-25T14:20:00.000Z',
          deviceId
        },
        {
          id: 'pat-103',
          patientId: 'PAT-RAM-0103',
          name: 'Rameshwar Lal',
          age: 58,
          gender: 'male',
          dateOfBirth: '1968-08-25',
          contactNumber: '9845123404',
          emergencyContact: '9845123405 (Son - Vijay)',
          abhaId: '91-4523-8891-2303',
          aadhaarLast4: '8834',
          villageHamlet: 'Main Village Center',
          wardNumber: 'Ward 1',
          houseNumber: 'H.No 105, Market Street',
          bloodGroup: 'A+',
          riskLevel: 'moderate',
          category: 'chronic',
          isPregnant: false,
          chronicConditions: ['Type 2 Diabetes Mellitus', 'Hypertension'],
          allergies: 'Sulfa drugs',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-08-10T10:00:00.000Z',
          updatedAt: '2026-11-18T16:00:00.000Z',
          deviceId
        },
        {
          id: 'pat-104',
          patientId: 'PAT-RAM-0104',
          name: 'Basamma Gowda',
          age: 62,
          gender: 'female',
          dateOfBirth: '1964-11-05',
          contactNumber: '9845123406',
          emergencyContact: '9845123407 (Daughter - Shobha)',
          abhaId: '91-4523-8891-2304',
          aadhaarLast4: '2051',
          villageHamlet: 'South Hamlet',
          wardNumber: 'Ward 3',
          houseNumber: 'H.No 88, Near Panchayat Office',
          bloodGroup: 'AB+',
          riskLevel: 'moderate',
          category: 'chronic',
          isPregnant: false,
          chronicConditions: ['Primary Hypertension', 'Osteoarthritis'],
          allergies: 'None',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-07-22T09:15:00.000Z',
          updatedAt: '2026-11-24T10:30:00.000Z',
          deviceId
        },
        {
          id: 'pat-105',
          patientId: 'PAT-RAM-0105',
          name: 'Lakshmi Bai',
          age: 28,
          gender: 'female',
          dateOfBirth: '1998-02-14',
          contactNumber: '9845123408',
          emergencyContact: '9845123409 (Husband - Anand)',
          abhaId: '91-4523-8891-2305',
          aadhaarLast4: '7721',
          villageHamlet: 'North Hamlet',
          wardNumber: 'Ward 2',
          houseNumber: 'H.No 15, Post Office Lane',
          bloodGroup: 'O-',
          riskLevel: 'normal',
          category: 'maternal',
          isPregnant: false,
          chronicConditions: [],
          allergies: 'None',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-09-01T11:00:00.000Z',
          updatedAt: '2026-11-25T11:45:00.000Z',
          deviceId
        },
        {
          id: 'pat-106',
          patientId: 'PAT-RAM-0106',
          name: 'Aarav Patil',
          age: 0,
          gender: 'male',
          dateOfBirth: '2026-06-18',
          contactNumber: '9845123410',
          emergencyContact: '9845123410 (Mother - Kavita)',
          abhaId: '91-4523-8891-2306',
          aadhaarLast4: '9912',
          villageHamlet: 'Main Village Center',
          wardNumber: 'Ward 1',
          houseNumber: 'H.No 64, School Cross',
          bloodGroup: 'B+',
          riskLevel: 'normal',
          category: 'child',
          isPregnant: false,
          chronicConditions: [],
          allergies: 'None',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-06-20T08:30:00.000Z',
          updatedAt: '2026-11-15T09:00:00.000Z',
          deviceId
        },
        {
          id: 'pat-107',
          patientId: 'PAT-RAM-0107',
          name: 'Suresh Chandra',
          age: 42,
          gender: 'male',
          dateOfBirth: '1984-05-30',
          contactNumber: '9845123411',
          emergencyContact: '9845123412 (Wife - Manjula)',
          abhaId: '91-4523-8891-2307',
          aadhaarLast4: '3341',
          villageHamlet: 'Rampur Hamlet 2',
          wardNumber: 'Ward 2',
          houseNumber: 'H.No 31, Farmer Cooperative Rd',
          bloodGroup: 'A-',
          riskLevel: 'normal',
          category: 'general',
          isPregnant: false,
          chronicConditions: [],
          allergies: 'None reported',
          consentGiven: true,
          syncStatus: 'synced',
          version: 1,
          isDeleted: false,
          createdAt: '2026-05-10T14:00:00.000Z',
          updatedAt: '2026-10-12T15:20:00.000Z',
          deviceId
        }
      ];
      await db.patients.bulkAdd(patientsData);

      // 2. Seed Health Assessments
      await db.healthAssessments.bulkAdd([
        {
          id: 'ha-01',
          patientId: 'pat-101',
          systolicBp: 154,
          diastolicBp: 98,
          pulse: 88,
          spo2: 98,
          bloodGlucose: 104,
          temperature: 98.4,
          respiratoryRate: 18,
          height: 156,
          weight: 64,
          bmi: 26.3,
          warningSigns: ['Severe Gestational Hypertension (BP >= 140/90)'],
          assessedBy: 'Sunita Devi (ASHA)',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-11-25T09:15:00.000Z',
          deviceId
        },
        {
          id: 'ha-02',
          patientId: 'pat-103',
          systolicBp: 148,
          diastolicBp: 92,
          pulse: 76,
          spo2: 97,
          bloodGlucose: 265,
          temperature: 98.6,
          respiratoryRate: 16,
          height: 168,
          weight: 78,
          bmi: 27.6,
          warningSigns: ['Uncontrolled Hyperglycemia (>200 mg/dL)', 'Stage 2 Hypertension'],
          assessedBy: 'Dr. Priya Rao',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-11-24T11:00:00.000Z',
          deviceId
        }
      ]);

      // 3. Seed Maternal Records & Antenatal Visits
      await db.maternalRecords.add({
        id: 'mat-101',
        patientId: 'pat-101',
        lmp: '2026-04-15',
        edd: '2027-01-22',
        trimester: 3,
        gravidity: 2,
        parity: 1,
        highRiskFactors: ['Pregnancy Induced Hypertension', 'Previous Caesarean Section'],
        status: 'active',
        syncStatus: 'synced',
        version: 1,
        createdAt: '2026-05-01T09:00:00.000Z',
        updatedAt: '2026-11-20T10:00:00.000Z',
        deviceId
      });

      await db.antenatalVisits.bulkAdd([
        {
          id: 'anc-01',
          patientId: 'pat-101',
          maternalRecordId: 'mat-101',
          visitNumber: 1,
          systolicBp: 120,
          diastolicBp: 80,
          weightKg: 58,
          fundalHeightCm: 16,
          fetalHeartRate: 142,
          urineProtein: 'Nil',
          hemoglobin: 11.2,
          warningSigns: 'None',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-06-12T10:00:00.000Z',
          deviceId
        },
        {
          id: 'anc-02',
          patientId: 'pat-101',
          maternalRecordId: 'mat-101',
          visitNumber: 3,
          systolicBp: 154,
          diastolicBp: 98,
          weightKg: 64,
          fundalHeightCm: 31,
          fetalHeartRate: 148,
          urineProtein: '1+',
          hemoglobin: 10.4,
          warningSigns: 'Severe Gestational Hypertension, Proteinuria',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-11-20T10:00:00.000Z',
          deviceId
        }
      ]);

      // 4. Seed Child Records, Growth, and Immunizations
      await db.childRecords.add({
        id: 'ch-102',
        patientId: 'pat-102',
        motherId: 'pat-101',
        birthWeight: 2.4,
        gestationalAge: 37,
        deliveryType: 'Institutional (PHC)',
        syncStatus: 'synced',
        version: 1,
        createdAt: '2025-09-10T12:00:00.000Z',
        deviceId
      });

      await db.growthRecords.add({
        id: 'gr-01',
        childId: 'ch-102',
        patientId: 'pat-102',
        ageMonths: 14,
        weightKg: 7.1,
        heightCm: 71.5,
        muacCm: 11.2,
        nutritionGrade: 'SAM (Severe Acute Malnutrition)',
        measuredBy: 'Sunita Devi (ASHA)',
        syncStatus: 'synced',
        version: 1,
        createdAt: '2026-11-22T08:30:00.000Z',
        deviceId
      });

      await db.immunizations.bulkAdd([
        {
          id: 'imm-01',
          childId: 'ch-102',
          patientId: 'pat-102',
          vaccineName: 'BCG + OPV-0',
          doseNumber: 1,
          dueDate: '2025-09-10',
          givenDate: '2025-09-10',
          status: 'administered',
          administeredBy: 'ANM Rekha',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2025-09-10T14:00:00.000Z',
          deviceId
        },
        {
          id: 'imm-02',
          childId: 'ch-102',
          patientId: 'pat-102',
          vaccineName: 'Pentavalent-3 & Rotavirus-3',
          doseNumber: 3,
          dueDate: '2026-01-10',
          givenDate: null,
          status: 'overdue',
          administeredBy: null,
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-01-10T09:00:00.000Z',
          deviceId
        }
      ]);

      // 5. Seed Chronic Conditions
      await db.chronicConditions.bulkAdd([
        {
          id: 'cc-01',
          patientId: 'pat-103',
          conditionName: 'Type 2 Diabetes Mellitus',
          severity: 'uncontrolled',
          diagnosedDate: '2022-04-15',
          lastChecked: '2026-11-24',
          medicationAdherence: 'Irregular (Missed Metformin)',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-08-10T10:00:00.000Z',
          deviceId
        },
        {
          id: 'cc-02',
          patientId: 'pat-104',
          conditionName: 'Essential Hypertension',
          severity: 'moderate',
          diagnosedDate: '2020-01-10',
          lastChecked: '2026-11-24',
          medicationAdherence: 'Regular (Amlodipine 5mg daily)',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-07-22T09:15:00.000Z',
          deviceId
        }
      ]);

      // 6. Seed Referrals
      await db.referrals.add({
        id: 'ref-01',
        patientId: 'pat-101',
        urgency: 'emergency',
        status: 'pending_doctor_review',
        referralFacility: 'Rampur Community Health Centre (Obstetrics)',
        reason: 'Severe pre-eclampsia with BP 154/98 at 32 weeks gestation and trace proteinuria',
        referredBy: 'Sunita Devi (ASHA)',
        doctorFeedback: 'Admit to High-Dependency Obstetric Unit. Magnesium sulfate protocol initialized.',
        syncStatus: 'synced',
        version: 1,
        createdAt: '2026-11-25T10:00:00.000Z',
        deviceId
      });

      // 7. Seed Follow-ups
      await db.followUps.bulkAdd([
        {
          id: 'fu-01',
          patientId: 'pat-101',
          scheduledDate: '2026-11-26',
          visitType: 'ANC Checkup (32 Weeks)',
          priority: 'urgent',
          isCompleted: false,
          notes: 'Home visit for blood pressure re-check and symptom surveillance.',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-11-20T10:00:00.000Z',
          deviceId
        },
        {
          id: 'fu-02',
          patientId: 'pat-102',
          scheduledDate: '2026-11-26',
          visitType: 'Immunization Catch-up & MUAC',
          priority: 'high',
          isCompleted: false,
          notes: 'Bring mother to Anganwadi center for Pentavalent-3 and supplementary nutrition mix.',
          syncStatus: 'synced',
          version: 1,
          createdAt: '2026-11-22T08:30:00.000Z',
          deviceId
        }
      ]);

      // 8. Seed Knowledge Articles
      await db.knowledgeArticles.bulkAdd(SEED_KNOWLEDGE);

      // 9. Initial Audit Log
      await db.auditLogs.add({
        entity: 'system',
        entityId: 'SYSTEM-INIT',
        action: 'SYSTEM_INITIALIZATION',
        performedBy: 'System Init',
        role: 'system',
        timestamp,
        details: '15 offline clinical and sync data collections initialized.'
      });

      console.log('[DB] Core offline datasets successfully initialized.');
    } else {
      // Ensure knowledge articles are populated even if patients exist
      const kbCount = await db.knowledgeArticles.count();
      if (kbCount === 0) {
        await db.knowledgeArticles.bulkAdd(SEED_KNOWLEDGE);
      }
    }
  } catch (error) {
    console.error('[DB] Database initialization error:', error);
  }
}
