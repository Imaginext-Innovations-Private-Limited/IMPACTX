import { db } from './db';

/**
 * Service to manage all local IndexedDB Patient Operations
 * Supports 100% offline CRUD, audit trails, and sync queue dispatching
 */

export const PatientService = {
  /**
   * Fetch all active patients with optional filtering, search, and sorting
   */
  async getPatients({
    search = '',
    villageHamlet = 'all',
    riskLevel = 'all',
    category = 'all',
    gender = 'all',
    sortBy = 'recent'
  } = {}) {
    let collection = db.patients.where('isDeleted').equals(0); // 0 or false

    let list = await db.patients
      .filter(p => !p.isDeleted)
      .toArray();

    // 1. Text Search (Name, PatientId, Contact, ABHA)
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(p => 
        (p.name && p.name.toLowerCase().includes(q)) ||
        (p.patientId && p.patientId.toLowerCase().includes(q)) ||
        (p.contactNumber && p.contactNumber.includes(q)) ||
        (p.abhaId && p.abhaId.toLowerCase().includes(q)) ||
        (p.villageHamlet && p.villageHamlet.toLowerCase().includes(q))
      );
    }

    // 2. Village Filter
    if (villageHamlet !== 'all') {
      list = list.filter(p => p.villageHamlet === villageHamlet);
    }

    // 3. Risk Level Filter
    if (riskLevel !== 'all') {
      list = list.filter(p => p.riskLevel === riskLevel);
    }

    // 4. Clinical Category Filter
    if (category !== 'all') {
      list = list.filter(p => p.category === category);
    }

    // 5. Gender Filter
    if (gender !== 'all') {
      list = list.filter(p => p.gender === gender);
    }

    // 6. Sorting
    list.sort((a, b) => {
      if (sortBy === 'name_asc') {
        return a.name.localeCompare(b.name);
      }
      if (sortBy === 'name_desc') {
        return b.name.localeCompare(a.name);
      }
      if (sortBy === 'age_asc') {
        return a.age - b.age;
      }
      if (sortBy === 'age_desc') {
        return b.age - a.age;
      }
      // default: recent (updatedAt descending)
      return new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt);
    });

    return list;
  },

  /**
   * Get unique patient by ID (either primary id or unique patientId)
   */
  async getPatientById(id) {
    let patient = await db.patients.get(id);
    if (!patient) {
      patient = await db.patients.where('patientId').equals(id).first();
    }
    return patient;
  },

  /**
   * Create a new patient record locally in IndexedDB
   */
  async createPatient(patientData, user) {
    const timestamp = new Date().toISOString();
    
    // Generate clean medical ID: PAT-RAM-XXXX
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const generatedPatientId = `PAT-RAM-${randomSuffix}`;
    const id = `pat-${Date.now()}`;

    const newPatient = {
      ...patientData,
      id,
      patientId: patientData.patientId || generatedPatientId,
      age: parseInt(patientData.age, 10) || 0,
      syncStatus: 'pending', // Pending sync to central cloud
      version: 1,
      isDeleted: false,
      createdAt: timestamp,
      updatedAt: timestamp,
      lastModifiedBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Offline Worker'
    };

    // 1. Add to IndexedDB patients table
    await db.patients.add(newPatient);

    // 2. Queue for Central Cloud Sync
    await db.syncQueue.add({
      entity: 'patients',
      entityId: newPatient.id,
      operation: 'CREATE',
      payload: newPatient,
      retryCount: 0,
      status: 'pending',
      createdAt: timestamp
    });

    // 3. Log Audit Trail
    await db.auditLogs.add({
      entity: 'patients',
      entityId: newPatient.id,
      action: 'PATIENT_REGISTERED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `New patient registered: ${newPatient.name} (${newPatient.patientId}), Village: ${newPatient.villageHamlet}`
    });

    return newPatient;
  },

  /**
   * Update existing patient record in IndexedDB
   */
  async updatePatient(id, updateData, user) {
    const existing = await this.getPatientById(id);
    if (!existing) {
      throw new Error(`Patient with ID ${id} not found`);
    }

    const timestamp = new Date().toISOString();
    const updatedVersion = (existing.version || 1) + 1;

    const merged = {
      ...existing,
      ...updateData,
      age: updateData.age !== undefined ? parseInt(updateData.age, 10) : existing.age,
      version: updatedVersion,
      syncStatus: 'pending', // Marks for sync
      updatedAt: timestamp,
      lastModifiedBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Offline Worker'
    };

    // 1. Save update in IndexedDB
    await db.patients.put(merged);

    // 2. Queue update in syncQueue
    await db.syncQueue.add({
      entity: 'patients',
      entityId: merged.id,
      operation: 'UPDATE',
      payload: merged,
      retryCount: 0,
      status: 'pending',
      createdAt: timestamp
    });

    // 3. Audit trail
    await db.auditLogs.add({
      entity: 'patients',
      entityId: merged.id,
      action: 'PATIENT_UPDATED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Patient details updated for ${merged.name} (${merged.patientId}). Version incremented to ${updatedVersion}.`
    });

    return merged;
  },

  /**
   * Soft-delete patient record subject to audit requirements
   */
  async deletePatient(id, user, reason = 'Clinical or administrative correction') {
    const existing = await this.getPatientById(id);
    if (!existing) {
      throw new Error(`Patient with ID ${id} not found`);
    }

    const timestamp = new Date().toISOString();

    const updated = {
      ...existing,
      isDeleted: true,
      syncStatus: 'pending',
      updatedAt: timestamp,
      deletionReason: reason,
      lastModifiedBy: user ? `${user.name} (${user.roleLabel || user.role})` : 'Offline Worker'
    };

    await db.patients.put(updated);

    // Add to sync queue as DELETE operation
    await db.syncQueue.add({
      entity: 'patients',
      entityId: updated.id,
      operation: 'DELETE',
      payload: { id: updated.id, patientId: updated.patientId, reason },
      retryCount: 0,
      status: 'pending',
      createdAt: timestamp
    });

    // Audit log
    await db.auditLogs.add({
      entity: 'patients',
      entityId: updated.id,
      action: 'PATIENT_DELETED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Patient ${existing.name} (${existing.patientId}) deleted. Reason: ${reason}`
    });

    return true;
  },

  /**
   * Fetch audit logs for a specific patient
   */
  async getPatientAuditLogs(patientId) {
    return await db.auditLogs
      .where('entityId')
      .equals(patientId)
      .reverse()
      .sortBy('timestamp');
  },

  /**
   * Summary counts for dashboard metrics
   */
  async getCounts() {
    const all = await db.patients.filter(p => !p.isDeleted).toArray();
    const total = all.length;
    const maternal = all.filter(p => p.category === 'maternal' || p.isPregnant).length;
    const child = all.filter(p => p.category === 'child' || p.age <= 5).length;
    const highRisk = all.filter(p => p.riskLevel === 'high').length;
    const pendingSync = await db.syncQueue.where('status').equals('pending').count();

    return {
      total,
      maternal,
      child,
      highRisk,
      pendingSync
    };
  }
};
