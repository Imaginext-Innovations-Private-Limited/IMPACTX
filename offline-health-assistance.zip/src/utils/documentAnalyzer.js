import { createWorker } from 'tesseract.js';

const CLINICAL_RULES = [
  {
    key: 'hemoglobin',
    label: 'Hemoglobin (Hb)',
    unit: 'g/dL',
    regex: /(?:hb|hgb|ha?emoglobin)\s*[:=\-]?\s*(\d{1,2}(?:\.\d{1,2})?)/i,
    evaluate: (val) => {
      if (val < 7) {
        return {
          status: 'critical',
          note: 'Severe Anemia — Urgent PHC/CHC medical officer referral & blood transfusion assessment required.',
        };
      }
      if (val < 11) {
        return {
          status: 'warning',
          note: 'Mild/Moderate Anemia — Start/continue IFA supplementation & iron-rich diet counseling.',
        };
      }
      return { status: 'normal', note: 'Within acceptable range.' };
    },
  },
  {
    key: 'bp',
    label: 'Blood Pressure (BP)',
    unit: 'mmHg',
    regex: /(?:bp|blood\s*pressure)\s*[:=\-]?\s*(\d{2,3})\s*[\/\\]\s*(\d{2,3})/i,
    parseValue: (match) => ({
      systolic: Number(match[1]),
      diastolic: Number(match[2]),
      display: `${match[1]}/${match[2]}`,
    }),
    evaluate: ({ systolic, diastolic }) => {
      if (systolic >= 160 || diastolic >= 110) {
        return {
          status: 'critical',
          note: 'Severe Hypertension — Immediate medical review (screen for preeclampsia if pregnant).',
        };
      }
      if (systolic >= 140 || diastolic >= 90) {
        return {
          status: 'warning',
          note: 'Elevated BP — Schedule repeat measurement & NCD hypertension follow-up.',
        };
      }
      if (systolic < 90 || diastolic < 60) {
        return {
          status: 'warning',
          note: 'Low BP (Hypotension) — Assess hydration, bleeding, or dizziness.',
        };
      }
      return { status: 'normal', note: 'Normal blood pressure.' };
    },
  },
  {
    key: 'bloodSugar',
    label: 'Blood Glucose (RBS/FBS/PPBS)',
    unit: 'mg/dL',
    regex: /(?:rbs|fbs|ppbs|fasting\s*blood\s*sugar|random\s*blood\s*sugar|blood\s*sugar|glucose)\s*[:=\-]?\s*(\d{2,3}(?:\.\d{1,2})?)/i,
    evaluate: (val) => {
      if (val < 70) {
        return {
          status: 'critical',
          note: 'Hypoglycemia Risk — Immediate oral glucose/sugar if conscious; urgent referral.',
        };
      }
      if (val >= 250) {
        return {
          status: 'critical',
          note: 'Severe Hyperglycemia — Urgent PHC medical officer review & ketone check.',
        };
      }
      if (val >= 140) {
        return {
          status: 'warning',
          note: 'Elevated Glucose — Verify fasting vs post-meal timing & monitor adherence.',
        };
      }
      return { status: 'normal', note: 'Within acceptable range.' };
    },
  },
  {
    key: 'hba1c',
    label: 'HbA1c',
    unit: '%',
    regex: /hba1c\s*[:=\-]?\s*(\d{1,2}(?:\.\d{1,2})?)\s*%?/i,
    evaluate: (val) => {
      if (val >= 9) {
        return { status: 'critical', note: 'Poor Glycemic Control — Doctor medication adjustment advised.' };
      }
      if (val >= 6.5) {
        return { status: 'warning', note: 'Diabetic Range — Reinforce diet, exercise, and medication adherence.' };
      }
      return { status: 'normal', note: 'Controlled HbA1c.' };
    },
  },
  {
    key: 'spo2',
    label: 'Oxygen Saturation (SpO2)',
    unit: '%',
    regex: /(?:spo2|o2\s*sat|oxygen\s*sat(?:uration)?)\s*[:=\-]?\s*(\d{2,3})\s*%?/i,
    evaluate: (val) => {
      if (val < 90) {
        return { status: 'critical', note: 'Hypoxemia — Immediate oxygen support & 108 ambulance referral.' };
      }
      if (val < 95) {
        return { status: 'warning', note: 'Borderline SpO2 — Monitor respiratory rate and re-check.' };
      }
      return { status: 'normal', note: 'Normal oxygenation.' };
    },
  },
  {
    key: 'temperature',
    label: 'Body Temperature',
    unit: '°F',
    regex: /(?:temp(?:erature)?)\s*[:=\-]?\s*(\d{2,3}(?:\.\d{1,2})?)\s*(?:°?\s*([FC]))?/i,
    parseValue: (match) => {
      let val = Number(match[1]);
      const unit = (match[2] || '').toUpperCase();
      if (unit === 'C' || (val >= 34 && val <= 43)) {
        const fahrenheit = Number(((val * 9) / 5 + 32).toFixed(1));
        return { numeric: fahrenheit, display: `${fahrenheit} (${val}°C)` };
      }
      return { numeric: val, display: String(val) };
    },
    evaluate: ({ numeric }) => {
      if (numeric >= 103) {
        return { status: 'critical', note: 'High-grade Fever — Evaluate for sepsis/malaria/dengue; urgent care.' };
      }
      if (numeric >= 100.4) {
        return { status: 'warning', note: 'Fever Detected — Hydration, tepid sponging, and fever workup.' };
      }
      return { status: 'normal', note: 'Afebrile.' };
    },
  },
  {
    key: 'platelets',
    label: 'Platelet Count',
    unit: '/µL',
    regex: /(?:platelets?|plt)\s*[:=\-]?\s*(\d{1,3}(?:,\d{2,3})+|\d+(?:\.\d+)?\s*(?:lakh|lac)s?|\d{5,6})/i,
    parseValue: (match) => {
      const raw = match[1].toLowerCase();
      if (raw.includes('lakh') || raw.includes('lac')) {
        const numeric = Math.round(parseFloat(raw) * 100000);
        return { numeric, display: match[1].trim() };
      }
      const numeric = Number(raw.replace(/,/g, ''));
      return { numeric, display: numeric.toLocaleString('en-IN') };
    },
    evaluate: ({ numeric }) => {
      if (numeric < 50000) {
        return { status: 'critical', note: 'Severe Thrombocytopenia — Urgent CHC/hospital referral (bleeding/dengue risk).' };
      }
      if (numeric < 150000) {
        return { status: 'warning', note: 'Low Platelets — Repeat CBC and monitor for fever/petechiae.' };
      }
      return { status: 'normal', note: 'Normal platelet count.' };
    },
  },
];

const MEDICATION_REGEX = /\b(?:tab\.?|cap\.?|syp\.?|inj\.?|drop\.?|oint\.?)\s+[a-z0-9\-\s]{2,35}(?:\d+\s*(?:mg|ml|mcg|g|iu))?/gi;

export const SAMPLE_DOCUMENTS = [
  {
    id: 'maternal_lab',
    label: 'Sample: ANC Lab Report',
    documentType: 'lab_report',
    text: `RAMPUR PHC LAB REPORT
Patient: Kavita Devi | 24 Yrs / Female (ANC 28 Weeks)
Hemoglobin (Hb): 6.8 g/dL
BP: 152/98 mmHg
RBS: 118 mg/dL
Platelets: 1,90,000 /uL
Rx: Tab. Iron Folic Acid 100mg OD, Tab. Calcium 500mg BD`,
  },
  {
    id: 'diabetes_rx',
    label: 'Sample: Diabetes Rx',
    documentType: 'prescription',
    text: `OUTPATIENT PRESCRIPTION - NCD CLINIC
FBS: 264 mg/dL
HbA1c: 9.4 %
BP: 144/92 mmHg
Tab. Metformin 500mg BD
Tab. Glimepiride 1mg OD
Tab. Amlodipine 5mg OD`,
  },
  {
    id: 'fever_cbc',
    label: 'Sample: Fever CBC',
    documentType: 'lab_report',
    text: `COMMUNITY HEALTH CENTRE CBC SLIP
Temp: 103.2 F
SpO2: 93 %
Platelets: 45,000 /uL
Hb: 11.6 g/dL
Advise: Inj. Paracetamol SOS, urgent MO review`,
  },
];

/**
 * Extract plain text from an uploaded image or text file completely offline.
 */
export async function extractTextFromDocument(file, onProgress) {
  if (!file) return '';

  if (file.type.startsWith('text/') || /\.(txt|csv|log)$/i.test(file.name)) {
    return (await file.text()).trim();
  }

  const worker = await createWorker('eng', 1, {
    logger: (m) => {
      if (m.status === 'recognizing text' && typeof onProgress === 'function') {
        onProgress(Math.round((m.progress || 0) * 100));
      }
    },
  });

  try {
    const { data } = await worker.recognize(file);
    return (data?.text || '').trim();
  } finally {
    await worker.terminate();
  }
}

/**
 * Deterministic offline clinical rule engine for extracted medical document text.
 */
export function analyzeMedicalTextOffline(rawText, documentType = 'lab_report') {
  const text = (rawText || '').trim();
  const findings = [];

  for (const rule of CLINICAL_RULES) {
    const match = text.match(rule.regex);
    if (!match) continue;

    const parsed = rule.parseValue ? rule.parseValue(match) : Number(match[1]);
    const displayValue = typeof parsed === 'object' ? parsed.display : String(parsed);
    const evaluation = rule.evaluate(parsed);

    findings.push({
      key: rule.key,
      label: rule.label,
      value: displayValue,
      unit: rule.unit,
      status: evaluation.status,
      note: evaluation.note,
    });
  }

  const medications = [...new Set((text.match(MEDICATION_REGEX) || []).map((m) => m.replace(/\s+/g, ' ').trim()))].slice(0, 12);

  let riskLevel = 'normal';
  if (findings.some((f) => f.status === 'critical')) riskLevel = 'critical';
  else if (findings.some((f) => f.status === 'warning')) riskLevel = 'warning';

  const summaryParts = [];
  if (findings.length > 0) {
    summaryParts.push(`Extracted ${findings.length} clinical metric(s) from ${documentType.replace(/_/g, ' ')}.`);
  } else {
    summaryParts.push('No standard numeric lab/vital markers were matched automatically. Review the extracted text carefully.');
  }

  if (riskLevel === 'critical') {
    summaryParts.push('URGENT: Critical value(s) flagged. Escalate to PHC/CHC Medical Officer or call 108 if emergency symptoms exist.');
  } else if (riskLevel === 'warning') {
    summaryParts.push('Borderline/abnormal findings detected. Schedule follow-up and counselor review.');
  }

  const recommendations = findings
    .filter((f) => f.status !== 'normal')
    .map((f) => `${f.label} (${f.value} ${f.unit}): ${f.note}`);

  if (recommendations.length === 0 && findings.length > 0) {
    recommendations.push('All detected parameters are within normal limits. Continue routine care.');
  }

  return {
    findings,
    medications,
    riskLevel,
    summary: summaryParts.join(' '),
    recommendations,
    analyzedMode: 'offline-rules',
  };
}
