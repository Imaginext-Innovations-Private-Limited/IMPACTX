import { db } from '../db/db';

/**
 * OFFLINE HEALTH - Safe Conflict Resolution Engine
 * Handles version collisions when multiple devices update records offline.
 * - Detects divergent versions
 * - Computes field-by-field diffs
 * - Supports resolution strategies: KEEP_LOCAL, KEEP_SERVER, MERGE_FIELDS
 * - Logs all conflict resolutions to audit trail
 */

export const ConflictResolver = {
  /**
   * Compare local record with incoming server record
   * Returns null if no conflict, or a detailed conflict object
   */
  detectConflict(localRecord, serverRecord) {
    if (!localRecord || !serverRecord) return null;

    // A conflict occurs if server version is different or higher and fields diverge
    if (serverRecord.version > localRecord.version || 
       (serverRecord.version === localRecord.version && serverRecord.deviceId !== localRecord.deviceId)) {
      
      const diffs = [];
      const allKeys = new Set([...Object.keys(localRecord), ...Object.keys(serverRecord)]);

      // Ignored internal metadata keys
      const ignore = new Set(['syncStatus', 'updatedAt', 'deviceId', 'version']);

      allKeys.forEach((key) => {
        if (ignore.has(key)) return;
        const localVal = JSON.stringify(localRecord[key]);
        const serverVal = JSON.stringify(serverRecord[key]);
        if (localVal !== serverVal) {
          diffs.push({
            field: key,
            local: localRecord[key],
            server: serverRecord[key]
          });
        }
      });

      if (diffs.length > 0) {
        return {
          hasConflict: true,
          entity: 'patients',
          entityId: localRecord.id || localRecord.patientId,
          localRecord,
          serverRecord,
          diffs,
          detectedAt: new Date().toISOString()
        };
      }
    }

    return null;
  },

  /**
   * Apply resolved record back into IndexedDB
   * strategy: 'KEEP_LOCAL' | 'KEEP_SERVER' | 'MERGE'
   */
  async resolve(conflict, strategy, mergedValues = {}, user = null) {
    const timestamp = new Date().toISOString();
    let finalRecord;

    if (strategy === 'KEEP_LOCAL') {
      finalRecord = {
        ...conflict.localRecord,
        version: Math.max(conflict.localRecord.version || 1, conflict.serverRecord.version || 1) + 1,
        syncStatus: 'pending',
        updatedAt: timestamp,
        conflictResolvedAt: timestamp
      };
    } else if (strategy === 'KEEP_SERVER') {
      finalRecord = {
        ...conflict.serverRecord,
        syncStatus: 'synced',
        updatedAt: timestamp,
        conflictResolvedAt: timestamp
      };
    } else {
      // Custom field-by-field merge
      finalRecord = {
        ...conflict.serverRecord,
        ...mergedValues,
        version: Math.max(conflict.localRecord.version || 1, conflict.serverRecord.version || 1) + 1,
        syncStatus: 'pending',
        updatedAt: timestamp,
        conflictResolvedAt: timestamp
      };
    }

    // Update in target Dexie table
    const targetTable = conflict.entity === 'patients' ? db.patients : db[conflict.entity] || db.patients;
    await targetTable.put(finalRecord);

    // Record audit trail
    await db.auditLogs.add({
      entity: conflict.entity || 'patients',
      entityId: finalRecord.id || finalRecord.patientId,
      action: 'CONFLICT_RESOLVED',
      performedBy: user?.name || 'Local User',
      role: user?.role || 'worker',
      timestamp,
      details: `Conflict resolved using strategy '${strategy}'. Fields affected: ${conflict.diffs?.map(d => d.field).join(', ') || 'N/A'}`
    });

    return finalRecord;
  }
};
