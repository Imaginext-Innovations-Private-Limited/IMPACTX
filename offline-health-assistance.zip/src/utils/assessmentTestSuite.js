import { db } from '../db/db';
import { AssessmentService } from '../services/assessmentService';
import { ClinicalCalculators } from './clinicalCalculators';

/**
 * OFFLINE HEALTH - Automated Health Assessment & Screening Test Suite
 * Validates all 22 clinical assessment, calculation, and triage workflows.
 */

export async function runAssessmentTestSuite(onProgress) {
  const results = [];
  const log = (id, name, passed, details) => {
    const item = { id, name, passed, details, timestamp: new Date().toLocaleTimeString() };
    results.push(item);
    if (onProgress) onProgress(item, results);
  };

  const testUser = { id: 'usr-asha-1', name: 'Sunita Devi', role: 'asha', roleLabel: 'Community Health Worker' };

  // 1. Get or create test patient
  let testPatient = await db.patients.filter(p => !p.isDeleted).first();
  if (!testPatient) {
    testPatient = {
      id: 'pat-test-ass-01',
      patientId: 'PAT-RAM-1001',
      name: 'Rukmini Bai',
      age: 38,
      gender: 'female',
      villageHamlet: 'Rampur Hamlet 1',
      riskLevel: 'normal',
      category: 'general',
      isPregnant: false,
      isDeleted: false,
      version: 1,
      createdAt: new Date().toISOString()
    };
    await db.patients.add(testPatient);
  }

  // TEST 1: Patient Selection & Context Lookup
  try {
    const p = await db.patients.get(testPatient.id);
    log('TEST-01', 'Patient Selection & Demographics Context', Boolean(p && p.id), `Loaded patient: ${p?.name} (${p?.age}y, ${p?.gender})`);
  } catch (e) {
    log('TEST-01', 'Patient Selection & Demographics Context', false, e.message);
  }

  // TEST 2: General Health Assessment Creation
  let createdAssessment = null;
  try {
    createdAssessment = await AssessmentService.createAssessment({
      patientId: testPatient.id,
      assessmentType: 'General Health Screening',
      systolicBp: 124,
      diastolicBp: 78,
      pulse: 74,
      temperature: 36.8,
      respiratoryRate: 16,
      spo2: 98,
      height: 160,
      weight: 58,
      bloodGlucose: 105,
      glucoseContext: 'random',
      observations: 'Routine community screening. Patient appears healthy.'
    }, testUser);

    log('TEST-02', 'General Health Assessment Creation', Boolean(createdAssessment && createdAssessment.id), `Created assessment ${createdAssessment?.id} in Dexie.js`);
  } catch (e) {
    log('TEST-02', 'General Health Assessment Creation', false, e.message);
  }

  // TEST 3: Vital Signs Range & Units Recording
  try {
    const passed = createdAssessment.systolicBp === 124 &&
                   createdAssessment.diastolicBp === 78 &&
                   createdAssessment.pulse === 74 &&
                   createdAssessment.spo2 === 98;
    log('TEST-03', 'Vital Signs Numeric Units & Precision', passed, `BP: ${createdAssessment?.systolicBp}/${createdAssessment?.diastolicBp} mmHg, SpO2: ${createdAssessment?.spo2}%`);
  } catch (e) {
    log('TEST-03', 'Vital Signs Numeric Units & Precision', false, e.message);
  }

  // TEST 4: Automatic Adult BMI Calculation (Asian Indian Criteria)
  try {
    // 58 kg / (1.6 m)^2 = 22.65 -> 22.7 kg/m² (Normal Weight)
    const bmiResult = ClinicalCalculators.calculateBmi(160, 58, { age: 38, isPregnant: false });
    const passed = bmiResult.bmi === 22.7 && bmiResult.category === 'Normal Weight';
    log('TEST-04', 'Automatic BMI & Asian Indian Population Classification', passed, `BMI: ${bmiResult.bmi} kg/m² (${bmiResult.category}) Formula: ${bmiResult.formula}`);
  } catch (e) {
    log('TEST-04', 'Automatic BMI & Asian Indian Population Classification', false, e.message);
  }

  // TEST 5: Repeated Blood Pressure Measurement & Protocol
  try {
    const repeatRecord = await AssessmentService.createAssessment({
      patientId: testPatient.id,
      assessmentType: 'Hypertension & NCD Screening',
      systolicBp: 148,
      diastolicBp: 94,
      bpPosition: 'Sitting',
      bpArm: 'Right Arm',
      repeatBp: [{ systolic: 144, diastolic: 92, time: '10:05 AM' }],
      observations: 'Repeat measurement after 5 minutes quiet rest.'
    }, testUser);
    const passed = repeatRecord.repeatBp && repeatRecord.repeatBp.length === 1 && repeatRecord.repeatBp[0].systolic === 144;
    log('TEST-05', 'Repeated Blood Pressure Measurement Protocol', passed, `Initial: 148/94, Repeat: ${repeatRecord.repeatBp[0]?.systolic}/${repeatRecord.repeatBp[0]?.diastolic} mmHg`);
  } catch (e) {
    log('TEST-05', 'Repeated Blood Pressure Measurement Protocol', false, e.message);
  }

  // TEST 6: Longitudinal Blood Pressure History & Trends
  try {
    const history = await AssessmentService.getPatientHistory(testPatient.id);
    const passed = history.bpTrends && history.bpTrends.length >= 2;
    log('TEST-06', 'Longitudinal Blood Pressure History Trajectory', passed, `Retrieved ${history.bpTrends.length} historical readings for patient`);
  } catch (e) {
    log('TEST-06', 'Longitudinal Blood Pressure History Trajectory', false, e.message);
  }

  // TEST 7: Diabetes Risk Screening (MDRF / ICMR IDRS Scoring)
  try {
    // Age 38 (20 pts), Waist 84cm Female (20 pts), Moderate activity (10 pts), One parent diabetic (10 pts) = 60 pts (High Risk)
    const idrs = ClinicalCalculators.calculateIdrs({
      waistCm: 84,
      physicalActivity: 'moderate',
      familyHistory: 'one_parent'
    }, { age: 38, gender: 'female' });
    const passed = idrs.score === 60 && idrs.riskTier === 'High Risk';
    log('TEST-07', 'Validated Diabetes Risk Screening (IDRS MDRF/ICMR)', passed, `Calculated IDRS Score: ${idrs.score}/100 (${idrs.riskTier})`);
  } catch (e) {
    log('TEST-07', 'Validated Diabetes Risk Screening (IDRS MDRF/ICMR)', false, e.message);
  }

  // TEST 8: Respiratory Screening & Fast Breathing Triage
  try {
    const resp = ClinicalCalculators.classifyRespiratory(26, 92, 38);
    const passed = resp.oxStatus.tier.includes('Hypoxia') && resp.rrStatus.tier.includes('Tachypnea');
    log('TEST-08', 'Respiratory Screening (Tachypnea & SpO2 Hypoxia Triage)', passed, `Alerts generated: ${resp.alerts.join('; ')}`);
  } catch (e) {
    log('TEST-08', 'Respiratory Screening (Tachypnea & SpO2 Hypoxia Triage)', false, e.message);
  }

  // TEST 9: Child MUAC Malnutrition Screening (SAM / MAM Red/Yellow Zone)
  try {
    const sam = ClinicalCalculators.classifyMuac(11.2, 2);
    const mam = ClinicalCalculators.classifyMuac(12.0, 2);
    const passed = sam.zone === 'Red Zone' && sam.isEmergency && mam.zone === 'Yellow Zone';
    log('TEST-09', 'Child Nutrition & MUAC Malnutrition Triage (WHO SAM/MAM)', passed, `11.2cm -> ${sam.tier} (${sam.zone}), 12.0cm -> ${mam.tier}`);
  } catch (e) {
    log('TEST-09', 'Child Nutrition & MUAC Malnutrition Triage (WHO SAM/MAM)', false, e.message);
  }

  // TEST 10: Maternal Assessment & Preeclampsia Rule
  try {
    const maternalBp = ClinicalCalculators.classifyBloodPressure(152, 98, { age: 26, isPregnant: true });
    const passed = maternalBp.stage.includes('Gestational') && maternalBp.isAlert;
    log('TEST-10', 'Maternal Healthcare ANC Integration & Preeclampsia Rule', passed, `Pregnant BP 152/98 -> ${maternalBp.stage}: ${maternalBp.warning}`);
  } catch (e) {
    log('TEST-10', 'Maternal Healthcare ANC Integration & Preeclampsia Rule', false, e.message);
  }

  // TEST 11: Child Healthcare Growth Linking
  try {
    const childPatient = {
      id: 'pat-test-child-99',
      name: 'Baby Aarav',
      age: 1.5,
      gender: 'male',
      villageHamlet: 'Rampur Hamlet 2',
      isDeleted: false,
      createdAt: new Date().toISOString()
    };
    await db.patients.put(childPatient);

    const childAss = await AssessmentService.createAssessment({
      patientId: childPatient.id,
      assessmentType: 'Child Healthcare',
      height: 78,
      weight: 10.2,
      muacCm: 13.5
    }, testUser);

    const growthRec = await db.growthRecords.where('patientId').equals(childPatient.id).first();
    const passed = Boolean(growthRec && growthRec.weightKg === 10.2);
    log('TEST-11', 'Child Profile & Shared Growth Record Synchronization', passed, `Linked assessment to growth record (Weight: ${growthRec?.weightKg} kg, Height: ${growthRec?.heightCm} cm)`);
  } catch (e) {
    log('TEST-11', 'Child Profile & Shared Growth Record Synchronization', false, e.message);
  }

  // TEST 12: Warning Indicator Trigger & Triage Classification
  let warningAssessment = null;
  try {
    warningAssessment = await AssessmentService.createAssessment({
      patientId: testPatient.id,
      systolicBp: 185,
      diastolicBp: 122,
      spo2: 88,
      symptoms: ['chest_pain', 'breathing_difficulty'],
      observations: 'Patient in acute distress'
    }, testUser);

    const passed = warningAssessment.isEmergency &&
                   warningAssessment.riskLevel === 'urgent_emergency' &&
                   warningAssessment.warningSigns.length >= 2;
    log('TEST-12', 'Configured Warning Indicator & Emergency Classification', passed, `Triggered ${warningAssessment?.warningSigns.length} clinical warnings. Classification: ${warningAssessment?.classification}`);
  } catch (e) {
    log('TEST-12', 'Configured Warning Indicator & Emergency Classification', false, e.message);
  }

  // TEST 13: 1-Click Referral Dispatch from Assessment
  let referral = null;
  try {
    referral = await AssessmentService.createReferralFromAssessment(
      warningAssessment.id,
      {
        referralFacility: 'Mandya District Hospital',
        urgency: 'emergency',
        reason: 'Severe Hypertensive Urgency with Hypoxia'
      },
      testUser
    );

    const updatedAss = await db.healthAssessments.get(warningAssessment.id);
    const passed = Boolean(referral && referral.id && updatedAss.referralId === referral.id);
    log('TEST-13', 'Emergency Referral Creation & Clinical Escalation Linking', passed, `Referral ${referral?.id} linked to assessment ${warningAssessment?.id}`);
  } catch (e) {
    log('TEST-13', 'Emergency Referral Creation & Clinical Escalation Linking', false, e.message);
  }

  // TEST 14: Follow-up Scheduling from Assessment
  let followUp = null;
  try {
    followUp = await AssessmentService.scheduleFollowUpFromAssessment(
      createdAssessment.id,
      {
        scheduledDate: '2026-12-05',
        visitType: 'Routine Community Follow-up'
      },
      testUser
    );

    const updatedAss = await db.healthAssessments.get(createdAssessment.id);
    const passed = Boolean(followUp && followUp.id && updatedAss.followUpId === followUp.id);
    log('TEST-14', 'Follow-up Scheduling & Care Continuity Integration', passed, `Scheduled follow-up ${followUp?.id} on ${followUp?.scheduledDate}`);
  } catch (e) {
    log('TEST-14', 'Follow-up Scheduling & Care Continuity Integration', false, e.message);
  }

  // TEST 15: Downloadable Assessment Summary & Report Structure
  try {
    const full = await AssessmentService.getAssessmentById(warningAssessment.id);
    const passed = Boolean(full && full.patient && full.referral && full.warningSigns && full.vitalSigns);
    log('TEST-15', 'Assessment Summary & Clinical Report Data Structure', passed, `Compiled full report with linked patient, referral (${full?.referral?.referralFacility}), and warnings`);
  } catch (e) {
    log('TEST-15', 'Assessment Summary & Clinical Report Data Structure', false, e.message);
  }

  // TEST 16: Audit Trail on Assessment Revision (Immutable History)
  try {
    const edited = await AssessmentService.updateAssessment(
      createdAssessment.id,
      { systolicBp: 122, diastolicBp: 76 },
      'Corrected transcription error from field logbook',
      testUser
    );

    const passed = edited.version === 2 &&
                   edited.auditHistory &&
                   edited.auditHistory.length >= 2 &&
                   edited.auditHistory[1].reason.includes('transcription error');
    log('TEST-16', 'Assessment Revision with Immutable Audit Trail', passed, `Updated v1 -> v${edited.version}, Audit reason: "${edited.auditHistory[1]?.reason}"`);
  } catch (e) {
    log('TEST-16', 'Assessment Revision with Immutable Audit Trail', false, e.message);
  }

  // TEST 17: Multi-Parameter Filtered Assessment Search
  try {
    const list = await AssessmentService.getAssessments({ search: testPatient.name });
    const passed = list && list.length >= 1 && list[0].patientName === testPatient.name;
    log('TEST-17', 'Offline Search & Multi-Filter Query Engine', passed, `Found ${list.length} assessment records for query "${testPatient.name}"`);
  } catch (e) {
    log('TEST-17', 'Offline Search & Multi-Filter Query Engine', false, e.message);
  }

  // TEST 18: Real-Time Dashboard Statistics Aggregation
  try {
    const stats = await AssessmentService.getDashboardStats();
    const passed = stats.total > 0 && stats.withWarnings >= 1;
    log('TEST-18', 'Real-Time Database Statistics Aggregation', passed, `Total: ${stats.total}, Today: ${stats.today}, Warnings: ${stats.withWarnings}, Referrals: ${stats.pendingReferrals}`);
  } catch (e) {
    log('TEST-18', 'Real-Time Database Statistics Aggregation', false, e.message);
  }

  // TEST 19: Offline Persistence Validation
  try {
    const reloaded = await db.healthAssessments.get(createdAssessment.id);
    const passed = Boolean(reloaded && reloaded.id === createdAssessment.id);
    log('TEST-19', 'Offline IndexedDB Data Persistence', passed, `Persisted assessment ${reloaded?.id} confirmed present in local Dexie store`);
  } catch (e) {
    log('TEST-19', 'Offline IndexedDB Data Persistence', false, e.message);
  }

  // TEST 20: Two-Way Synchronization Queue Integration
  try {
    const queuedItems = await db.syncQueue
      .where('entity')
      .equals('healthAssessments')
      .toArray();
    const passed = queuedItems.length >= 1;
    log('TEST-20', 'Cloud Synchronization Queue Integration', passed, `Found ${queuedItems.length} queued assessment operations ready for cloud push`);
  } catch (e) {
    log('TEST-20', 'Cloud Synchronization Queue Integration', false, e.message);
  }

  // TEST 21: Partial Assessment Handling & Unit Validation
  try {
    const partial = await AssessmentService.createAssessment({
      patientId: testPatient.id,
      assessmentType: 'General Health Screening',
      observations: 'Partial vitals check: blood pressure cuff unavailable in remote hamlet'
    }, testUser);
    const passed = partial.status === 'partial' && partial.systolicBp === null;
    log('TEST-21', 'Partial Assessment Support & Missing Parameter Handling', passed, `Successfully saved partial assessment ${partial?.id} with status: ${partial?.status}`);
  } catch (e) {
    log('TEST-21', 'Partial Assessment Support & Missing Parameter Handling', false, e.message);
  }

  // TEST 22: Clinical Safety Boundary Verification (Zero Unauthorized Diagnosis)
  try {
    const adultBp = ClinicalCalculators.classifyBloodPressure(142, 92);
    // Must contain screening alert and disclaim single reading diagnosis
    const passed = adultBp.stage.includes('Screen') &&
                   adultBp.recommendation.includes('Single reading does not diagnose') &&
                   !adultBp.stage.includes('Diagnosed');
    log('TEST-22', 'Clinical Safety Rule: Screening Alerts Without Medical Diagnosis', passed, `Classification: "${adultBp.stage}". Clinical advisory: "${adultBp.recommendation}"`);
  } catch (e) {
    log('TEST-22', 'Clinical Safety Rule: Screening Alerts Without Medical Diagnosis', false, e.message);
  }

  return results;
}
