/**
 * OFFLINE HEALTH - Clinical Calculators & Decision Support Engine
 * Clinically validated screening rules, age-stratified calculations,
 * and transparent formula evaluations for Community Health Workers.
 *
 * Sources & Citations:
 * 1. WHO Expert Consultation / Consensus Guidelines for Asian Indians (Lancet 2004; ICMR 2020)
 * 2. Indian Hypertension Guidelines (IHS-IV / ACC/AHA Adult Guidelines)
 * 3. Madras Diabetes Research Foundation (MDRF) Indian Diabetes Risk Score (IDRS - Mohan et al.)
 * 4. National Health Mission (NHM) Antenatal Care & Preeclampsia Protocols
 * 5. WHO Child Growth Standards & MUAC Malnutrition Triage (SAM/MAM)
 * 6. Integrated Management of Neonatal & Childhood Illness (IMNCI)
 */

export const ClinicalCalculators = {
  /**
   * 1. BMI Calculation & Population-Specific Interpretation
   * BMI = weight (kg) / [height (m)]^2
   */
  calculateBmi(heightCm, weightKg, patientContext = {}) {
    const h = parseFloat(heightCm);
    const w = parseFloat(weightKg);
    const age = parseInt(patientContext.age, 10);
    const isPregnant = Boolean(patientContext.isPregnant);

    if (!h || !w || h <= 0 || w <= 0 || h > 260 || w > 350) {
      return {
        bmi: null,
        category: 'Incomplete Data',
        color: 'text-slate-400',
        bg: 'bg-slate-100',
        border: 'border-slate-200',
        interpretation: 'Requires valid height and weight measurements.',
        formula: 'BMI = Weight (kg) / [Height (m)]²',
        isValid: false
      };
    }

    const hm = h / 100;
    const bmiVal = parseFloat((w / (hm * hm)).toFixed(1));

    // Special Case 1: Pregnancy
    if (isPregnant) {
      return {
        bmi: bmiVal,
        category: 'Maternal Assessment',
        color: 'text-pink-700',
        bg: 'bg-pink-50',
        border: 'border-pink-200',
        interpretation: `BMI is ${bmiVal} kg/m². Standard non-pregnant adult cutoffs do not apply during active gestation due to physiological fluid and fetal weight gain. Evaluate gestational weight gain per trimester.`,
        source: 'IOM / NHM Maternal Nutrition Guidelines',
        formula: `${w} kg / (${hm.toFixed(2)} m)² = ${bmiVal} kg/m²`,
        isValid: true,
        isPregnant: true
      };
    }

    // Special Case 2: Pediatric / Child under 18 years
    if (!isNaN(age) && age < 18) {
      return {
        bmi: bmiVal,
        category: 'Pediatric Reference Needed',
        color: 'text-indigo-700',
        bg: 'bg-indigo-50',
        border: 'border-indigo-200',
        interpretation: `BMI is ${bmiVal} kg/m². Adult BMI classifications must NOT be applied to children. Refer to WHO age- and sex-specific growth charts and percentiles for pediatric classification.`,
        source: 'WHO Child Growth Standards (0-18 years)',
        formula: `${w} kg / (${hm.toFixed(2)} m)² = ${bmiVal} kg/m²`,
        isValid: true,
        isPediatric: true
      };
    }

    // Adult Asian Indian Consensus Thresholds (ICMR / WHO Asian Cutoffs)
    let category = 'Normal Weight';
    let color = 'text-emerald-700';
    let bg = 'bg-emerald-50';
    let border = 'border-emerald-200';
    let interpretation = 'Healthy weight range according to Asian Indian clinical consensus.';

    if (bmiVal < 18.5) {
      category = 'Underweight';
      color = 'text-amber-700';
      bg = 'bg-amber-50';
      border = 'border-amber-200';
      interpretation = 'Below healthy range. Screen for chronic energy deficiency, nutritional deficits, or underlying illness.';
    } else if (bmiVal >= 18.5 && bmiVal <= 22.9) {
      category = 'Normal Weight';
      color = 'text-emerald-700';
      bg = 'bg-emerald-50';
      border = 'border-emerald-200';
      interpretation = 'Optimal weight associated with lower risk of type 2 diabetes and hypertension in Asian Indian populations.';
    } else if (bmiVal >= 23.0 && bmiVal <= 24.9) {
      category = 'Overweight';
      color = 'text-orange-700';
      bg = 'bg-orange-50';
      border = 'border-orange-200';
      interpretation = 'Increased risk of cardiometabolic disease (Asian Indian cutoff is 23.0 kg/m² vs International 25.0 kg/m²). Recommend dietary and lifestyle counselling.';
    } else {
      category = 'Obese';
      color = 'text-rose-700';
      bg = 'bg-rose-50';
      border = 'border-rose-200';
      interpretation = 'Significantly elevated cardiometabolic risk (Asian Indian cutoff is ≥25.0 kg/m²). Clinical assessment and structured lifestyle intervention advised.';
    }

    return {
      bmi: bmiVal,
      category,
      color,
      bg,
      border,
      interpretation,
      source: 'Consensus Guidelines for Asian Indians (ICMR / Lancet 2004)',
      formula: `${w} kg / (${hm.toFixed(2)} m)² = ${bmiVal} kg/m²`,
      isValid: true
    };
  },

  /**
   * 2. Blood Pressure Classification & Hypertension Triage
   */
  classifyBloodPressure(systolic, diastolic, patientContext = {}) {
    const sys = parseInt(systolic, 10);
    const dia = parseInt(diastolic, 10);
    const isPregnant = Boolean(patientContext.isPregnant);
    const age = parseInt(patientContext.age, 10);

    if (!sys || !dia || isNaN(sys) || isNaN(dia)) {
      return {
        stage: 'Unrecorded',
        color: 'text-slate-400',
        badge: 'bg-slate-100 text-slate-600 border-slate-200',
        recommendation: 'Blood pressure was not recorded.',
        isAlert: false
      };
    }

    // Severe Hypertensive Crisis Alert (Medical Emergency)
    if (sys >= 180 || dia >= 120) {
      return {
        stage: 'Hypertensive Emergency Alert',
        color: 'text-rose-700',
        badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
        recommendation: 'CRITICAL: Severe blood pressure elevation (≥180/120 mmHg). Immediate physician consultation and emergency escalation required. Do not delay care.',
        warning: `Extreme Blood Pressure Elevation: ${sys}/${dia} mmHg`,
        isAlert: true,
        isEmergency: true,
        stageNumber: 4
      };
    }

    // Pregnancy-Specific Hypertension (Pre-eclampsia Alert)
    if (isPregnant) {
      if (sys >= 160 || dia >= 110) {
        return {
          stage: 'Severe Gestational Hypertension',
          color: 'text-rose-700',
          badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
          recommendation: 'OBSTETRIC EMERGENCY: Severe gestational hypertension (≥160/110 mmHg). Immediate referral to FRU / District Hospital for preeclampsia management.',
          warning: `Obstetric Warning: BP ${sys}/${dia} mmHg at active gestation`,
          isAlert: true,
          isEmergency: true,
          stageNumber: 3
        };
      }
      if (sys >= 140 || dia >= 90) {
        return {
          stage: 'Gestational Hypertension Screen',
          color: 'text-amber-800',
          badge: 'bg-amber-100 text-amber-800 border-amber-300 font-bold',
          recommendation: 'HIGH RISK: Blood pressure ≥140/90 mmHg in pregnancy. Check for pre-eclampsia warning signs (headache, vision changes, epigastric pain, proteinuria). Prompt medical officer referral needed.',
          warning: `Elevated Gestational BP: ${sys}/${dia} mmHg`,
          isAlert: true,
          isHighRisk: true,
          stageNumber: 2
        };
      }
      return {
        stage: 'Normotensive (Maternal)',
        color: 'text-emerald-700',
        badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        recommendation: 'Blood pressure is within standard maternal limits. Continue routine ANC monitoring.',
        isAlert: false,
        stageNumber: 0
      };
    }

    // Pediatric Alert
    if (!isNaN(age) && age < 16) {
      if (sys >= 130 || dia >= 85) {
        return {
          stage: 'Pediatric BP Elevated',
          color: 'text-amber-800',
          badge: 'bg-amber-100 text-amber-800 border-amber-300',
          recommendation: 'Blood pressure is elevated for pediatric age. Repeat measurement and refer to Medical Officer for percentile chart assessment.',
          warning: `Pediatric BP Elevated: ${sys}/${dia} mmHg`,
          isAlert: true,
          stageNumber: 2
        };
      }
      return {
        stage: 'Normal Pediatric BP',
        color: 'text-emerald-700',
        badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        recommendation: 'Normal blood pressure for pediatric screening.',
        isAlert: false,
        stageNumber: 0
      };
    }

    // General Adult Classification (ACC/AHA / Indian Hypertension Guidelines)
    if (sys >= 140 || dia >= 90) {
      return {
        stage: 'Stage 2 Hypertension Screen',
        color: 'text-rose-700',
        badge: 'bg-rose-50 text-rose-700 border-rose-200 font-semibold',
        recommendation: 'Blood pressure ≥140/90 mmHg. Screening alert: Single reading does not diagnose hypertension. Rest for 5 minutes, take repeat reading. Schedule clinical evaluation at PHC.',
        warning: `Stage 2 Hypertension Alert (BP ${sys}/${dia} mmHg)`,
        isAlert: true,
        stageNumber: 2
      };
    }

    if ((sys >= 130 && sys <= 139) || (dia >= 80 && dia <= 89)) {
      return {
        stage: 'Stage 1 Hypertension Screen',
        color: 'text-amber-700',
        badge: 'bg-amber-50 text-amber-700 border-amber-200 font-semibold',
        recommendation: 'Blood pressure 130-139 / 80-89 mmHg. Advise dietary salt restriction, exercise, and repeat screening within 2 weeks.',
        warning: `Stage 1 Hypertension Alert (BP ${sys}/${dia} mmHg)`,
        isAlert: false,
        stageNumber: 1
      };
    }

    if (sys >= 120 && sys <= 129 && dia < 80) {
      return {
        stage: 'Elevated Blood Pressure',
        color: 'text-yellow-700',
        badge: 'bg-yellow-50 text-yellow-800 border-yellow-200',
        recommendation: 'Systolic 120-129 mmHg with normal diastolic. Counsel on healthy lifestyle, salt intake, and regular monitoring.',
        isAlert: false,
        stageNumber: 0.5
      };
    }

    return {
      stage: 'Normal Blood Pressure',
      color: 'text-emerald-700',
      badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      recommendation: 'Blood pressure is within standard normal limits (<120/<80 mmHg). Continue regular community wellness checks.',
      isAlert: false,
      stageNumber: 0
    };
  },

  /**
   * 3. Diabetes Risk Screening - Indian Diabetes Risk Score (IDRS)
   * Developed by Madras Diabetes Research Foundation (MDRF) & endorsed by ICMR
   */
  calculateIdrs(answers = {}, patient = {}) {
    const age = parseInt(patient.age, 10) || parseInt(answers.age, 10) || 0;
    let score = 0;
    const breakdown = [];

    // Factor 1: Age
    if (age >= 50) {
      score += 30;
      breakdown.push({ factor: 'Age ≥ 50 years', points: 30 });
    } else if (age >= 35) {
      score += 20;
      breakdown.push({ factor: 'Age 35 - 49 years', points: 20 });
    } else {
      score += 0;
      breakdown.push({ factor: 'Age < 35 years', points: 0 });
    }

    // Factor 2: Abdominal Obesity / Waist Circumference or BMI surrogate
    const waist = parseFloat(answers.waistCm);
    const gender = (patient.gender || answers.gender || 'male').toLowerCase();
    const bmi = parseFloat(answers.bmi);

    if (waist > 0) {
      if ((gender === 'female' && waist >= 80) || (gender !== 'female' && waist >= 90)) {
        score += 20;
        breakdown.push({ factor: `Waist ≥ ${gender === 'female' ? 80 : 90} cm (High abdominal obesity)`, points: 20 });
      } else if ((gender === 'female' && waist >= 70) || (gender !== 'female' && waist >= 80)) {
        score += 10;
        breakdown.push({ factor: `Waist ${gender === 'female' ? '70-79' : '80-89'} cm (Moderate abdominal obesity)`, points: 10 });
      } else {
        breakdown.push({ factor: 'Normal waist circumference', points: 0 });
      }
    } else if (bmi > 0) {
      // BMI surrogate
      if (bmi >= 25.0) {
        score += 20;
        breakdown.push({ factor: 'BMI ≥ 25.0 kg/m² (Surrogate)', points: 20 });
      } else if (bmi >= 23.0) {
        score += 10;
        breakdown.push({ factor: 'BMI 23.0 - 24.9 kg/m² (Surrogate)', points: 10 });
      } else {
        breakdown.push({ factor: 'BMI < 23.0 kg/m²', points: 0 });
      }
    }

    // Factor 3: Physical Activity
    const activity = answers.physicalActivity || 'moderate';
    if (activity === 'sedentary') {
      score += 20;
      breakdown.push({ factor: 'No regular physical activity / Sedentary', points: 20 });
    } else if (activity === 'moderate') {
      score += 10;
      breakdown.push({ factor: 'Moderate physical activity / daily walking', points: 10 });
    } else if (activity === 'strenuous') {
      score += 0;
      breakdown.push({ factor: 'Vigorous exercise / active agricultural labor', points: 0 });
    }

    // Factor 4: Family History of Diabetes
    const famHistory = answers.familyHistory || 'none';
    if (famHistory === 'both_parents') {
      score += 20;
      breakdown.push({ factor: 'Both parents diabetic', points: 20 });
    } else if (famHistory === 'one_parent') {
      score += 10;
      breakdown.push({ factor: 'One parent diabetic', points: 10 });
    } else {
      breakdown.push({ factor: 'No parental diabetes history', points: 0 });
    }

    // Interpretation
    let riskTier = 'Low Risk';
    let color = 'text-emerald-700';
    let badge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    let action = 'Score < 30: Low likelihood of diabetes. Encourage continuing active lifestyle and balanced diet.';

    if (score >= 60) {
      riskTier = 'High Risk';
      color = 'text-rose-700';
      badge = 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
      action = 'Score ≥ 60: High risk of diabetes. Recommend confirmatory capillary blood glucose testing or venous plasma glucose test at PHC.';
    } else if (score >= 30) {
      riskTier = 'Moderate Risk';
      color = 'text-amber-700';
      badge = 'bg-amber-100 text-amber-800 border-amber-300';
      action = 'Score 30 - 50: Moderate risk of diabetes. Provide lifestyle counseling on nutrition, physical activity, and schedule annual screening.';
    }

    return {
      score,
      maxScore: 100,
      riskTier,
      color,
      badge,
      action,
      breakdown,
      citation: 'Indian Diabetes Risk Score (IDRS) - Mohan et al., Journal of Association of Physicians of India'
    };
  },

  /**
   * 4. Blood Glucose Evaluation
   */
  classifyBloodGlucose(value, context = 'random') {
    const glu = parseFloat(value);
    if (!glu || isNaN(glu) || glu <= 0) {
      return { status: 'Unrecorded', isAlert: false };
    }

    // Hypoglycemia Emergency Alert
    if (glu < 70) {
      return {
        status: 'Hypoglycemia Alert',
        color: 'text-rose-700',
        badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
        recommendation: 'URGENT: Blood glucose is abnormally low (<70 mg/dL). If patient is conscious, administer 15-20g of fast-acting oral glucose/sugar immediately and recheck in 15 minutes. Escalate to Medical Officer.',
        warning: `Critical Hypoglycemia Alert: ${glu} mg/dL (${context})`,
        isEmergency: true,
        isAlert: true
      };
    }

    // Severe Hyperglycemia
    if (glu >= 300) {
      return {
        status: 'Severe Hyperglycemia',
        color: 'text-rose-700',
        badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
        recommendation: 'URGENT: Severe blood glucose elevation (≥300 mg/dL). Assess for dehydration, deep breathing, and ketoacidosis warning signs. Immediate referral to PHC/CHC.',
        warning: `Severe Hyperglycemia Alert: ${glu} mg/dL (${context})`,
        isEmergency: true,
        isAlert: true
      };
    }

    if (context === 'fasting') {
      if (glu >= 126) {
        return {
          status: 'Diabetic Range (Fasting)',
          color: 'text-rose-700',
          badge: 'bg-rose-50 text-rose-700 border-rose-200',
          recommendation: 'Fasting glucose ≥126 mg/dL. Screening indication of possible diabetes. Confirmatory testing and physician evaluation recommended.',
          warning: `Elevated Fasting Glucose: ${glu} mg/dL`,
          isAlert: true
        };
      }
      if (glu >= 100 && glu <= 125) {
        return {
          status: 'Impaired Fasting Glucose (Pre-diabetes)',
          color: 'text-amber-700',
          badge: 'bg-amber-50 text-amber-700 border-amber-200',
          recommendation: 'Fasting glucose 100-125 mg/dL. Pre-diabetes range. Advise lifestyle intervention and recheck in 3-6 months.',
          isAlert: false
        };
      }
      return {
        status: 'Normal Fasting Glucose',
        color: 'text-emerald-700',
        badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        recommendation: 'Normal fasting blood glucose (<100 mg/dL).',
        isAlert: false
      };
    }

    // Default: Random Blood Glucose (RBG)
    if (glu >= 200) {
      return {
        status: 'Diabetic Range (Random)',
        color: 'text-rose-700',
        badge: 'bg-rose-50 text-rose-700 border-rose-200 font-semibold',
        recommendation: 'Random glucose ≥200 mg/dL. Screening indication of possible diabetes, especially if accompanied by classic symptoms (polyuria, polydipsia). Referral to Medical Officer required.',
        warning: `Elevated Random Blood Glucose: ${glu} mg/dL`,
        isAlert: true
      };
    }
    if (glu >= 140 && glu <= 199) {
      return {
        status: 'Impaired Glucose Tolerance',
        color: 'text-amber-700',
        badge: 'bg-amber-50 text-amber-700 border-amber-200',
        recommendation: 'Random glucose 140-199 mg/dL. Recommend confirmatory fasting plasma glucose testing.',
        isAlert: false
      };
    }

    return {
      status: 'Normal Blood Glucose',
      color: 'text-emerald-700',
      badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      recommendation: 'Random blood glucose is within expected normal limits (<140 mg/dL).',
      isAlert: false
    };
  },

  /**
   * 5. MUAC Malnutrition Triage for Children (6 to 59 Months)
   */
  classifyMuac(muacCm, ageYears = 2) {
    const m = parseFloat(muacCm);
    if (!m || isNaN(m) || m <= 0) return null;

    if (m < 11.5) {
      return {
        tier: 'Severe Acute Malnutrition (SAM)',
        color: 'text-rose-700',
        badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
        zone: 'Red Zone',
        recommendation: 'CRITICAL: MUAC < 11.5 cm indicates Severe Acute Malnutrition (SAM). Immediate referral to Nutrition Rehabilitation Centre (NRC) or Taluka Hospital required.',
        warning: `SAM Red Zone Alert: MUAC ${m} cm`,
        isAlert: true,
        isEmergency: true
      };
    }
    if (m >= 11.5 && m <= 12.4) {
      return {
        tier: 'Moderate Acute Malnutrition (MAM)',
        color: 'text-amber-800',
        badge: 'bg-amber-100 text-amber-800 border-amber-300 font-bold',
        zone: 'Yellow Zone',
        recommendation: 'WARNING: MUAC 11.5 - 12.4 cm indicates Moderate Acute Malnutrition. Enroll in Supplementary Nutrition Programme (Anganwadi) and conduct weekly monitoring.',
        warning: `MAM Yellow Zone: MUAC ${m} cm`,
        isAlert: true
      };
    }
    return {
      tier: 'Normal Nutritional Status',
      color: 'text-emerald-700',
      badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      zone: 'Green Zone',
      recommendation: 'MUAC ≥ 12.5 cm is within healthy green zone. Continue age-appropriate complementary feeding.',
      isAlert: false
    };
  },

  /**
   * 6. Respiratory Screening (Respiratory Rate & SpO2)
   */
  classifyRespiratory(rr, spo2, ageYears = 30) {
    const rate = parseInt(rr, 10);
    const ox = parseInt(spo2, 10);
    const alerts = [];
    let isEmergency = false;

    // SpO2 Hypoxia Screening
    let oxStatus = null;
    if (ox > 0) {
      if (ox < 90) {
        oxStatus = {
          tier: 'Severe Hypoxia (Emergency)',
          color: 'text-rose-700',
          badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
          recommendation: 'CRITICAL: Severe oxygen desaturation (SpO2 < 90%). Emergency oxygenation and immediate referral to Secondary/Tertiary care facility required.',
          isEmergency: true
        };
        alerts.push(`Severe Hypoxia Alert: SpO2 ${ox}%`);
        isEmergency = true;
      } else if (ox >= 90 && ox <= 94) {
        oxStatus = {
          tier: 'Mild-to-Moderate Hypoxia',
          color: 'text-amber-800',
          badge: 'bg-amber-100 text-amber-800 border-amber-300 font-bold',
          recommendation: 'SpO2 90-94% indicates compromised oxygen saturation. Evaluate for asthma, pneumonia, or respiratory distress. Medical Officer review recommended.',
          isEmergency: false
        };
        alerts.push(`Hypoxia Warning: SpO2 ${ox}%`);
      } else {
        oxStatus = {
          tier: 'Normal Oxygen Saturation',
          color: 'text-emerald-700',
          badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          recommendation: 'SpO2 is within healthy standard range (≥95%).'
        };
      }
    }

    // Respiratory Rate Triage
    let rrStatus = null;
    if (rate > 0) {
      let isFastBreathing = false;
      let threshold = 20;

      if (ageYears < 1) {
        threshold = 50;
        isFastBreathing = rate >= 50;
      } else if (ageYears < 5) {
        threshold = 40;
        isFastBreathing = rate >= 40;
      } else {
        threshold = 24;
        isFastBreathing = rate >= 24;
      }

      if (isFastBreathing) {
        rrStatus = {
          tier: 'Tachypnea / Rapid Breathing',
          color: 'text-rose-700',
          badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
          recommendation: `Fast breathing detected (≥${threshold} breaths/min). Screen for pneumonia, acute respiratory infection, or acidosis. Immediate clinical check advised.`
        };
        alerts.push(`Rapid Breathing Alert: ${rate} breaths/min`);
      } else if (rate < 10) {
        rrStatus = {
          tier: 'Bradypnea / Abnormally Slow',
          color: 'text-rose-700',
          badge: 'bg-rose-100 text-rose-800 border-rose-300 font-bold',
          recommendation: 'Respiratory rate < 10 breaths/min. Screen for central nervous depression or severe respiratory fatigue.'
        };
        alerts.push(`Bradypnea Alert: ${rate} breaths/min`);
        isEmergency = true;
      } else {
        rrStatus = {
          tier: 'Normal Respiratory Rate',
          color: 'text-emerald-700',
          badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          recommendation: 'Respiratory rate is within age-appropriate baseline.'
        };
      }
    }

    return {
      oxStatus,
      rrStatus,
      alerts,
      isEmergency
    };
  },

  /**
   * 7. Comprehensive Assessment Evaluator
   * Aggregates all indicators, calculates overall score, and flags urgent escalation requirements.
   */
  evaluateAssessment(data = {}, patient = {}) {
    const warnings = [];
    let isEmergency = false;
    let requiresFollowUp = false;

    // 1. Vitals Evaluation
    const bpResult = this.classifyBloodPressure(data.systolicBp, data.diastolicBp, patient);
    if (bpResult.warning) {
      warnings.push(bpResult.warning);
      if (bpResult.isEmergency) isEmergency = true;
      else requiresFollowUp = true;
    }

    const gluResult = this.classifyBloodGlucose(data.bloodGlucose, data.glucoseContext || 'random');
    if (gluResult.warning) {
      warnings.push(gluResult.warning);
      if (gluResult.isEmergency) isEmergency = true;
      else requiresFollowUp = true;
    }

    const respResult = this.classifyRespiratory(data.respiratoryRate, data.spo2, patient.age || 30);
    if (respResult.alerts && respResult.alerts.length > 0) {
      warnings.push(...respResult.alerts);
      if (respResult.isEmergency) isEmergency = true;
      else requiresFollowUp = true;
    }

    // 2. Temperature Screening
    const temp = parseFloat(data.temperature);
    if (temp >= 38.5) {
      warnings.push(`High Fever Warning: ${temp}°C`);
      requiresFollowUp = true;
    } else if (temp >= 40.0) {
      warnings.push(`Hyperpyrexia Critical Alert: ${temp}°C`);
      isEmergency = true;
    }

    // 3. Nutrition & MUAC
    if (data.muacCm) {
      const muacRes = this.classifyMuac(data.muacCm, patient.age);
      if (muacRes && muacRes.warning) {
        warnings.push(muacRes.warning);
        if (muacRes.isEmergency) isEmergency = true;
        else requiresFollowUp = true;
      }
    }

    // 4. Symptoms Danger Signs
    const symptoms = data.symptoms || [];
    if (symptoms.includes('chest_pain') && (symptoms.includes('breathing_difficulty') || symptoms.includes('dizziness'))) {
      warnings.push('Acute Coronary Syndrome Risk: Chest discomfort with shortness of breath');
      isEmergency = true;
    }
    if (symptoms.includes('stiff_neck') && symptoms.includes('fever')) {
      warnings.push('Meningeal Sign Warning: Fever accompanied by neck stiffness');
      isEmergency = true;
    }
    if (patient.isPregnant && (symptoms.includes('severe_headache') || symptoms.includes('blurred_vision') || symptoms.includes('vaginal_bleeding'))) {
      warnings.push('Maternal Danger Sign: Neurological or bleeding symptom in pregnancy');
      isEmergency = true;
    }

    // Overall Classification
    let classification = 'Recorded';
    let overallBadge = 'bg-slate-100 text-slate-800 border-slate-200';
    let riskTier = 'normal';

    if (isEmergency) {
      classification = 'Urgent Clinical Escalation Required';
      overallBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-extrabold';
      riskTier = 'urgent_emergency';
    } else if (warnings.length > 0) {
      classification = 'Warning Indicator Detected';
      overallBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
      riskTier = 'warning_detected';
    } else if (requiresFollowUp) {
      classification = 'Requires Clinical Follow-up';
      overallBadge = 'bg-blue-100 text-blue-800 border-blue-300 font-semibold';
      riskTier = 'requires_follow_up';
    } else {
      classification = 'Normal According to Screening Rules';
      overallBadge = 'bg-emerald-100 text-emerald-800 border-emerald-300 font-semibold';
      riskTier = 'normal';
    }

    return {
      warnings,
      isEmergency,
      requiresFollowUp,
      classification,
      overallBadge,
      riskTier,
      bpResult,
      gluResult,
      respResult
    };
  },

  /**
   * 8. Estimated Date of Delivery (EDD) Calculator (Naegele's Rule)
   * Formula: EDD = LMP + 280 days (or LMP + 1 year - 3 months + 7 days)
   * Citation: ACOG / National Health Mission (NHM) Antenatal Guidelines
   */
  calculateEdd(lmpDate) {
    if (!lmpDate) return { edd: null, formatted: 'LMP required', isValid: false };

    const lmp = new Date(lmpDate);
    if (isNaN(lmp.getTime())) {
      return { edd: null, formatted: 'Invalid LMP date', isValid: false };
    }

    // Add 280 days (40 weeks) to LMP
    const edd = new Date(lmp.getTime() + (280 * 24 * 60 * 60 * 1000));
    const isoString = edd.toISOString().slice(0, 10);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    const formatted = edd.toLocaleDateString('en-IN', options);

    return {
      edd: isoString,
      formatted,
      formula: "Naegele's Rule: LMP + 280 days (40 completed weeks)",
      citation: 'ACOG / National Health Mission (NHM) Antenatal Guidelines',
      isValid: true
    };
  },

  /**
   * 9. Gestational Age Calculation (Weeks & Days) & Trimester Assessment
   */
  calculateGestationalAge(lmpDate, asOfDate = new Date()) {
    if (!lmpDate) {
      return { weeks: 0, days: 0, trimester: 1, text: 'LMP not set', isValid: false };
    }

    const lmp = new Date(lmpDate);
    const current = new Date(asOfDate);
    if (isNaN(lmp.getTime()) || isNaN(current.getTime())) {
      return { weeks: 0, days: 0, trimester: 1, text: 'Invalid date', isValid: false };
    }

    const diffMs = current.getTime() - lmp.getTime();
    if (diffMs < 0) {
      return { weeks: 0, days: 0, trimester: 1, text: 'LMP in future', isValid: false };
    }

    const totalDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
    const weeks = Math.floor(totalDays / 7);
    const remainingDays = totalDays % 7;

    let trimester = 1;
    let trimesterLabel = '1st Trimester';
    let trimesterBadge = 'bg-blue-100 text-blue-800 border-blue-200';
    if (weeks >= 28) {
      trimester = 3;
      trimesterLabel = '3rd Trimester';
      trimesterBadge = 'bg-pink-100 text-pink-800 border-pink-300 font-bold';
    } else if (weeks >= 13) {
      trimester = 2;
      trimesterLabel = '2nd Trimester';
      trimesterBadge = 'bg-teal-100 text-teal-800 border-teal-200';
    }

    const isPostTerm = weeks >= 41;
    const progressPercent = Math.min(100, Math.round((totalDays / 280) * 100));
    const daysToEdd = Math.max(0, 280 - totalDays);

    return {
      weeks,
      days: remainingDays,
      totalDays,
      trimester,
      trimesterLabel,
      trimesterBadge,
      progressPercent,
      daysToEdd,
      isPostTerm,
      text: `${weeks}w ${remainingDays}d`,
      longText: `${weeks} weeks ${remainingDays} days (${trimesterLabel})`,
      isValid: true
    };
  },

  /**
   * 10. High-Risk Pregnancy (HRP) Stratification & Danger Sign Evaluation
   * Evaluates maternal history, obstetric background, and current vitals.
   * Citations: NHM Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA) / WHO
   */
  evaluateHighRiskPregnancy(maternalData = {}, vitals = {}) {
    const riskFactors = [];
    let isEmergency = false;
    let isHighRisk = false;

    const age = parseInt(maternalData.age, 10);
    const gravidity = parseInt(maternalData.gravidity, 10);
    const parity = parseInt(maternalData.parity, 10);
    const sys = parseInt(vitals.systolicBp, 10);
    const dia = parseInt(vitals.diastolicBp, 10);
    const hb = parseFloat(vitals.hemoglobin);
    const urineProtein = (vitals.urineProtein || '').toLowerCase();
    const symptoms = maternalData.symptoms || vitals.symptoms || [];

    // Demographic & Obstetric History Risks
    if (!isNaN(age)) {
      if (age < 18) {
        riskFactors.push({ category: 'Maternal Age', factor: 'Teenage Pregnancy (< 18 years)', severity: 'high' });
        isHighRisk = true;
      } else if (age >= 35) {
        riskFactors.push({ category: 'Maternal Age', factor: 'Advanced Maternal Age (≥ 35 years)', severity: 'moderate' });
        isHighRisk = true;
      }
    }

    if (parity >= 4) {
      riskFactors.push({ category: 'Obstetric History', factor: 'Grand Multipara (Parity ≥ 4)', severity: 'moderate' });
      isHighRisk = true;
    }

    if (maternalData.previousCesarean || (maternalData.highRiskFactors || []).includes('Previous Caesarean Section')) {
      riskFactors.push({ category: 'Surgical History', factor: 'Previous Caesarean Section (Scarred Uterus)', severity: 'high' });
      isHighRisk = true;
    }

    if (maternalData.previousStillbirth || (maternalData.highRiskFactors || []).includes('Previous Stillbirth / Recurrent Abortion')) {
      riskFactors.push({ category: 'Obstetric History', factor: 'History of previous stillbirth / recurrent pregnancy loss', severity: 'high' });
      isHighRisk = true;
    }

    if (maternalData.isMultipleGestation || (maternalData.highRiskFactors || []).includes('Multiple Gestation (Twins)')) {
      riskFactors.push({ category: 'Gestational Risk', factor: 'Multiple Gestation (Twins/Multiples)', severity: 'high' });
      isHighRisk = true;
    }

    // Clinical Vitals Risks: Hypertension / Preeclampsia
    if (sys >= 160 || dia >= 110) {
      riskFactors.push({ category: 'Vitals Alert', factor: `Severe Gestational Hypertension (${sys}/${dia} mmHg)`, severity: 'critical' });
      isEmergency = true;
      isHighRisk = true;
    } else if (sys >= 140 || dia >= 90) {
      if (urineProtein && urineProtein !== 'nil' && urineProtein !== 'negative') {
        riskFactors.push({ category: 'Vitals Alert', factor: `Preeclampsia Screen Positive (BP ${sys}/${dia} with Proteinuria ${urineProtein.toUpperCase()})`, severity: 'critical' });
        isEmergency = true;
      } else {
        riskFactors.push({ category: 'Vitals Alert', factor: `Gestational Hypertension (${sys}/${dia} mmHg)`, severity: 'high' });
      }
      isHighRisk = true;
    }

    // Anemia Screening (Hemoglobin g/dL)
    if (!isNaN(hb) && hb > 0) {
      if (hb < 7.0) {
        riskFactors.push({ category: 'Laboratory', factor: `Severe Anemia (Hb ${hb} g/dL - Immediate transfusion/IV iron referral required)`, severity: 'critical' });
        isEmergency = true;
        isHighRisk = true;
      } else if (hb < 11.0) {
        riskFactors.push({ category: 'Laboratory', factor: `Anemia in Pregnancy (Hb ${hb} g/dL - Therapeutic Iron-Folic Acid required)`, severity: 'moderate' });
        isHighRisk = true;
      }
    }

    // Obstetric Red Flags / Danger Signs
    if (symptoms.includes('vaginal_bleeding')) {
      riskFactors.push({ category: 'Obstetric Danger Sign', factor: 'Antepartum Hemorrhage (Vaginal Bleeding)', severity: 'critical' });
      isEmergency = true;
      isHighRisk = true;
    }
    if (symptoms.includes('severe_headache') || symptoms.includes('blurred_vision')) {
      riskFactors.push({ category: 'Neurological Sign', factor: 'Severe persistent headache or visual blurring (Imminent Eclampsia)', severity: 'critical' });
      isEmergency = true;
      isHighRisk = true;
    }
    if (symptoms.includes('convulsions')) {
      riskFactors.push({ category: 'Obstetric Emergency', factor: 'Convulsions / Fits (Eclampsia Alert)', severity: 'critical' });
      isEmergency = true;
      isHighRisk = true;
    }
    if (symptoms.includes('decreased_fetal_movement')) {
      riskFactors.push({ category: 'Fetal Wellbeing', factor: 'Reduced or absent fetal movements', severity: 'high' });
      isHighRisk = true;
    }

    let riskTier = 'Normal Risk';
    let badge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    let actionRecommendation = 'Routine Antenatal Care (ANC) surveillance. Continue IFA tablets and balanced nutrition.';

    if (isEmergency) {
      riskTier = 'Obstetric Emergency';
      badge = 'bg-rose-100 text-rose-800 border-rose-300 font-extrabold';
      actionRecommendation = 'IMMEDIATE EMERGENCY ESCALATION: Transport to First Referral Unit (FRU) / District Hospital via 108 Ambulance. Notify Medical Officer.';
    } else if (isHighRisk) {
      riskTier = 'High-Risk Pregnancy (HRP)';
      badge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
      actionRecommendation = 'HIGH-RISK PREGNANCY: Schedule specialist review at PMSMA clinic on 9th of the month. Intensified home visit monitoring required.';
    }

    return {
      isHighRisk,
      isEmergency,
      riskTier,
      badge,
      riskFactors,
      count: riskFactors.length,
      actionRecommendation,
      guidelineSource: 'NHM PMSMA Protocol / Guidelines on High Risk Pregnancy'
    };
  },

  /**
   * 11. National Health Mission Standard ANC Visit Schedule
   */
  getAncSchedule(lmpDate, existingVisits = []) {
    if (!lmpDate) return [];

    const lmp = new Date(lmpDate);
    const msPerDay = 24 * 60 * 60 * 1000;

    const schedule = [
      {
        visitNumber: 1,
        title: 'ANC 1 (Early Registration)',
        timingWeeks: 'Within 12 weeks',
        idealDays: 70, // ~10 weeks
        targetDueDate: new Date(lmp.getTime() + (70 * msPerDay)).toISOString().slice(0, 10),
        keyActivities: ['LMP confirmation & EDD calculation', 'Baseline BP & Weight', 'Hemoglobin & Blood Grouping', 'Urine Albumin & Sugar', 'First Tetanus Toxoid (TT-1/Td)', 'IFA Tablets (after 1st trimester)'],
        completed: false,
        visitData: null
      },
      {
        visitNumber: 2,
        title: 'ANC 2 (Second Trimester)',
        timingWeeks: '14 - 26 weeks',
        idealDays: 140, // ~20 weeks
        targetDueDate: new Date(lmp.getTime() + (140 * msPerDay)).toISOString().slice(0, 10),
        keyActivities: ['Fundal Height & Fetal Heart Rate (FHR)', 'BP & Weight gain monitoring', 'Second Td/TT (4 weeks after TT-1)', 'Calcium & Iron supplementation', 'Anomaly Ultrasound Screen referral'],
        completed: false,
        visitData: null
      },
      {
        visitNumber: 3,
        title: 'ANC 3 (Third Trimester)',
        timingWeeks: '28 - 34 weeks',
        idealDays: 210, // ~30 weeks
        targetDueDate: new Date(lmp.getTime() + (210 * msPerDay)).toISOString().slice(0, 10),
        keyActivities: ['Fetal lie & presentation check', 'Preeclampsia screening (BP + Urine)', 'Repeat Hemoglobin for late anemia', 'Birth preparedness & Institutional delivery plan', '108 Ambulance orientation'],
        completed: false,
        visitData: null
      },
      {
        visitNumber: 4,
        title: 'ANC 4 (Pre-delivery Check)',
        timingWeeks: '36 - 40 weeks',
        idealDays: 259, // ~37 weeks
        targetDueDate: new Date(lmp.getTime() + (259 * msPerDay)).toISOString().slice(0, 10),
        keyActivities: ['Fetal engagement assessment', 'Identify danger signs (leaking, bleeding)', 'Confirm birth companion & hospital transport', 'Newborn care & early breastfeeding counseling'],
        completed: false,
        visitData: null
      }
    ];

    // Map existing visits
    existingVisits.forEach(v => {
      const num = parseInt(v.visitNumber, 10);
      const match = schedule.find(s => s.visitNumber === num);
      if (match) {
        match.completed = true;
        match.visitData = v;
      }
    });

    return schedule;
  },

  /**
   * 12. Pediatric Birth Weight & Gestational Classification
   * Citations: WHO / National Neonatology Forum (NNF) India
   */
  classifyBirthWeight(weightKg, gestationalWeeks = 38) {
    const w = parseFloat(weightKg);
    const g = parseInt(gestationalWeeks, 10);

    if (!w || isNaN(w) || w <= 0) {
      return { tier: 'Unknown', isLbw: false, isPreterm: false, badge: 'bg-slate-100 text-slate-700' };
    }

    let isLbw = false;
    let isVlbw = false;
    let weightTier = 'Normal Birth Weight (≥ 2.5 kg)';
    let weightBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    let recommendation = 'Standard newborn thermal care and exclusive breastfeeding for first 6 months.';

    if (w < 1.5) {
      isVlbw = true;
      isLbw = true;
      weightTier = 'Very Low Birth Weight (VLBW < 1.5 kg)';
      weightBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
      recommendation = 'NEONATAL CRITICAL: Very Low Birth Weight. Requires Special Newborn Care Unit (SNCU) admission and intensive monitoring.';
    } else if (w < 2.5) {
      isLbw = true;
      weightTier = 'Low Birth Weight (LBW < 2.5 kg)';
      weightBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
      recommendation = 'Provide Kangaroo Mother Care (KMC), frequent breastfeeding (every 2h), and weekly weight checks.';
    }

    const isPreterm = !isNaN(g) && g < 37;
    const termTier = isPreterm ? `Preterm Infant (${g} weeks)` : `Full Term (${g} weeks)`;

    return {
      weightKg: w,
      weightTier,
      weightBadge,
      isLbw,
      isVlbw,
      isPreterm,
      termTier,
      recommendation,
      guidelineSource: 'WHO / NNF India Neonatal Care Guidelines'
    };
  },

  /**
   * 13. Universal Immunization Programme (UIP) India Schedule
   * Automatic milestone calculation from Child Date of Birth (DOB).
   * Citations: Ministry of Health & Family Welfare (MoHFW) / WHO UIP India
   */
  getUipImmunizationSchedule(dob, administeredList = []) {
    if (!dob) return [];

    const birthDate = new Date(dob);
    if (isNaN(birthDate.getTime())) return [];

    const msPerDay = 24 * 60 * 60 * 1000;
    const now = new Date();

    const addDays = (d, days) => new Date(d.getTime() + (days * msPerDay)).toISOString().slice(0, 10);

    const baseSchedule = [
      // At Birth
      {
        vaccineKey: 'BCG',
        vaccineName: 'BCG (Bacillus Calmette-Guérin)',
        doseNumber: 1,
        milestone: 'At Birth (or up to 1 yr)',
        targetDueDate: addDays(birthDate, 0),
        route: 'Intradermal (Left upper arm)',
        protectsAgainst: 'Tuberculosis (Miliary & Meningeal TB)'
      },
      {
        vaccineKey: 'OPV-0',
        vaccineName: 'OPV-0 (Oral Polio Vaccine)',
        doseNumber: 0,
        milestone: 'At Birth (within 15 days)',
        targetDueDate: addDays(birthDate, 0),
        route: 'Oral (2 drops)',
        protectsAgainst: 'Poliomyelitis'
      },
      {
        vaccineKey: 'HepB-0',
        vaccineName: 'Hepatitis B (Birth Dose)',
        doseNumber: 0,
        milestone: 'At Birth (within 24 hours)',
        targetDueDate: addDays(birthDate, 0),
        route: 'Intramuscular (Anterolateral mid-thigh)',
        protectsAgainst: 'Perinatal Hepatitis B Transmission'
      },

      // 6 Weeks (42 days)
      {
        vaccineKey: 'Penta-1',
        vaccineName: 'Pentavalent-1 (DPT + HepB + Hib)',
        doseNumber: 1,
        milestone: '6 Weeks',
        targetDueDate: addDays(birthDate, 42),
        route: 'Intramuscular (Left mid-thigh)',
        protectsAgainst: 'Diphtheria, Pertussis, Tetanus, Hepatitis B, Hib Pneumonia'
      },
      {
        vaccineKey: 'OPV-1',
        vaccineName: 'OPV-1 (Oral Polio Vaccine)',
        doseNumber: 1,
        milestone: '6 Weeks',
        targetDueDate: addDays(birthDate, 42),
        route: 'Oral (2 drops)',
        protectsAgainst: 'Poliomyelitis'
      },
      {
        vaccineKey: 'Rota-1',
        vaccineName: 'Rotavirus Vaccine (RVV-1)',
        doseNumber: 1,
        milestone: '6 Weeks',
        targetDueDate: addDays(birthDate, 42),
        route: 'Oral (5 drops)',
        protectsAgainst: 'Rotaviral Diarrhea'
      },
      {
        vaccineKey: 'fIPV-1',
        vaccineName: 'Fractional IPV-1',
        doseNumber: 1,
        milestone: '6 Weeks',
        targetDueDate: addDays(birthDate, 42),
        route: 'Intradermal (Right upper arm)',
        protectsAgainst: 'Poliomyelitis booster'
      },
      {
        vaccineKey: 'PCV-1',
        vaccineName: 'Pneumococcal Conjugate Vaccine (PCV-1)',
        doseNumber: 1,
        milestone: '6 Weeks',
        targetDueDate: addDays(birthDate, 42),
        route: 'Intramuscular (Right mid-thigh)',
        protectsAgainst: 'Pneumococcal Pneumonia & Meningitis'
      },

      // 10 Weeks (70 days)
      {
        vaccineKey: 'Penta-2',
        vaccineName: 'Pentavalent-2',
        doseNumber: 2,
        milestone: '10 Weeks',
        targetDueDate: addDays(birthDate, 70),
        route: 'Intramuscular (Left mid-thigh)',
        protectsAgainst: 'Diphtheria, Pertussis, Tetanus, Hepatitis B, Hib'
      },
      {
        vaccineKey: 'OPV-2',
        vaccineName: 'OPV-2',
        doseNumber: 2,
        milestone: '10 Weeks',
        targetDueDate: addDays(birthDate, 70),
        route: 'Oral (2 drops)',
        protectsAgainst: 'Poliomyelitis'
      },
      {
        vaccineKey: 'Rota-2',
        vaccineName: 'Rotavirus Vaccine (RVV-2)',
        doseNumber: 2,
        milestone: '10 Weeks',
        targetDueDate: addDays(birthDate, 70),
        route: 'Oral (5 drops)',
        protectsAgainst: 'Rotaviral Diarrhea'
      },

      // 14 Weeks (98 days)
      {
        vaccineKey: 'Penta-3',
        vaccineName: 'Pentavalent-3',
        doseNumber: 3,
        milestone: '14 Weeks',
        targetDueDate: addDays(birthDate, 98),
        route: 'Intramuscular (Left mid-thigh)',
        protectsAgainst: 'Diphtheria, Pertussis, Tetanus, Hepatitis B, Hib'
      },
      {
        vaccineKey: 'OPV-3',
        vaccineName: 'OPV-3',
        doseNumber: 3,
        milestone: '14 Weeks',
        targetDueDate: addDays(birthDate, 98),
        route: 'Oral (2 drops)',
        protectsAgainst: 'Poliomyelitis'
      },
      {
        vaccineKey: 'Rota-3',
        vaccineName: 'Rotavirus Vaccine (RVV-3)',
        doseNumber: 3,
        milestone: '14 Weeks',
        targetDueDate: addDays(birthDate, 98),
        route: 'Oral (5 drops)',
        protectsAgainst: 'Rotaviral Diarrhea'
      },
      {
        vaccineKey: 'fIPV-2',
        vaccineName: 'Fractional IPV-2',
        doseNumber: 2,
        milestone: '14 Weeks',
        targetDueDate: addDays(birthDate, 98),
        route: 'Intradermal (Right upper arm)',
        protectsAgainst: 'Poliomyelitis'
      },
      {
        vaccineKey: 'PCV-2',
        vaccineName: 'PCV-2',
        doseNumber: 2,
        milestone: '14 Weeks',
        targetDueDate: addDays(birthDate, 98),
        route: 'Intramuscular (Right mid-thigh)',
        protectsAgainst: 'Pneumococcal infections'
      },

      // 9 - 12 Months (270 days)
      {
        vaccineKey: 'MR-1',
        vaccineName: 'Measles & Rubella-1 (MR-1)',
        doseNumber: 1,
        milestone: '9 - 12 Months',
        targetDueDate: addDays(birthDate, 274),
        route: 'Subcutaneous (Right upper arm)',
        protectsAgainst: 'Measles & Congenital Rubella Syndrome'
      },
      {
        vaccineKey: 'PCV-Booster',
        vaccineName: 'PCV Booster',
        doseNumber: 3,
        milestone: '9 - 12 Months',
        targetDueDate: addDays(birthDate, 274),
        route: 'Intramuscular (Right mid-thigh)',
        protectsAgainst: 'Pneumococcal booster'
      },
      {
        vaccineKey: 'VitA-1',
        vaccineName: 'Vitamin A (1st Dose - 1 Lakh IU)',
        doseNumber: 1,
        milestone: '9 Months (with MR-1)',
        targetDueDate: addDays(birthDate, 274),
        route: 'Oral (1 ml syrup)',
        protectsAgainst: 'Night Blindness & Childhood Morbidity'
      },

      // 16 - 24 Months (500 days)
      {
        vaccineKey: 'MR-2',
        vaccineName: 'Measles & Rubella-2 (MR-2)',
        doseNumber: 2,
        milestone: '16 - 24 Months',
        targetDueDate: addDays(birthDate, 500),
        route: 'Subcutaneous (Right upper arm)',
        protectsAgainst: 'Measles & Rubella immunity reinforcement'
      },
      {
        vaccineKey: 'DPT-B1',
        vaccineName: 'DPT Booster-1',
        doseNumber: 1,
        milestone: '16 - 24 Months',
        targetDueDate: addDays(birthDate, 500),
        route: 'Intramuscular (Left mid-thigh)',
        protectsAgainst: 'Diphtheria, Pertussis, Tetanus booster'
      },
      {
        vaccineKey: 'OPV-Booster',
        vaccineName: 'OPV Booster',
        doseNumber: 1,
        milestone: '16 - 24 Months',
        targetDueDate: addDays(birthDate, 500),
        route: 'Oral (2 drops)',
        protectsAgainst: 'Polio booster'
      }
    ];

    // Map administered records
    return baseSchedule.map(vax => {
      const match = administeredList.find(a =>
        a.vaccineName?.toLowerCase().includes(vax.vaccineKey.toLowerCase()) ||
        a.vaccineName?.toLowerCase() === vax.vaccineName.toLowerCase() ||
        (a.vaccineKey && a.vaccineKey.toLowerCase() === vax.vaccineKey.toLowerCase())
      );

      const isDue = new Date(vax.targetDueDate) <= now;
      let status = 'scheduled';
      let givenDate = null;
      let administeredBy = null;

      if (match && (match.status === 'administered' || match.givenDate)) {
        status = 'administered';
        givenDate = match.givenDate;
        administeredBy = match.administeredBy;
      } else if (isDue) {
        status = 'overdue';
      }

      return {
        ...vax,
        status,
        givenDate,
        administeredBy,
        recordId: match?.id || null
      };
    });
  },

  /**
   * 14. Comprehensive Pediatric Growth & Malnutrition Classification
   * Evaluates weight-for-age, height-for-age (stunting), and MUAC (wasting/SAM/MAM).
   * Citations: WHO Child Growth Standards (2006) / IMNCI Protocols
   */
  classifyPediatricGrowth(ageMonths, gender = 'male', weightKg, heightCm, muacCm) {
    const months = parseInt(ageMonths, 10) || 0;
    const w = parseFloat(weightKg);
    const h = parseFloat(heightCm);
    const m = parseFloat(muacCm);
    const alerts = [];
    let isEmergency = false;
    let isMalnourished = false;

    // 1. MUAC Evaluation (Valid for 6 - 59 months)
    let muacResult = null;
    if (months >= 6 && months <= 60 && m > 0) {
      muacResult = this.classifyMuac(m, months / 12);
      if (muacResult && muacResult.isAlert) {
        alerts.push(muacResult.warning);
        isMalnourished = true;
        if (muacResult.isEmergency) isEmergency = true;
      }
    }

    // 2. Expected Weight for Age (WHO Median Approximation: 3.3 + (months * 0.5kg for 0-12m; 9 + (months-12)*0.2 for 1-5y))
    let expectedWeightMedian = 3.3;
    if (months <= 12) {
      expectedWeightMedian = 3.3 + (months * 0.55);
    } else {
      expectedWeightMedian = 9.5 + ((months - 12) * 0.18);
    }

    let weightForAgeTier = 'Normal Weight for Age';
    let weightBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';

    if (w > 0) {
      const weightRatio = w / expectedWeightMedian;
      if (weightRatio < 0.70) {
        weightForAgeTier = 'Severely Underweight (< -3 SD)';
        weightBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
        alerts.push(`Severely Underweight for Age: ${w} kg (expected ~${expectedWeightMedian.toFixed(1)} kg)`);
        isMalnourished = true;
      } else if (weightRatio < 0.80) {
        weightForAgeTier = 'Moderately Underweight (-2 to -3 SD)';
        weightBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-semibold';
        alerts.push(`Underweight for Age: ${w} kg (expected ~${expectedWeightMedian.toFixed(1)} kg)`);
        isMalnourished = true;
      }
    }

    let overallGrade = 'Normal Healthy Growth';
    let overallBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    let actionRecommendation = 'Continue age-appropriate feeding, exclusive breastfeeding for infants < 6 months, and routine growth monitoring.';

    if (isEmergency || (muacResult && muacResult.tier?.includes('SAM'))) {
      overallGrade = 'Severe Acute Malnutrition (SAM - Red Zone)';
      overallBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-black';
      actionRecommendation = 'EMERGENCY NRC REFERRAL: Immediate admission to Village Nutrition Rehabilitation Centre (NRC) or Taluka Hospital. Provide medical antibiotic cover and therapeutic feeding.';
    } else if (isMalnourished || (muacResult && muacResult.tier?.includes('MAM'))) {
      overallGrade = 'Moderate Acute Malnutrition (MAM - Yellow Zone)';
      overallBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
      actionRecommendation = 'Enroll child in Anganwadi Supplementary Nutrition Programme (SNP). Weekly MUAC and weight tracking required.';
    }

    return {
      ageMonths: months,
      weightKg: w,
      heightCm: h,
      muacCm: m,
      expectedWeightMedian: parseFloat(expectedWeightMedian.toFixed(1)),
      weightForAgeTier,
      weightBadge,
      muacResult,
      overallGrade,
      overallBadge,
      alerts,
      isEmergency,
      isMalnourished,
      actionRecommendation,
      guidelineSource: 'WHO Child Growth Standards / National IMNCI Guidelines'
    };
  },

  /**
   * 15. Non-Communicable Disease (NCD) Control Status & Target Stratification
   * Citations: National Programme for Prevention & Control of Cancer, Diabetes,
   * Cardiovascular Diseases and Stroke (NPCDCS) / Indian Hypertension Guidelines
   */
  evaluateNcdControlStatus(conditions = [], vitals = {}) {
    const sys = parseInt(vitals.systolicBp, 10);
    const dia = parseInt(vitals.diastolicBp, 10);
    const glu = parseFloat(vitals.bloodGlucose);
    const gluContext = vitals.glucoseContext || 'random';
    const adherence = vitals.medicationAdherence || 'regular';

    const alerts = [];
    let isEmergency = false;
    let isUncontrolled = false;
    let bpControl = 'Normal';
    let glucoseControl = 'Normal';

    // 1. Blood Pressure Control in Hypertensive Patients
    if (sys && dia) {
      if (sys >= 180 || dia >= 120) {
        bpControl = 'Hypertensive Emergency (≥180/120)';
        alerts.push(`Hypertensive Emergency: ${sys}/${dia} mmHg`);
        isEmergency = true;
        isUncontrolled = true;
      } else if (sys >= 160 || dia >= 100) {
        bpControl = 'Stage 2 Uncontrolled (≥160/100)';
        alerts.push(`Stage 2 Hypertension: ${sys}/${dia} mmHg`);
        isUncontrolled = true;
      } else if (sys >= 140 || dia >= 90) {
        bpControl = 'Stage 1 Uncontrolled (140-159/90-99)';
        alerts.push(`Elevated BP: ${sys}/${dia} mmHg`);
        isUncontrolled = true;
      } else {
        bpControl = 'Controlled (<140/90 mmHg)';
      }
    }

    // 2. Blood Glucose Control in Diabetic Patients
    if (glu && glu > 0) {
      if (glu < 70) {
        glucoseControl = 'Critical Hypoglycemia (<70 mg/dL)';
        alerts.push(`Severe Hypoglycemia: ${glu} mg/dL`);
        isEmergency = true;
      } else if (glu >= 300) {
        glucoseControl = 'Severe Hyperglycemia (≥300 mg/dL)';
        alerts.push(`Severe Hyperglycemia: ${glu} mg/dL`);
        isEmergency = true;
        isUncontrolled = true;
      } else if (gluContext === 'fasting' ? glu >= 130 : glu >= 200) {
        glucoseControl = `Uncontrolled Hyperglycemia (${glu} mg/dL)`;
        alerts.push(`Uncontrolled Glucose: ${glu} mg/dL`);
        isUncontrolled = true;
      } else {
        glucoseControl = `Controlled (${glu} mg/dL ${gluContext})`;
      }
    }

    // 3. Medication Adherence Tier
    let adherenceTier = 'Good Adherence (≥80%)';
    let adherenceBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (adherence.toLowerCase().includes('default') || adherence.toLowerCase().includes('stopped')) {
      adherenceTier = 'Defaulted / Treatment Interrupted (<50%)';
      adherenceBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
      alerts.push('Medication Default: Patient has stopped prescribed NCD medicines');
      isUncontrolled = true;
    } else if (adherence.toLowerCase().includes('irregular')) {
      adherenceTier = 'Irregular Adherence (50-79%)';
      adherenceBadge = 'bg-amber-100 text-amber-800 border-amber-300';
      alerts.push('Suboptimal Adherence: Missed doses reported');
    }

    let overallStatus = 'Controlled / Stable';
    let overallBadge = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (isEmergency) {
      overallStatus = 'Critical NCD Crisis (Urgent Escalation)';
      overallBadge = 'bg-rose-100 text-rose-800 border-rose-300 font-black';
    } else if (isUncontrolled) {
      overallStatus = 'Uncontrolled Disease (Physician Review)';
      overallBadge = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
    }

    return {
      bpControl,
      glucoseControl,
      adherenceTier,
      adherenceBadge,
      overallStatus,
      overallBadge,
      alerts,
      isEmergency,
      isUncontrolled,
      guidelineSource: 'NPCDCS / Indian Hypertension Guidelines (IHS-IV)'
    };
  },

  /**
   * 16. NCD Target Complications & Red-Flags Screen
   */
  evaluateNcdComplications(symptoms = []) {
    const redFlags = [];
    let isEmergency = false;

    if (symptoms.includes('chest_pain') || symptoms.includes('angina')) {
      redFlags.push({ condition: 'Acute Coronary Syndrome', text: 'Chest pain / tightening radiating to arm or jaw', severity: 'emergency' });
      isEmergency = true;
    }
    if (symptoms.includes('stroke_fast') || symptoms.includes('facial_droop') || symptoms.includes('arm_weakness')) {
      redFlags.push({ condition: 'Cerebrovascular Event (Stroke)', text: 'Sudden facial droop, arm weakness or speech difficulty', severity: 'emergency' });
      isEmergency = true;
    }
    if (symptoms.includes('diabetic_foot') || symptoms.includes('foot_ulcer')) {
      redFlags.push({ condition: 'Diabetic Foot Ulcer', text: 'Non-healing foot wound, numbness, or signs of gangrene', severity: 'urgent' });
    }
    if (symptoms.includes('visual_blurring') || symptoms.includes('retinopathy')) {
      redFlags.push({ condition: 'Diabetic Retinopathy', text: 'Progressive vision blurring or floaters', severity: 'moderate' });
    }

    return {
      redFlags,
      hasComplications: redFlags.length > 0,
      isEmergency
    };
  }
};
