import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AppLayout from './components/layout/AppLayout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Patients from './pages/Patients';
import SyncCenter from './pages/SyncCenter';
import KnowledgeCenter from './pages/KnowledgeCenter';
import HealthAssistant from './pages/HealthAssistant';
import Assessments from './pages/Assessments';
import Maternal from './pages/Maternal';
import Child from './pages/Child';
import Chronic from './pages/Chronic';
import Referrals from './pages/Referrals';
import FollowUps from './pages/FollowUps';
import Reports from './pages/Reports';
import DocumentAnalysis from './pages/DocumentAnalysis';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<AppLayout />}>
        <Route index element={<Dashboard />} />
        
        <Route path="patients" element={<Patients />} />
        <Route path="assistant" element={<HealthAssistant />} />
        <Route path="sync" element={<SyncCenter />} />
        <Route path="knowledge" element={<KnowledgeCenter />} />

        <Route path="assessments" element={<Assessments />} />
        <Route path="maternal" element={<Maternal />} />
        <Route path="child" element={<Child />} />
        <Route path="chronic" element={<Chronic />} />
        <Route path="referrals" element={<Referrals />} />
        <Route path="follow-ups" element={<FollowUps />} />
        <Route path="reports" element={<Reports />} />
        <Route path="document-analysis" element={<DocumentAnalysis />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
