import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export const DEMO_USERS = [
  {
    id: 'usr-asha-1',
    name: 'Sunita Devi',
    role: 'asha',
    roleLabel: 'Community Health Worker (ASHA)',
    village: 'Rampur Village Sub-Centre',
    district: 'Mandya District',
    avatar: 'SD',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300'
  },
  {
    id: 'usr-doc-1',
    name: 'Dr. Priya Rao, MBBS',
    role: 'doctor',
    roleLabel: 'Medical Officer (PHC)',
    village: 'Rampur Primary Health Centre',
    district: 'Mandya District',
    avatar: 'PR',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-300'
  },
  {
    id: 'usr-admin-1',
    name: 'Dr. Rajesh Sharma',
    role: 'admin',
    roleLabel: 'District Health Administrator',
    village: 'District Health Directorate',
    district: 'District HQ',
    avatar: 'RS',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-300'
  }
];

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('offline_health_user');
      return saved ? JSON.parse(saved) : DEMO_USERS[0]; // Default to ASHA worker
    } catch {
      return DEMO_USERS[0];
    }
  });

  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('offline_health_lang') || 'en';
  });

  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loginAsDemo = (roleKey) => {
    const selected = DEMO_USERS.find(u => u.role === roleKey) || DEMO_USERS[0];
    setCurrentUser(selected);
    localStorage.setItem('offline_health_user', JSON.stringify(selected));
  };

  const loginCustom = (username, password, role = 'asha') => {
    const customUser = {
      id: 'usr-custom-' + Date.now(),
      name: username || 'Health Worker',
      role: role,
      roleLabel: role === 'doctor' ? 'Medical Officer' : role === 'admin' ? 'Health Admin' : 'Community Health Worker (ASHA)',
      village: 'Rampur Sub-Centre',
      district: 'Mandya District',
      avatar: username ? username.slice(0, 2).toUpperCase() : 'HW',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300'
    };
    setCurrentUser(customUser);
    localStorage.setItem('offline_health_user', JSON.stringify(customUser));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('offline_health_user');
  };

  const changeLanguage = (lang) => {
    setLanguage(lang);
    localStorage.setItem('offline_health_lang', lang);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loginAsDemo,
        loginCustom,
        logout,
        language,
        changeLanguage,
        isOnline,
        setIsOnline
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
