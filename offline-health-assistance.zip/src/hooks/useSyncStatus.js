import { useState, useEffect } from 'react';
import { syncService } from '../services/syncService';

export function useSyncStatus() {
  const [summary, setSummary] = useState({
    totalLocal: 0,
    pending: 0,
    failed: 0,
    synced: 0,
    conflicts: 0,
    lastSyncTime: syncService.lastSyncTime,
    isOnline: true,
    isSyncing: false
  });

  const refreshSummary = async () => {
    const data = await syncService.getStatusSummary();
    setSummary(data);
  };

  useEffect(() => {
    refreshSummary();
    const unsubscribe = syncService.addListener((event) => {
      refreshSummary();
    });
    return () => unsubscribe();
  }, []);

  return {
    ...summary,
    refreshSummary,
    syncNow: () => syncService.syncAll(),
    retryFailed: () => syncService.retryFailed(),
    activeConflicts: syncService.activeConflicts
  };
}
