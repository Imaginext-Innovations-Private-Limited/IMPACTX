import { useAuth } from '../context/AuthContext';
import en from '../translations/en.json';
import kn from '../translations/kn.json';
import hi from '../translations/hi.json';

const dictionaries = { en, kn, hi };

export function useTranslation() {
  const { language, changeLanguage } = useAuth();
  const currentLang = language && dictionaries[language] ? language : 'en';
  const dict = dictionaries[currentLang] || en;

  /**
   * Helper function to get nested keys, e.g. t('nav.dashboard')
   */
  const t = (path, fallback = '') => {
    if (!path) return fallback;
    const parts = path.split('.');
    let cur = dict;
    for (const part of parts) {
      if (cur && cur[part] !== undefined) {
        cur = cur[part];
      } else {
        // Fallback to English dictionary if key is missing in chosen language
        let enCur = en;
        for (const enPart of parts) {
          if (enCur && enCur[enPart] !== undefined) {
            enCur = enCur[enPart];
          } else {
            return fallback || path;
          }
        }
        return enCur;
      }
    }
    return cur;
  };

  return { t, language: currentLang, changeLanguage };
}
