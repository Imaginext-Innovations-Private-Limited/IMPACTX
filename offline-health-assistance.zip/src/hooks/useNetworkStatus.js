import { useState, useEffect } from 'react';
import { networkService } from '../services/networkService';

export function useNetworkStatus() {
  const [status, setStatus] = useState({
    isOnline: networkService.isOnline,
    lastChecked: networkService.lastChecked
  });

  useEffect(() => {
    const unsubscribe = networkService.addListener(setStatus);
    return () => unsubscribe();
  }, []);

  return {
    isOnline: status.isOnline,
    lastChecked: status.lastChecked,
    checkNow: () => networkService.verifyConnectivity(true),
    toggleSimulated: (online) => networkService.setSimulatedStatus(online)
  };
}
