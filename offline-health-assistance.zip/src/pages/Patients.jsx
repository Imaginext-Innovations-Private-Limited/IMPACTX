import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { PatientService } from '../db/patientService';
import PatientFormModal from '../components/patients/PatientFormModal';
import PatientProfileModal from '../components/patients/PatientProfileModal';
import PatientDeleteModal from '../components/patients/PatientDeleteModal';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  AlertTriangle,
  HeartHandshake,
  Baby,
  Stethoscope,
  Activity,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  RefreshCw,
  CheckCircle2,
  Phone,
  MapPin,
  ChevronRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export default function Patients() {
  const { currentUser, isOnline } = useAuth();

  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState({ total: 0, maternal: 0, child: 0, highRisk: 0, pendingSync: 0 });

  // Filter & Search states
  const [search, setSearch] = useState('');
  const [villageHamlet, setVillageHamlet] = useState('all');
  const [riskLevel, setRiskLevel] = useState('all');
  const [category, setCategory] = useState('all');
  const [gender, setGender] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedPatientForEdit, setSelectedPatientForEdit] = useState(null);
  const [selectedPatientForProfile, setSelectedPatientForProfile] = useState(null);
  const [selectedPatientForDelete, setSelectedPatientForDelete] = useState(null);

  // Toast notification state
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    loadPatients();
  }, [search, villageHamlet, riskLevel, category, gender, sortBy]);

  const loadPatients = async () => {
    setLoading(true);
    try {
      const [list, stats] = await Promise.all([
        PatientService.getPatients({
          search,
          villageHamlet,
          riskLevel,
          category,
          gender,
          sortBy
        }),
        PatientService.getCounts()
      ]);
      setPatients(list);
      setCounts(stats);
    } catch (err) {
      console.error('Failed to load patients:', err);
      showToast('Error loading patients from IndexedDB', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSavePatient = async (formData, existingId) => {
    try {
      if (existingId) {
        await PatientService.updatePatient(existingId, formData, currentUser);
        showToast(`Patient ${formData.name} updated successfully in offline database.`);
      } else {
        const created = await PatientService.createPatient(formData, currentUser);
        showToast(`Patient ${created.name} (${created.patientId}) registered offline.`);
      }
      loadPatients();
    } catch (err) {
      console.error('Error saving patient:', err);
      showToast(err.message || 'Failed to save patient', 'error');
      throw err;
    }
  };

  const handleDeletePatient = async (id, reason) => {
    try {
      await PatientService.deletePatient(id, currentUser, reason);
      showToast('Patient record deleted and queued for sync audit.', 'info');
      loadPatients();
    } catch (err) {
      console.error('Error deleting patient:', err);
      showToast('Failed to delete patient', 'error');
    }
  };

  const exportCSV = () => {
    if (patients.length === 0) {
      showToast('No patients to export', 'error');
      return;
    }

    const headers = ['Patient ID', 'Name', 'Age', 'Gender', 'Blood Group', 'Phone', 'Village Hamlet', 'Ward', 'Category', 'Risk Level', 'ABHA ID', 'Sync Status'];
    const rows = patients.map(p => [
      `"${p.patientId || ''}"`,
      `"${p.name || ''}"`,
      p.age,
      `"${p.gender || ''}"`,
      `"${p.bloodGroup || ''}"`,
      `"${p.contactNumber || ''}"`,
      `"${p.villageHamlet || ''}"`,
      `"${p.wardNumber || ''}"`,
      `"${p.category || ''}"`,
      `"${p.riskLevel || ''}"`,
      `"${p.abhaId || ''}"`,
      `"${p.syncStatus || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `offline_health_patients_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported patient list to CSV successfully.');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-bottom-5 duration-200 ${
          toast.type === 'error'
            ? 'bg-rose-600 text-white border-rose-700'
            : toast.type === 'info'
            ? 'bg-amber-600 text-white border-amber-700'
            : 'bg-emerald-700 text-white border-emerald-800'
        }`}>
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900">Patient Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
              {counts.total} Registered
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Local IndexedDB Village Health Directory • 100% Offline Access & Search
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
            title="Download CSV report of current patient list"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            onClick={() => {
              setSelectedPatientForEdit(null);
              setIsFormOpen(true);
            }}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-teal-700/20 flex items-center gap-2 transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Register Patient</span>
          </button>
        </div>
      </div>

      {/* Cohort Metric Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => { setCategory('all'); setRiskLevel('all'); }}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            category === 'all' && riskLevel === 'all'
              ? 'bg-teal-50/70 border-teal-300 ring-1 ring-teal-300'
              : 'bg-white border-slate-200/80 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-semibold text-slate-500 block">Total Patients</span>
          <span className="text-xl font-extrabold text-slate-900">{counts.total}</span>
        </button>

        <button
          onClick={() => { setCategory('maternal'); setRiskLevel('all'); }}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            category === 'maternal'
              ? 'bg-pink-50/70 border-pink-300 ring-1 ring-pink-300'
              : 'bg-white border-slate-200/80 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-semibold text-pink-600 block flex items-center gap-1">
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Maternal / ANC</span>
          </span>
          <span className="text-xl font-extrabold text-pink-900">{counts.maternal}</span>
        </button>

        <button
          onClick={() => { setCategory('child'); setRiskLevel('all'); }}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            category === 'child'
              ? 'bg-indigo-50/70 border-indigo-300 ring-1 ring-indigo-300'
              : 'bg-white border-slate-200/80 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-semibold text-indigo-600 block flex items-center gap-1">
            <Baby className="w-3.5 h-3.5" />
            <span>Children (0-5y)</span>
          </span>
          <span className="text-xl font-extrabold text-indigo-900">{counts.child}</span>
        </button>

        <button
          onClick={() => { setRiskLevel('high'); setCategory('all'); }}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            riskLevel === 'high'
              ? 'bg-rose-50/70 border-rose-300 ring-1 ring-rose-300'
              : 'bg-white border-slate-200/80 hover:border-slate-300'
          }`}
        >
          <span className="text-[11px] font-semibold text-rose-600 block flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>High-Risk Patients</span>
          </span>
          <span className="text-xl font-extrabold text-rose-900">{counts.highRisk}</span>
        </button>
      </div>

      {/* Search & Filters Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row items-center gap-3">
          
          {/* Main search input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by Patient Name, ID (PAT-RAM-...), Phone, ABHA ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all placeholder:text-slate-400"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-bold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Filter Dropdowns */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full lg:w-auto">
            
            {/* Village Hamlet */}
            <select
              value={villageHamlet}
              onChange={(e) => setVillageHamlet(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="all">All Hamlets</option>
              <option value="Main Village Center">Main Village Center</option>
              <option value="Rampur Hamlet 2">Rampur Hamlet 2</option>
              <option value="South Hamlet">South Hamlet</option>
              <option value="North Hamlet">North Hamlet</option>
              <option value="Rampur Hamlet 4">Rampur Hamlet 4</option>
            </select>

            {/* Risk Level */}
            <select
              value={riskLevel}
              onChange={(e) => setRiskLevel(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="all">All Risk Levels</option>
              <option value="high">High Risk</option>
              <option value="moderate">Moderate Risk</option>
              <option value="normal">Normal</option>
            </select>

            {/* Category */}
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="all">All Streams</option>
              <option value="maternal">Maternal (ANC)</option>
              <option value="child">Child (0-5y)</option>
              <option value="chronic">Chronic (NCD)</option>
              <option value="general">General</option>
            </select>

            {/* Sorting */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="recent">Recently Updated</option>
              <option value="name_asc">Name (A to Z)</option>
              <option value="name_desc">Name (Z to A)</option>
              <option value="age_asc">Age (Lowest First)</option>
              <option value="age_desc">Age (Highest First)</option>
            </select>

          </div>
        </div>

        {/* Active filter summary pill */}
        {(villageHamlet !== 'all' || riskLevel !== 'all' || category !== 'all' || search) && (
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
            <span>Active filters:</span>
            {search && <span className="px-2 py-0.5 rounded-md bg-teal-50 text-teal-700 font-semibold">"{search}"</span>}
            {villageHamlet !== 'all' && <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">{villageHamlet}</span>}
            {riskLevel !== 'all' && <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 font-semibold">{riskLevel} risk</span>}
            {category !== 'all' && <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700">{category}</span>}
            <button
              onClick={() => {
                setSearch('');
                setVillageHamlet('all');
                setRiskLevel('all');
                setCategory('all');
                setGender('all');
                setSortBy('recent');
              }}
              className="text-teal-700 hover:underline font-bold ml-auto"
            >
              Reset all
            </button>
          </div>
        )}
      </div>

      {/* Patient Directory Table & Cards */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
            <RefreshCw className="w-6 h-6 animate-spin text-teal-600" />
            <span>Loading village records from IndexedDB...</span>
          </div>
        ) : patients.length === 0 ? (
          <div className="py-16 text-center px-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">No Patient Records Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              No matching records for your current search or filter criteria. Try resetting filters or register a new patient.
            </p>
            <button
              onClick={() => {
                setSelectedPatientForEdit(null);
                setIsFormOpen(true);
              }}
              className="mt-4 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-sm inline-flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register Patient Now</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3.5 px-4">Patient Information</th>
                  <th className="py-3.5 px-4">Age / Gender</th>
                  <th className="py-3.5 px-4">Village Location</th>
                  <th className="py-3.5 px-4">Clinical Stream</th>
                  <th className="py-3.5 px-4">Risk Triage</th>
                  <th className="py-3.5 px-4">Offline Sync</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {patients.map((p) => (
                  <tr
                    key={p.id}
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                    onClick={() => setSelectedPatientForProfile(p)}
                  >
                    {/* Patient Name & ID */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-500/10 to-emerald-500/20 text-teal-800 font-bold flex items-center justify-center flex-shrink-0 border border-teal-200/50">
                          {p.name?.slice(0, 2).toUpperCase() || 'PT'}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                            {p.name}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                            <span>{p.patientId}</span>
                            {p.contactNumber && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-0.5">
                                  <Phone className="w-2.5 h-2.5" />
                                  {p.contactNumber}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Age / Gender */}
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800">
                        {p.age} Yrs
                      </span>
                      <span className="text-slate-400 capitalize block text-[11px]">
                        {p.gender} • {p.bloodGroup || 'Blood: N/A'}
                      </span>
                    </td>

                    {/* Village Location */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-800 font-medium truncate max-w-[170px]">
                        {p.villageHamlet}
                      </div>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {p.wardNumber || 'Ward -'} {p.houseNumber ? `• ${p.houseNumber}` : ''}
                      </span>
                    </td>

                    {/* Clinical Stream */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold ${
                        p.category === 'maternal' || p.isPregnant
                          ? 'bg-pink-50 text-pink-700 border border-pink-200'
                          : p.category === 'child'
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : p.category === 'chronic'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {p.category === 'maternal' || p.isPregnant ? (
                          <>
                            <HeartHandshake className="w-3 h-3 text-pink-600" />
                            <span>Maternal ANC</span>
                          </>
                        ) : p.category === 'child' ? (
                          <>
                            <Baby className="w-3 h-3 text-indigo-600" />
                            <span>Child 0-5y</span>
                          </>
                        ) : p.category === 'chronic' ? (
                          <>
                            <Stethoscope className="w-3 h-3 text-blue-600" />
                            <span>NCD Patient</span>
                          </>
                        ) : (
                          <span>General</span>
                        )}
                      </span>
                    </td>

                    {/* Risk Triage */}
                    <td className="py-3.5 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold inline-block ${
                        p.riskLevel === 'high'
                          ? 'bg-rose-100 text-rose-800'
                          : p.riskLevel === 'moderate'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {p.riskLevel}
                      </span>
                    </td>

                    {/* Sync Status */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                        p.syncStatus === 'synced' ? 'text-emerald-700' : 'text-amber-700 font-semibold'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          p.syncStatus === 'synced' ? 'bg-emerald-500' : 'bg-amber-500'
                        }`} />
                        <span>{p.syncStatus === 'synced' ? 'Synced' : 'Local Only'}</span>
                      </span>
                    </td>

                    {/* Action Buttons */}
                    <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setSelectedPatientForProfile(p)}
                          className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                          title="View Profile Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            setSelectedPatientForEdit(p);
                            setIsFormOpen(true);
                          }}
                          className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                          title="Edit Patient Information"
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => setSelectedPatientForDelete(p)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Delete Patient Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <PatientFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setSelectedPatientForEdit(null);
        }}
        patient={selectedPatientForEdit}
        onSaved={handleSavePatient}
      />

      <PatientProfileModal
        isOpen={Boolean(selectedPatientForProfile)}
        onClose={() => setSelectedPatientForProfile(null)}
        patient={selectedPatientForProfile}
        onEdit={(p) => {
          setSelectedPatientForEdit(p);
          setIsFormOpen(true);
        }}
        onDelete={(p) => {
          setSelectedPatientForDelete(p);
        }}
      />

      <PatientDeleteModal
        isOpen={Boolean(selectedPatientForDelete)}
        onClose={() => setSelectedPatientForDelete(null)}
        patient={selectedPatientForDelete}
        onConfirm={handleDeletePatient}
      />

    </div>
  );
}
