import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { MaternalService } from '../services/maternalService';
import { ClinicalCalculators } from '../utils/clinicalCalculators';
import { db } from '../db/db';
import PregnancyRegisterModal from '../components/maternal/PregnancyRegisterModal';
import AncVisitModal from '../components/maternal/AncVisitModal';
import MaternalDetailModal from '../components/maternal/MaternalDetailModal';
import DeliveryModal from '../components/maternal/DeliveryModal';
import {
  HeartHandshake,
  Search,
  Filter,
  PlusCircle,
  Eye,
  Stethoscope,
  Activity,
  Baby,
  Share2,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  User,
  ShieldAlert,
  PlayCircle,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  X
} from 'lucide-react';

export default function Maternal() {
  const { currentUser, isOnline } = useAuth();
  const { t } = useTranslation();

  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    trimester1: 0,
    trimester2: 0,
    trimester3: 0,
    highRisk: 0,
    delivered: 0
  });

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [trimesterFilter, setTrimesterFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');
  const [villageFilter, setVillageFilter] = useState('all');

  // Modals
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showAncModal, setShowAncModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [selectedMaternal, setSelectedMaternal] = useState(null);
  const [selectedMaternalId, setSelectedMaternalId] = useState(null);

  useEffect(() => {
    loadData();
  }, [searchQuery, statusFilter, trimesterFilter, riskFilter, villageFilter]);

  async function loadData() {
    setLoading(true);
    try {
      const [s, list] = await Promise.all([
        MaternalService.getDashboardStats(),
        MaternalService.getMaternalRecords({
          query: searchQuery,
          status: statusFilter,
          trimester: trimesterFilter,
          riskLevel: riskFilter,
          village: villageFilter
        })
      ]);
      setStats(s);
      setRecords(list);
    } catch (err) {
      console.error('[Maternal] Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  }

  // 20-Point Automated Maternal Clinical Verification Runner
  const runVerificationSuite = async () => {
    setRunningTests(true);
    const results = [];

    const assert = (id, name, condition, details) => {
      results.push({
        id,
        name,
        passed: Boolean(condition),
        details: String(details)
      });
    };

    try {
      // TEST-01: Naegele's rule calculation (+280 days)
      const lmpSample = '2026-04-15';
      const eddRes = ClinicalCalculators.calculateEdd(lmpSample);
      assert(
        'TEST-01',
        "Naegele's Rule EDD Calculation",
        eddRes.isValid && eddRes.edd === '2027-01-20',
        `LMP ${lmpSample} -> EDD: ${eddRes.edd} (${eddRes.formatted})`
      );

      // TEST-02: Gestational age calculation (weeks and days)
      const refDate = new Date('2026-11-25');
      const gaRes = ClinicalCalculators.calculateGestationalAge(lmpSample, refDate);
      assert(
        'TEST-02',
        'Gestational Age (Weeks & Days)',
        gaRes.isValid && gaRes.weeks === 32,
        `Calculated: ${gaRes.weeks} weeks ${gaRes.days} days (${gaRes.totalDays} total days)`
      );

      // TEST-03: Trimester classification
      assert(
        'TEST-03',
        'Trimester Assignment (3rd Trimester ≥28w)',
        gaRes.trimester === 3,
        `Trimester: ${gaRes.trimesterLabel}`
      );

      // TEST-04: Pregnancy registration in Dexie db.maternalRecords
      const testMatPatientId = 'pat-105'; // Lakshmi Bai
      const regRes = await MaternalService.registerPregnancy({
        patientId: testMatPatientId,
        lmp: '2026-06-01',
        gravidity: '2',
        parity: '1',
        livingChildren: '1',
        abortions: '0',
        expectedDeliveryPlace: 'Mandya District Hospital',
        highRiskFactors: ['Previous Caesarean Section'],
        notes: 'Verification test registration'
      }, currentUser);
      assert(
        'TEST-04',
        'Pregnancy Registration in Dexie.js',
        regRes && regRes.id && regRes.edd,
        `Created maternal record ${regRes.id} for ${testMatPatientId}`
      );

      // TEST-05: Patient maternal profile update
      const updatedPat = await db.patients.get(testMatPatientId);
      assert(
        'TEST-05',
        'Patient Profile Maternal Flagging',
        updatedPat.isPregnant === true && updatedPat.category === 'maternal',
        `isPregnant: ${updatedPat.isPregnant}, category: ${updatedPat.category}`
      );

      // TEST-06: Automatic ANC-1 follow-up scheduling
      const followUps = await db.followUps.where('patientId').equals(testMatPatientId).toArray();
      const hasAncFu = followUps.some(f => f.visitType?.includes('ANC Visit #1'));
      assert(
        'TEST-06',
        'Automatic ANC-1 Follow-up Scheduler',
        hasAncFu,
        `Found ${followUps.length} follow-up tasks for patient`
      );

      // TEST-07: ANC Visit #1 logging
      const ancRes1 = await MaternalService.recordAntenatalVisit({
        patientId: testMatPatientId,
        maternalRecordId: regRes.id,
        visitNumber: 1,
        visitDate: '2026-07-10',
        systolicBp: '118',
        diastolicBp: '76',
        weightKg: '54.5',
        fundalHeightCm: '14',
        fetalHeartRate: '144',
        hemoglobin: '11.4',
        urineProtein: 'Nil',
        tdVaccineDose: 'Td-1',
        ifaTabletsGiven: 30,
        calciumTabletsGiven: 30
      }, currentUser);
      assert(
        'TEST-07',
        'ANC Visit #1 Record Logging',
        ancRes1 && ancRes1.visit && ancRes1.visit.id,
        `Logged ANC Visit #1 with BP 118/76 mmHg and Hb 11.4 g/dL`
      );

      // TEST-08: Severe gestational hypertension detection (BP >= 160/110)
      const hrpSevereBp = ClinicalCalculators.evaluateHighRiskPregnancy(
        { age: 26 },
        { systolicBp: 164, diastolicBp: 112 }
      );
      assert(
        'TEST-08',
        'Severe Gestational Hypertension Screen',
        hrpSevereBp.isEmergency && hrpSevereBp.isHighRisk,
        `Emergency flag: ${hrpSevereBp.isEmergency}, Tier: ${hrpSevereBp.riskTier}`
      );

      // TEST-09: Preeclampsia screening (BP >= 140/90 + proteinuria)
      const hrpPreeclampsia = ClinicalCalculators.evaluateHighRiskPregnancy(
        { age: 24 },
        { systolicBp: 144, diastolicBp: 94, urineProtein: '1+' }
      );
      assert(
        'TEST-09',
        'Preeclampsia Triage Screen',
        hrpPreeclampsia.isEmergency && hrpPreeclampsia.riskFactors.some(r => r.factor.includes('Preeclampsia')),
        `Preeclampsia detected: ${hrpPreeclampsia.riskFactors[0]?.factor}`
      );

      // TEST-10: Severe anemia screening (Hb < 7.0 g/dL)
      const hrpSevereAnemia = ClinicalCalculators.evaluateHighRiskPregnancy(
        { age: 22 },
        { systolicBp: 110, diastolicBp: 70, hemoglobin: 6.4 }
      );
      assert(
        'TEST-10',
        'Severe Maternal Anemia Screen (<7 g/dL)',
        hrpSevereAnemia.isEmergency && hrpSevereAnemia.riskFactors.some(r => r.factor.includes('Severe Anemia')),
        `Detected: ${hrpSevereAnemia.riskFactors[0]?.factor}`
      );

      // TEST-11: Moderate anemia screening (Hb < 11.0 g/dL)
      const hrpModAnemia = ClinicalCalculators.evaluateHighRiskPregnancy(
        { age: 28 },
        { systolicBp: 112, diastolicBp: 72, hemoglobin: 9.8 }
      );
      assert(
        'TEST-11',
        'Moderate Anemia Detection (7-11 g/dL)',
        hrpModAnemia.isHighRisk && hrpModAnemia.riskFactors.some(r => r.factor.includes('Anemia in Pregnancy')),
        `Detected: ${hrpModAnemia.riskFactors[0]?.factor}`
      );

      // TEST-12: High-risk pregnancy escalation on danger visit
      const ancRes2 = await MaternalService.recordAntenatalVisit({
        patientId: testMatPatientId,
        maternalRecordId: regRes.id,
        visitNumber: 2,
        visitDate: '2026-10-15',
        systolicBp: '154',
        diastolicBp: '98',
        weightKg: '58.0',
        fundalHeightCm: '22',
        fetalHeartRate: '150',
        hemoglobin: '9.2',
        urineProtein: '1+',
        symptoms: ['severe_headache']
      }, currentUser);
      assert(
        'TEST-12',
        'High-Risk Flagging on Adverse Vitals',
        ancRes2.hrp.isHighRisk,
        `Flagged ${ancRes2.visit.warningSigns.length} warning signs`
      );

      // TEST-13: Automatic emergency referral creation on obstetric emergency
      assert(
        'TEST-13',
        'Automatic Emergency Referral Dispatch',
        ancRes2.referralCreated === true,
        `Emergency referral generated and dispatched to local queue`
      );

      // TEST-14: Sequential ANC visit scheduling (ANC #3)
      const allFu = await db.followUps.where('patientId').equals(testMatPatientId).toArray();
      const hasAnc3 = allFu.some(f => f.visitType?.includes('ANC Visit #3'));
      assert(
        'TEST-14',
        'Sequential ANC #3 Schedule Generation',
        hasAnc3,
        `Verified ANC #3 target schedule in follow-up registry`
      );

      // TEST-15: Standard 4-visit ANC schedule checklist mapping
      const ancSchedule = ClinicalCalculators.getAncSchedule('2026-06-01', [ancRes1.visit, ancRes2.visit]);
      assert(
        'TEST-15',
        'Standard 4-Visit ANC Schedule Mapping',
        ancSchedule.length === 4 && ancSchedule[0].completed && ancSchedule[1].completed && !ancSchedule[2].completed,
        `ANC 1: ${ancSchedule[0].completed}, ANC 2: ${ancSchedule[1].completed}, ANC 3: ${ancSchedule[2].completed}`
      );

      // TEST-16: Mother & Child Protection (MCP) card retrieval
      const mcpRecord = await MaternalService.getMaternalRecordById(regRes.id);
      assert(
        'TEST-16',
        'MCP Card Full Data Model Retrieval',
        mcpRecord && mcpRecord.visits.length === 2 && mcpRecord.patient,
        `Loaded MCP card with ${mcpRecord.visits.length} visits and patient details`
      );

      // TEST-17: Delivery recording and status transition
      const deliveryRes = await MaternalService.recordDelivery(regRes.id, {
        deliveryDate: '2026-11-20',
        deliveryPlace: 'Primary Health Centre (PHC)',
        deliveryType: 'Normal Vaginal Delivery',
        birthOutcome: 'Live Birth',
        childGender: 'female',
        birthWeight: '2.9',
        gestationalAgeAtDelivery: '38',
        maternalComplications: 'None',
        vaccinesGivenAtBirth: ['BCG', 'OPV-0', 'Hepatitis B (Birth Dose)']
      }, currentUser);
      assert(
        'TEST-17',
        'Delivery Logging & Maternal Status Transition',
        deliveryRes.success === true,
        `Mother status changed to delivered, infant profile created: ${deliveryRes.childCreated}`
      );

      // TEST-18: Automatic newborn child record generation
      const childRec = await db.childRecords.where('motherId').equals(testMatPatientId).first();
      assert(
        'TEST-18',
        'Automatic Newborn Child Record Creation',
        childRec && childRec.birthWeight === 2.9,
        `Child record ${childRec?.id} created with birth weight ${childRec?.birthWeight} kg`
      );

      // TEST-19: Automatic PNC home visit schedule generation (48h, 7d, 14d, 28d)
      const postPnc = await db.followUps.where('patientId').equals(testMatPatientId).toArray();
      const pncVisits = postPnc.filter(f => f.visitType?.includes('PNC'));
      assert(
        'TEST-19',
        'Automatic PNC Home Visits Schedule (48h/7d/14d/28d)',
        pncVisits.length >= 4,
        `Generated ${pncVisits.length} PNC follow-up tasks`
      );

      // TEST-20: Multi-parameter filtering and stats aggregation
      const statsAfter = await MaternalService.getDashboardStats();
      assert(
        'TEST-20',
        'Live Statistics & Multi-Parameter Filter Aggregation',
        statsAfter.total >= 1 && statsAfter.delivered >= 1,
        `Total Pregnancies: ${statsAfter.total}, Delivered: ${statsAfter.delivered}, Active: ${statsAfter.active}`
      );

    } catch (testErr) {
      console.error('Test suite error:', testErr);
      results.push({
        id: 'TEST-ERR',
        name: 'Execution Exception',
        passed: false,
        details: testErr.message
      });
    }

    setTestResults(results);
    setRunningTests(false);
    await loadData();
  };

  const villages = Array.from(new Set(records.map(r => r.patient?.villageHamlet).filter(Boolean)));

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Maternal Healthcare & Antenatal Care (ANC)
            </h1>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-pink-100 text-pink-800 border border-pink-200">
              National Health Mission Protocol
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Comprehensive Pregnancy Surveillance • High-Risk Triage • Gestational Timeline & EDD Tracker • PNC Scheduling
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={runVerificationSuite}
            disabled={runningTests}
            className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
          >
            <PlayCircle className={`w-4 h-4 text-pink-600 ${runningTests ? 'animate-spin' : ''}`} />
            <span>{runningTests ? 'Running 20-Point Tests...' : 'Run 20-Point Verification'}</span>
          </button>

          <button
            onClick={() => setShowRegisterModal(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-xl text-xs font-bold shadow-md shadow-pink-600/20 transition-all flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Register Pregnant Mother</span>
          </button>
        </div>
      </div>

      {/* Automated Verification Suite Results Banner */}
      {testResults && (
        <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl relative overflow-hidden animate-in fade-in duration-300">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-pink-500/20 text-pink-400 font-black text-xs flex items-center justify-center border border-pink-500/30">
                {testResults.filter(t => t.passed).length}/{testResults.length}
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Maternal Healthcare Verification Suite Results</h3>
                <p className="text-[11px] text-slate-400">20 Real Dexie.js & Clinical Protocol Assertions</p>
              </div>
            </div>

            <button
              onClick={() => setTestResults(null)}
              className="text-xs text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              Dismiss
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto pr-1">
            {testResults.map(t => (
              <div
                key={t.id}
                className={`p-2.5 rounded-xl border text-xs transition-colors ${
                  t.passed
                    ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] font-bold text-slate-400">{t.id}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                    t.passed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {t.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
                <p className="font-semibold text-slate-200 truncate">{t.name}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{t.details}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6 Real-time Database Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Total Registered
          </span>
          <div className="text-2xl font-black text-slate-900">{stats.total}</div>
          <span className="text-[10px] text-teal-600 font-semibold mt-1 block">In local IndexedDB</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Active ANC
          </span>
          <div className="text-2xl font-black text-teal-700">{stats.active}</div>
          <span className="text-[10px] text-teal-600 font-semibold mt-1 block">Current gestations</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            1st Trimester
          </span>
          <div className="text-2xl font-black text-blue-700">{stats.trimester1}</div>
          <span className="text-[10px] text-blue-600 font-semibold mt-1 block">Early registration</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            2nd Trimester
          </span>
          <div className="text-2xl font-black text-teal-700">{stats.trimester2}</div>
          <span className="text-[10px] text-teal-600 font-semibold mt-1 block">Mid pregnancy</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            3rd Trimester
          </span>
          <div className="text-2xl font-black text-pink-700">{stats.trimester3}</div>
          <span className="text-[10px] text-pink-600 font-semibold mt-1 block">Delivery planning</span>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-500 block mb-1">
            High-Risk (HRP)
          </span>
          <div className="text-2xl font-black text-rose-700">{stats.highRisk}</div>
          <span className="text-[10px] text-rose-600 font-semibold mt-1 block">Intensified review</span>
        </div>
      </div>

      {/* High-Risk Maternal Alert Banner */}
      {stats.highRisk > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 via-pink-50 to-amber-50 border border-rose-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center flex-shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-rose-900">
                {stats.highRisk} High-Risk Pregnancies Require Clinical Surveillance
              </h4>
              <p className="text-[11px] text-rose-700 mt-0.5">
                Screened positive for gestational hypertension, severe anemia, previous cesarean scar, or danger signs under PMSMA protocol.
              </p>
            </div>
          </div>
          <button
            onClick={() => setRiskFilter('high')}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex-shrink-0"
          >
            View High-Risk Mothers
          </button>
        </div>
      )}

      {/* Search & Multi-Parameter Filter Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          {/* Search Box */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by mother name, Patient ID, phone, hamlet..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500"
            />
          </div>

          {/* Trimester Filter */}
          <div>
            <select
              value={trimesterFilter}
              onChange={(e) => setTrimesterFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500 font-medium text-slate-700"
            >
              <option value="all">All Trimesters</option>
              <option value="1">1st Trimester (1 - 12w)</option>
              <option value="2">2nd Trimester (13 - 27w)</option>
              <option value="3">3rd Trimester (28w+)</option>
            </select>
          </div>

          {/* Risk Filter */}
          <div>
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500 font-medium text-slate-700"
            >
              <option value="all">All Risk Levels</option>
              <option value="high">High-Risk (HRP)</option>
              <option value="normal">Normal Risk</option>
            </select>
          </div>

          {/* Village Filter */}
          <div>
            <select
              value={villageFilter}
              onChange={(e) => setVillageFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pink-500 font-medium text-slate-700"
            >
              <option value="all">All Hamlets</option>
              {villages.map(v => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Maternal Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">Antenatal Mothers Registry</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
              {records.length} records
            </span>
          </div>

          <button
            onClick={loadData}
            title="Refresh registry"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading maternal registry...</div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400 space-y-2">
            <HeartHandshake className="w-8 h-8 text-slate-300 mx-auto" />
            <p>No maternal records match your selected filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-6 py-3.5">Mother & Hamlet</th>
                  <th className="px-4 py-3.5">Obstetric Dates (LMP / EDD)</th>
                  <th className="px-4 py-3.5">Gestation & Trimester</th>
                  <th className="px-4 py-3.5">Latest Vitals</th>
                  <th className="px-4 py-3.5">HRP Risk Triage</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {records.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Mother & Demographics */}
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                          <span>{rec.patient.name}</span>
                          {rec.patient.bloodGroup && (
                            <span className="text-[10px] font-semibold text-pink-700 bg-pink-50 px-1.5 py-0.2 rounded border border-pink-200">
                              {rec.patient.bloodGroup}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {rec.patient.patientId} • {rec.patient.age}y • {rec.patient.villageHamlet}
                        </p>
                      </div>
                    </td>

                    {/* LMP / EDD */}
                    <td className="px-4 py-4">
                      <div className="space-y-0.5">
                        <p className="text-slate-700">LMP: <span className="font-semibold">{rec.lmp}</span></p>
                        <p className="text-slate-900 font-bold">EDD: {rec.calculatedEdd.formatted}</p>
                        {rec.status !== 'delivered' && (
                          <span className="text-[10px] text-pink-700 block">
                            {rec.gestationalAge.daysToEdd} days remaining
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Gestation & Trimester */}
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <span className="font-bold text-slate-900 block text-xs">
                          {rec.gestationalAge.text}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border inline-block ${rec.gestationalAge.trimesterBadge}`}>
                          {rec.status === 'delivered' ? 'Delivered' : rec.gestationalAge.trimesterLabel}
                        </span>
                      </div>
                    </td>

                    {/* Latest Vitals */}
                    <td className="px-4 py-4">
                      {rec.latestVisit ? (
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-800">
                            BP: {rec.latestVisit.systolicBp}/{rec.latestVisit.diastolicBp} mmHg
                          </p>
                          <p className="text-[11px] text-slate-500">
                            Wt: {rec.latestVisit.weightKg} kg • Hb: {rec.latestVisit.hemoglobin ? `${rec.latestVisit.hemoglobin} g/dL` : '--'}
                          </p>
                          <span className="text-[10px] text-teal-600 block">
                            ANC #{rec.latestVisit.visitNumber} on {rec.latestVisit.visitDate}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No ANC visit logged</span>
                      )}
                    </td>

                    {/* HRP Risk Triage */}
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border inline-block ${rec.hrp.badge}`}>
                          {rec.hrp.riskTier}
                        </span>
                        {rec.hrp.riskFactors.length > 0 && (
                          <p className="text-[10px] text-rose-700 font-medium truncate max-w-[160px]" title={rec.hrp.riskFactors.map(r => r.factor).join(', ')}>
                            {rec.hrp.riskFactors[0].factor}
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedMaternalId(rec.id);
                            setShowDetailModal(true);
                          }}
                          title="View MCP Card & Full History"
                          className="p-1.5 text-slate-500 hover:text-pink-600 hover:bg-pink-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {rec.status !== 'delivered' && (
                          <>
                            <button
                              onClick={() => {
                                setSelectedMaternal(rec);
                                setShowAncModal(true);
                              }}
                              title="Record Antenatal Checkup (ANC)"
                              className="p-1.5 text-slate-500 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors"
                            >
                              <Stethoscope className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setSelectedMaternal(rec);
                                setShowDeliveryModal(true);
                              }}
                              title="Log Delivery & Birth Outcome"
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            >
                              <Baby className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <PregnancyRegisterModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onRegistered={loadData}
        currentUser={currentUser}
      />

      <AncVisitModal
        isOpen={showAncModal}
        onClose={() => {
          setShowAncModal(false);
          setSelectedMaternal(null);
        }}
        maternalRecord={selectedMaternal}
        onVisitRecorded={loadData}
        currentUser={currentUser}
      />

      <MaternalDetailModal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedMaternalId(null);
        }}
        maternalId={selectedMaternalId}
        onRecordUpdated={loadData}
        onOpenAncModal={(rec) => {
          setSelectedMaternal(rec);
          setShowAncModal(true);
        }}
        onOpenDeliveryModal={(rec) => {
          setSelectedMaternal(rec);
          setShowDeliveryModal(true);
        }}
        currentUser={currentUser}
      />

      <DeliveryModal
        isOpen={showDeliveryModal}
        onClose={() => {
          setShowDeliveryModal(false);
          setSelectedMaternal(null);
        }}
        maternalRecord={selectedMaternal}
        onDeliveryLogged={loadData}
        currentUser={currentUser}
      />

    </div>
  );
}
