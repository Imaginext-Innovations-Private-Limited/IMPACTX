import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { PatientService } from '../db/patientService';
import {
  Users,
  Activity,
  HeartHandshake,
  Baby,
  AlertTriangle,
  CalendarCheck,
  RefreshCw,
  PlusCircle,
  FileText,
  Share2,
  Stethoscope,
  Clock,
  MapPin,
  CheckCircle,
  TrendingUp,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  Cross
} from 'lucide-react';

export default function Dashboard() {
  const { currentUser, isOnline } = useAuth();
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [dbCounts, setDbCounts] = useState(null);

  useEffect(() => {
    PatientService.getCounts().then(setDbCounts).catch(console.error);
  }, []);

  // Dashboard state metrics
  const stats = [
    {
      id: 'patients',
      label: t('dashboard.totalPatients'),
      value: dbCounts ? String(dbCounts.total) : '142',
      change: '+8 this week',
      isPositive: true,
      icon: Users,
      color: 'teal',
      bgLight: 'bg-teal-50',
      textColor: 'text-teal-700',
      borderColor: 'border-teal-200'
    },
    {
      id: 'today_visits',
      label: t('dashboard.todayVisits'),
      value: '7',
      change: '3 completed, 4 pending',
      isPositive: true,
      icon: CalendarCheck,
      color: 'emerald',
      bgLight: 'bg-emerald-50',
      textColor: 'text-emerald-700',
      borderColor: 'border-emerald-200'
    },
    {
      id: 'maternal',
      label: t('dashboard.maternalCare'),
      value: dbCounts ? String(dbCounts.maternal) : '18',
      change: '4 in 3rd trimester',
      isPositive: true,
      icon: HeartHandshake,
      color: 'pink',
      bgLight: 'bg-pink-50',
      textColor: 'text-pink-700',
      borderColor: 'border-pink-200'
    },
    {
      id: 'child',
      label: t('dashboard.childrenMonitored'),
      value: dbCounts ? String(dbCounts.child) : '34',
      change: '98% immunization cov.',
      isPositive: true,
      icon: Baby,
      color: 'indigo',
      bgLight: 'bg-indigo-50',
      textColor: 'text-indigo-700',
      borderColor: 'border-indigo-200'
    },
    {
      id: 'high_risk',
      label: t('dashboard.highRisk'),
      value: dbCounts ? String(dbCounts.highRisk) : '4',
      change: 'Immediate follow-up',
      isAlert: true,
      icon: AlertTriangle,
      color: 'rose',
      bgLight: 'bg-rose-50',
      textColor: 'text-rose-700',
      borderColor: 'border-rose-200'
    },
    {
      id: 'sync',
      label: t('dashboard.syncQueue'),
      value: dbCounts ? String(dbCounts.pendingSync) : '5',
      change: isOnline ? 'Ready to sync now' : 'Safely queued locally',
      icon: RefreshCw,
      color: 'amber',
      bgLight: 'bg-amber-50',
      textColor: 'text-amber-700',
      borderColor: 'border-amber-200'
    }
  ];

  // Clinical Warning Alerts
  const [warnings, setWarnings] = useState([
    {
      id: 'w-1',
      patient: 'Geeta Devi (Age 24)',
      type: 'Severe Gestational Hypertension',
      details: 'BP 154/98 mmHg at 32 weeks gestation. Needs urgent PHC medical officer review.',
      village: 'Rampur Hamlet 2',
      severity: 'critical',
      time: 'Logged 45 min ago'
    },
    {
      id: 'w-2',
      patient: 'Aniket Kumar (14 Months)',
      type: 'Growth Faltering (SAM Screening)',
      details: 'MUAC in Red Zone (<11.5cm), Weight: 7.1 kg. Nutrition rehabilitation protocol required.',
      village: 'Rampur Hamlet 4',
      severity: 'high',
      time: 'Logged today 08:30 AM'
    },
    {
      id: 'w-3',
      patient: 'Rameshwar Lal (Age 58)',
      type: 'Uncontrolled Fasting Glucose',
      details: 'Random Capillary Blood Glucose 265 mg/dL. Reports persistent polydipsia and foot tingling.',
      village: 'Main Village Center',
      severity: 'moderate',
      time: 'Logged yesterday'
    }
  ]);

  // Today's scheduled visits
  const todayVisits = [
    {
      id: 'v-1',
      patient: 'Geeta Devi',
      type: 'ANC Checkup (32 Weeks)',
      time: '09:30 AM',
      location: 'House #42, Rampur Ward 2',
      status: 'pending',
      badge: 'High Risk',
      badgeColor: 'bg-rose-100 text-rose-800'
    },
    {
      id: 'v-2',
      patient: 'Master Aarav',
      type: 'Pentavalent 3 & Oral Polio',
      time: '11:00 AM',
      location: 'Anganwadi Centre 1',
      status: 'completed',
      badge: 'Immunization',
      badgeColor: 'bg-emerald-100 text-emerald-800'
    },
    {
      id: 'v-3',
      patient: 'Basamma Gowda (Age 62)',
      type: 'Hypertension Monthly Monitoring',
      time: '02:00 PM',
      location: 'House #88, South Hamlet',
      status: 'pending',
      badge: 'NCD Follow-up',
      badgeColor: 'bg-blue-100 text-blue-800'
    },
    {
      id: 'v-4',
      patient: 'Lakshmi Bai (Age 28)',
      type: 'PNC Day-14 Newborn Wellness',
      time: '04:00 PM',
      location: 'House #15, North Hamlet',
      status: 'pending',
      badge: 'Postnatal',
      badgeColor: 'bg-pink-100 text-pink-800'
    }
  ];

  // Recent clinical activity log
  const recentActivities = [
    {
      id: 1,
      title: 'Vitals Recorded (Offline)',
      patient: 'Basamma Gowda',
      desc: 'BP: 138/86 mmHg, SpO2: 98%, Pulse: 72 bpm',
      time: '25 min ago',
      icon: Activity
    },
    {
      id: 2,
      title: 'Maternal ANC Registration',
      patient: 'Savita Patil',
      desc: 'EDD calculated: 14-Aug-2027, LMP: 07-Nov-2026',
      time: '1 hour ago',
      icon: HeartHandshake
    },
    {
      id: 3,
      title: 'Community Referral Issued',
      patient: 'Geeta Devi',
      desc: 'Referred to Rampur Community Health Centre (Obstetrics)',
      time: '2 hours ago',
      icon: Share2
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-teal-800 via-teal-700 to-emerald-700 p-6 sm:p-8 text-white shadow-xl shadow-teal-900/10 overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 backdrop-blur-3xl transform skew-x-12 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-teal-100 text-xs font-semibold border border-white/10">
              <MapPin className="w-3.5 h-3.5 text-emerald-300" />
              <span>{currentUser?.village || 'Rampur Primary Healthcare Zone'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {t('dashboard.greeting')}, {currentUser?.name}!
            </h1>
            <p className="text-sm text-teal-100 max-w-2xl leading-relaxed">
              Your offline clinical workstation is active. All patient records, vital assessments, and follow-ups are safely stored in your local database and will synchronize seamlessly.
            </p>
          </div>

          {/* Quick status card on right */}
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15">
            <div className={`p-3 rounded-xl ${isOnline ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>
              <RefreshCw className={`w-6 h-6 ${isOnline ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <p className="text-xs text-teal-200 font-medium">Sync Engine Status</p>
              <p className="text-sm font-bold">{isOnline ? 'Online - Auto Sync On' : 'Offline - Local DB Active'}</p>
              <p className="text-[11px] text-teal-100/80">5 local updates pending sync</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Center */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
        <button
          onClick={() => navigate('/patients')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-teal-500 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center mb-3 group-hover:bg-teal-600 group-hover:text-white transition-colors">
            <PlusCircle className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Register Patient</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Add village resident</p>
        </button>

        <button
          onClick={() => navigate('/assessments')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-emerald-500 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <Activity className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Health Checkup</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Record vitals & BMI</p>
        </button>

        <button
          onClick={() => navigate('/maternal')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-pink-500 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center mb-3 group-hover:bg-pink-600 group-hover:text-white transition-colors">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Maternal ANC</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Register & track visits</p>
        </button>

        <button
          onClick={() => navigate('/child')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-indigo-500 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
            <Baby className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Child Wellness</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Vaccines & Growth</p>
        </button>

        <button
          onClick={() => navigate('/referrals')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-rose-500 hover:shadow-md transition-all text-left group col-span-2 sm:col-span-1"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-3 group-hover:bg-rose-600 group-hover:text-white transition-colors">
            <Share2 className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Emergency Referral</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Escalate to CHC/DH</p>
        </button>
      </div>

      {/* Analytics & Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className={`p-5 rounded-2xl bg-white border border-slate-200/80 shadow-sm hover:shadow transition-shadow flex flex-col justify-between`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-500 leading-tight">
                  {item.label}
                </span>
                <div className={`p-2 rounded-xl ${item.bgLight} ${item.textColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div>
                <div className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {item.value}
                </div>
                <p className={`text-[11px] mt-1 font-medium ${
                  item.isAlert ? 'text-rose-600 font-bold' : 'text-slate-500'
                }`}>
                  {item.change}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Grid: Clinical Warnings + Today's Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: High-Risk Screening Warnings (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-rose-100 text-rose-700">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <h2 className="text-sm font-bold text-slate-900">
                Critical Warning Alerts ({warnings.length})
              </h2>
            </div>
            <span className="text-xs text-rose-600 font-semibold cursor-pointer hover:underline">
              View all risks
            </span>
          </div>

          <div className="space-y-3">
            {warnings.map((w) => (
              <div
                key={w.id}
                className="p-4 rounded-2xl bg-white border-l-4 border-l-rose-500 border border-slate-200/80 shadow-sm hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-slate-900">{w.patient}</span>
                    <span className="text-[10px] text-slate-400 block">{w.village}</span>
                  </div>
                  <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                    w.severity === 'critical' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {w.severity}
                  </span>
                </div>

                <div className="mt-2.5">
                  <p className="text-xs font-semibold text-rose-700 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{w.type}</span>
                  </p>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {w.details}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {w.time}
                  </span>
                  <button
                    onClick={() => navigate('/referrals')}
                    className="text-teal-700 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Create Referral</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Today's Field Visits & Schedule (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
                <CalendarCheck className="w-4 h-4" />
              </div>
              <h2 className="text-sm font-bold text-slate-900">
                Today's Field Appointments & Home Visits
              </h2>
            </div>
            <button
              onClick={() => navigate('/follow-ups')}
              className="text-xs text-teal-700 font-semibold hover:underline"
            >
              Full Calendar
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden divide-y divide-slate-100">
            {todayVisits.map((v) => (
              <div
                key={v.id}
                className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex flex-col items-center justify-center flex-shrink-0 font-medium">
                    <Clock className="w-4 h-4 text-teal-600" />
                    <span className="text-[9px] font-bold mt-0.5">{v.time}</span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-xs font-bold text-slate-900">{v.patient}</h4>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${v.badgeColor}`}>
                        {v.badge}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5 font-medium">{v.type}</p>
                    <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {v.location}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  {v.status === 'completed' ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" />
                      Completed
                    </span>
                  ) : (
                    <button
                      onClick={() => navigate('/assessments')}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-sm transition-colors"
                    >
                      Record Visit
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Recent Activity Log & Database Health */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Recent Clinical Log (Stored Offline)
            </h3>
            <div className="space-y-3">
              {recentActivities.map((act) => {
                const Icon = act.icon;
                return (
                  <div key={act.id} className="flex items-start gap-3 text-xs">
                    <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-800">
                        {act.title} - <span className="text-teal-700 font-bold">{act.patient}</span>
                      </p>
                      <p className="text-slate-500 text-[11px]">{act.desc}</p>
                    </div>
                    <span className="text-[10px] text-slate-400 flex-shrink-0">{act.time}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
