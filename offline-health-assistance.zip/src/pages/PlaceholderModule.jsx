import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Layers,
  Database,
  CheckCircle2,
  Sparkles,
  Users,
  Bot,
  BookOpen,
  ArrowRight
} from 'lucide-react';

export default function PlaceholderModule({
  title,
  description,
  badge = 'Active Clinical Protocol',
  features = [],
  icon: Icon
}) {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center gap-2">
        <button
          onClick={() => navigate('/')}
          className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
          title="Back to Dashboard"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-semibold text-slate-400">Back to Dashboard</span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 p-8 sm:p-10 shadow-sm relative overflow-hidden">
        <div className="flex items-start gap-5">
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0 border border-teal-100 shadow-inner">
            {Icon ? <Icon className="w-7 h-7" /> : <Layers className="w-7 h-7" />}
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
                {badge}
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              {description}
            </p>
          </div>
        </div>

        {/* Clinical Protocols & Capabilities */}
        <div className="mt-8 pt-8 border-t border-slate-100">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-teal-600" />
            <span>Core Clinical Capabilities & Protocols</span>
          </h3>

          <div className="grid sm:grid-cols-2 gap-3">
            {features.map((feat, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-3 text-xs font-medium text-slate-700 hover:border-teal-200 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4 text-teal-600 flex-shrink-0" />
                <span>{feat}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Clinical Workflows */}
        <div className="mt-8 pt-8 border-t border-slate-100">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
            Connected Workflows
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => navigate('/patients')}
              className="p-3.5 rounded-2xl border border-slate-200/80 hover:border-teal-500 bg-white hover:bg-teal-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <Users className="w-4 h-4 text-teal-700" />
                <span className="text-xs font-bold text-slate-800">Patient Directory</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-700 group-hover:translate-x-0.5 transition-all" />
            </button>

            <button
              onClick={() => navigate('/assistant')}
              className="p-3.5 rounded-2xl border border-slate-200/80 hover:border-teal-500 bg-white hover:bg-teal-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <Bot className="w-4 h-4 text-teal-700" />
                <span className="text-xs font-bold text-slate-800">AI Health Assistant</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-700 group-hover:translate-x-0.5 transition-all" />
            </button>

            <button
              onClick={() => navigate('/knowledge')}
              className="p-3.5 rounded-2xl border border-slate-200/80 hover:border-teal-500 bg-white hover:bg-teal-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <BookOpen className="w-4 h-4 text-teal-700" />
                <span className="text-xs font-bold text-slate-800">Knowledge Centre</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-700 group-hover:translate-x-0.5 transition-all" />
            </button>
          </div>
        </div>

        {/* System & Offline Status Banner */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-teal-50/60 border border-teal-100 text-xs">
          <div className="flex items-center gap-2 text-teal-800">
            <Database className="w-4 h-4 text-teal-600" />
            <span>Offline Clinical Workstation • Records safely stored in local IndexedDB and synchronized with PHC servers.</span>
          </div>
          <button
            onClick={() => navigate('/')}
            className="w-full sm:w-auto px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl font-semibold shadow-sm transition-colors text-center flex-shrink-0"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
