import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { FollowUpService } from '../services/followUpService';
import { db } from '../db/db';
import ScheduleFollowUpModal from '../components/followups/ScheduleFollowUpModal';
import CompleteFollowUpModal from '../components/followups/CompleteFollowUpModal';
import {
  CalendarClock,
  Search,
  PlusCircle,
  Eye,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldAlert,
  RefreshCw,
  Filter,
  CheckSquare,
  Calendar,
  User,
  ListTodo,
  ChevronRight
} from 'lucide-react';

export default function FollowUps() {
  const { currentUser } = useAuth();
  const { t } = useTranslation();

  const [stats, setStats] = useState({
    total: 0,
    dueToday: 0,
    overdue: 0,
    urgentPriority: 0,
    completed: 0,
    upcomingWeek: 0
  });

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [visitTypeFilter, setVisitTypeFilter] = useState('all');
  const [villageFilter, setVillageFilter] = useState('all');

  // Modals
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [selectedFollowUp, setSelectedFollowUp] = useState(null);

  useEffect(() => {
    loadData();
  }, [searchQuery, dateFilter, priorityFilter, statusFilter, visitTypeFilter, villageFilter]);

  async function loadData() {
    setLoading(true);
    try {
      const [s, list] = await Promise.all([
        FollowUpService.getDashboardStats(),
        FollowUpService.getFollowUps({
          query: searchQuery,
          dateFilter,
          priorityFilter,
          statusFilter,
          visitTypeFilter,
          villageFilter
        })
      ]);
      setStats(s);
      setRecords(list);
    } catch (err) {
      console.error('[FollowUps] Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleQuickToggle(id, currentStatus) {
    try {
      await FollowUpService.toggleComplete(id, !currentStatus, currentUser);
      loadData();
    } catch (err) {
      console.error('Failed to toggle completion:', err);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CalendarClock className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Follow-up & Field Schedule</h1>
              <p className="text-sm text-gray-500">
                Daily village route coordinator, overdue home visits & clinical surveillance
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowScheduleModal(true)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold flex items-center gap-2 shadow-sm transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Schedule Follow-Up</span>
          </button>
        </div>
      </div>

      {/* Overdue Alert Banner */}

      {/* 6 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-xs font-semibold">Total Scheduled</span>
            <CalendarClock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-[11px] text-gray-500 mt-0.5">Field appointments</div>
        </div>

        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 shadow-sm">
          <div className="flex items-center justify-between text-blue-700 mb-1">
            <span className="text-xs font-semibold">Due Today</span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-blue-900">{stats.dueToday}</div>
          <div className="text-[11px] text-blue-700 mt-0.5">Today's field route</div>
        </div>

        <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 shadow-sm">
          <div className="flex items-center justify-between text-amber-800 mb-1">
            <span className="text-xs font-semibold">Overdue Visits</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-900">{stats.overdue}</div>
          <div className="text-[11px] text-amber-800 mt-0.5">Target date elapsed</div>
        </div>

        <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
          <div className="flex items-center justify-between text-red-700 mb-1">
            <span className="text-xs font-semibold">Urgent Priority</span>
            <ShieldAlert className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-900">{stats.urgentPriority}</div>
          <div className="text-[11px] text-red-700 mt-0.5">High-risk cases</div>
        </div>

        <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
          <div className="flex items-center justify-between text-emerald-700 mb-1">
            <span className="text-xs font-semibold">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-900">{stats.completed}</div>
          <div className="text-[11px] text-emerald-700 mt-0.5">Visits finalized</div>
        </div>

        <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 shadow-sm">
          <div className="flex items-center justify-between text-purple-700 mb-1">
            <span className="text-xs font-semibold">Next 7 Days</span>
            <ListTodo className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-purple-900">{stats.upcomingWeek}</div>
          <div className="text-[11px] text-purple-700 mt-0.5">Upcoming pipeline</div>
        </div>
      </div>

      {/* Date Filter Tabs & Search Controls */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
        {/* Quick Date Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
          <button
            onClick={() => setDateFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition ${
              dateFilter === 'all'
                ? 'bg-gray-900 text-white shadow-sm'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All Scheduled ({stats.total})
          </button>
          <button
            onClick={() => setDateFilter('today')}
            className={`px-3 py-1.5 rounded-xl transition ${
              dateFilter === 'today'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-blue-50 text-blue-800 hover:bg-blue-100'
            }`}
          >
            Due Today ({stats.dueToday})
          </button>
          <button
            onClick={() => setDateFilter('overdue')}
            className={`px-3 py-1.5 rounded-xl transition ${
              dateFilter === 'overdue'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
            }`}
          >
            Overdue ({stats.overdue})
          </button>
          <button
            onClick={() => setDateFilter('this_week')}
            className={`px-3 py-1.5 rounded-xl transition ${
              dateFilter === 'this_week'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-purple-50 text-purple-800 hover:bg-purple-100'
            }`}
          >
            This Week ({stats.upcomingWeek})
          </button>
          <button
            onClick={() => setDateFilter('completed')}
            className={`px-3 py-1.5 rounded-xl transition ${
              dateFilter === 'completed'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            Completed History ({stats.completed})
          </button>
        </div>

        {/* Filter inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-1">
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Search by patient name, ID, visit type, or notes..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">🚨 Urgent Priority</option>
              <option value="high">⚠️ High Priority</option>
              <option value="routine">ℹ️ Routine Priority</option>
            </select>
          </div>

          <div>
            <select
              value={visitTypeFilter}
              onChange={e => setVisitTypeFilter(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            >
              <option value="all">All Visit Types</option>
              <option value="ANC">ANC Checkup</option>
              <option value="Postnatal">Postnatal Home Visit</option>
              <option value="Immunization">Immunization Catch-up</option>
              <option value="NCD">NCD Surveillance</option>
              <option value="Post-Referral">Post-Referral Check</option>
              <option value="Malnutrition">Malnutrition Review</option>
            </select>
          </div>
        </div>
      </div>

      {/* Follow-up Registry Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
            <span>Field Visits & Tasks Registry</span>
            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full font-medium">
              {records.length} records
            </span>
          </h3>

          <button
            onClick={loadData}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition"
            title="Refresh table"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-sm text-gray-500">
            Loading field follow-up schedule...
          </div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-gray-500 space-y-2">
            <CalendarClock className="w-10 h-10 mx-auto text-gray-300" />
            <p className="font-medium text-gray-700">No scheduled visits match the current criteria.</p>
            <p className="text-xs text-gray-500">
              Schedule a home visit or immunization follow-up to plan your field route.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4 w-12 text-center">Done</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Scheduled Date</th>
                  <th className="py-3 px-4">Visit Type</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Objectives & Instructions</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {records.map(fu => {
                  return (
                    <tr
                      key={fu.id}
                      className={`hover:bg-gray-50/80 transition ${
                        fu.isCompleted ? 'bg-gray-50/40 text-gray-500' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={fu.isCompleted}
                          onChange={() => handleQuickToggle(fu.id, fu.isCompleted)}
                          className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>

                      <td className="py-3 px-4">
                        <div className={`font-bold ${fu.isCompleted ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                          {fu.patientName}
                        </div>
                        <div className="text-xs text-gray-500">
                          {fu.patientId} • {fu.patientVillage}
                        </div>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-gray-800 text-xs flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-gray-400" />
                          <span>{fu.scheduledDate}</span>
                        </div>
                        {fu.isOverdue && (
                          <span className="text-[10px] bg-red-100 text-red-700 font-bold px-1.5 py-0.5 rounded block mt-0.5 w-fit">
                            OVERDUE
                          </span>
                        )}
                        {fu.isToday && (
                          <span className="text-[10px] bg-blue-100 text-blue-700 font-bold px-1.5 py-0.5 rounded block mt-0.5 w-fit">
                            DUE TODAY
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium text-gray-800 text-xs block">{fu.visitType}</span>
                        {fu.assignedWorker && (
                          <span className="text-[11px] text-gray-400">Worker: {fu.assignedWorker}</span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${
                          fu.priority === 'urgent'
                            ? 'bg-red-100 text-red-700'
                            : fu.priority === 'high'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {fu.priority}
                        </span>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <p className="text-xs text-gray-700 line-clamp-2">{fu.notes || 'Routine follow-up'}</p>
                        {fu.completionNotes && (
                          <div className="text-[11px] text-emerald-700 mt-1 font-medium bg-emerald-50/70 p-1.5 rounded-lg border border-emerald-100">
                            Outcome: {fu.completionNotes}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => {
                            setSelectedFollowUp(fu);
                            setShowCompleteModal(true);
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                            fu.isCompleted
                              ? 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                              : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {fu.isCompleted ? 'Edit Outcome' : 'Complete Visit'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <ScheduleFollowUpModal
        isOpen={showScheduleModal}
        onClose={() => setShowScheduleModal(false)}
        onSuccess={loadData}
        currentUser={currentUser}
      />

      <CompleteFollowUpModal
        isOpen={showCompleteModal}
        onClose={() => setShowCompleteModal(false)}
        onSuccess={loadData}
        followUp={selectedFollowUp}
        currentUser={currentUser}
      />
    </div>
  );
}
