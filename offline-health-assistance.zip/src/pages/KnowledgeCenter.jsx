import React, { useState, useEffect } from 'react';
import { db, SEED_KNOWLEDGE } from '../db/db';
import {
  BookOpen,
  Search,
  Globe,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  AlertTriangle,
  Heart,
  Baby,
  Activity,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Clock
} from 'lucide-react';

export default function KnowledgeCenter() {
  const [articles, setArticles] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [bookmarks, setBookmarks] = useState(() => {
    try {
      const saved = localStorage.getItem('offline_health_kb_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [activeArticle, setActiveArticle] = useState(null);

  useEffect(() => {
    loadArticles();
  }, []);

  const loadArticles = async () => {
    let list = await db.knowledgeArticles.toArray();
    if (list.length === 0) {
      await db.knowledgeArticles.bulkAdd(SEED_KNOWLEDGE);
      list = SEED_KNOWLEDGE;
    }
    setArticles(list);
    if (!activeArticle && list.length > 0) {
      setActiveArticle(list[0]);
    }
  };

  const toggleBookmark = (id) => {
    setBookmarks(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem('offline_health_kb_bookmarks', JSON.stringify(next));
      return next;
    });
  };

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'first_aid', name: 'First Aid Emergency' },
    { id: 'maternal', name: 'Maternal & ANC' },
    { id: 'child', name: 'Child Health & IMNCI' },
    { id: 'nutrition', name: 'Nutrition & Dehydration' }
  ];

  const filtered = articles.filter(art => {
    if (selectedCategory !== 'all' && art.category !== selectedCategory) return false;
    if (selectedLanguage !== 'all' && art.language !== selectedLanguage) return false;
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      return art.title.toLowerCase().includes(q) || art.content.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900">Medical Knowledge Centre</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
              100% Offline
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Verified Clinical Guidelines & First Aid • English, ಕನ್ನಡ (Kannada) & हिन्दी (Hindi)
          </p>
        </div>

        {/* Multilingual Selector */}
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-teal-700" />
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="px-3 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 shadow-sm"
          >
            <option value="all">All Languages</option>
            <option value="en">English Guidelines</option>
            <option value="kn">ಕನ್ನಡ (Kannada)</option>
            <option value="hi">हिन्दी (Hindi)</option>
          </select>
        </div>
      </div>

      {/* Search & Category Pills */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search first aid, snakebite, preeclampsia, ORS, pneumonia guidelines..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all placeholder:text-slate-400"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map(c => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === c.id
                  ? 'bg-teal-700 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Reading & Catalog Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Article Catalog (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Available Modules ({filtered.length})
          </h3>

          <div className="space-y-2.5">
            {filtered.map(art => {
              const isSelected = activeArticle?.id === art.id;
              const isBookmarked = bookmarks.includes(art.id);

              return (
                <div
                  key={art.id}
                  onClick={() => setActiveArticle(art)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer text-left flex items-start justify-between gap-3 ${
                    isSelected
                      ? 'bg-teal-50/80 border-teal-500 shadow-sm ring-1 ring-teal-500'
                      : 'bg-white border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                        {art.language.toUpperCase()}
                      </span>
                      <span className="text-[10px] text-teal-700 font-semibold capitalize">
                        {art.category.replace('_', ' ')}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 leading-snug">
                      {art.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                      {art.summary}
                    </p>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleBookmark(art.id);
                    }}
                    className="p-1 text-slate-400 hover:text-teal-700 rounded-lg"
                  >
                    {isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4 text-teal-600 fill-teal-600" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Article Reader Pane (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
          {activeArticle ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 uppercase">
                      {activeArticle.language.toUpperCase()} • {activeArticle.category}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Reviewed: {activeArticle.lastUpdated}
                    </span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-2">
                    {activeArticle.title}
                  </h2>
                </div>

                <button
                  onClick={() => toggleBookmark(activeArticle.id)}
                  className="p-2 text-slate-400 hover:text-teal-700 rounded-xl hover:bg-slate-50"
                  title="Bookmark for quick offline access"
                >
                  {bookmarks.includes(activeArticle.id) ? (
                    <BookmarkCheck className="w-5 h-5 text-teal-600 fill-teal-600" />
                  ) : (
                    <Bookmark className="w-5 h-5" />
                  )}
                </button>
              </div>

              {/* Formatted Content */}
              <div className="prose prose-sm max-w-none text-slate-700 text-xs sm:text-sm leading-relaxed space-y-4">
                <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-100 text-xs text-teal-900 flex items-center gap-2 font-medium">
                  <ShieldCheck className="w-4 h-4 text-teal-700 flex-shrink-0" />
                  <span>Approved National Health Mission & IMNCI field clinical protocol.</span>
                </div>

                <div className="whitespace-pre-line leading-loose">
                  {activeArticle.content}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-24 text-center text-xs text-slate-400">
              Select an educational module from the left to read.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
