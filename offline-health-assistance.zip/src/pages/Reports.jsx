import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { ReportService } from '../services/reportService';
import { db } from '../db/db';
import {
  FileBarChart2,
  Download,
  Printer,
  Calendar,
  RefreshCw,
  HeartHandshake,
  Baby,
  Stethoscope,
  Share2,
  Building2,
  ChevronRight
} from 'lucide-react';

export default function Reports() {
  const { currentUser } = useAuth();
  const { t } = useTranslation();

  const [activeTab, setActiveTab] = useState('vhnd'); // vhnd, maternal, child, ncd, referrals
  const [loading, setLoading] = useState(true);

  // Indicators
  const [maternalData, setMaternalData] = useState({});
  const [childData, setChildData] = useState({});
  const [ncdData, setNcdData] = useState({});
  const [referralData, setReferralData] = useState({});
  const [vhndData, setVhndData] = useState([]);

  // Raw registers for table rendering
  const [maternalList, setMaternalList] = useState([]);
  const [childList, setChildList] = useState([]);
  const [ncdList, setNcdList] = useState([]);
  const [referralList, setReferralList] = useState([]);

  useEffect(() => {
    loadAllReports();
  }, []);

  async function loadAllReports() {
    setLoading(true);
    try {
      const [mat, ch, ncd, ref, vhnd, mList, cList, pList, rList, ncdConditions, assessments] = await Promise.all([
        ReportService.getMaternalIndicators(),
        ReportService.getChildIndicators(),
        ReportService.getNcdIndicators(),
        ReportService.getReferralAuditIndicators(),
        ReportService.getVhndMonthlySummary(),
        db.maternalRecords.toArray(),
        db.childRecords.toArray(),
        db.patients.toArray(),
        db.referrals.toArray(),
        db.chronicConditions.toArray(),
        db.healthAssessments.toArray()
      ]);

      const patientMap = {};
      pList.forEach(p => {
        if (p.id) patientMap[p.id] = p;
        if (p.patientId) patientMap[p.patientId] = p;
      });

      // Join lists
      setMaternalData(mat);
      setChildData(ch);
      setNcdData(ncd);
      setReferralData(ref);
      setVhndData(vhnd);

      setMaternalList(mList.map(m => ({
        ...m,
        patientName: patientMap[m.patientId]?.name || 'Unknown',
        village: patientMap[m.patientId]?.villageHamlet || 'Unknown'
      })));

      setChildList(cList.map(c => ({
        ...c,
        childName: patientMap[c.patientId]?.name || 'Child',
        village: patientMap[c.patientId]?.villageHamlet || 'Unknown'
      })));

      setReferralList(rList.map(r => ({
        ...r,
        patientName: patientMap[r.patientId]?.name || 'Patient',
        village: patientMap[r.patientId]?.villageHamlet || 'Unknown'
      })));

      // Map latest vitals by patientId
      const assessmentMap = {};
      assessments.forEach(a => {
        if (!assessmentMap[a.patientId] || new Date(a.createdAt) > new Date(assessmentMap[a.patientId].createdAt)) {
          assessmentMap[a.patientId] = a;
        }
      });

      setNcdList(ncdConditions.map(n => {
        const pat = patientMap[n.patientId] || {};
        const ass = assessmentMap[n.patientId] || {};
        const bp = ass.systolicBp && ass.diastolicBp ? `${ass.systolicBp}/${ass.diastolicBp} mmHg` : 'N/A';
        const rbs = ass.bloodGlucose ? `${ass.bloodGlucose} mg/dL` : 'N/A';
        const isBpCtrl = ass.systolicBp ? (ass.systolicBp < 140 && ass.diastolicBp < 90) : true;
        const isRbsCtrl = ass.bloodGlucose ? (ass.bloodGlucose < 140) : true;
        const controlStatus = (isBpCtrl && isRbsCtrl) ? 'Controlled' : 'Uncontrolled';

        return {
          ...n,
          patientName: pat.name || 'Patient',
          village: pat.villageHamlet || 'Unknown',
          recentBp: bp,
          recentRbs: rbs,
          controlStatus
        };
      }));

    } catch (err) {
      console.error('Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  }

  function handleExportCsv() {
    if (activeTab === 'vhnd') {
      const headers = [
        { label: 'Village Name', key: 'villageName' },
        { label: 'Total Population', key: 'totalPopulation' },
        { label: 'Registered Mothers', key: 'registeredMothers' },
        { label: 'Registered Children', key: 'registeredChildren' },
        { label: 'High Risk Cases', key: 'highRiskCases' },
        { label: 'Referrals Escalated', key: 'referralsEscalated' }
      ];
      ReportService.exportToCsv('OfflineHealth_VHND_Monthly_Report', headers, vhndData);
    } else if (activeTab === 'maternal') {
      const headers = [
        { label: 'Record ID', key: 'id' },
        { label: 'Mother Name', key: 'patientName' },
        { label: 'Patient ID', key: 'patientId' },
        { label: 'Village', key: 'village' },
        { label: 'LMP Date', key: 'lmp' },
        { label: 'EDD Date', key: 'edd' },
        { label: 'Trimester', key: 'trimester' },
        { label: 'High Risk Pregnancy', key: 'isHighRisk' },
        { label: 'Status', key: 'status' }
      ];
      ReportService.exportToCsv('OfflineHealth_Maternal_Health_Register', headers, maternalList);
    } else if (activeTab === 'child') {
      const headers = [
        { label: 'Record ID', key: 'id' },
        { label: 'Child Name', key: 'childName' },
        { label: 'Patient ID', key: 'patientId' },
        { label: 'Village', key: 'village' },
        { label: 'Birth Weight (kg)', key: 'birthWeight' },
        { label: 'Delivery Type', key: 'deliveryType' }
      ];
      ReportService.exportToCsv('OfflineHealth_Child_Health_Register', headers, childList);
    } else if (activeTab === 'ncd') {
      const headers = [
        { label: 'Condition ID', key: 'id' },
        { label: 'Patient Name', key: 'patientName' },
        { label: 'Patient ID', key: 'patientId' },
        { label: 'Village', key: 'village' },
        { label: 'Chronic Condition', key: 'conditionName' },
        { label: 'Severity', key: 'severity' },
        { label: 'Recent BP', key: 'recentBp' },
        { label: 'Recent RBS', key: 'recentRbs' },
        { label: 'Control Status', key: 'controlStatus' }
      ];
      ReportService.exportToCsv('OfflineHealth_NCD_Surveillance_Register', headers, ncdList);
    } else if (activeTab === 'referrals') {
      const headers = [
        { label: 'Referral ID', key: 'id' },
        { label: 'Patient Name', key: 'patientName' },
        { label: 'Patient ID', key: 'patientId' },
        { label: 'Urgency', key: 'urgency' },
        { label: 'Destination Facility', key: 'referralFacility' },
        { label: 'Reason', key: 'reason' },
        { label: 'Ambulance Dispatched', key: 'ambulanceDispatched' },
        { label: 'Doctor Review', key: 'doctorFeedback' },
        { label: 'Status', key: 'status' }
      ];
      ReportService.exportToCsv('OfflineHealth_Referral_Audit_Register', headers, referralList);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
              <FileBarChart2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics Centre</h1>
              <p className="text-sm text-gray-500">
                Village health indicators, immunization coverage, NCD registers & referral audits
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-semibold flex items-center gap-2 transition"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Print Report</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold flex items-center gap-2 shadow-sm transition"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Report Module Tabs */}
      <div className="bg-white p-2 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveTab('vhnd')}
          className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'vhnd'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Village Health Summary (VHND)</span>
        </button>

        <button
          onClick={() => setActiveTab('maternal')}
          className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'maternal'
              ? 'bg-rose-600 text-white shadow-sm'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <HeartHandshake className="w-4 h-4" />
          <span>Maternal Health Register</span>
        </button>

        <button
          onClick={() => setActiveTab('child')}
          className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'child'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Baby className="w-4 h-4" />
          <span>Child Health & Immunization</span>
        </button>

        <button
          onClick={() => setActiveTab('ncd')}
          className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'ncd'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>NCD Surveillance Register</span>
        </button>

        <button
          onClick={() => setActiveTab('referrals')}
          className={`px-4 py-2 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'referrals'
              ? 'bg-red-600 text-white shadow-sm'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          <Share2 className="w-4 h-4" />
          <span>Referral & Audit Register</span>
        </button>
      </div>

      {/* Dynamic Key Metric Cards */}
      {activeTab === 'vhnd' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <span className="text-xs font-semibold text-gray-500">Villages Covered</span>
            <div className="text-2xl font-bold text-gray-900 mt-1">{vhndData.length}</div>
            <span className="text-[11px] text-gray-500">Active community hamlets</span>
          </div>
          <div className="bg-rose-50 p-4 rounded-2xl border border-rose-200 shadow-sm">
            <span className="text-xs font-semibold text-rose-700">Mothers Screened</span>
            <div className="text-2xl font-bold text-rose-900 mt-1">
              {vhndData.reduce((acc, v) => acc + (v.registeredMothers || 0), 0)}
            </div>
            <span className="text-[11px] text-rose-700">Pregnant & lactating</span>
          </div>
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 shadow-sm">
            <span className="text-xs font-semibold text-amber-700">Children Weighed & Immunized</span>
            <div className="text-2xl font-bold text-amber-900 mt-1">
              {vhndData.reduce((acc, v) => acc + (v.registeredChildren || 0), 0)}
            </div>
            <span className="text-[11px] text-amber-700">Under-5 cohort</span>
          </div>
          <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
            <span className="text-xs font-semibold text-red-700">High Risk Identified</span>
            <div className="text-2xl font-bold text-red-900 mt-1">
              {vhndData.reduce((acc, v) => acc + (v.highRiskCases || 0), 0)}
            </div>
            <span className="text-[11px] text-red-700">Priority surveillance</span>
          </div>
        </div>
      )}

      {activeTab === 'maternal' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <span className="text-xs font-semibold text-gray-500">Total Pregnancies</span>
            <div className="text-2xl font-bold text-gray-900 mt-1">{maternalData.totalPregnancies || 0}</div>
            <span className="text-[11px] text-gray-500">{maternalData.activePregnancies || 0} currently active</span>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
            <span className="text-xs font-semibold text-emerald-700">Early Trimester 1 Registrations</span>
            <div className="text-2xl font-bold text-emerald-900 mt-1">{maternalData.earlyRegistrationRate || 0}%</div>
            <span className="text-[11px] text-emerald-700">{maternalData.trimester1Count || 0} early registrations</span>
          </div>
          <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
            <span className="text-xs font-semibold text-red-700">High-Risk Pregnancies</span>
            <div className="text-2xl font-bold text-red-900 mt-1">{maternalData.hrpCount || 0}</div>
            <span className="text-[11px] text-red-700">Severe anemia, HTN, pre-eclampsia</span>
          </div>
          <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 shadow-sm">
            <span className="text-xs font-semibold text-blue-700">Total ANC Visits Conducted</span>
            <div className="text-2xl font-bold text-blue-900 mt-1">{maternalData.totalAncVisits || 0}</div>
            <span className="text-[11px] text-blue-700">Field checkups completed</span>
          </div>
        </div>
      )}

      {activeTab === 'child' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <span className="text-xs font-semibold text-gray-500">Total Under-5 Children</span>
            <div className="text-2xl font-bold text-gray-900 mt-1">{childData.totalChildren || 0}</div>
            <span className="text-[11px] text-gray-500">Registered infants & toddlers</span>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
            <span className="text-xs font-semibold text-emerald-700">Full Immunization Rate</span>
            <div className="text-2xl font-bold text-emerald-900 mt-1">{childData.fullCoverageRate || 0}%</div>
            <span className="text-[11px] text-emerald-700">{childData.fullyImmunizedCount || 0} fully covered</span>
          </div>
          <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
            <span className="text-xs font-semibold text-red-700">Severe Malnutrition (SAM)</span>
            <div className="text-2xl font-bold text-red-900 mt-1">{childData.samCount || 0}</div>
            <span className="text-[11px] text-red-700">MUAC &lt; 11.5 cm</span>
          </div>
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 shadow-sm">
            <span className="text-xs font-semibold text-amber-700">Moderate Malnutrition (MAM)</span>
            <div className="text-2xl font-bold text-amber-900 mt-1">{childData.mamCount || 0}</div>
            <span className="text-[11px] text-amber-700">MUAC 11.5 - 12.5 cm</span>
          </div>
        </div>
      )}

      {activeTab === 'ncd' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <span className="text-xs font-semibold text-gray-500">Hypertension Cases</span>
            <div className="text-2xl font-bold text-gray-900 mt-1">{ncdData.htnCases || 0}</div>
            <span className="text-[11px] text-gray-500">Diagnosed chronic HTN</span>
          </div>
          <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 shadow-sm">
            <span className="text-xs font-semibold text-blue-700">Diabetes Mellitus</span>
            <div className="text-2xl font-bold text-blue-900 mt-1">{ncdData.diabetesCases || 0}</div>
            <span className="text-[11px] text-blue-700">Diagnosed Type 2 DM</span>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
            <span className="text-xs font-semibold text-emerald-700">BP Target Control Rate</span>
            <div className="text-2xl font-bold text-emerald-900 mt-1">{ncdData.bpControlRate || 0}%</div>
            <span className="text-[11px] text-emerald-700">&lt; 140/90 mmHg achieved</span>
          </div>
          <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 shadow-sm">
            <span className="text-xs font-semibold text-purple-700">Blood Glucose Control</span>
            <div className="text-2xl font-bold text-purple-900 mt-1">{ncdData.rbsControlRate || 0}%</div>
            <span className="text-[11px] text-purple-700">RBS &lt; 140 mg/dL target</span>
          </div>
        </div>
      )}

      {activeTab === 'referrals' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <span className="text-xs font-semibold text-gray-500">Total Referrals</span>
            <div className="text-2xl font-bold text-gray-900 mt-1">{referralData.totalReferrals || 0}</div>
            <span className="text-[11px] text-gray-500">Escalated to higher centres</span>
          </div>
          <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
            <span className="text-xs font-semibold text-red-700">108 Ambulance Transfers</span>
            <div className="text-2xl font-bold text-red-900 mt-1">{referralData.ambulanceCount || 0}</div>
            <span className="text-[11px] text-red-700">Emergency mobile dispatches</span>
          </div>
          <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 shadow-sm">
            <span className="text-xs font-semibold text-blue-700">Doctor Review Rate</span>
            <div className="text-2xl font-bold text-blue-900 mt-1">{referralData.reviewRate || 0}%</div>
            <span className="text-[11px] text-blue-700">{referralData.reviewedCount || 0} reviewed cases</span>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
            <span className="text-xs font-semibold text-emerald-700">Discharged & Completed</span>
            <div className="text-2xl font-bold text-emerald-900 mt-1">{referralData.completedCount || 0}</div>
            <span className="text-[11px] text-emerald-700">Closed-loop recovery</span>
          </div>
        </div>
      )}

      {/* Main Report Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden printable-area">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-gray-900 text-sm">
              {activeTab === 'vhnd' && 'Village Health & Nutrition Day (VHND) Monthly Summary'}
              {activeTab === 'maternal' && 'Maternal Health & Antenatal Care Performance Register'}
              {activeTab === 'child' && 'Child Health & Universal Immunization Register'}
              {activeTab === 'ncd' && 'Non-Communicable Diseases (NCD) Surveillance Register'}
              {activeTab === 'referrals' && 'Referral Escalation & Hospital Feedback Audit Register'}
            </h3>
            <p className="text-xs text-gray-500">
              Generated from offline IndexedDB records • Ramanagara District
            </p>
          </div>

          <button
            onClick={loadAllReports}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition"
            title="Refresh statistics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-sm text-gray-500">
            Compiling analytical indicators...
          </div>
        ) : activeTab === 'vhnd' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Village Name</th>
                  <th className="py-3 px-4">Total Population</th>
                  <th className="py-3 px-4">Mothers Registered</th>
                  <th className="py-3 px-4">Children Registered</th>
                  <th className="py-3 px-4">High Risk Cases</th>
                  <th className="py-3 px-4">Referrals Escalated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {vhndData.map((v, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/80 transition">
                    <td className="py-3 px-4 font-bold text-gray-900">{v.villageName}</td>
                    <td className="py-3 px-4 font-semibold text-gray-800">{v.totalPopulation}</td>
                    <td className="py-3 px-4 text-rose-700 font-medium">{v.registeredMothers}</td>
                    <td className="py-3 px-4 text-amber-700 font-medium">{v.registeredChildren}</td>
                    <td className="py-3 px-4 text-red-700 font-bold">{v.highRiskCases}</td>
                    <td className="py-3 px-4 text-blue-700 font-medium">{v.referralsEscalated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : activeTab === 'maternal' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Mother Name</th>
                  <th className="py-3 px-4">Village</th>
                  <th className="py-3 px-4">LMP / EDD</th>
                  <th className="py-3 px-4">Trimester</th>
                  <th className="py-3 px-4">Risk Tier</th>
                  <th className="py-3 px-4">Delivery</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {maternalList.map(m => (
                  <tr key={m.id} className="hover:bg-gray-50/80 transition">
                    <td className="py-3 px-4 font-bold text-gray-900">{m.patientName}</td>
                    <td className="py-3 px-4 text-gray-600">{m.village}</td>
                    <td className="py-3 px-4 text-xs">
                      <div>LMP: {m.lmp}</div>
                      <div className="text-gray-500">EDD: {m.edd}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-gray-800">Trimester {m.trimester}</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        m.isHighRisk ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {m.isHighRisk ? 'HIGH RISK' : 'NORMAL'}
                      </span>
                    </td>
                    <td className="py-3 px-4 capitalize text-xs text-gray-700">{m.deliveryType || 'Antenatal'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : activeTab === 'child' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Child Name</th>
                  <th className="py-3 px-4">Village</th>
                  <th className="py-3 px-4">Birth Weight</th>
                  <th className="py-3 px-4">Delivery Mode</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {childList.map(c => (
                  <tr key={c.id} className="hover:bg-gray-50/80 transition">
                    <td className="py-3 px-4 font-bold text-gray-900">{c.childName}</td>
                    <td className="py-3 px-4 text-gray-600">{c.village}</td>
                    <td className="py-3 px-4 font-semibold text-gray-800">
                      {c.birthWeight ? `${c.birthWeight} kg` : 'N/A'}
                    </td>
                    <td className="py-3 px-4 capitalize text-gray-600">{c.deliveryType || 'Institutional'}</td>
                    <td className="py-3 px-4">
                      <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
                        Active Monitoring
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : activeTab === 'ncd' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Patient Name</th>
                  <th className="py-3 px-4">Village</th>
                  <th className="py-3 px-4">Chronic Condition</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4">Recent Vitals</th>
                  <th className="py-3 px-4">Target Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {ncdList.map(n => (
                  <tr key={n.id} className="hover:bg-gray-50/80 transition">
                    <td className="py-3 px-4 font-bold text-gray-900">{n.patientName}</td>
                    <td className="py-3 px-4 text-gray-600">{n.village}</td>
                    <td className="py-3 px-4 font-semibold text-purple-900">{n.conditionName}</td>
                    <td className="py-3 px-4 capitalize text-xs text-gray-700">{n.severity || 'Moderate'}</td>
                    <td className="py-3 px-4 text-xs">
                      <div>BP: {n.recentBp || 'N/A'}</div>
                      <div className="text-gray-500">RBS: {n.recentRbs || 'N/A'}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        n.controlStatus?.includes('Controlled')
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {n.controlStatus || 'Monitored'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Urgency</th>
                  <th className="py-3 px-4">Destination Facility</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Doctor Feedback</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {referralList.map(r => (
                  <tr key={r.id} className="hover:bg-gray-50/80 transition">
                    <td className="py-3 px-4 font-bold text-gray-900">{r.patientName}</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        r.urgency === 'emergency' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {r.urgency?.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-semibold text-gray-800 text-xs">{r.referralFacility}</td>
                    <td className="py-3 px-4 text-xs text-gray-700 max-w-xs truncate">{r.reason}</td>
                    <td className="py-3 px-4 text-xs text-gray-600 max-w-xs truncate">
                      {r.doctorFeedback || 'Pending review'}
                    </td>
                    <td className="py-3 px-4 capitalize text-xs font-semibold text-emerald-700">
                      {r.status?.replace('_', ' ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
