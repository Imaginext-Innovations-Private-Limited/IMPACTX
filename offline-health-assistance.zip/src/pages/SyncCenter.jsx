import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { syncService } from '../services/syncService';
import { networkService } from '../services/networkService';
import { apiClient } from '../services/apiClient';
import { ConflictResolver } from '../utils/conflictResolver';
import { runOfflineTestSuite } from '../utils/offlineTestSuite';
import { db } from '../db/db';
import {
  RefreshCw,
  Wifi,
  WifiOff,
  Database,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Server,
  Layers,
  History,
  Zap,
  RotateCw,
  FileText,
  X,
  PlayCircle,
  CheckCircle,
  XCircle
} from 'lucide-react';

export default function SyncCenter() {
  const { currentUser } = useAuth();
  const [isOnline, setIsOnline] = useState(networkService.isOnline);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSync, setLastSync] = useState(syncService.lastSyncTime);
  const [counts, setCounts] = useState({ totalLocal: 0, pending: 0, synced: 0, failed: 0, conflicts: 0 });
  const [queueItems, setQueueItems] = useState([]);
  const [syncLogs, setSyncLogs] = useState([]);
  const [selectedConflict, setSelectedConflict] = useState(null);
  const [toast, setToast] = useState(null);

  // Automated test suite states
  const [testResults, setTestResults] = useState([]);
  const [runningTests, setRunningTests] = useState(false);

  const [cloudStatus, setCloudStatus] = useState({ checked: false, connected: false, engine: '' });

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const checkCloudHealth = async () => {
    const health = await apiClient.checkServerHealth();
    setCloudStatus({
      checked: true,
      connected: health.reachable !== false && health.status === 'healthy',
      engine: health.database?.engine || 'Standby'
    });
  };

  useEffect(() => {
    loadData();
    checkCloudHealth();

    const unsubNet = networkService.addListener(({ isOnline: online }) => {
      setIsOnline(online);
    });

    const unsubSync = syncService.addListener((event) => {
      if (event.type === 'SYNC_STARTED') setIsSyncing(true);
      if (event.type === 'SYNC_COMPLETED') {
        setIsSyncing(false);
        setLastSync(event.lastSyncTime);
        showToast(`Sync completed: ${event.syncedCount} records updated.`, 'success');
        loadData();
      }
      if (event.type === 'SYNC_OFFLINE') {
        setIsSyncing(false);
        showToast(event.message, 'info');
      }
    });

    return () => {
      unsubNet();
      unsubSync();
    };
  }, []);

  const loadData = async () => {
    const summary = await syncService.getStatusSummary();
    setCounts(summary);

    const [items, logs] = await Promise.all([
      db.syncQueue.orderBy('id').reverse().limit(30).toArray(),
      db.syncLogs.orderBy('id').reverse().limit(15).toArray()
    ]);
    setQueueItems(items);
    setSyncLogs(logs);
  };

  const handleManualSync = async () => {
    setIsSyncing(true);
    try {
      await syncService.syncAll();
      loadData();
    } catch (e) {
      console.error(e);
      showToast('Sync encountered an error', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRetryFailed = async () => {
    setIsSyncing(true);
    try {
      await syncService.retryFailed();
      showToast('Retrying failed operations...', 'info');
      loadData();
    } catch (e) {
      console.error(e);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSimulateConflict = async () => {
    // Inject a simulated conflicting patient update for testing
    const testPatient = await db.patients.filter(p => !p.isDeleted).first();
    if (!testPatient) return;

    await db.syncQueue.add({
      entity: 'patients',
      entityId: testPatient.id,
      operation: 'UPDATE',
      payload: { ...testPatient, age: testPatient.age + 1, simulateConflict: true },
      status: 'pending',
      retryCount: 0,
      createdAt: new Date().toISOString()
    });

    showToast('Injected simulated server conflict. Click "Sync Now" to trigger detection.', 'info');
    loadData();
  };

  const handleResolveConflict = async (strategy) => {
    if (!selectedConflict) return;
    try {
      await ConflictResolver.resolve(selectedConflict, strategy, {}, currentUser);
      syncService.activeConflicts = syncService.activeConflicts.filter(c => c !== selectedConflict);
      setSelectedConflict(null);
      showToast(`Conflict resolved using '${strategy}'.`, 'success');
      loadData();
    } catch (e) {
      console.error(e);
      showToast('Failed to resolve conflict', 'error');
    }
  };

  const handleRunTests = async () => {
    setRunningTests(true);
    setTestResults([]);
    try {
      const results = await runOfflineTestSuite((item, all) => {
        setTestResults([...all]);
      });
      showToast(`Completed ${results.length} offline architecture tests.`, 'success');
      loadData();
    } catch (e) {
      console.error(e);
      showToast('Error during test execution', 'error');
    } finally {
      setRunningTests(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs font-semibold ${
          toast.type === 'error'
            ? 'bg-rose-600 text-white border-rose-700'
            : toast.type === 'info'
            ? 'bg-amber-600 text-white border-amber-700'
            : 'bg-emerald-700 text-white border-emerald-800'
        }`}>
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-2xl font-bold text-slate-900">Synchronization Centre</h1>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${
              isOnline
                ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                : 'bg-amber-100 text-amber-800 border-amber-200'
            }`}>
              {isOnline ? 'Network Online' : 'Field Offline Mode'}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
              cloudStatus.connected
                ? 'bg-teal-100 text-teal-800 border-teal-200'
                : 'bg-slate-100 text-slate-700 border-slate-200'
            }`}>
              <Server className="w-3 h-3" />
              {cloudStatus.connected ? `Cloud API: ${cloudStatus.engine}` : 'Cloud API Standby'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Local IndexedDB Queue Engine • Idempotency Keys • Cryptographic Conflict Detection
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleRunTests}
            disabled={runningTests}
            className="px-3.5 py-2 rounded-xl border border-teal-300 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
            title="Execute automated 18-point verification test suite"
          >
            <PlayCircle className={`w-3.5 h-3.5 ${runningTests ? 'animate-spin' : 'text-teal-700'}`} />
            <span>{runningTests ? 'Running Verification...' : 'Run 18-Point Tests'}</span>
          </button>

          <button
            onClick={() => networkService.setSimulatedStatus(!isOnline)}
            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            title="Toggle between online and simulated offline modes"
          >
            {isOnline ? <WifiOff className="w-3.5 h-3.5 text-amber-600" /> : <Wifi className="w-3.5 h-3.5 text-emerald-600" />}
            <span>{isOnline ? 'Simulate Offline' : 'Simulate Online'}</span>
          </button>

          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            className="px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-teal-700/20 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronizing...' : 'Sync Now'}</span>
          </button>
        </div>
      </div>

      {/* Status Overview Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        
        {/* GREEN: Synchronized */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase text-emerald-700">Synchronized</span>
            <div className="w-3 h-3 rounded-full bg-emerald-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{counts.synced}</div>
          <p className="text-[10px] text-slate-400 mt-1">Safe on central cloud</p>
        </div>

        {/* ORANGE: Pending Queue */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase text-amber-700">Pending Queue</span>
            <div className="w-3 h-3 rounded-full bg-amber-500 animate-pulse" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{counts.pending}</div>
          <p className="text-[10px] text-slate-400 mt-1">Queued in IndexedDB</p>
        </div>

        {/* BLUE: Synchronizing Progress */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase text-blue-700">Engine State</span>
            <div className={`w-3 h-3 rounded-full ${isSyncing ? 'bg-blue-500 animate-ping' : 'bg-slate-300'}`} />
          </div>
          <div className="text-sm font-bold text-slate-800 mt-1">
            {isSyncing ? 'Sync in Progress' : 'Idle / Listening'}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">
            {lastSync ? `Last: ${new Date(lastSync).toLocaleTimeString()}` : 'Never synced'}
          </p>
        </div>

        {/* RED: Failed Operations */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase text-rose-700">Failed / Retries</span>
            <div className="w-3 h-3 rounded-full bg-rose-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{counts.failed}</div>
          {counts.failed > 0 ? (
            <button
              onClick={handleRetryFailed}
              className="text-[10px] font-bold text-rose-600 hover:underline mt-1 block"
            >
              Retry all failed
            </button>
          ) : (
            <p className="text-[10px] text-slate-400 mt-1">Zero network drops</p>
          )}
        </div>

        {/* PURPLE: Conflicts Requiring Review */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase text-purple-700">Conflicts</span>
            <div className="w-3 h-3 rounded-full bg-purple-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{counts.conflicts}</div>
          <button
            onClick={handleSimulateConflict}
            className="text-[10px] font-bold text-purple-700 hover:underline mt-1 block"
          >
            + Test Conflict Flow
          </button>
        </div>

      </div>

      {/* Active Conflict Notification Drawer (If conflicts exist) */}
      {syncService.activeConflicts.length > 0 && (
        <div className="p-5 rounded-2xl bg-purple-50 border-2 border-purple-300 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-purple-900 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 text-purple-700" />
              <span>Version Conflict Detected ({syncService.activeConflicts.length})</span>
            </div>
            <span className="text-xs text-purple-700">Clinical reconciliation required</span>
          </div>
          <p className="text-xs text-purple-800 leading-relaxed">
            Another clinic terminal has updated patient records with divergent clinical values. Offline Health guarantees zero silent overwrites. Review and reconcile versions below.
          </p>

          <div className="space-y-2">
            {syncService.activeConflicts.map((conf, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-white rounded-xl border border-purple-200 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-900">{conf.localRecord?.name}</span>
                  <span className="text-slate-400 ml-2">ID: {conf.entityId}</span>
                  <div className="text-[11px] text-purple-700 mt-0.5">
                    Divergent fields: {conf.diffs.map(d => `${d.field} (Local: ${d.local} vs Server: ${d.server})`).join(', ')}
                  </div>
                </div>
                <button
                  onClick={() => setSelectedConflict(conf)}
                  className="px-3 py-1.5 bg-purple-700 text-white rounded-xl text-xs font-semibold hover:bg-purple-800 transition-colors"
                >
                  Review & Resolve
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Automated 18-Point Test Suite Diagnostics Panel */}
      {testResults.length > 0 && (
        <div className="p-5 rounded-2xl bg-white border border-teal-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
                <CheckCircle className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Offline Architecture Test Suite Results ({testResults.filter(t => t.passed).length}/{testResults.length} Passed)
              </h3>
            </div>
            <button
              onClick={() => setTestResults([])}
              className="text-xs text-slate-400 hover:text-slate-600 font-semibold"
            >
              Clear Results
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-96 overflow-y-auto">
            {testResults.map((t) => (
              <div
                key={t.id}
                className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                  t.passed ? 'bg-emerald-50/60 border-emerald-200' : 'bg-rose-50/60 border-rose-200'
                }`}
              >
                {t.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">{t.id}: {t.name}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      t.passed ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'
                    }`}>
                      {t.passed ? 'PASS' : 'FAIL'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">{t.details}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Synchronization Engine Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Local Sync Queue (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/80 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
                <Layers className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Local Queue Inspector ({queueItems.length})
              </h3>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Dexie: syncQueue</span>
          </div>

          {queueItems.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              Sync queue is empty. All local patient records and assessments are up to date!
            </div>
          ) : (
            <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
              {queueItems.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between text-xs gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 uppercase text-[10px] px-1.5 py-0.5 rounded bg-slate-100">
                        {item.operation}
                      </span>
                      <span className="font-semibold text-slate-900 truncate">
                        {item.entity} ({item.entityId})
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-slate-400 truncate mt-1">
                      Key: {item.idempotencyKey ? item.idempotencyKey.slice(0, 24) + '...' : 'Auto-derived'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${
                      item.status === 'synced'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'failed'
                        ? 'bg-rose-100 text-rose-800'
                        : item.status === 'conflict'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {item.status}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(item.createdAt).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Historical Sync Handshake Logs (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/80 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
                <History className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Sync History & Latency
              </h3>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Dexie: syncLogs</span>
          </div>

          {syncLogs.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No previous sync runs logged.
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {syncLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 text-xs flex items-start gap-2.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">
                        {log.itemsSynced} records synchronized
                      </span>
                      <span className="text-[10px] text-teal-700 font-semibold font-mono">
                        {log.durationMs}ms
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">{log.details}</p>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Conflict Resolution Modal */}
      {selectedConflict && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-purple-700" />
                <h3 className="text-base font-bold text-slate-900">Reconcile Version Conflict</h3>
              </div>
              <button
                onClick={() => setSelectedConflict(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Patient: <span className="font-bold text-slate-900">{selectedConflict.localRecord?.name}</span> ({selectedConflict.entityId}). Select the clinical resolution strategy:
            </p>

            <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
              <div className="grid grid-cols-3 bg-slate-50 p-2.5 font-bold text-slate-600 uppercase text-[10px]">
                <span>Field</span>
                <span>Local Device Version</span>
                <span>Server Cloud Version</span>
              </div>
              {selectedConflict.diffs.map((d, idx) => (
                <div key={idx} className="grid grid-cols-3 p-3 items-center">
                  <span className="font-semibold text-slate-800 capitalize">{d.field}</span>
                  <span className="text-amber-800 font-medium bg-amber-50 px-2 py-1 rounded-md">{String(d.local)}</span>
                  <span className="text-teal-800 font-medium bg-teal-50 px-2 py-1 rounded-md">{String(d.server)}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => handleResolveConflict('KEEP_LOCAL')}
                className="p-3 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold text-left transition-colors"
              >
                <div>Keep Local Device Edit</div>
                <div className="text-[10px] text-amber-700 font-normal mt-0.5">Overrides server and dispatches new version</div>
              </button>

              <button
                onClick={() => handleResolveConflict('KEEP_SERVER')}
                className="p-3 rounded-xl border border-teal-300 bg-teal-50 hover:bg-teal-100 text-teal-900 text-xs font-bold text-left transition-colors"
              >
                <div>Accept Server Record</div>
                <div className="text-[10px] text-teal-700 font-normal mt-0.5">Adopts cloud version into local IndexedDB</div>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
