import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  FileText,
  Upload,
  Camera,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  WifiOff,
  Wifi,
  Save,
  Trash2,
  Loader2,
  ShieldAlert,
  ClipboardCheck,
  Pill,
  FileSearch
} from 'lucide-react';
import { db } from '../db/db';
import { useAuth } from '../context/AuthContext';
import {
  SAMPLE_DOCUMENTS,
  extractTextFromDocument,
  analyzeMedicalTextOffline,
} from '../utils/documentAnalyzer';
import { DocumentService } from '../services/documentService';

const DOC_TYPES = [
  { value: 'lab_report', label: 'Lab / Blood Report' },
  { value: 'prescription', label: 'Doctor Prescription' },
  { value: 'mcp_card', label: 'MCP / Mamta Card' },
  { value: 'discharge_summary', label: 'Discharge Summary' },
];

const RISK_STYLES = {
  critical: 'bg-rose-50 text-rose-900 border-rose-200',
  warning: 'bg-amber-50 text-amber-900 border-amber-200',
  normal: 'bg-emerald-50 text-emerald-900 border-emerald-200',
};

const BADGE_STYLES = {
  critical: 'bg-rose-100 text-rose-800 border-rose-200',
  warning: 'bg-amber-100 text-amber-800 border-amber-200',
  normal: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

export default function DocumentAnalysis() {
  const { currentUser, isOnline } = useAuth();

  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [documentType, setDocumentType] = useState('lab_report');
  const [language, setLanguage] = useState('en');
  const [fileName, setFileName] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [rawText, setRawText] = useState('');
  const [ocrProgress, setOcrProgress] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loadingCloud, setLoadingCloud] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState('');

  const patients =
    useLiveQuery(() => db.patients.filter((p) => !p.isDeleted).toArray(), []) || [];
  const savedDocs =
    useLiveQuery(() => DocumentService.getAllAnalyses(), []) || [];

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError('');
    setStatusMessage('');
    setAnalysis(null);
    setFileName(file.name);

    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl('');
    }
    if (file.type.startsWith('image/')) {
      setPreviewUrl(URL.createObjectURL(file));
    }

    try {
      setOcrProgress(0);
      const text = await extractTextFromDocument(file, setOcrProgress);
      setRawText(text);
      if (text) {
        setAnalysis(analyzeMedicalTextOffline(text, documentType));
      } else {
        setError('No readable text detected in the image. Try a clearer photo or enter text manually.');
      }
    } catch (err) {
      setError(`Offline OCR error: ${err.message}. You can still type or paste the report text below.`);
    } finally {
      setOcrProgress(null);
    }
  };

  const handleLoadSample = (sample) => {
    setError('');
    setStatusMessage('');
    setPreviewUrl('');
    setFileName(sample.label);
    setDocumentType(sample.documentType);
    setRawText(sample.text);
    setAnalysis(analyzeMedicalTextOffline(sample.text, sample.documentType));
  };

  const handleRunOfflineAnalysis = () => {
    if (!rawText.trim()) {
      setError('Please upload a document photo/text file or paste report text first.');
      return;
    }
    setError('');
    setStatusMessage('');
    setAnalysis(analyzeMedicalTextOffline(rawText, documentType));
  };

  const handleCloudEnhance = async () => {
    if (!isOnline || !rawText.trim()) return;
    setLoadingCloud(true);
    setError('');
    setStatusMessage('');

    const baseline = analysis || analyzeMedicalTextOffline(rawText, documentType);

    try {
      const cloudResult = await DocumentService.enhanceWithCloudAI({
        text: rawText,
        documentType,
        language,
        findings: baseline.findings,
      });

      setAnalysis({
        ...baseline,
        cloudSummary: cloudResult.summary,
        recommendations:
          cloudResult.actionItems?.length > 0
            ? cloudResult.actionItems
            : baseline.recommendations,
        analyzedMode: cloudResult.provider || 'hybrid-offline+cloud',
      });
    } catch (err) {
      setError(`Cloud AI enhancement unavailable (${err.message}). Keeping local offline analysis.`);
    } finally {
      setLoadingCloud(false);
    }
  };

  const handleSaveOffline = async () => {
    if (!analysis) return;
    setSaving(true);
    setError('');

    try {
      const patient = patients.find((p) => p.id === selectedPatientId);
      await DocumentService.saveAnalysis(
        {
          patientId: selectedPatientId || null,
          patientName: patient ? `${patient.name} (${patient.patientId})` : 'Unlinked Document',
          documentType,
          fileName: fileName || 'Manual Text Entry',
          rawText,
          findings: analysis.findings,
          medications: analysis.medications,
          riskLevel: analysis.riskLevel,
          summary: analysis.cloudSummary || analysis.summary,
          recommendations: analysis.recommendations,
          analyzedMode: analysis.analyzedMode,
          language,
        },
        currentUser
      );

      setStatusMessage('Document analysis saved offline to IndexedDB and queued for cloud sync.');
      setRawText('');
      setFileName('');
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
        setPreviewUrl('');
      }
      setAnalysis(null);
    } catch (err) {
      setError(`Failed to save analysis: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-teal-600 to-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
            <FileSearch className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">AI Medical Document Analysis</h1>
            <p className="text-xs sm:text-sm text-slate-600">
              Scan prescriptions, blood reports, or MCP cards with on-device OCR & clinical risk alerts.
            </p>
          </div>
        </div>

        <div
          className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold border self-start md:self-auto ${
            isOnline
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-amber-50 text-amber-900 border-amber-200'
          }`}
        >
          {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
          <span>{isOnline ? 'Online: Offline OCR + Cloud AI Ready' : 'Offline Mode: Local OCR & Clinical Rules'}</span>
        </div>
      </div>

      {/* Quick Test Samples */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mr-1">
          Quick Demo Reports:
        </span>
        {SAMPLE_DOCUMENTS.map((sample) => (
          <button
            key={sample.id}
            type="button"
            onClick={() => handleLoadSample(sample)}
            className="text-xs px-3 py-1.5 rounded-lg bg-white border border-slate-200 hover:border-teal-400 hover:bg-teal-50 text-slate-700 font-medium transition"
          >
            {sample.label}
          </button>
        ))}
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {statusMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Main Split Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input & OCR Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Link Patient (Optional)
              </label>
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600"
              >
                <option value="">-- General / Unlinked --</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Document Category
              </label>
              <select
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600"
              >
                {DOC_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label className="flex flex-col items-center justify-center border-2 border-dashed border-teal-300 rounded-2xl p-6 bg-teal-50/40 hover:bg-teal-50 cursor-pointer transition">
            <div className="flex items-center gap-2 text-teal-800 font-semibold text-sm">
              <Camera className="w-5 h-5" />
              <Upload className="w-5 h-5" />
              <span>Capture Photo or Upload Report</span>
            </div>
            <p className="text-xs text-slate-500 mt-1 text-center">
              Supports JPG, PNG, or TXT reports. OCR runs locally on your device.
            </p>
            <input
              type="file"
              accept="image/*,.txt,.csv"
              capture="environment"
              onChange={handleFileChange}
              className="hidden"
            />
          </label>

          {ocrProgress !== null && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold text-teal-700">
                <span>Running Offline OCR...</span>
                <span>{ocrProgress}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-teal-600 to-emerald-500 h-2 transition-all"
                  style={{ width: `${ocrProgress}%` }}
                />
              </div>
            </div>
          )}

          {previewUrl && (
            <img
              src={previewUrl}
              alt="Document preview"
              className="w-full max-h-48 object-contain rounded-xl border border-slate-200 bg-slate-50"
            />
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              Extracted / Editable Document Text
            </label>
            <textarea
              rows={7}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Extracted OCR text will appear here. You can also paste or edit values (e.g. Hb: 8.2 g/dL, BP: 150/96 mmHg, RBS: 210 mg/dL)..."
              className="w-full rounded-xl border border-slate-300 p-3 text-xs sm:text-sm font-mono focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleRunOfflineAnalysis}
              className="flex-1 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white px-4 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition"
            >
              Analyze Offline
            </button>

            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              aria-label="Summary language"
              className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm bg-white"
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी (Hindi)</option>
              <option value="kn">ಕನ್ನಡ (Kannada)</option>
            </select>

            <button
              type="button"
              disabled={!isOnline || !rawText.trim() || loadingCloud}
              onClick={handleCloudEnhance}
              className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-900 disabled:opacity-40 text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition"
            >
              {loadingCloud ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>Cloud AI Summary</span>
            </button>
          </div>
        </div>

        {/* Output / Structured Clinical Insights Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-teal-600" />
                Clinical Findings & Risk Triage
              </h2>
              {analysis && (
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                  {analysis.analyzedMode}
                </span>
              )}
            </div>

            {!analysis ? (
              <div className="py-16 text-center text-slate-400 text-sm border border-dashed border-slate-200 rounded-2xl">
                Upload a medical document or select a demo report to view structured clinical analysis.
              </div>
            ) : (
              <div className="space-y-4">
                <div className={`p-3.5 rounded-xl border text-sm ${RISK_STYLES[analysis.riskLevel]}`}>
                  <div className="flex items-center gap-2 font-bold uppercase text-xs mb-1">
                    {analysis.riskLevel === 'critical' && <ShieldAlert className="w-4 h-4" />}
                    <span>Risk Classification: {analysis.riskLevel}</span>
                  </div>
                  <p className="leading-relaxed">{analysis.cloudSummary || analysis.summary}</p>
                </div>

                {analysis.findings.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Detected Vitals & Lab Values
                    </h3>
                    <div className="space-y-2">
                      {analysis.findings.map((f) => (
                        <div
                          key={f.key}
                          className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-start justify-between gap-3"
                        >
                          <div>
                            <div className="text-sm font-bold text-slate-900">
                              {f.label}: <span className="text-teal-700">{f.value} {f.unit}</span>
                            </div>
                            <p className="text-xs text-slate-600 mt-0.5">{f.note}</p>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] font-semibold uppercase border shrink-0 ${
                              BADGE_STYLES[f.status]
                            }`}
                          >
                            {f.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {analysis.medications.length > 0 && (
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1">
                      <Pill className="w-3.5 h-3.5" />
                      Extracted Medications
                    </h3>
                    <div className="flex flex-wrap gap-1.5">
                      {analysis.medications.map((med, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-lg bg-teal-50 text-teal-800 border border-teal-200 text-xs font-medium"
                        >
                          {med}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {analysis.recommendations?.length > 0 && (
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                      Recommended Next Steps
                    </h3>
                    <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700">
                      {analysis.recommendations.map((rec, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  type="button"
                  disabled={saving}
                  onClick={handleSaveOffline}
                  className="w-full inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? 'Saving to IndexedDB...' : 'Save Offline & Queue for Sync'}</span>
                </button>
              </div>
            )}
          </div>

          <p className="text-[11px] text-slate-400 text-center pt-2 border-t border-slate-100">
            Decision-support only. Always verify OCR values against the physical report. Call 108 for emergencies.
          </p>
        </div>
      </div>

      {/* Saved History */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h2 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
          <FileText className="w-4 h-4 text-teal-600" />
          Saved Document Analyses ({savedDocs.length})
        </h2>

        {savedDocs.length === 0 ? (
          <p className="text-sm text-slate-500">No analyzed documents saved locally yet.</p>
        ) : (
          <div className="divide-y divide-slate-100">
            {savedDocs.map((doc) => (
              <div key={doc.id} className="py-3 flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-900">
                    <span>{doc.patientName}</span>
                    <span className="text-xs font-normal text-slate-500 capitalize">
                      • {doc.documentType.replace(/_/g, ' ')}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-semibold uppercase border ${
                        BADGE_STYLES[doc.riskLevel] || BADGE_STYLES.normal
                      }`}
                    >
                      {doc.riskLevel}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                      Sync: {doc.syncStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{doc.summary}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {new Date(doc.createdAt).toLocaleString()} • {doc.fileName}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => DocumentService.deleteAnalysis(doc.id, currentUser)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                  title="Delete saved analysis"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
