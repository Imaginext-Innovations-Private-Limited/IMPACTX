import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { ChronicService } from '../services/chronicService';
import { ClinicalCalculators } from '../utils/clinicalCalculators';
import { db } from '../db/db';
import EnrollConditionModal from '../components/chronic/EnrollConditionModal';
import NcdVitalsModal from '../components/chronic/NcdVitalsModal';
import NcdDetailModal from '../components/chronic/NcdDetailModal';
import {
  Stethoscope,
  Search,
  PlusCircle,
  Eye,
  Activity,
  Heart,
  Droplet,
  Pill,
  Share2,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  PlayCircle,
  RefreshCw,
  Sparkles,
  Filter
} from 'lucide-react';

export default function Chronic() {
  const { currentUser } = useAuth();
  const { t } = useTranslation();

  const [stats, setStats] = useState({
    total: 0,
    controlled: 0,
    uncontrolledDiabetes: 0,
    uncontrolledHypertension: 0,
    complicationFlags: 0,
    defaulters: 0
  });

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [conditionFilter, setConditionFilter] = useState('all');
  const [controlFilter, setControlFilter] = useState('all');
  const [adherenceFilter, setAdherenceFilter] = useState('all');
  const [villageFilter, setVillageFilter] = useState('all');

  // Modals
  const [showEnrollModal, setShowEnrollModal] = useState(false);
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [selectedPatientId, setSelectedPatientId] = useState(null);

  // Test Runner State
  const [testResults, setTestResults] = useState(null);
  const [runningTests, setRunningTests] = useState(false);

  useEffect(() => {
    loadData();
  }, [searchQuery, conditionFilter, controlFilter, adherenceFilter, villageFilter]);

  async function loadData() {
    setLoading(true);
    try {
      const [s, list] = await Promise.all([
        ChronicService.getDashboardStats(),
        ChronicService.getNcdPatients({
          query: searchQuery,
          conditionFilter,
          controlFilter,
          adherenceFilter,
          village: villageFilter
        })
      ]);
      setStats(s);
      setRecords(list);
    } catch (err) {
      console.error('[Chronic] Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  }

  // 20-Point Automated Chronic Disease Verification Runner
  const runVerificationSuite = async () => {
    setRunningTests(true);
    const results = [];

    const assert = (id, name, condition, details) => {
      results.push({
        id,
        name,
        passed: Boolean(condition),
        details: String(details)
      });
    };

    try {
      // TEST-01: Controlled blood pressure classification (<140/90)
      const bpCtrl = ClinicalCalculators.evaluateNcdControlStatus([], { systolicBp: 124, diastolicBp: 78 });
      assert(
        'TEST-01',
        'Controlled Blood Pressure Target (<140/90)',
        bpCtrl.bpControl.includes('Controlled'),
        `BP 124/78 -> ${bpCtrl.bpControl}`
      );

      // TEST-02: Stage 1 Uncontrolled Hypertension (140-159/90-99)
      const bpStage1 = ClinicalCalculators.evaluateNcdControlStatus([], { systolicBp: 148, diastolicBp: 92 });
      assert(
        'TEST-02',
        'Stage 1 Hypertension Stratification',
        bpStage1.isUncontrolled && bpStage1.bpControl.includes('Stage 1'),
        `BP 148/92 -> ${bpStage1.bpControl}`
      );

      // TEST-03: Stage 2 Severe Hypertension (>=160/100)
      const bpStage2 = ClinicalCalculators.evaluateNcdControlStatus([], { systolicBp: 168, diastolicBp: 104 });
      assert(
        'TEST-03',
        'Stage 2 Severe Hypertension Alert',
        bpStage2.isUncontrolled && bpStage2.bpControl.includes('Stage 2'),
        `BP 168/104 -> ${bpStage2.bpControl}`
      );

      // TEST-04: Hypertensive Emergency Crisis (>=180/120)
      const bpHyperCrisis = ClinicalCalculators.evaluateNcdControlStatus([], { systolicBp: 188, diastolicBp: 124 });
      assert(
        'TEST-04',
        'Hypertensive Emergency Crisis (≥180/120)',
        bpHyperCrisis.isEmergency && bpHyperCrisis.bpControl.includes('Emergency'),
        `BP 188/124 -> ${bpHyperCrisis.bpControl}`
      );

      // TEST-05: Critical Hypoglycemia Alert (<70 mg/dL)
      const gluHypo = ClinicalCalculators.evaluateNcdControlStatus([], { bloodGlucose: 62 });
      assert(
        'TEST-05',
        'Critical Hypoglycemia Alert (<70 mg/dL)',
        gluHypo.isEmergency && gluHypo.glucoseControl.includes('Hypoglycemia'),
        `Glucose: 62 mg/dL -> ${gluHypo.glucoseControl}`
      );

      // TEST-06: Severe Hyperglycemia Alert (>=300 mg/dL)
      const gluSevere = ClinicalCalculators.evaluateNcdControlStatus([], { bloodGlucose: 320 });
      assert(
        'TEST-06',
        'Severe Hyperglycemia Alert (≥300 mg/dL)',
        gluSevere.isEmergency && gluSevere.glucoseControl.includes('Severe Hyperglycemia'),
        `Glucose: 320 mg/dL -> ${gluSevere.glucoseControl}`
      );

      // TEST-07: Uncontrolled Random Hyperglycemia (>=200 mg/dL)
      const gluUncontrolled = ClinicalCalculators.evaluateNcdControlStatus([], { bloodGlucose: 230, glucoseContext: 'random' });
      assert(
        'TEST-07',
        'Uncontrolled Random Hyperglycemia (≥200 mg/dL)',
        gluUncontrolled.isUncontrolled,
        `Glucose: 230 mg/dL -> ${gluUncontrolled.glucoseControl}`
      );

      // TEST-08: Controlled Blood Sugar Target
      const gluNormal = ClinicalCalculators.evaluateNcdControlStatus([], { bloodGlucose: 118, glucoseContext: 'random' });
      assert(
        'TEST-08',
        'Controlled Blood Sugar Target (<140 mg/dL)',
        !gluNormal.isUncontrolled,
        `Glucose: 118 mg/dL -> ${gluNormal.glucoseControl}`
      );

      // TEST-09: Medication Defaulter Detection
      const adhDefault = ClinicalCalculators.evaluateNcdControlStatus([], { medicationAdherence: 'Defaulted' });
      assert(
        'TEST-09',
        'Medication Treatment Interruption Defaulter Flag',
        adhDefault.adherenceTier.includes('Defaulted') && adhDefault.isUncontrolled,
        `Adherence: ${adhDefault.adherenceTier}`
      );

      // TEST-10: NCD enrollment in Dexie
      const testPatId = 'pat-107'; // Suresh Chandra
      const enrollRes = await ChronicService.enrollCondition({
        patientId: testPatId,
        conditionName: 'Type 2 Diabetes Mellitus',
        severity: 'moderate',
        diagnosedDate: '2023-01-15',
        medications: ['Metformin 500mg BD', 'Glimepiride 1mg OD'],
        medicationAdherence: 'Regular (Daily adherence)'
      }, currentUser);
      assert(
        'TEST-10',
        'Chronic Condition Registration in Dexie.js',
        enrollRes && enrollRes.id,
        `Created condition ${enrollRes.id} for ${testPatId}`
      );

      // TEST-11: Patient profile category update
      const updatedPat = await db.patients.get(testPatId);
      assert(
        'TEST-11',
        'Patient Category Flagging (Chronic)',
        updatedPat.category === 'chronic' && updatedPat.chronicConditions.includes('Type 2 Diabetes Mellitus'),
        `Category: ${updatedPat.category}, Conditions: ${updatedPat.chronicConditions.join(', ')}`
      );

      // TEST-12: Monthly NCD follow-up task generation
      const ncdFu = await db.followUps.where('patientId').equals(testPatId).toArray();
      const hasNcdTask = ncdFu.some(f => f.visitType?.includes('NCD Follow-up'));
      assert(
        'TEST-12',
        'Monthly NCD Drug Refill Follow-up Scheduler',
        hasNcdTask,
        `Scheduled task found: ${ncdFu[0]?.visitType}`
      );

      // TEST-13: Recording NCD vitals in db.healthAssessments
      const vitalsRes1 = await ChronicService.recordNcdVitals({
        patientId: testPatId,
        systolicBp: '132',
        diastolicBp: '84',
        bloodGlucose: '136',
        glucoseContext: 'random',
        medicationAdherence: 'Regular (Daily adherence)',
        daysOfMedicineRemaining: '20'
      }, currentUser);
      assert(
        'TEST-13',
        'NCD Surveillance Vitals Logging',
        vitalsRes1 && vitalsRes1.assessment && vitalsRes1.assessment.id,
        `Recorded vitals: BP 132/84 mmHg, Glucose 136 mg/dL`
      );

      // TEST-14: Controlled status evaluation on stable vitals
      assert(
        'TEST-14',
        'Controlled Status Verification on Stable Vitals',
        !vitalsRes1.control.isUncontrolled,
        `Status: ${vitalsRes1.control.overallStatus}`
      );

      // TEST-15: Complication Red-Flags: Acute Coronary Syndrome
      const compChest = ClinicalCalculators.evaluateNcdComplications(['chest_pain']);
      assert(
        'TEST-15',
        'Acute Coronary Syndrome Complication Screen',
        compChest.isEmergency && compChest.redFlags.some(r => r.condition.includes('Coronary')),
        `Emergency flag: ${compChest.isEmergency}, Condition: ${compChest.redFlags[0]?.condition}`
      );

      // TEST-16: Complication Red-Flags: Stroke FAST screen
      const compStroke = ClinicalCalculators.evaluateNcdComplications(['stroke_fast']);
      assert(
        'TEST-16',
        'Stroke FAST Neurological Deficit Screen',
        compStroke.isEmergency && compStroke.redFlags.some(r => r.condition.includes('Stroke')),
        `Detected: ${compStroke.redFlags[0]?.text}`
      );

      // TEST-17: Complication Red-Flags: Diabetic Foot Ulcer
      const compFoot = ClinicalCalculators.evaluateNcdComplications(['diabetic_foot']);
      assert(
        'TEST-17',
        'Diabetic Foot Ulcer Complication Screen',
        compFoot.hasComplications && compFoot.redFlags.some(r => r.condition.includes('Foot')),
        `Detected: ${compFoot.redFlags[0]?.text}`
      );

      // TEST-18: Emergency Referral creation on adverse crisis
      const crisisRes = await ChronicService.recordNcdVitals({
        patientId: testPatId,
        systolicBp: '184',
        diastolicBp: '122',
        bloodGlucose: '310',
        glucoseContext: 'random',
        symptoms: ['chest_pain']
      }, currentUser);
      assert(
        'TEST-18',
        'Automatic Crisis Emergency Referral Dispatch',
        crisisRes.referralDispatched !== null,
        `Referral dispatched to: ${crisisRes.referralDispatched?.referralFacility}`
      );

      // TEST-19: Disease Passport full data model retrieval
      const passportData = await ChronicService.getNcdPatientById(testPatId);
      assert(
        'TEST-19',
        'Chronic Disease Passport Full Data Model Retrieval',
        passportData && passportData.assessments.length >= 2,
        `Retrieved passport with ${passportData.assessments.length} longitudinal vitals logs`
      );

      // TEST-20: Multi-parameter filtering & live stats aggregation
      const statsAgg = await ChronicService.getDashboardStats();
      assert(
        'TEST-20',
        'Live Statistics & Multi-Parameter Filter Aggregation',
        statsAgg.total >= 1,
        `Total NCD Patients: ${statsAgg.total}, Uncontrolled HTN: ${statsAgg.uncontrolledHypertension}, Controlled: ${statsAgg.controlled}`
      );

    } catch (testErr) {
      console.error('Chronic test error:', testErr);
      results.push({
        id: 'TEST-ERR',
        name: 'Execution Exception',
        passed: false,
        details: testErr.message
      });
    }

    setTestResults(results);
    setRunningTests(false);
    await loadData();
  };

  const villages = Array.from(new Set(records.map(r => r.villageHamlet).filter(Boolean)));

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Chronic Disease Monitoring (NCD)
            </h1>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
              NPCDCS Community Protocol
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Diabetes & Hypertension Registers • Longitudinal BP & Blood Glucose Surveillance • Medication Adherence & Complication Alerts
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={runVerificationSuite}
            disabled={runningTests}
            className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
          >
            <PlayCircle className={`w-4 h-4 text-teal-600 ${runningTests ? 'animate-spin' : ''}`} />
            <span>{runningTests ? 'Running 20-Point Tests...' : 'Run 20-Point Verification'}</span>
          </button>

          <button
            onClick={() => setShowEnrollModal(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-700 to-emerald-700 hover:from-teal-800 hover:to-emerald-800 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-700/20 transition-all flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Enroll NCD Patient</span>
          </button>
        </div>
      </div>

      {/* Automated Verification Suite Results Banner */}
      {testResults && (
        <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl relative overflow-hidden animate-in fade-in duration-300">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 font-black text-xs flex items-center justify-center border border-teal-500/30">
                {testResults.filter(t => t.passed).length}/{testResults.length}
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Chronic Disease Verification Suite Results</h3>
                <p className="text-[11px] text-slate-400">20 Real Dexie.js & NPCDCS Clinical Protocol Assertions</p>
              </div>
            </div>

            <button
              onClick={() => setTestResults(null)}
              className="text-xs text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              Dismiss
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto pr-1">
            {testResults.map(t => (
              <div
                key={t.id}
                className={`p-2.5 rounded-xl border text-xs transition-colors ${
                  t.passed
                    ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] font-bold text-slate-400">{t.id}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                    t.passed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {t.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
                <p className="font-semibold text-slate-200 truncate">{t.name}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{t.details}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6 Real-time Database Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Total Patients
          </span>
          <div className="text-2xl font-black text-slate-900">{stats.total}</div>
          <span className="text-[10px] text-teal-600 font-semibold mt-1 block">Active NCD cohort</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Controlled Parameters
          </span>
          <div className="text-2xl font-black text-emerald-700">{stats.controlled}</div>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">At target targets</span>
        </div>

        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
            Uncontrolled Diabetes
          </span>
          <div className="text-2xl font-black text-amber-800">{stats.uncontrolledDiabetes}</div>
          <span className="text-[10px] text-amber-700 font-semibold mt-1 block">High blood sugar</span>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block mb-1">
            Uncontrolled BP
          </span>
          <div className="text-2xl font-black text-rose-700">{stats.uncontrolledHypertension}</div>
          <span className="text-[10px] text-rose-600 font-semibold mt-1 block">BP ≥140/90</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Complication Flags
          </span>
          <div className="text-2xl font-black text-rose-600">{stats.complicationFlags}</div>
          <span className="text-[10px] text-rose-600 font-semibold mt-1 block">Urgent check</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Med Defaulters
          </span>
          <div className="text-2xl font-black text-orange-700">{stats.defaulters}</div>
          <span className="text-[10px] text-orange-600 font-semibold mt-1 block">Refill catch-up</span>
        </div>
      </div>

      {/* Complications & Severe Hypertension Alert Banner */}
      {(stats.uncontrolledHypertension > 0 || stats.uncontrolledDiabetes > 0) && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 via-amber-50 to-orange-50 border border-rose-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center flex-shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-rose-900">
                Active Non-Communicable Disease Alerts ({stats.uncontrolledHypertension + stats.uncontrolledDiabetes} Uncontrolled Patients)
              </h4>
              <p className="text-[11px] text-rose-700 mt-0.5">
                Patients with uncontrolled blood pressure (≥140/90) or hyperglycemia (&ge;200 mg/dL) require medication adherence counseling and Medical Officer review.
              </p>
            </div>
          </div>
          <button
            onClick={() => setControlFilter('uncontrolled')}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex-shrink-0"
          >
            Filter Uncontrolled
          </button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by patient name, ID, phone, village..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
            />
          </div>

          <div>
            <select
              value={conditionFilter}
              onChange={(e) => setConditionFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium text-slate-700"
            >
              <option value="all">All Conditions</option>
              <option value="diabetes">Diabetes Mellitus</option>
              <option value="hypertension">Hypertension</option>
              <option value="cardiovascular">Cardiovascular</option>
              <option value="asthma">Asthma / COPD</option>
            </select>
          </div>

          <div>
            <select
              value={controlFilter}
              onChange={(e) => setControlFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium text-slate-700"
            >
              <option value="all">All Control Statuses</option>
              <option value="controlled">Controlled / Stable</option>
              <option value="uncontrolled">Uncontrolled Disease</option>
              <option value="emergency">Critical NCD Crisis</option>
            </select>
          </div>

          <div>
            <select
              value={villageFilter}
              onChange={(e) => setVillageFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium text-slate-700"
            >
              <option value="all">All Hamlets</option>
              {villages.map(v => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Chronic Patients Registry Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">Chronic Disease Registry & Surveillance</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
              {records.length} patients
            </span>
          </div>

          <button
            onClick={loadData}
            title="Refresh"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading NCD registry...</div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400 space-y-2">
            <Stethoscope className="w-8 h-8 text-slate-300 mx-auto" />
            <p>No chronic disease patients match your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-6 py-3.5">Patient & Hamlet</th>
                  <th className="px-4 py-3.5">Diagnosed Conditions</th>
                  <th className="px-4 py-3.5">Latest Vitals (BP / Glucose)</th>
                  <th className="px-4 py-3.5">Clinical Control Status</th>
                  <th className="px-4 py-3.5">Medication Adherence</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {records.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Patient */}
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                          <span>{p.name}</span>
                          <span className="text-[10px] font-semibold text-teal-700 bg-teal-50 px-1.5 py-0.2 rounded border border-teal-200">
                            {p.gender}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {p.patientId} • {p.age}y • {p.villageHamlet}
                        </p>
                      </div>
                    </td>

                    {/* Conditions */}
                    <td className="px-4 py-4">
                      <div className="flex flex-wrap gap-1 max-w-[200px]">
                        {p.conditions.length > 0 ? p.conditions.map(c => (
                          <span key={c.id} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            {c.conditionName}
                          </span>
                        )) : (p.chronicConditions || []).map((c, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            {c}
                          </span>
                        ))}
                      </div>
                    </td>

                    {/* Latest Vitals */}
                    <td className="px-4 py-4">
                      {p.latestVitals ? (
                        <div className="space-y-0.5">
                          <p className={`font-bold ${p.latestVitals.systolicBp >= 140 ? 'text-rose-600' : 'text-slate-800'}`}>
                            BP: {p.latestVitals.systolicBp ? `${p.latestVitals.systolicBp}/${p.latestVitals.diastolicBp} mmHg` : '--'}
                          </p>
                          <p className={`text-[11px] font-semibold ${p.latestVitals.bloodGlucose >= 200 ? 'text-amber-700' : 'text-slate-600'}`}>
                            Glucose: {p.latestVitals.bloodGlucose ? `${p.latestVitals.bloodGlucose} mg/dL (${p.latestVitals.glucoseContext || 'RBS'})` : '--'}
                          </p>
                          <span className="text-[10px] text-slate-400 block">
                            Logged: {p.latestVitals.assessmentDate || p.latestVitals.createdAt?.slice(0, 10)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No vitals recorded</span>
                      )}
                    </td>

                    {/* Control Status */}
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border inline-block ${p.control.overallBadge}`}>
                          {p.control.overallStatus}
                        </span>
                        {p.control.alerts.length > 0 && (
                          <p className="text-[10px] text-rose-700 font-medium truncate max-w-[150px]" title={p.control.alerts.join(', ')}>
                            {p.control.alerts[0]}
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Medication Adherence */}
                    <td className="px-4 py-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border inline-block ${p.control.adherenceBadge}`}>
                        {p.control.adherenceTier}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedPatientId(p.id);
                            setShowDetailModal(true);
                          }}
                          title="View Disease Passport"
                          className="p-1.5 text-slate-500 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            setSelectedPatient(p);
                            setShowVitalsModal(true);
                          }}
                          title="Record Surveillance Vitals"
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        >
                          <Activity className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <EnrollConditionModal
        isOpen={showEnrollModal}
        onClose={() => setShowEnrollModal(false)}
        onEnrolled={loadData}
        currentUser={currentUser}
      />

      <NcdVitalsModal
        isOpen={showVitalsModal}
        onClose={() => {
          setShowVitalsModal(false);
          setSelectedPatient(null);
        }}
        patient={selectedPatient}
        onVitalsRecorded={loadData}
        currentUser={currentUser}
      />

      <NcdDetailModal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedPatientId(null);
        }}
        patientId={selectedPatientId}
        onRecordUpdated={loadData}
        onOpenVitalsModal={(p) => {
          setSelectedPatient(p);
          setShowVitalsModal(true);
        }}
        currentUser={currentUser}
      />

    </div>
  );
}
