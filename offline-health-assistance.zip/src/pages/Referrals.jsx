import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { ReferralService } from '../services/referralService';
import { db } from '../db/db';
import CreateReferralModal from '../components/referrals/CreateReferralModal';
import DoctorFeedbackModal from '../components/referrals/DoctorFeedbackModal';
import ReferralSlipModal from '../components/referrals/ReferralSlipModal';
import {
  Share2,
  Search,
  PlusCircle,
  Eye,
  AlertTriangle,
  Ambulance,
  Building2,
  CheckCircle2,
  Clock,
  ShieldAlert,
  RefreshCw,
  Filter,
  Printer,
  Stethoscope,
  ChevronRight
} from 'lucide-react';

export default function Referrals() {
  const { currentUser } = useAuth();
  const { t } = useTranslation();

  const [stats, setStats] = useState({
    total: 0,
    emergency: 0,
    urgent: 0,
    routine: 0,
    pendingDoctorReview: 0,
    acceptedAdmitted: 0,
    completed: 0,
    ambulanceDispatched: 0
  });

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [facilityFilter, setFacilityFilter] = useState('all');
  const [villageFilter, setVillageFilter] = useState('all');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [showSlipModal, setShowSlipModal] = useState(false);
  const [selectedReferral, setSelectedReferral] = useState(null);

  useEffect(() => {
    loadData();
  }, [searchQuery, urgencyFilter, statusFilter, facilityFilter, villageFilter]);

  async function loadData() {
    setLoading(true);
    try {
      const [s, list] = await Promise.all([
        ReferralService.getDashboardStats(),
        ReferralService.getReferrals({
          query: searchQuery,
          urgencyFilter,
          statusFilter,
          facilityFilter,
          villageFilter
        })
      ]);
      setStats(s);
      setRecords(list);
    } catch (err) {
      console.error('[Referrals] Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  }

  const emergencyAlertCount = records.filter(r => r.urgency === 'emergency' && r.status !== 'completed').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
              <Share2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Emergency Referral Management</h1>
              <p className="text-sm text-gray-500">
                Clinical escalation directory, 108 ambulance dispatch & doctor review loop
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-semibold flex items-center gap-2 shadow-sm transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Referral</span>
          </button>
        </div>
      </div>

      {/* Critical Emergency Alert Banner */}
      {emergencyAlertCount > 0 && (
        <div className="bg-red-500 text-white p-4 rounded-2xl shadow-lg flex items-center justify-between gap-4 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="font-bold text-sm tracking-wide flex items-center gap-2">
                CRITICAL EMERGENCY REFERRALS ACTIVE ({emergencyAlertCount})
              </div>
              <p className="text-xs text-red-100 mt-0.5">
                Immediate patient transfers pending hospital review or ambulance dispatch. Ensure 108 ambulance is mobilized.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setUrgencyFilter('emergency');
              setStatusFilter('all');
            }}
            className="px-3 py-1.5 bg-white text-red-600 font-bold text-xs rounded-xl hover:bg-red-50 transition shadow-sm flex items-center gap-1 flex-shrink-0"
          >
            <span>View Emergencies</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 6 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-sm">
          <div className="flex items-center justify-between text-gray-500 mb-1">
            <span className="text-xs font-semibold">Total Referrals</span>
            <Share2 className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-[11px] text-gray-500 mt-0.5">Escalated cases</div>
        </div>

        <div className="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm">
          <div className="flex items-center justify-between text-red-700 mb-1">
            <span className="text-xs font-semibold">Emergency</span>
            <ShieldAlert className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-900">{stats.emergency}</div>
          <div className="text-[11px] text-red-700 mt-0.5">Immediate triage</div>
        </div>

        <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 shadow-sm">
          <div className="flex items-center justify-between text-amber-800 mb-1">
            <span className="text-xs font-semibold">Pending Review</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-900">{stats.pendingDoctorReview}</div>
          <div className="text-[11px] text-amber-800 mt-0.5">Awaiting MO triage</div>
        </div>

        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 shadow-sm">
          <div className="flex items-center justify-between text-blue-700 mb-1">
            <span className="text-xs font-semibold">Accepted / In Care</span>
            <Building2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-blue-900">{stats.acceptedAdmitted}</div>
          <div className="text-[11px] text-blue-700 mt-0.5">Admitted / Inpatient</div>
        </div>

        <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-sm">
          <div className="flex items-center justify-between text-emerald-700 mb-1">
            <span className="text-xs font-semibold">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-900">{stats.completed}</div>
          <div className="text-[11px] text-emerald-700 mt-0.5">Discharged & stabilized</div>
        </div>

        <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200 shadow-sm">
          <div className="flex items-center justify-between text-purple-700 mb-1">
            <span className="text-xs font-semibold">108 Dispatched</span>
            <Ambulance className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-purple-900">{stats.ambulanceDispatched}</div>
          <div className="text-[11px] text-purple-700 mt-0.5">Emergency vehicles</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Search by patient name, ID, clinical reason, or hospital..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <select
              value={urgencyFilter}
              onChange={e => setUrgencyFilter(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            >
              <option value="all">All Urgencies</option>
              <option value="emergency">🚨 Emergency Only</option>
              <option value="urgent">⚠️ Urgent (24-48h)</option>
              <option value="routine">ℹ️ Routine</option>
            </select>
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            >
              <option value="all">All Statuses</option>
              <option value="referred">Referred / Sent</option>
              <option value="pending_doctor_review">Pending Doctor Review</option>
              <option value="accepted">Accepted / In Care</option>
              <option value="completed">Completed / Discharged</option>
            </select>
          </div>

          <div>
            <select
              value={facilityFilter}
              onChange={e => setFacilityFilter(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            >
              <option value="all">All Facilities</option>
              <option value="PHC">Primary Health Centre (PHC)</option>
              <option value="CHC">Community Health Centre (CHC)</option>
              <option value="Taluka">Taluka Hospital</option>
              <option value="District">District Hospital</option>
            </select>
          </div>
        </div>
      </div>

      {/* Referrals Registry Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
            <span>Referrals Registry</span>
            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full font-medium">
              {records.length} records
            </span>
          </h3>

          <button
            onClick={loadData}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition"
            title="Refresh table"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-sm text-gray-500">
            Loading referral records...
          </div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-gray-500 space-y-2">
            <Share2 className="w-10 h-10 mx-auto text-gray-300" />
            <p className="font-medium text-gray-700">No referral records found.</p>
            <p className="text-xs text-gray-500">
              Create an emergency or routine referral to escalate patient care.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/70 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Patient Info</th>
                  <th className="py-3 px-4">Urgency</th>
                  <th className="py-3 px-4">Destination Facility</th>
                  <th className="py-3 px-4">Reason & Findings</th>
                  <th className="py-3 px-4">Transport</th>
                  <th className="py-3 px-4">Doctor Review</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {records.map(ref => {
                  const isEmerg = ref.urgency === 'emergency';
                  return (
                    <tr key={ref.id} className="hover:bg-gray-50/80 transition">
                      <td className="py-3 px-4">
                        <div className="font-bold text-gray-900">{ref.patientName}</div>
                        <div className="text-xs text-gray-500">
                          {ref.patientId} • {ref.patientAge}y/{ref.patientGender} • {ref.patientVillage}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full ${
                          isEmerg
                            ? 'bg-red-100 text-red-700 border border-red-200 animate-pulse'
                            : ref.urgency === 'urgent'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-blue-100 text-blue-700 border border-blue-200'
                        }`}>
                          {isEmerg && <ShieldAlert className="w-3 h-3 text-red-600" />}
                          {ref.urgency?.toUpperCase()}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-gray-800 text-xs">{ref.referralFacility}</div>
                        <div className="text-[11px] text-gray-500">
                          Escorted by: {ref.accompaniedByAsha ? 'ASHA Worker' : 'Self'}
                        </div>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <p className="text-xs text-gray-800 line-clamp-2">{ref.reason}</p>
                        {ref.provisionalDiagnosis && (
                          <span className="text-[11px] text-emerald-700 font-medium block mt-0.5">
                            {ref.provisionalDiagnosis}
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 text-xs text-gray-700">
                          {ref.transportation?.includes('108') ? (
                            <Ambulance className="w-4 h-4 text-red-600" />
                          ) : (
                            <Building2 className="w-4 h-4 text-gray-400" />
                          )}
                          <span className="font-medium">{ref.transportation || '108 Ambulance'}</span>
                        </div>
                        {ref.ambulanceDispatched && (
                          <span className="text-[10px] bg-red-50 text-red-700 px-1.5 py-0.5 rounded font-mono block mt-0.5 w-fit">
                            Dispatched
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        {ref.doctorFeedback ? (
                          <div className="text-xs">
                            <span className="font-medium text-emerald-700 block">Reviewed</span>
                            <span className="text-[11px] text-gray-500 line-clamp-1">{ref.doctorName}</span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 italic">Pending review</span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${
                          ref.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : ref.status === 'accepted'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {ref.status?.replace('_', ' ')}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedReferral(ref);
                              setShowSlipModal(true);
                            }}
                            className="p-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-medium flex items-center gap-1 transition"
                            title="View / Print Referral Slip"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Slip</span>
                          </button>

                          <button
                            onClick={() => {
                              setSelectedReferral(ref);
                              setShowDoctorModal(true);
                            }}
                            className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-medium flex items-center gap-1 transition"
                            title="Hospital Doctor Feedback"
                          >
                            <Stethoscope className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Doctor</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateReferralModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSuccess={loadData}
        currentUser={currentUser}
      />

      <DoctorFeedbackModal
        isOpen={showDoctorModal}
        onClose={() => setShowDoctorModal(false)}
        onSuccess={loadData}
        referral={selectedReferral}
        currentUser={currentUser}
      />

      <ReferralSlipModal
        isOpen={showSlipModal}
        onClose={() => setShowSlipModal(false)}
        referral={selectedReferral}
      />
    </div>
  );
}
