import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { KnowledgeEngine } from '../services/knowledgeEngine';
import ArticleManagerModal from '../components/knowledge/ArticleManagerModal';
import { db } from '../db/db';
import {
  Bot,
  Send,
  Sparkles,
  Wifi,
  WifiOff,
  Trash2,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  ShieldAlert,
  ShieldCheck,
  BookOpen,
  ArrowRight,
  Globe,
  HelpCircle,
  AlertTriangle,
  HeartHandshake,
  Baby,
  Activity,
  PlusCircle,
  CheckCircle2
} from 'lucide-react';

export default function HealthAssistant() {
  const { currentUser, isOnline } = useAuth();
  const { t, language, changeLanguage } = useTranslation();

  const [mode, setMode] = useState('offline'); // 'offline' or 'online'
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      text: language === 'kn'
        ? 'ನಮಸ್ಕಾರ! ನಾನು ನಿಮ್ಮ ಆಫ್‌ಲೈನ್ ಆರೋಗ್ಯ ಸಹಾಯಕ. ಗರ್ಭಾವಸ್ಥೆ, ಶಿಶು ಪೋಷಣೆ, ಲಸಿಕೆಗಳು, ಜ್ವರ ಅಥವಾ ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ ಕುರಿತು ಯಾವುದೇ ಪ್ರಶ್ನೆಗಳನ್ನು ಕೇಳಬಹುದು.'
        : language === 'hi'
        ? 'नमस्ते! मैं आपका ऑफलाइन स्वास्थ्य सहायक हूँ। आप गर्भावस्था, शिशु देखभाल, टीकाकरण, बुखार या प्राथमिक उपचार से संबंधित प्रश्न पूछ सकते हैं।'
        : 'Namaste! I am your Offline Healthcare Knowledge Companion. You can ask questions about maternal danger signs, newborn care, child immunization schedules, dehydration, or first aid emergency steps.',
      sources: ['National Health Mission (NHM)', 'Ministry of Health and Family Welfare (MoHFW)', 'WHO'],
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isArticleModalOpen, setIsArticleModalOpen] = useState(false);

  const messagesEndRef = useRef(null);

  const suggestedQuestions = KnowledgeEngine.getSuggestedQuestions(language);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load chat history from IndexedDB
  useEffect(() => {
    loadChatHistory();
  }, []);

  const loadChatHistory = async () => {
    try {
      if (db.assistantHistory) {
        const history = await db.assistantHistory.orderBy('id').reverse().limit(15).toArray();
        if (history.length > 0) {
          const formatted = history.reverse().map(h => ({
            id: `hist-${h.id}`,
            role: h.role,
            text: h.text,
            sources: h.sources || ['Approved National Guidelines'],
            emergency: h.emergencyFlag,
            timestamp: new Date(h.timestamp).toLocaleTimeString()
          }));
          setMessages(prev => [prev[0], ...formatted]);
        }
      }
    } catch (e) {
      console.warn('Failed to load history:', e);
    }
  };

  const handleSend = async (overrideText = null) => {
    const textToSend = overrideText || inputQuery;
    if (!textToSend || !textToSend.trim() || isProcessing) return;

    const userMsg = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsProcessing(true);

    try {
      // Execute 100% offline knowledge search
      const response = await KnowledgeEngine.query(textToSend.trim(), language);

      const assistantMsg = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        text: response.text,
        sources: response.sources,
        emergency: response.emergency,
        category: response.category,
        timestamp: new Date().toLocaleTimeString()
      };

      setMessages(prev => [...prev, assistantMsg]);

      // Read aloud if user had enabled speech
      if (isSpeaking) {
        speakText(response.text, response.language || language);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearChat = async () => {
    setMessages([messages[0]]);
    try {
      if (db.assistantHistory) {
        await db.assistantHistory.clear();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Text-to-Speech (Web Speech API)
  const speakText = (text, lang) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);

    if (lang === 'kn') utterance.lang = 'kn-IN';
    else if (lang === 'hi') utterance.lang = 'hi-IN';
    else utterance.lang = 'en-IN';

    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Speech-to-Text (Web Speech API)
  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please use keyboard input.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = language === 'kn' ? 'kn-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputQuery(transcript);
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (e) {
      console.error('Speech recognition error:', e);
      setIsListening(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900">{t('assistant.title')}</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>100% Offline Engine</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{t('assistant.tagline')}</p>
        </div>

        {/* Action Controls & Mode Switch */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-2.5 py-1.5 rounded-xl shadow-sm text-xs font-semibold">
            <Globe className="w-3.5 h-3.5 text-teal-700" />
            <select
              value={language}
              onChange={(e) => changeLanguage(e.target.value)}
              className="bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="en">English</option>
              <option value="kn">ಕನ್ನಡ (Kannada)</option>
              <option value="hi">हिन्दी (Hindi)</option>
            </select>
          </div>

          {/* Mode Pill */}
          <div className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Deterministic Local Knowledge</span>
          </div>

          {/* Admin Publish Button */}
          {(currentUser?.role === 'admin' || currentUser?.role === 'doctor') && (
            <button
              onClick={() => setIsArticleModalOpen(true)}
              className="px-3 py-1.5 bg-teal-50 border border-teal-200 hover:bg-teal-100 text-teal-800 rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5 text-teal-700" />
              <span>Publish Guideline</span>
            </button>
          )}

          <button
            onClick={handleClearChat}
            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
            title="Clear Chat Conversation"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Suggested Questions Carousel */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-teal-600" />
            <span>{t('assistant.suggestedTitle')}</span>
          </span>
          <span className="text-[10px] text-slate-400">Click to ask instantly</span>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="px-3 py-1.5 rounded-xl bg-teal-50/70 hover:bg-teal-100 border border-teal-200/80 text-teal-900 text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5"
            >
              <span>{q}</span>
              <ArrowRight className="w-3 h-3 text-teal-600 flex-shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Main Conversational View Area */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm flex flex-col h-[600px] overflow-hidden">
        
        {/* Chat Message List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold shadow-sm ${
                  isUser
                    ? 'bg-gradient-to-tr from-teal-600 to-emerald-600 text-white'
                    : 'bg-teal-50 border border-teal-200 text-teal-800'
                }`}>
                  {isUser ? (currentUser?.avatar || 'HW') : <Bot className="w-4 h-4 text-teal-700" />}
                </div>

                {/* Message Bubble */}
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-sm ${
                    isUser
                      ? 'bg-gradient-to-r from-teal-700 to-emerald-700 text-white rounded-tr-none'
                      : 'bg-slate-50 border border-slate-200/80 text-slate-800 rounded-tl-none'
                  }`}>
                    {/* Emergency Escalation Callout */}
                    {msg.emergency && (
                      <div className="mb-3 p-3 rounded-xl bg-rose-100 border border-rose-300 text-rose-900 text-xs font-semibold flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                        <span>{t('assistant.emergencyEscalation')} - Initiate 108 ambulance transport immediately.</span>
                      </div>
                    )}

                    <div className="whitespace-pre-line">
                      {msg.text}
                    </div>

                    {/* Sources Badge */}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-200/60 text-[11px] text-slate-500">
                        <span className="font-bold text-slate-700 block mb-1">
                          {t('assistant.sourcesTitle')}:
                        </span>
                        <ul className="list-disc list-inside space-y-0.5">
                          {msg.sources.map((s, sIdx) => (
                            <li key={sIdx} className="text-teal-800 font-medium">{s}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Bubble Footer & Actions */}
                  <div className={`flex items-center gap-2 text-[10px] text-slate-400 px-1 ${
                    isUser ? 'justify-end' : 'justify-between'
                  }`}>
                    <span>{msg.timestamp}</span>

                    {!isUser && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => isSpeaking ? stopSpeaking() : speakText(msg.text, language)}
                          className="hover:text-teal-700 p-0.5 rounded"
                          title="Read aloud"
                        >
                          {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-teal-600" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isProcessing && (
            <div className="flex gap-3 max-w-xl">
              <div className="w-8 h-8 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-800">
                <Bot className="w-4 h-4 animate-bounce" />
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs text-slate-500 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-teal-600 animate-ping" />
                <span>Searching local offline healthcare guidelines...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar & Disclaimer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/80 space-y-2.5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <input
                type="text"
                placeholder={t('assistant.placeholder')}
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                disabled={isProcessing}
                className="w-full pl-4 pr-10 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all placeholder:text-slate-400 shadow-inner"
              />

              <button
                type="button"
                onClick={startListening}
                className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-xl transition-colors ${
                  isListening ? 'bg-rose-100 text-rose-600 animate-pulse' : 'text-slate-400 hover:text-teal-700'
                }`}
                title="Speak question (voice recognition)"
              >
                {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </button>
            </div>

            <button
              type="submit"
              disabled={!inputQuery.trim() || isProcessing}
              className="p-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-2xl shadow-md shadow-teal-700/20 disabled:opacity-40 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Legal Medical Disclaimer */}
          <p className="text-[10px] text-center text-slate-400 leading-tight">
            <span className="font-semibold text-slate-500">Notice:</span> {t('assistant.disclaimer')}
          </p>
        </div>

      </div>

      {/* Admin Guideline Modal */}
      <ArticleManagerModal
        isOpen={isArticleModalOpen}
        onClose={() => setIsArticleModalOpen(false)}
        onSaved={(article) => {
          setMessages(prev => [
            ...prev,
            {
              id: `pub-${Date.now()}`,
              role: 'assistant',
              text: `New clinical guideline published into local library: "${article.title}". Authority: ${article.authority}. Available for offline question matching.`,
              sources: [article.authority],
              timestamp: new Date().toLocaleTimeString()
            }
          ]);
        }}
      />

    </div>
  );
}
