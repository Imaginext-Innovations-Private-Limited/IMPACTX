import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { AssessmentService } from '../services/assessmentService';
import { networkService } from '../services/networkService';
import AssessmentWizardModal from '../components/assessments/AssessmentWizardModal';
import AssessmentDetailModal from '../components/assessments/AssessmentDetailModal';
import AssessmentEditModal from '../components/assessments/AssessmentEditModal';
import AssessmentTrendsModal from '../components/assessments/AssessmentTrendsModal';
import { runAssessmentTestSuite } from '../utils/assessmentTestSuite';
import {
  Activity,
  PlusCircle,
  PlayCircle,
  Search,
  Filter,
  Calendar,
  AlertTriangle,
  Heart,
  TrendingUp,
  FileText,
  Clock,
  User,
  CheckCircle2,
  Share2,
  CalendarClock,
  ShieldAlert,
  ChevronRight,
  Eye,
  RefreshCw,
  Baby,
  HeartHandshake
} from 'lucide-react';

export default function Assessments() {
  const { currentUser } = useAuth();
  const { t } = useTranslation();

  // Stats & Assessment Lists
  const [stats, setStats] = useState({
    total: 0,
    today: 0,
    thisMonth: 0,
    withWarnings: 0,
    requiringFollowUp: 0,
    pendingReferrals: 0,
    completed: 0,
    partial: 0,
    highPriorityAlerts: []
  });
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedRisk, setSelectedRisk] = useState('all');
  const [selectedDate, setSelectedDate] = useState('');

  // Modals
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [editingAssessment, setEditingAssessment] = useState(null);
  const [trendsPatient, setTrendsPatient] = useState(null);

  // Automated 22-Point Test Suite state
  const [testResults, setTestResults] = useState([]);
  const [runningTests, setRunningTests] = useState(false);

  useEffect(() => {
    loadData();
  }, [searchQuery, selectedCategory, selectedRisk, selectedDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, listData] = await Promise.all([
        AssessmentService.getDashboardStats(),
        AssessmentService.getAssessments({
          search: searchQuery,
          category: selectedCategory,
          riskLevel: selectedRisk,
          date: selectedDate
        })
      ]);
      setStats(statsData);
      setAssessments(listData);
    } catch (err) {
      console.error('[Assessments] Failed to load assessment records:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAssessmentCreated = () => {
    loadData();
  };

  const handleRunTests = async () => {
    setRunningTests(true);
    setTestResults([]);
    try {
      const results = await runAssessmentTestSuite((item, all) => {
        setTestResults([...all]);
      });
      loadData();
    } catch (e) {
      console.error(e);
    } finally {
      setRunningTests(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900">Health Assessments & Vitals Screening</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
              Offline Clinical Protocol
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Community Vital Screening • Population Risk Stratification • Automatic BMI & IDRS • Emergency Triage
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRunTests}
            disabled={runningTests}
            className="px-3.5 py-2.5 rounded-xl border border-teal-300 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all"
            title="Execute automated 22-point clinical assessment verification test suite"
          >
            <PlayCircle className={`w-4 h-4 ${runningTests ? 'animate-spin' : 'text-teal-700'}`} />
            <span>{runningTests ? 'Running Clinical Tests...' : 'Run 22-Point Verification'}</span>
          </button>

          <button
            onClick={() => setIsWizardOpen(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-700/20 flex items-center gap-2 transition-all flex-shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Health Assessment</span>
          </button>
        </div>
      </div>

      {/* Automated 22-Point Test Suite Live Results */}
      {testResults.length > 0 && (
        <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center font-mono font-bold text-xs">
                {testResults.filter(t => t.passed).length}/{testResults.length}
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Clinical Assessment Verification Suite Results</h3>
                <p className="text-[11px] text-slate-400">22 Comprehensive Screening & Offline Verification Tests</p>
              </div>
            </div>
            <button
              onClick={() => setTestResults([])}
              className="text-xs text-slate-400 hover:text-white"
            >
              Dismiss
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1 text-xs">
            {testResults.map((t, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-start justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] text-slate-400">{t.id}</span>
                    <span className="font-semibold text-white">{t.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 truncate max-w-sm">{t.details}</p>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  t.passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                }`}>
                  {t.passed ? 'PASS' : 'FAIL'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Real Database Statistics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* Total */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Recorded</span>
          <span className="text-xl font-extrabold text-slate-900 mt-0.5 block">{stats.total}</span>
          <span className="text-[10px] text-teal-600 font-medium">All field screenings</span>
        </div>

        {/* Today */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Today's Visits</span>
          <span className="text-xl font-extrabold text-emerald-700 mt-0.5 block">{stats.today}</span>
          <span className="text-[10px] text-slate-400">Assessed today</span>
        </div>

        {/* This Month */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">This Month</span>
          <span className="text-xl font-extrabold text-teal-700 mt-0.5 block">{stats.thisMonth}</span>
          <span className="text-[10px] text-slate-400">Monthly progress</span>
        </div>

        {/* Warnings */}
        <div className="p-3.5 rounded-2xl bg-white border border-rose-200 shadow-2xs bg-rose-50/20">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block">Warning Flags</span>
          <span className="text-xl font-extrabold text-rose-700 mt-0.5 block">{stats.withWarnings}</span>
          <span className="text-[10px] text-rose-600 font-semibold">Abnormal readings</span>
        </div>

        {/* Follow-ups */}
        <div className="p-3.5 rounded-2xl bg-white border border-amber-200 shadow-2xs bg-amber-50/20">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block">Need Follow-up</span>
          <span className="text-xl font-extrabold text-amber-800 mt-0.5 block">{stats.requiringFollowUp}</span>
          <span className="text-[10px] text-amber-700">Scheduled checks</span>
        </div>

        {/* Referrals */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Pending Referrals</span>
          <span className="text-xl font-extrabold text-purple-700 mt-0.5 block">{stats.pendingReferrals}</span>
          <span className="text-[10px] text-purple-600 font-medium">Referred to PHC</span>
        </div>

        {/* Completed */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Complete</span>
          <span className="text-xl font-extrabold text-slate-800 mt-0.5 block">{stats.completed}</span>
          <span className="text-[10px] text-slate-400">All vitals logged</span>
        </div>

        {/* Partial */}
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Partial Logs</span>
          <span className="text-xl font-extrabold text-slate-500 mt-0.5 block">{stats.partial}</span>
          <span className="text-[10px] text-slate-400">Awaiting inputs</span>
        </div>
      </div>

      {/* High Priority Alerts Panel (If any exist) */}
      {stats.highPriorityAlerts.length > 0 && (
        <div className="p-5 rounded-3xl bg-rose-50 border-2 border-rose-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-900 font-bold text-sm">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <span>Critical Clinical Alerts Requiring Escalation ({stats.highPriorityAlerts.length})</span>
            </div>
            <span className="text-xs text-rose-700 font-semibold">Immediate Review Advised</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {stats.highPriorityAlerts.map(alert => (
              <div
                key={alert.id}
                onClick={async () => {
                  const full = await AssessmentService.getAssessmentById(alert.id);
                  setSelectedAssessment(full);
                }}
                className="p-3.5 bg-white rounded-2xl border border-rose-200 shadow-2xs hover:border-rose-400 cursor-pointer transition-all space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">{alert.patientName}</span>
                  <span className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                    alert.isEmergency ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {alert.isEmergency ? 'Emergency' : 'Warning'}
                  </span>
                </div>
                <p className="text-[11px] text-rose-700 font-semibold line-clamp-2">
                  {alert.warnings.join(' • ')}
                </p>
                <p className="text-[10px] text-slate-400 pt-1 flex justify-between">
                  <span>{alert.village}</span>
                  <span>{new Date(alert.date).toLocaleDateString()}</span>
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Patient Name, ID, or Village Hamlet..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all placeholder:text-slate-400"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none"
          >
            <option value="all">All Screening Types</option>
            <option value="General Health Screening">General Health Screening</option>
            <option value="Hypertension & NCD Screening">Hypertension & NCD</option>
            <option value="Maternal Healthcare">Maternal Healthcare (ANC)</option>
            <option value="Child Healthcare">Child Healthcare & Wellness</option>
            <option value="Respiratory Screening">Respiratory Screening</option>
          </select>

          {/* Risk Tier Filter */}
          <select
            value={selectedRisk}
            onChange={(e) => setSelectedRisk(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none"
          >
            <option value="all">All Risk Levels</option>
            <option value="normal">Normal (Screening)</option>
            <option value="requires_follow_up">Requires Follow-up</option>
            <option value="warning_detected">Warning Detected</option>
            <option value="urgent_emergency">Urgent Emergency</option>
          </select>

          {/* Date Filter */}
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none"
          />

          {(searchQuery || selectedCategory !== 'all' || selectedRisk !== 'all' || selectedDate) && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedRisk('all');
                setSelectedDate('');
              }}
              className="text-xs text-rose-600 font-bold hover:underline px-2"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Main Assessment Registry Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Assessment Records ({assessments.length})
          </h3>
          <span className="text-xs text-slate-400">100% Offline Accessible • Dexie.js Persistence</span>
        </div>

        {loading ? (
          <div className="text-center py-16 text-slate-400 text-xs font-semibold">
            Loading clinical assessment records...
          </div>
        ) : assessments.length === 0 ? (
          <div className="text-center py-16 space-y-2">
            <Activity className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No Assessment Records Found</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No clinical screenings match your search filters. Click "New Health Assessment" to record vital signs and screening questionnaires.
            </p>
            <button
              onClick={() => setIsWizardOpen(true)}
              className="mt-3 px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold shadow-sm"
            >
              + Record First Assessment
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Type & Date</th>
                  <th className="py-3 px-4">Vital Signs</th>
                  <th className="py-3 px-4">BMI & Glucose</th>
                  <th className="py-3 px-4">Triage Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {assessments.map(item => {
                  const warnings = item.warningSigns || item.warningIndicators || [];
                  const isEmerg = item.isEmergency || item.riskLevel === 'urgent_emergency';
                  const hasWarn = warnings.length > 0;

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Patient */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 font-bold flex items-center justify-center text-xs flex-shrink-0">
                            {item.patientName?.slice(0, 2).toUpperCase() || 'PT'}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">{item.patientName}</div>
                            <div className="text-[11px] text-slate-400">
                              {item.patientAge}y • {item.patientGender} • {item.patientVillage}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Type & Date */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800">{item.assessmentType}</div>
                        <div className="text-[11px] text-slate-400">
                          {item.assessmentDate || item.createdAt?.slice(0, 10)} • By {item.assessedBy}
                        </div>
                      </td>

                      {/* Vital Signs */}
                      <td className="py-3 px-4">
                        <div className="font-mono text-slate-900 font-semibold">
                          {item.systolicBp && item.diastolicBp ? `${item.systolicBp}/${item.diastolicBp} mmHg` : 'BP unrecorded'}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {item.pulse ? `Pulse: ${item.pulse} bpm` : ''} {item.spo2 ? `• SpO2: ${item.spo2}%` : ''}
                        </div>
                      </td>

                      {/* BMI & Glucose */}
                      <td className="py-3 px-4">
                        <div>
                          {item.bmi ? (
                            <span className="font-semibold text-slate-800">{item.bmi} kg/m²</span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                          {item.bloodGlucose && (
                            <span className="text-[11px] text-slate-500 block">
                              Glucose: {item.bloodGlucose} mg/dL ({item.glucoseContext})
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Triage Status */}
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border inline-block ${
                          isEmerg
                            ? 'bg-rose-100 text-rose-800 border-rose-300'
                            : hasWarn
                            ? 'bg-amber-100 text-amber-800 border-amber-300'
                            : item.status === 'requires_follow_up'
                            ? 'bg-blue-100 text-blue-800 border-blue-200'
                            : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        }`}>
                          {item.classification || item.status || 'Recorded'}
                        </span>
                        {item.referralId && (
                          <span className="text-[9px] text-purple-700 block font-semibold mt-0.5">
                            Referred
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={async () => {
                              const full = await AssessmentService.getAssessmentById(item.id);
                              setSelectedAssessment(full);
                            }}
                            className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                            title="View Full Report"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              setTrendsPatient({ id: item.patientId, name: item.patientName });
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                            title="View Patient Trends"
                          >
                            <TrendingUp className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODALS */}
      {/* 1. New Assessment Wizard */}
      <AssessmentWizardModal
        isOpen={isWizardOpen}
        onClose={() => setIsWizardOpen(false)}
        onAssessmentCreated={handleAssessmentCreated}
        currentUser={currentUser}
      />

      {/* 2. Detailed Assessment Summary Report Modal */}
      <AssessmentDetailModal
        assessment={selectedAssessment}
        isOpen={Boolean(selectedAssessment)}
        onClose={() => setSelectedAssessment(null)}
        onEdit={(ass) => {
          setSelectedAssessment(null);
          setEditingAssessment(ass);
        }}
        onUpdated={loadData}
        currentUser={currentUser}
      />

      {/* 3. Audit Edit Modal */}
      <AssessmentEditModal
        assessment={editingAssessment}
        isOpen={Boolean(editingAssessment)}
        onClose={() => setEditingAssessment(null)}
        onSaved={loadData}
        currentUser={currentUser}
      />

      {/* 4. Longitudinal Trends Modal */}
      <AssessmentTrendsModal
        patientId={trendsPatient?.id}
        patientName={trendsPatient?.name}
        isOpen={Boolean(trendsPatient)}
        onClose={() => setTrendsPatient(null)}
      />

    </div>
  );
}
