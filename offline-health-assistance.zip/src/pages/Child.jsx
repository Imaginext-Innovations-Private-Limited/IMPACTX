import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../hooks/useTranslation';
import { ChildService } from '../services/childService';
import { ClinicalCalculators } from '../utils/clinicalCalculators';
import { db } from '../db/db';
import ChildRegisterModal from '../components/child/ChildRegisterModal';
import GrowthMeasurementModal from '../components/child/GrowthMeasurementModal';
import ImmunizationModal from '../components/child/ImmunizationModal';
import ChildDetailModal from '../components/child/ChildDetailModal';
import {
  Baby,
  Search,
  PlusCircle,
  Eye,
  Scale,
  ShieldCheck,
  Share2,
  AlertTriangle,
  CheckCircle2,
  User,
  ShieldAlert,
  PlayCircle,
  Sparkles,
  RefreshCw,
  Clock,
  Filter
} from 'lucide-react';

export default function Child() {
  const { currentUser, isOnline } = useAuth();
  const { t } = useTranslation();

  const [stats, setStats] = useState({
    total: 0,
    normalGrowth: 0,
    mamCount: 0,
    samCount: 0,
    overdueVaccines: 0,
    upToDateCount: 0
  });

  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [nutritionFilter, setNutritionFilter] = useState('all');
  const [immunizationFilter, setImmunizationFilter] = useState('all');
  const [villageFilter, setVillageFilter] = useState('all');

  // Modals
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showGrowthModal, setShowGrowthModal] = useState(false);
  const [showVaxModal, setShowVaxModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);
  const [selectedChildId, setSelectedChildId] = useState(null);
  const [targetVaccine, setTargetVaccine] = useState(null);

  // Test Runner State
  const [testResults, setTestResults] = useState(null);
  const [runningTests, setRunningTests] = useState(false);

  useEffect(() => {
    loadData();
  }, [searchQuery, nutritionFilter, immunizationFilter, villageFilter]);

  async function loadData() {
    setLoading(true);
    try {
      const [s, list] = await Promise.all([
        ChildService.getDashboardStats(),
        ChildService.getChildRecords({
          query: searchQuery,
          nutritionFilter,
          immunizationFilter,
          village: villageFilter
        })
      ]);
      setStats(s);
      setRecords(list);
    } catch (err) {
      console.error('[Child] Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  }

  // 20-Point Automated Child Healthcare Verification Runner
  const runVerificationSuite = async () => {
    setRunningTests(true);
    const results = [];

    const assert = (id, name, condition, details) => {
      results.push({
        id,
        name,
        passed: Boolean(condition),
        details: String(details)
      });
    };

    try {
      // TEST-01: Low Birth Weight classification (<2.5 kg)
      const lbwEval = ClinicalCalculators.classifyBirthWeight(2.1, 36);
      assert(
        'TEST-01',
        'Low Birth Weight Classification (<2.5 kg)',
        lbwEval.isLbw && lbwEval.isPreterm,
        `Weight: 2.1 kg -> Tier: ${lbwEval.weightTier}, Preterm: ${lbwEval.isPreterm}`
      );

      // TEST-02: Normal Birth Weight (>=2.5 kg)
      const nbwEval = ClinicalCalculators.classifyBirthWeight(3.1, 39);
      assert(
        'TEST-02',
        'Normal Birth Weight Classification (≥2.5 kg)',
        !nbwEval.isLbw && !nbwEval.isPreterm,
        `Weight: 3.1 kg -> Tier: ${nbwEval.weightTier}`
      );

      // TEST-03: Preterm Infant Classification (<37 weeks)
      const pretermEval = ClinicalCalculators.classifyBirthWeight(2.8, 35);
      assert(
        'TEST-03',
        'Preterm Infant Triage (<37 weeks)',
        pretermEval.isPreterm,
        `Gestational Age: 35w -> ${pretermEval.termTier}`
      );

      // TEST-04: UIP birth doses generation
      const uipSchedule = ClinicalCalculators.getUipImmunizationSchedule('2026-06-01');
      assert(
        'TEST-04',
        'UIP National Immunization Schedule Generation',
        uipSchedule.length >= 15 && uipSchedule[0].vaccineKey === 'BCG',
        `Generated ${uipSchedule.length} vaccination milestones`
      );

      // TEST-05: Child registration in Dexie
      const regRes = await ChildService.registerChild({
        name: 'Virendra Kumar',
        gender: 'male',
        dateOfBirth: '2026-05-10',
        contactNumber: '9845199991',
        villageHamlet: 'Rampur Hamlet 4',
        birthWeight: '2.3',
        gestationalAge: '36',
        vaccinesGivenAtBirth: ['BCG', 'OPV-0', 'HepB-0']
      }, currentUser);
      assert(
        'TEST-05',
        'Child Registration in Dexie.js',
        regRes && regRes.patient && regRes.birthRecord,
        `Registered child ${regRes.patient.id} with LBW birth record ${regRes.birthRecord.id}`
      );

      // TEST-06: 6-week immunization follow-up scheduling
      const fuList = await db.followUps.where('patientId').equals(regRes.patient.id).toArray();
      const has6wFu = fuList.some(f => f.visitType?.includes('6-Week Universal Immunization'));
      assert(
        'TEST-06',
        '6-Week Immunization Follow-Up Scheduler',
        has6wFu,
        `Found scheduled task: ${fuList[0]?.visitType}`
      );

      // TEST-07: Growth measurement recording
      const growthRes1 = await ChildService.recordGrowthMeasurement({
        patientId: regRes.patient.id,
        childId: regRes.birthRecord.id,
        ageMonths: '6',
        weightKg: '7.2',
        heightCm: '66.0',
        muacCm: '13.5'
      }, currentUser);
      assert(
        'TEST-07',
        'Growth Measurement Logging in Dexie',
        growthRes1 && growthRes1.record && growthRes1.record.id,
        `Logged growth record: 7.2 kg, MUAC 13.5 cm`
      );

      // TEST-08: Normal pediatric growth classification
      assert(
        'TEST-08',
        'Normal Healthy Growth Evaluation',
        growthRes1.growthEval.overallGrade?.includes('Normal'),
        `Grade: ${growthRes1.growthEval.overallGrade}`
      );

      // TEST-09: Moderate Acute Malnutrition (MAM) screening (MUAC 11.5 - 12.4 cm)
      const mamEval = ClinicalCalculators.classifyPediatricGrowth(14, 'male', 7.5, 71.0, 11.8);
      assert(
        'TEST-09',
        'Moderate Acute Malnutrition (MAM) Yellow Zone',
        mamEval.overallGrade?.includes('MAM'),
        `MUAC: 11.8 cm -> Grade: ${mamEval.overallGrade}`
      );

      // TEST-10: Severe Acute Malnutrition (SAM) red zone screening (MUAC < 11.5 cm)
      const samEval = ClinicalCalculators.classifyPediatricGrowth(14, 'male', 6.8, 70.0, 11.0);
      assert(
        'TEST-10',
        'Severe Acute Malnutrition (SAM) Red Zone (<11.5 cm)',
        samEval.isEmergency && samEval.overallGrade?.includes('SAM'),
        `MUAC: 11.0 cm -> Grade: ${samEval.overallGrade}`
      );

      // TEST-11: Weight-for-age failure detection (< -3 SD)
      const lowWeightEval = ClinicalCalculators.classifyPediatricGrowth(12, 'male', 5.5, 68.0, 13.0);
      assert(
        'TEST-11',
        'Severely Underweight for Age Detection (< -3 SD)',
        lowWeightEval.isMalnourished && lowWeightEval.weightForAgeTier.includes('Severely Underweight'),
        `Weight: 5.5 kg at 12m -> Tier: ${lowWeightEval.weightForAgeTier}`
      );

      // TEST-12: Child risk level escalation on SAM detection
      const samGrowthRes = await ChildService.recordGrowthMeasurement({
        patientId: regRes.patient.id,
        childId: regRes.birthRecord.id,
        ageMonths: '14',
        weightKg: '6.9',
        heightCm: '71.0',
        muacCm: '11.1'
      }, currentUser);
      const updatedChild = await db.patients.get(regRes.patient.id);
      assert(
        'TEST-12',
        'Risk Level Escalation to High Risk on SAM',
        updatedChild.riskLevel === 'high',
        `Child risk level set to: ${updatedChild.riskLevel}`
      );

      // TEST-13: Automatic Emergency NRC Referral dispatch
      const refList = await db.referrals.where('patientId').equals(regRes.patient.id).toArray();
      const hasNrcRef = refList.some(r => r.referralFacility?.includes('NRC'));
      assert(
        'TEST-13',
        'Automatic Emergency NRC Referral Creation',
        hasNrcRef,
        `Created emergency referral: ${refList[0]?.reason}`
      );

      // TEST-14: Vaccine administration logging in db.immunizations
      const vaxAdmin = await ChildService.recordImmunization({
        patientId: regRes.patient.id,
        childId: regRes.birthRecord.id,
        vaccineName: 'Pentavalent-1',
        vaccineKey: 'Penta-1',
        doseNumber: 1,
        dueDate: '2026-06-21',
        givenDate: '2026-06-21',
        batchNumber: 'PENTA-LOT-992'
      }, currentUser);
      assert(
        'TEST-14',
        'Universal Vaccine Administration Logging',
        vaxAdmin && vaxAdmin.status === 'administered',
        `Administered Pentavalent-1 on ${vaxAdmin.givenDate}`
      );

      // TEST-15: Overdue vaccine detection
      const testDobPast = '2025-06-01'; // 1.5 years ago
      const schedulePast = ClinicalCalculators.getUipImmunizationSchedule(testDobPast, []);
      const overdueCount = schedulePast.filter(v => v.status === 'overdue').length;
      assert(
        'TEST-15',
        'Overdue Vaccine Automated Detection',
        overdueCount > 0,
        `Detected ${overdueCount} overdue vaccines for unvaccinated toddler`
      );

      // TEST-16: Full Mamta card data model retrieval
      const mamtaCard = await ChildService.getChildById(regRes.patient.id);
      assert(
        'TEST-16',
        'Mamta Card Full Data Model Retrieval',
        mamtaCard && mamtaCard.growths.length === 2 && mamtaCard.uipSchedule.length >= 15,
        `Retrieved card with ${mamtaCard.growths.length} growth logs & ${mamtaCard.uipSchedule.length} vaccines`
      );

      // TEST-17: 1-Click Pediatric Referral
      const directRef = await ChildService.createReferralFromChild(
        regRes.patient,
        'Persistent diarrhea with severe dehydration signs',
        'Mandya Taluka Hospital (Pediatrics)',
        'emergency',
        currentUser
      );
      assert(
        'TEST-17',
        '1-Click Pediatric Referral Dispatch',
        directRef && directRef.id,
        `Referral dispatched to ${directRef.referralFacility}`
      );

      // TEST-18: 1-Click Pediatric Follow-up Scheduling
      const directFu = await ChildService.scheduleFollowUpFromChild(
        regRes.patient,
        'Home Nutrition & Micronutrient Follow-up',
        '2026-11-30',
        'Check supplementary nutrition porridge intake.',
        'urgent',
        currentUser
      );
      assert(
        'TEST-18',
        '1-Click Pediatric Follow-up Scheduling',
        directFu && directFu.id,
        `Scheduled task for ${directFu.scheduledDate}`
      );

      // TEST-19: Up-to-date vs overdue aggregation
      const statsAgg = await ChildService.getDashboardStats();
      assert(
        'TEST-19',
        'Pediatric Cohort Status Aggregation',
        statsAgg.total >= 1,
        `Total: ${statsAgg.total}, Normal: ${statsAgg.normalGrowth}, SAM: ${statsAgg.samCount}, Overdue: ${statsAgg.overdueVaccines}`
      );

      // TEST-20: Multi-parameter filtering
      const filteredList = await ChildService.getChildRecords({ nutritionFilter: 'sam' });
      assert(
        'TEST-20',
        'Multi-Parameter Nutrition Filtering',
        filteredList.length >= 1 && filteredList.every(c => c.isSam),
        `Filtered ${filteredList.length} children in SAM Red Zone`
      );

    } catch (testErr) {
      console.error('Child test error:', testErr);
      results.push({
        id: 'TEST-ERR',
        name: 'Execution Exception',
        passed: false,
        details: testErr.message
      });
    }

    setTestResults(results);
    setRunningTests(false);
    await loadData();
  };

  const villages = Array.from(new Set(records.map(r => r.villageHamlet).filter(Boolean)));

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Child Healthcare & Universal Immunization
            </h1>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
              WHO Growth Standards • UIP India
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Infant & Child Health (0-5y) • Growth Surveillance & MUAC Malnutrition Triage (SAM/MAM) • Universal Vaccine Schedule
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={runVerificationSuite}
            disabled={runningTests}
            className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
          >
            <PlayCircle className={`w-4 h-4 text-indigo-600 ${runningTests ? 'animate-spin' : ''}`} />
            <span>{runningTests ? 'Running 20-Point Tests...' : 'Run 20-Point Verification'}</span>
          </button>

          <button
            onClick={() => setShowRegisterModal(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-teal-600 hover:from-indigo-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Register Child (0-5 Years)</span>
          </button>
        </div>
      </div>

      {/* Automated Verification Suite Results Banner */}
      {testResults && (
        <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl relative overflow-hidden animate-in fade-in duration-300">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 font-black text-xs flex items-center justify-center border border-indigo-500/30">
                {testResults.filter(t => t.passed).length}/{testResults.length}
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Child Healthcare Verification Suite Results</h3>
                <p className="text-[11px] text-slate-400">20 Real Dexie.js & Pediatric Protocol Assertions</p>
              </div>
            </div>

            <button
              onClick={() => setTestResults(null)}
              className="text-xs text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              Dismiss
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto pr-1">
            {testResults.map(t => (
              <div
                key={t.id}
                className={`p-2.5 rounded-xl border text-xs transition-colors ${
                  t.passed
                    ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] font-bold text-slate-400">{t.id}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                    t.passed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {t.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
                <p className="font-semibold text-slate-200 truncate">{t.name}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{t.details}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6 Real-time Database Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Total Monitored
          </span>
          <div className="text-2xl font-black text-slate-900">{stats.total}</div>
          <span className="text-[10px] text-indigo-600 font-semibold mt-1 block">Under-5 cohort</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Normal Growth
          </span>
          <div className="text-2xl font-black text-emerald-700">{stats.normalGrowth}</div>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">Healthy z-scores</span>
        </div>

        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
            MAM (Yellow Zone)
          </span>
          <div className="text-2xl font-black text-amber-800">{stats.mamCount}</div>
          <span className="text-[10px] text-amber-700 font-semibold mt-1 block">Anganwadi SNP</span>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block mb-1">
            SAM (Red Zone Alert)
          </span>
          <div className="text-2xl font-black text-rose-700">{stats.samCount}</div>
          <span className="text-[10px] text-rose-600 font-semibold mt-1 block">NRC admission</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Fully Immunized
          </span>
          <div className="text-2xl font-black text-teal-700">{stats.upToDateCount}</div>
          <span className="text-[10px] text-teal-600 font-semibold mt-1 block">Up to date</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Overdue Vaccines
          </span>
          <div className="text-2xl font-black text-orange-700">{stats.overdueVaccines}</div>
          <span className="text-[10px] text-orange-600 font-semibold mt-1 block">Catch-up needed</span>
        </div>
      </div>

      {/* Malnutrition Emergency Alert Banner */}
      {stats.samCount > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 via-pink-50 to-amber-50 border border-rose-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center flex-shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-rose-900">
                {stats.samCount} Children in Severe Acute Malnutrition (SAM) Red Zone
              </h4>
              <p className="text-[11px] text-rose-700 mt-0.5">
                Mid-Upper Arm Circumference &lt;11.5 cm or severe wasting. Immediate therapeutic feeding and Nutrition Rehabilitation Centre (NRC) admission required.
              </p>
            </div>
          </div>
          <button
            onClick={() => setNutritionFilter('sam')}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors flex-shrink-0"
          >
            View SAM Children
          </button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by child name, Patient ID, phone, village..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          <div>
            <select
              value={nutritionFilter}
              onChange={(e) => setNutritionFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700"
            >
              <option value="all">All Nutritional Status</option>
              <option value="sam">SAM (Red Zone Alert)</option>
              <option value="mam">MAM (Yellow Zone)</option>
              <option value="normal">Normal Healthy Growth</option>
            </select>
          </div>

          <div>
            <select
              value={immunizationFilter}
              onChange={(e) => setImmunizationFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700"
            >
              <option value="all">All Immunization States</option>
              <option value="overdue">Overdue Vaccines</option>
              <option value="uptodate">Up to Date</option>
            </select>
          </div>

          <div>
            <select
              value={villageFilter}
              onChange={(e) => setVillageFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700"
            >
              <option value="all">All Hamlets</option>
              {villages.map(v => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Children Registry Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">Child Health & Immunization Cohort</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
              {records.length} children
            </span>
          </div>

          <button
            onClick={loadData}
            title="Refresh"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading child records...</div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400 space-y-2">
            <Baby className="w-8 h-8 text-slate-300 mx-auto" />
            <p>No child records match your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-6 py-3.5">Child & Demographics</th>
                  <th className="px-4 py-3.5">Age & DOB</th>
                  <th className="px-4 py-3.5">Growth & Anthropometry</th>
                  <th className="px-4 py-3.5">Nutritional Triage</th>
                  <th className="px-4 py-3.5">Immunization (UIP)</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {records.map((child) => (
                  <tr key={child.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Child Demographics */}
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                          <span>{child.name}</span>
                          <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200 uppercase">
                            {child.gender}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {child.patientId} • {child.villageHamlet}
                        </p>
                      </div>
                    </td>

                    {/* Age & DOB */}
                    <td className="px-4 py-4">
                      <div className="space-y-0.5">
                        <p className="font-bold text-slate-800">{child.age} years</p>
                        <p className="text-[11px] text-slate-500">DOB: {child.dateOfBirth}</p>
                        {child.birth?.birthWeight && (
                          <span className="text-[10px] text-slate-400 block">
                            Birth Wt: {child.birth.birthWeight} kg
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Growth & Anthropometry */}
                    <td className="px-4 py-4">
                      {child.latestGrowth ? (
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-800">
                            Weight: {child.latestGrowth.weightKg} kg
                          </p>
                          <p className="text-[11px] text-slate-500">
                            Ht: {child.latestGrowth.heightCm ? `${child.latestGrowth.heightCm} cm` : '--'} • MUAC: {child.latestGrowth.muacCm ? `${child.latestGrowth.muacCm} cm` : '--'}
                          </p>
                          <span className="text-[10px] text-teal-600 block">
                            Logged at {child.latestGrowth.ageMonths}m
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No growth measured</span>
                      )}
                    </td>

                    {/* Nutritional Triage */}
                    <td className="px-4 py-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border inline-block ${child.nutritionBadge}`}>
                        {child.nutritionGrade}
                      </span>
                    </td>

                    {/* Immunization */}
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-800">
                            {child.administeredCount} / {child.uipSchedule.length}
                          </span>
                          {child.overdueCount > 0 ? (
                            <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                              {child.overdueCount} Overdue
                            </span>
                          ) : (
                            <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                              Up to Date
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedChildId(child.id);
                            setShowDetailModal(true);
                          }}
                          title="View Mamta Card & History"
                          className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            setSelectedChild(child);
                            setShowGrowthModal(true);
                          }}
                          title="Record Growth & MUAC"
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        >
                          <Scale className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            setSelectedChild(child);
                            setTargetVaccine(child.uipSchedule.find(v => v.status === 'overdue') || child.uipSchedule[0]);
                            setShowVaxModal(true);
                          }}
                          title="Administer Vaccine"
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <ShieldCheck className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <ChildRegisterModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onRegistered={loadData}
        currentUser={currentUser}
      />

      <GrowthMeasurementModal
        isOpen={showGrowthModal}
        onClose={() => {
          setShowGrowthModal(false);
          setSelectedChild(null);
        }}
        child={selectedChild}
        onGrowthRecorded={loadData}
        currentUser={currentUser}
      />

      <ImmunizationModal
        isOpen={showVaxModal}
        onClose={() => {
          setShowVaxModal(false);
          setSelectedChild(null);
          setTargetVaccine(null);
        }}
        child={selectedChild}
        targetVaccine={targetVaccine}
        onImmunized={loadData}
        currentUser={currentUser}
      />

      <ChildDetailModal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedChildId(null);
        }}
        childId={selectedChildId}
        onRecordUpdated={loadData}
        onOpenGrowthModal={(c) => {
          setSelectedChild(c);
          setShowGrowthModal(true);
        }}
        onOpenVaxModal={(c, vax) => {
          setSelectedChild(c);
          setTargetVaccine(vax);
          setShowVaxModal(true);
        }}
        currentUser={currentUser}
      />

    </div>
  );
}
