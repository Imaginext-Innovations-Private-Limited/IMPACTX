import React, { useState } from 'react';
import { useAuth, DEMO_USERS } from '../context/AuthContext';
import {
  HeartPulse,
  ShieldCheck,
  UserCheck,
  Stethoscope,
  Lock,
  ArrowRight,
  WifiOff,
  CheckCircle2,
  Cross
} from 'lucide-react';

export default function Login() {
  const { loginAsDemo, loginCustom } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState('asha');

  const handleCustomLogin = (e) => {
    e.preventDefault();
    if (username.trim()) {
      loginCustom(username, password, selectedRole);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl grid md:grid-cols-5 bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100">
        
        {/* Left Branding Panel (2 columns on md) */}
        <div className="md:col-span-2 bg-gradient-to-b from-teal-700 via-teal-800 to-emerald-900 p-8 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute -right-16 -top-16 w-56 h-56 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
          <div className="absolute -left-16 -bottom-16 w-56 h-56 rounded-full bg-teal-400/10 blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
                <Cross className="w-7 h-7 text-emerald-300 stroke-[2.5]" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">OFFLINE HEALTH</h1>
                <p className="text-xs text-teal-200">National Health Mission Ready</p>
              </div>
            </div>

            <div className="space-y-4 my-8">
              <h2 className="text-2xl font-bold leading-tight">
                Healthcare Access, Even Without Internet.
              </h2>
              <p className="text-xs text-teal-100/90 leading-relaxed">
                Empowering Community Health Workers, ASHA workers, ANMs, and rural medical officers with zero-latency, local-first clinical assistance.
              </p>
            </div>
          </div>

          <div className="space-y-3 pt-6 border-t border-white/10">
            <div className="flex items-center gap-2 text-xs text-teal-200 font-medium">
              <WifiOff className="w-4 h-4 text-emerald-300 flex-shrink-0" />
              <span>Full Offline IndexedDB Local Storage</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-teal-200 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-300 flex-shrink-0" />
              <span>Automatic Background Sync with Cloud</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-teal-200 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-300 flex-shrink-0" />
              <span>Role-based Clinical Audit Trail</span>
            </div>
          </div>
        </div>

        {/* Right Authentication Panel (3 columns on md) */}
        <div className="md:col-span-3 p-8 sm:p-10 flex flex-col justify-center bg-white">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-slate-900">Sign In to Workstation</h3>
            <p className="text-xs text-slate-500 mt-1">
              Select a quick demo role or sign in with your healthcare credentials.
            </p>
          </div>

          {/* Quick Demo Access Buttons */}
          <div className="mb-6">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 block">
              1-Click Demo Profiles (For Instant Evaluation)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {DEMO_USERS.map((user) => (
                <button
                  key={user.id}
                  onClick={() => loginAsDemo(user.role)}
                  className="p-3 text-left rounded-2xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 transition-all group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="w-7 h-7 rounded-lg bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs group-hover:bg-teal-600 group-hover:text-white transition-colors">
                      {user.avatar}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">
                      {user.role}
                    </span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-800 truncate">{user.name}</p>
                    <p className="text-[10px] text-slate-500 truncate">{user.village}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-slate-400 font-semibold">Or enter custom credentials</span>
            </div>
          </div>

          {/* Custom Login Form */}
          <form onSubmit={handleCustomLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Staff Name / Worker ID
              </label>
              <input
                type="text"
                placeholder="e.g. ASHA Sunita or Dr. Verma"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all placeholder:text-slate-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Assigned Role
                </label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all"
                >
                  <option value="asha">ASHA Worker</option>
                  <option value="doctor">Medical Officer</option>
                  <option value="admin">District Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Offline Passcode
                </label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all"
                  />
                  <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-teal-700/20 flex items-center justify-center gap-2 transition-all mt-2"
            >
              <span>Authenticate & Open Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="text-[11px] text-center text-slate-400 mt-5">
            Works 100% offline. Local credentials validated against device IndexedDB storage.
          </p>
        </div>
      </div>
    </div>
  );
}
